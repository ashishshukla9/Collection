import React from "react";
import { createHashRouter } from "react-router-dom";

import HOC from "./components/HOC";
import Login from "./components/Login";
import ForgotPassword from "./components/ForgotPassword/index"
import ForgotScrren from "./components/ForgotPassword/forgotScreen";
import Error404 from "./Pages/404";
import Region from "./Pages/Master/GeographyMaster/Region";
import DownloadPaymntRecipt from "./Pages/Cases/caseActivity.js/Payment/browsPaymentForDownload";
import CaseFeedbackUpload from "./Pages/CaseFeedbackUpload";
import LiveTrackingDetails from "./Pages/LiveTracking/LiveTrackingDetails";
// import Zone from "./Pages/Master/GeographyMaster/Zone";

const Dashboard = React.lazy(() => import("./Pages/Dashboard"));
const PullWise = React.lazy(() => import("./Pages/Dashboard/PullWise"))
const User = React.lazy(() => import("./Pages/User"));
const Lender = React.lazy(() => import("./Pages/Lender"));
const Agency = React.lazy(() => import("./Pages/Agency"));
const TrackingConfigure = React.lazy(() => import("./Pages/TrackingConfigure"));

const Role = React.lazy(() => import("./Pages/Role"));
const Cases = React.lazy(() => import("./Pages/Cases"));
const CasesProfile = React.lazy(() => import("./Pages/Cases/CaseProfile"));
const Requests = React.lazy(() => import("./Pages/Requests"));
const Agents = React.lazy(() => import("./Pages/Agents"));
const Campaign = React.lazy(() => import("./Pages/Campaign"));
const Audit = React.lazy(() => import("./Pages/Audit"));
const Reports = React.lazy(() => import("./Pages/Reports"));
const Repossession = React.lazy(() => import("./Pages/Repossesions"));
const UserType = React.lazy(() => import("./Pages/Master/LookupMaster/AddUserType"));
const Profiles = React.lazy(() => import("./Pages/Profile"));
const Country = React.lazy(() => import("./Pages/Master/GeographyMaster/Country"));
const State = React.lazy(() => import("./Pages/Master/GeographyMaster/State"));
const City = React.lazy(() => import("./Pages/Master/GeographyMaster/City"));
const Zone = React.lazy(() => import("./Pages/Master/GeographyMaster/Zone"));
const Pincode = React.lazy(() => import("./Pages/Master/GeographyMaster/Pincode"));
const BankMaster = React.lazy(() => import("./Pages/Master/Bank/BankMaster"));
const BankBranchMaster = React.lazy(() => import("./Pages/Master/Bank/BankBranchMaster"));
const ProfolioMaster = React.lazy(() => import("./Pages/Master/PortfolioMaster"));
const ProductMaster = React.lazy(() => import("./Pages/Master/ProductMaster"));
const AgencyType = React.lazy(() => import("./Pages/Master/LookupMaster/AgencyType"));
const NatureOfService = React.lazy(() => import("./Pages/Master/LookupMaster/NatureOfService"));
const RejectReasonMaster = React.lazy(() => import("./Pages/Master/LookupMaster/RejectReasonMaster"));
const DisputeReasonMaster = React.lazy(() => import("./Pages/Master/LookupMaster/DisputeReasonMaster"));
const UserDesignation = React.lazy(() => import("./Pages/Master/LookupMaster/UserDesignation"))
const ExceptionType = React.lazy(() => import("./Pages/Master/LookupMaster/ExceptionType"));
const RequestType = React.lazy(() => import("./Pages/Master/LookupMaster/RequestType"));
const OutcomeType = React.lazy(() => import("./Pages/Master/LookupMaster/Outcome"))
const CaseUpload = React.lazy(() => import("./Pages/Cases/CaseUpload"));
const GridType = React.lazy(() => import("./Pages/Master/LookupMaster/GridType"));
const AddressType = React.lazy(() => import("./Pages/Master/LookupMaster/AddressType"));
const Document = React.lazy(() => import('./Pages/Master/LookupMaster/Documents'))
const CampaignManagemnt = React.lazy(() => import("./Pages/CampaignManagment/Index"))
const LiveTracking = React.lazy(() => import("./Pages/LiveTracking/Index.jsx"))


// const IncentiveAndPayout = React.lazy(() => import("./Pages/IncentiveAndPayout/IncentiveConfiguration"))
const IncentiveConfiguration = React.lazy(() => import("./Pages/IncentivesAndPayout/Configuration"))
const Reconciliation = React.lazy(() => import('./Pages/Reconciliation'))
const Calculation = React.lazy(() => import('./Pages/IncentivesAndPayout/Calculation'))
const SmtpSettings = React.lazy(() => import("./Pages/Sequrity/SMTP/index"));
const Lock_Policy = React.lazy(() => import("./Pages/Sequrity/Lock/index"));
const Password_Policy = React.lazy(() => import("./Pages/Sequrity/Password/Index"));
const SmsSettings = React.lazy(() => import("./Pages/Sequrity/SMS/Index"));
const Log = React.lazy(() => import("./Pages/Sequrity/Log/index"));
const Audit_settings = React.lazy(() => import("./Pages/Sequrity/Audit/Index"));
const Upload_Settings = React.lazy(() => import("./Pages/Sequrity/Upload/Index"));
const BulkDealocation = React.lazy(() => import("./Pages/DealocationBulkUpload/index"))
const AgencyFeedBackUpload = React.lazy(() => import('./Pages/AgencyFeedbackUpload/index'))

const router = createHashRouter(
  [
    {
      path: "/",
      element: <Login />,
      errorElement: <Error404 />,
    },
    {
      path: "/forgot_password",
      element: <ForgotPassword />,
      errorElement: <Error404 />,
    },
    {
      path: "/reset_password",
      element: <ForgotScrren />,
      errorElement: <Error404 />,
    },
    {
      path: `/download_Payment_recipt/:id`,
      element: <DownloadPaymntRecipt />,
      errorElement: <Error404 />
    },
    {
      element: <HOC />,
      errorElement: <Error404 />,
      children: [
        {
          path: "/dashboard",
          element: <Dashboard />,
        },
        {
          path: "/poolwise",
          element: <PullWise />,
        },
        {
          path: "/cases",
          element: <Cases />,
        },
        {
          path: "/case_profile/:tab/:module/:lanId",
          element: <CasesProfile />,
        },
        {
          path: '/agencyofflinefeedback',
          element: <AgencyFeedBackUpload access={"agencyfeedbackupload"} />

        },
        {
          path: "/requests",
          element: <Requests />,
        },
        {
          path: "/agents",
          element: <Agents />,
        },
        {
          path: "/campaign",
          element: <Campaign />,
        },
        {
          path: "/live_Tracking",
          element: <LiveTracking />,
        },
        {
          path: "/live_tracking/:userName",
          element: <LiveTrackingDetails />,
        },
        {
          path: "/audit",
          element: <Audit access={"audit_audit"} />,
        },
        {
          path: "/reports",
          element: <Reports />,
        },
        {
          path: "/repo",
          element: <Repossession />,
        },
        {
          path: "/lenders",
          element: <Lender access={"administrator_lender"} />,
        },
        {
          path: "/role",
          element: <Role access={"administrator_role"} />,
        },
        {
          path: "/agencies",
          element: <Agency access={"administrator_agency"} />,
        },
        {
          path: "/trackingConfigure",
          element: <TrackingConfigure access={"administrator_tracking_Configure"} />,
        },
        {
          path: "/users",
          element: <User access={"administrator_user"} />,
        },
        {
          path: "/profiles",
          element: <Profiles access={"administrator_profile"} />,
        },
        {
          path: "/country",
          element: (
            <Country access={"administrator_geographymaster"} />
          ),
        },
        {
          path: "/zone",
          element: (
            <Zone access={"administrator_geographymaster"} />
          ),
        },
        {
          path: "/state",
          element: (
            <State access={"administrator_geographymaster"} />
          ),
        },
        {
          path: "/region",
          element: (
            <Region access={"administrator_geographymaster"} />
          ),
        },
        {
          path: "/city",
          element: (
            <City access={"administrator_geographymaster"} />
          ),
        },
        {
          path: "/pincode",
          element: (
            <Pincode access={"administrator_geographymaster"} />
          ),
        },
        {
          path: "/bank",
          element: (
            <BankMaster access={"administrator_bankbranchmaster"} />
          ),
        },
        {
          path: "/bank_branch",
          element: (
            <BankBranchMaster access={"administrator_bankbranchmaster"} />
          ),
        },
        {
          path: "/portfolio_master",
          element: (
            <ProfolioMaster access={"administrator_portfoliomaster"} />
          ),
        },
        {
          path: "/product_master",
          element: (
            <ProductMaster access={"administrator_productmaster"} />
          ),
        },
        {
          path: "/types",
          element: (
            <UserType access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/agency_types",
          element: (
            <AgencyType access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/nature_of_service",
          element: (
            <NatureOfService access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/rejects",
          element: (
            <RejectReasonMaster access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/disputes",
          element: (
            <DisputeReasonMaster access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/exception_type",
          element: (
            <ExceptionType access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/user_designation",
          element: (
            <UserDesignation access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/request_type",
          element: (
            <RequestType access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/address_type",
          element: (
            <AddressType access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/documents",
          element: (
            <Document access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/gridtype",
          element: (
            <GridType access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/outcome",
          element: (
            <OutcomeType access={"administrator_lookupmaster"} />
          ),
        },
        {
          path: "/case_upload",
          element: <CaseUpload access={"caseupload_caseupload"} />
        },
        // {
        //   path: "/case_upload",
        //   element: <CaseUpload access={"caseupload_caseupload"} />
        // },
        {
          path: '/bulk_deallocation',
          element: <BulkDealocation access={"bulkdeallocation"} />
        },
        {
          path: "/case_feedback_upload",
          element: <CaseFeedbackUpload access={"caseFeedback_upload"} />
        },
        {
          path: "/campaign_management",
          element: <CampaignManagemnt access={"campaignmanagement"} />
        },
        {
          path: "/payoutconfiguration",
          element: <IncentiveConfiguration />
        },
        {
          path: "/payoutreconciliation",
          element: <Reconciliation />
        },
        {
          path: "/payoutcalculation",
          element: <Calculation />
        },
        {
          path: "/smtp_settings",
          element: <SmtpSettings access={"securitypolicies_securitypolicies"} />,
        },
        {
          path: "/lockout_policy",
          element: <Lock_Policy access={"securitypolicies_securitypolicies"} />,
        },
        {
          path: "/password_policy",
          element: <Password_Policy access={"securitypolicies_securitypolicies"} />,
        },
        {
          path: "/sms_settings",
          element: <SmsSettings access={"securitypolicies_securitypolicies"} />,
        },
        {
          path: "/log_settings",
          element: <Log access={"securitypolicies_securitypolicies"} />,
        },
        {
          path: "/audit_settings",
          element: <Audit_settings access={"securitypolicies_securitypolicies"} />,
        },
        {
          path: "/upload_settings",
          element: <Upload_Settings access={"securitypolicies_securitypolicies"} />,
        }
      ]
    },
    {
      path: '*',
      element: <Error404 />
    }
  ]
  // { basename: "/collection" }
  // { basename: "" }
);

export default router;
