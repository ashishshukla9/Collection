import * as yup from "yup";

export const ContactCenterCallSummarySchema = {
    callDuration: {
        hh: '',
        mm: '',
        time: ''
    },
    callStatus:'',
    callOutcome:'',
    followUpCall: ''
}


export const contactCenterCallSummaryValidation = yup.object({
    callStatus: yup.object().required("Required"),

    callOutcome: yup.object().required("Required")
})