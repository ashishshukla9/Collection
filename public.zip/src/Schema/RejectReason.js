import * as yup from "yup";

export const RejectReasonSchema = {
  isActive: "Y",
  code: "",
  description: "",
};

export const rejectReasonValidation = yup.object({
  code: yup.string().max(8, "Too Long").required("Required"),
  description: yup.string().max(20, "Too Long!").required("Required"),
});
