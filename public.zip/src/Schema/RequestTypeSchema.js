import * as yup from "yup";

export const requestTypeSchema = {
  code: "",
  description: "",
  isActive: "Y",
};

export const validationSchema = yup.object({
  code: yup.string().max(4, "Too Long!").required("Required"),
  description: yup.string().max(25, "Too Long!").required("Required"),
});

export const validationSchema1 = yup.object({
  code: yup.string().max(10, "Too Long!").required("Required"),
  description: yup.string().max(25, "Too Long!").required("Required"),
});
