import * as yup from "yup";

export const CountrySchema = {
  countryCode: "",
  countryName: "",
  active: "Y",
};

export const CountryValidationSchema = yup.object({
  countryCode: yup.string().max(4, "Too Long!").required("Required"),

  countryName: yup.string().max(50, "Too Long!").required("Required"),
});

export const StateSchema = {
  stateCode: "",
  stateName: "",
  region: "",
  active: "Y",
};

export const StateValidationSchema = yup.object({
  stateCode: yup.string().max(4, "Too Long!").required("Required"),
  stateName: yup.string().max(50, "Too Long!").required("Required"),
  region: yup.string().required("Required"),
});

export const CitySchema = {
  cityCode: "",
  cityName: "",
  // stateCode: "",
  state: "",
  region: "",
  // countryName: "",
  active: "Y",
};

export const CityValidationSchema = yup.object({
  cityCode: yup.string().max(4, "Too Long!").required("Required"),
  cityName: yup.string().max(50, "Too Long!").required("Required"),
  region: yup.string().required("Required"),
  // stateCode: yup.string().required("Required"),
  // countryName: yup.string().required("Required"),
  state: yup.string().required("Required")

});

export const PincodeSchema = {
  // code: "",
  pincode: "",
  cityCode: "",
  areaName: "",
  active: "Y",
};

export const PincodeValidationSchema = yup.object({
  // code: yup
  //   .string()
  //   .max(6, "Too Long!")
  //   .matches(/^\d+$/, "Invalid")
  //   .required("Required"),
  pincode: yup
    .number()
    // .max(6, "Too Long!")
    // .matches(/^\d+$/, "Invalid")
    .required("Required"),
  // cityCode: yup.string().max(4, "Too Long!").required("Required"),
  // cityCode: yup.object().required("Required"),
  areaName: yup.string().max(50, "Too Long!").required("Required"),
});

// abhay
export const ZoneSchema = {
  zoneCode: "",
  zoneName: "",
  country: "",
  active: "Y",
};

export const ZoneValidationSchema = yup.object({
  zoneCode: yup.string().max(4, "Too Long!").required("Required"),
  zoneName: yup.string().max(50, "Too Long!").required("Required"),
  country: yup.string().required("Required"),
});

export const RegionSchema = {
  regionCode: "",
  regionName: "",
  zone: "",
  active: "Y",
};

export const RegionValidationSchema = yup.object({
  regionCode: yup.string().max(4, "Too Long!").required("Required"),
  regionName: yup.string().max(50, "Too Long!").required("Required"),
  zone: yup.string().max(50, "Too Long!").required("Required"),
});
