import * as yup from "yup";

export const BankBranchMasterSchema = {
  bankBranchCode: "",
  bankBranchName: "",
  bankCode: "",
  addressLine1: "",
  addressLine2: "",
  addressLine3: "",
  pincode: "",
  cityCode: "",
  stateCode: "",
  contactNo: "",
  micrCode: "",
  ifscCode: "",
  active: "Y",
};
export const IFSC_Validation = /^[A-Za-z]{4}0[A-Za-z0-9]{6}$/;

export const validationSchema = yup.object({
  bankBranchCode: yup.string().max(8, "Too Long!").required("Required"),
  bankBranchName: yup.string().max(35, "Too Long!").required("Required"),
  bankCode: yup.string().required("Required"),

  addressLine1: yup.string().max(50, "Too Long!").required("Required"),
  addressLine2: yup.string().max(50, "Too Long!"),
  addressLine3: yup.string().max(50, "Too Long!"),

  pincode: yup.string().required("Required"),
  cityCode: yup.string(),
  stateCode: yup.string(),

  contactNo: yup
    .string()
    // .min(10, "Invalid Contact")
    // .max(10, "Invalid Contact")
    .matches(/^[0-9]{10}$/, 'Mobile number is not valid')
    .required("Required"),
  micrCode: yup.string().max(10, "Invalid MICR").required("Required"),
  ifscCode: yup
    .string()
    .matches(IFSC_Validation, "Invalid IFSC")
    .required("Required"),
});
