import * as yup from "yup";

export const ProductMasterSchema = {
  isActive: "Y",
  productCode: "",
  portfolioCode: "",
  productDescription: "",
};

export const productMasterValidation = yup.object({
  productCode: yup.string().max(8, "Too Long").required("Required"),
  productDescription: yup.string().max(60, "Too Long!").required("Required"),
  portfolioCode: yup.string().max(8, "Too Long!").required("Required"),
});
