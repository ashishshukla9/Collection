import * as yup from "yup";

export const exceptionSchema = {
  request: "",
  remark: "",
  evidance: "",
};

export const exceptionValidationSchema = yup.object({
  request: yup.string().required("Required"),
  remark: yup.string().max(250, "Too Long.").required("Required"),
  evidance: yup.mixed().required("Required"),
});

export const updateExceptionValidationSchema = yup.object({
  request: yup.string().required("Required"),
  remark: yup.string().max(250, "Too Long.").required("Required"),
});
