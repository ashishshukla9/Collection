import * as yup from "yup";

export const disputeSchema = {
  amount: "",
  disputeType: "",
  disputeReason: "",
  remark: "",
  evidance: "",
};

export const disputeValidationSchema = yup.object({
  amount: yup.number().required("Required"),
  disputeType: yup.string().required("Required"),
  disputeReason: yup.string().required("Required"),
  remark: yup.string().max(250, "Too Long.").required("Required"),
  evidance: yup.mixed().required("Required"),
});

export const disputeUpdateValidationSchema = yup.object({
  amount: yup.number().required("Required"),
  disputeType: yup.string().required("Required"),
  disputeReason: yup.string().required("Required"),
  remark: yup.string().max(250, "Too Long.").required("Required"),
});
