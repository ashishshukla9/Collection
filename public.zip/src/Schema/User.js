import * as yup from "yup";

export const UserSchema = {
  firstName: "",
  lastName: "",
  email: "",
  mobileNo: "",
  role: [],
  profile: [],
  userType: "",
  organisationName: "Turboard",
  designation: "",
  reportingManager: "",
  branch: "",

  zone: "",
  state: "",
  region:"",
  city: "",
  pincode: "",
  areaname: "",
  portfolio: "",
  product: "",
  maxTicketSize: 10,
  minTicketSize: 0,
  maxBucket: 10,
  minBucket: 0,
  deal: "1",

  isCertificate: "N",
  ufile: "",
  // userName: "",
  status: "Y",
  password: "",
  confirmPassword: "",
  sendWelcome: "Y",
  activiyType:''
};

// const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}$/;
// min 5 characters, 1 upper case letter, 1 lower case letter, 1 numeric digit.

export const validationSchema = yup.object({
  firstName: yup
    .string()
    .max(50, "Too Long!")
    .required("Required"),
  lastName: yup
    .string()
    .max(50, "Too Long!")
    .required("Required"),
  email: yup
    .string("Enter your email")
    .email("Enter a valid email")
    .required("Email is required"),
  password: yup
    .string("Enter your password")
    .min(8, "Password should be of minimum 8 characters length")
    .required("Password is required"),
  mobileNo: yup
    .string()
    .matches(/^[0-9]{10}$/, "Invalid mobile number")
    .required("Mobile number is required"),
  // ufile: yup.mixed().test("fileTest", "Required", function () {
  //   let { isCertificate } = this.parent;

  //   return isCertificate === "N" ? true : false;
  // }),
  ufile: yup
    .mixed()
    .when('isCertificate',{
      is:(isCertificate)=> isCertificate === "Y",
      then:()=> yup.mixed().required('Required')
    }),
  designation: yup.string().required('Required'),
  loginType: yup.mixed().required('Required'),
  // file: yup
  //   .mixed()
  //   .required("A file is required")
  //   .test("fileType", "Invalid file format", (value) => {
  //     if (value) {
  //       const supportedFormats = ["image/jpeg", "image/png", "image/gif"];
  //       return supportedFormats.includes(value.type);
  //     }
  //     return false;
  //   })
  //   .test("fileSize", "File size is too large", (value) => {
  //     if (value) {
  //       const maxSize = 5 * 1024 * 1024; // 5 MB
  //       return value.size <= maxSize;
  //     }
  //     return false;
  //   }),
  // zone: yup.array().test("arrayLen", "Required", (value) => {
  //   console.log('value',value)
  //   return value?.length > 0;
  // }),
  zone: yup.array().when('userType',{
    is: (userType) => userType === "U101",
    then: ()=> yup.array().min(1,'Required')
  }),
  state:  yup.array().when('userType',{
    is: (userType) => userType === "U101",
    then: ()=> yup.array().min(1,'Required')
  }),
  region:  yup.array().when('userType',{
    is: (userType) => userType === "U101",
    then: ()=> yup.array().min(1,'Required')
  }),
  city: yup.array().when('userType',{
    is: (userType) => userType === "U101",
    then: ()=> yup.array().min(1,'Required')
  }),
  pincode: yup.array().when('userType',{
    is: (userType) => userType === "U101",
    then: ()=> yup.array().min(1,'Required')
  }),
  portfolio: yup.array().when('userType',{
    is: (userType) => userType === "U101",
    then: ()=> yup.array().min(1,'Required')
  }),
  product: yup.array().when('userType',{
    is: (userType) => userType === "U101",
    then: ()=> yup.array().min(1,'Required')
  }),
  agency: yup.mixed().when("userType",{
    is: (userType) => userType === 'Agency',
    then: () => yup.mixed().required('Required')
  }),
  lender: yup.object().when('userType',{
    is:(userType) => userType === 'Lender',
    then: () => yup.object().required('Required')
  }),
  // ticketSize: "",
  // bucket: [0, 10],
  // deal: "",
  organisationName: yup.object().when('userType',{
    is:(userType) => userType === "U101",
    then: () => yup.object().required('Required')
  }),
  userType: yup.string().required("Required"),
  reportingManager: yup.string().required("Required"),
  agencyBranch: yup.mixed().when(['userType','agency'],{
    is: (userType,agency) => ((userType === "U101" && agency?.length) || (userType !== 'Internal')),
    then: () => yup.mixed().required("Required")
  }),
  profile: yup.array().test("customProfileTest", "Required", (value) => {
    return value?.length > 0;
  }),
  role: yup.array().test("customRoleTest", "Required", (value) => {
    return value?.length > 0;
  }),
  // userName: yup.string().required("Required"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("password"), null], "Passwords must match")
    .required("Confirm Password cannot be empty"),

  activityType: yup.object().required("Required"),
  minTicketSize: yup.string().when('userType',{
    is:(userType) => userType === "U101",
    then: () => yup.string().required('Required').test('minTicket','Min Ticket Size value is less than or equal to Max Ticket Size value',(value,context)=>{
      return parseInt(value) <= parseInt(context?.parent?.maxTicketSize)
    })
  }),
  maxTicketSize: yup.string().when('userType',{
    is:(userType) => userType === "U101",
    then: () => yup.string().required('Required').test('maxTicket','Max Ticket Size value is greater than or equal to Min Ticket Size value',(value,context)=>{
      return parseInt(value) >= parseInt(context?.parent?.minTicketSize)
    })
  }),
  minBucket: yup.string().when('userType',{
    is:(userType) => userType === "U101",
    then: () => yup.string().required('Required').test('minBucket','Min Bucket Size value is less than or equal to Max Bucket Size value',(value,context)=>{
      return parseInt(value) <= parseInt(context?.parent?.maxBucket)
    })
  }),
  maxBucket: yup.string().when('userType',{
    is:(userType) => userType === "U101",
    then: () => yup.string().required('Required').test('maxBucket','Max Bucket Size value is greater than or equal to Min Bucket Size value',(value,context)=>{
      return parseInt(value) >= parseInt(context?.parent?.minBucket)
    })
  })
});

export const updateValidationSchema = yup.object({
  firstName: yup
    .string()
    .min(2, "Too Short!")
    .max(50, "Too Long!")
    .required("Required"),
  lastName: yup
    .string()
    .min(2, "Too Short!")
    .max(50, "Too Long!")
    .required("Required"),
  email: yup
    .string("Enter your email")
    .email("Enter a valid email")
    .required("Email is required"),
  password: yup
    .string("Enter your password")
    .min(8, "Password should be of minimum 8 characters length")
    .required("Password is required"),
  mobileNo: yup
    .string()
    .matches(/^[0-9]{10}$/, "Invalid mobile number")
    .required("Mobile number is required"),

  organisationName: yup.mixed().required("Required"),
  // designation: yup.mixed().required("Required"),
  userType: yup.mixed().required("Required"),
  reportingManager: yup.mixed().required("Required"),
  state: yup.mixed().required("Required"),
  city: yup.mixed().required("Required"),
  branch: yup.mixed().required("Required"),
  profile: yup.array().test("customProfileTest", "Required", (value) => {
    return value?.length > 0;
  }),
  role: yup.array().test("customRoleTest", "Required", (value) => {
    return value?.length > 0;
  }),
  userName: yup.string().required("Required"),
  activityType: yup.object().required("Required"),
  loginType: yup.object().required("Required")
});
