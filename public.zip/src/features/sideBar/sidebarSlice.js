import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  sidebarShow: true,
  sidebarUnfoldable: false,
};

const sidebarSlice = createSlice({
  name: "sidebar",
  initialState,
  reducers: {
    set: (state, action) => {
      state.sidebarShow = action.payload;
    },
    foldable: (state, action) => {
      state.sidebarUnfoldable = action.payload;
    },
  },
});

export const { set, foldable } = sidebarSlice.actions;

export default sidebarSlice.reducer;
