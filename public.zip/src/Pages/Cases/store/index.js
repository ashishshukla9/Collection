import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { setLoader } from "../../../reducer/globalReducer";
import { Cookies } from "react-cookie";
var cookies = new Cookies();
const initialState = {
  lists: [],
  allData: [],
  caseProfile: null,
  roleId: "",
  activityHistory: [],
  statCardHistory: null,
  communicationHistory: [],
  filterPayload: {},
  agencySelected: "",
  totalCount: 0,
  allTotalCount: 0,
  newTotalCount: 0,
  allocatedTotalCount: 0,
  InprogressTotalCount: 0,
  caseCloaseTotalCount: 0,
  caseCloaseRejectedTotalCount: 0,
  caseCloaseApprovedTotalCount: 0,
  mycaseTotalCount: 0,
  unalloactedPendingTotalCount: 0,
  unalloactedApproveTotalCount: 0,
  unalloactedRejectTotalCount: 0,
  callHistory: [],
  filterpayload: [],
  currentModule: "",
  oldvalue: "",
  isFilter: false,
  isSearch: false,
  reset: false,
};
var checkrole = "";
const dummayPayload = {
  portfolio: null,
  product: null,
  borrowerName: null,
  zone: null,
  region: null,
  state: null,
  location: null,
  pincode: null,
  bucket: null,
  dpd: null,
  pos: null,
  tos: null,
  lenderName: null,
  lenderId: null,
  paymentStatus: null,
  callStatus: null,
  allocatedUser: null,
};
const caseStatus = (allCases, loanAccountNumber) => {
  return allCases?.allNewCases?.includes(loanAccountNumber)
    ? "New"
    : allCases?.allAllocatedCases?.includes(loanAccountNumber) ||
      allCases?.allMyCases?.includes(loanAccountNumber)
    ? "Allocated"
    : "";
};
export const getAllCases = createAsyncThunk(
  "cases/getAllCases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url =
        data?.currentModule === "Field"
          ? `/findAllSuccessData${data?.currentModule}/${data?.currentPage}/${data?.numberOfDataPerPage}`
          : `/findAllSuccessData/${data?.currentPage}/${data?.numberOfDataPerPage}`;
      const res = await axios.get(url);
      dispatch(setLoader(false));
      const filteredData = res.data.response.filter((caseItem) => {
        const keepItem = caseItem.caseStatus !== "Deallocated";
        console.log(
          `Case ID: ${caseItem.id}, Status: ${caseItem.caseStatus}, Keep: ${keepItem}`
        );
        return keepItem;
      });
      return {
        data: filteredData,
        allTotalCount: res?.data?.totalApplicationCount,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getLegaPending = createAsyncThunk(
  "cases/getLegaPending",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = `getLegalByTab/${data?.userId}/${data?.currentTab}?page=${data?.currentPage}&size=${data?.numberOfDataPerPage}`;
      const res = await axios.get(url);
      dispatch(setLoader(false));
      return {
        data: res?.data?.response,
        totalCount: res?.data?.totalApplicationCount,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getLenderAllCases = createAsyncThunk(
  "getLenderAllCases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = `/getLenderCases/${data?.userId}/${data?.dataOption}/${data?.currentPage}/${data?.numberOfDataPerPage}`;
      const res = await axios.post(url, dummayPayload);
      dispatch(setLoader(false));
      return {
        data: res?.data?.response,
        allTotalCount: res?.data?.totalApplicationCount,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getLenderCaseCloase = createAsyncThunk(
  "getLenderCaseCloase",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = `/getLenderCases/${data?.userId}/${data?.dataOption}/${data?.currentPage}/${data?.numberOfDataPerPage}`;
      const res = await axios.post(url, dummayPayload);
      dispatch(setLoader(false));
      return {
        data: res?.data?.response,
        caseCloaseTotalCount: res?.data?.totalApplicationCount,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getLenderInprogressCases = createAsyncThunk(
  "getLenderInprogressCases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = `/getLenderCases/${data?.userId}/${data?.dataOption}/${data?.currentPage}/${data?.numberOfDataPerPage}`;
      const res = await axios.post(url, dummayPayload);
      dispatch(setLoader(false));
      return {
        data: res?.data?.response,
        InprogressTotalCount: res?.data?.totalApplicationCount,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getNewMISCases = createAsyncThunk(
  "cases/getNewMISCases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url =
        data?.currentModule === "Field"
          ? `/getAllNewSuccessData${data?.currentModule}/${data?.currentPage}/${data?.numberOfDataPerPage}`
          : `/getAllNewSuccessData/${data?.currentPage}/${data?.numberOfDataPerPage}`;
      const res = await axios.get(url);
      dispatch(setLoader(false));
      return {
        data: res?.data?.response,
        newTotalCount: res?.data?.totalApplicationCount,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getAllocatedMISCases = createAsyncThunk(
  "cases/getAllocatedMISCases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url =
        data?.currentModule === "Field"
          ? `/getAllocatedSuccessData${data?.currentModule}/${data?.currentPage}/${data?.numberOfDataPerPage}`
          : `/getAllocatedSuccessData/${data?.currentPage}/${data?.numberOfDataPerPage}`;
      const res = await axios.get(url);
      dispatch(setLoader(false));
      return {
        data: res?.data?.response,
        allocatedTotalCount: res?.data?.totalApplicationCount,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCases = createAsyncThunk(
  "cases/unallocatedCases",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(params?.activityType)
        ? `/getCaseAllocationByUseridForUnAllocatedCasesField`
        : `/getCaseAllocationByUseridForUnAllocatedCases`;
      const res = await axios.get(
        `${url}/${params?.userId}/${params?.currentPage}/${params?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const res1 = res?.data?.response;
        const allLenId = res1?.map((a) => a?.allLan);
        const allNewCases = res1
          ?.filter((a) => a?.newCase === "Y")
          ?.map((a) => a?.allLan);
        const allAllocatedCases = res1
          ?.filter((a) => a?.allocated === "Y")
          ?.map((a) => a?.allLan);
        const allMyCases = res1
          ?.filter((a) => a?.myCase === "Y")
          ?.map((a) => a?.allLan);
        const allCases = { allNewCases, allAllocatedCases, allMyCases };
        const userId = {};
        const allocatedUserId = {};
        const fieldVisit = {};
        res1?.map((a) => {
          Object.assign(allocatedUserId, {
            [a?.allLan]: a?.allocatedUser,
            [`fieldPickUp${a?.allLan}`]: a?.fieldPickUp,
          });
          Object.assign(fieldVisit, { [a?.allLan]: a?.fieldvisit });
          Object.assign(userId, { [a?.allLan]: a?.userId });
        });
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${params?.userId}`,
          allLenId
        );
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus:
            userId[data?.loanAccountNumber] === params?.userId
              ? caseStatus(allCases, data?.loanAccountNumber)
              : "Allocated",
          fieldPickUp:
            params?.userType === "U103"
              ? allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`]
              : fieldVisit?.[`${data?.loanAccountNumber}`] === "Y" &&
                allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`] !==
                  "Y"
              ? "P"
              : data?.fieldPickUp,
        }));
        return {
          data: finalData,
          roleId: res?.data?.response[0]?.roleId,
          allTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
      console.log(error);
    }
  }
);
export const getNewCases = createAsyncThunk(
  "cases/getNewCases",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    return axios
      .get("/getAllNewSuccessData")
      .then(({ data }) => {
        dispatch(setLoader(false));
        return data.data;
      })
      .catch((err) => {
        dispatch(setLoader(false));
      });
  }
);
export const getCaseProfile = createAsyncThunk(
  "cases/getProfile",
  async (lanId) => {
    return axios.get(`/${lanId}`);
  }
);
export const getCaseByLanId = createAsyncThunk(
  "cases/getCaseByLanId",
  async (lanId) => {
    return axios
      .get(`/getSuccessDataByLoanNumber/${lanId}`)
      .then(({ data }) => data.data);
  }
);
export const getNewCasesForOtherRole = createAsyncThunk(
  "cases/getNewCasesFOrOtherRole",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(params?.activityType)
        ? `/getNewCaseAllocationFieldByUserid`
        : `/getNewCaseAllocationByUserid`;
      const res = await axios.get(
        `${url}/${params?.userId}/${params?.currentPage}/${params?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allNewCases = res?.data?.response
          ?.filter((a) => a?.newCase === "Y")
          ?.map((a) => a?.allLan);
        const allocatedUserId = {};
        const fieldVisit = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, {
            [a?.allLan]: a?.allocatedUser,
            [`fieldPickUp${a?.allLan}`]: a?.fieldPickUp,
          });
          Object.assign(fieldVisit, { [a?.allLan]: a?.fieldvisit });
        });
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${params?.userId}`,
          allLenId
        );
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: allNewCases?.includes(data?.loanAccountNumber)
            ? "New"
            : "",
          fieldPickUp:
            params?.userType === "U103"
              ? allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`]
              : fieldVisit?.[`${data?.loanAccountNumber}`] === "Y" &&
                allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`] !==
                  "Y"
              ? "P"
              : data?.fieldPickUp,
        }));
        return {
          data: finalData,
          newTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getAllocatedCasesForOtherRole = createAsyncThunk(
  "cases/getAllocatedCasesFOrOtherRole",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(params?.activityType)
        ? "/getAllocatedCaseAllocationFieldByUserid"
        : "/getAllocatedCaseAllocationByUserid";
      const res = await axios.get(
        `${url}/${params?.userId}/${params?.currentPage}/${params?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allAllocatedCases = res?.data?.response
          ?.filter((a) => a?.allocated === "Y")
          ?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        const fieldVisit = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, {
            [a?.allLan]: a?.allocatedUser,
            [`fieldPickUp${a?.allLan}`]: a?.fieldPickUp,
          });
          Object.assign(fieldVisit, { [a?.allLan]: a?.fieldvisit });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${params?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus:
            userId === params?.userId
              ? allAllocatedCases?.includes(data?.loanAccountNumber)
                ? "Allocated"
                : ""
              : "Allocated",
          fieldPickUp:
            params?.userType === "U103"
              ? allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`]
              : fieldVisit?.[`${data?.loanAccountNumber}`] === "Y" &&
                allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`] !==
                  "Y"
              ? "P"
              : data?.fieldPickUp,
        }));
        return {
          data: finalData,
          allocatedTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getMyCasesForOtherRole = createAsyncThunk(
  "cases/getMyCasesForOtherRole",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(params?.activityType)
        ? "/getMyCaseAllocationFieldByUserid"
        : "/getMyCaseAllocationByUserid";
      const res = await axios.get(
        `${url}/${params?.userId}/${params?.currentPage}/${params?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allMyCases = res?.data?.response
          ?.filter((a) => a?.myCase === "Y")
          ?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        const fieldVisit = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, {
            [a?.allLan]: a?.allocatedUser,
            [`fieldPickUp${a?.allLan}`]: a?.fieldPickUp,
          });
          Object.assign(fieldVisit, { [a?.allLan]: a?.fieldvisit });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${params?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus:
            userId === params?.userId
              ? allMyCases?.includes(data?.loanAccountNumber)
                ? "Allocated"
                : ""
              : "Allocated",
          fieldPickUp:
            params?.userType === "U103"
              ? allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`]
              : fieldVisit?.[`${data?.loanAccountNumber}`] === "Y" &&
                allocatedUserId?.[`fieldPickUp${data?.loanAccountNumber}`] !==
                  "Y"
              ? "P"
              : data?.fieldPickUp,
        }));
        return {
          data: finalData,
          mycaseTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getInProgressCases = createAsyncThunk(
  "cases/getInProgressCases",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(params?.activityType)
        ? "/getMyInProcessByUseridField"
        : "/getMyInProcessByUserid";
      const res = await axios.get(
        `${url}/${params?.userId}/${params?.currentPage}/${params?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allInProgressCases = res?.data?.response
          ?.filter((a) => a?.inProcess === "Y")
          ?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${params?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus:
            userId === params?.userId
              ? allInProgressCases?.includes(data?.loanAccountNumber)
                ? "In Progress"
                : ""
              : "In Progress",
        }));
        return {
          data: finalData,
          InprogressTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const updateInProgressCase = createAsyncThunk(
  "cases/updateInprogressCase",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url =
        "CA" === data?.role ||
        ("FA" === data?.role && data?.activityType === "Calling")
          ? "updateMyCaseForInProcessForCA"
          : ("FA" === data?.role &&
              (data?.activityType === "Field" ||
                data?.activityType === "Both")) ||
            "DRA" === data?.role
          ? "updateMyCaseForInProcessForDRA"
          : data?.activityType === "Field" || data?.currentTab == "Field"
          ? "updateMyCaseForInProcessField"
          : "updateMyCaseForInProcess";
      const res = await axios.put(`/${url}/${data?.userId}/${data?.lanId}`);
      dispatch(setLoader(false));
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const CACases = createAsyncThunk(
  "cases/CACases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `/getCACaseAllocationByUserid/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
          mycaseTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getCAInProgressCases = createAsyncThunk(
  "cases/getCAInProgressCases",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `/getMyInProcessByUseridForCA/${params?.userId}/${params?.currentPage}/${params?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allInProgressCases = res?.data?.response
          ?.filter((a) => a?.inProcess === "Y")
          ?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${params?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus:
            userId === params?.userId
              ? allInProgressCases?.includes(data?.loanAccountNumber)
                ? "In Progress"
                : ""
              : "In Progress",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
          InprogressTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getDRACases = createAsyncThunk(
  "cases/getDRACases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `/getDRACaseAllocationByUserid/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "",
        }));
        checkrole = data?.roleId;
        return {
          data: finalData,
          allTotalCount: res?.data?.totalApplicationCount,
          mycaseTotalCount: res?.data?.totalApplicationCount,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getInProgressCasesDRA = createAsyncThunk(
  "cases/getInProgressCasesDRA",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url =
        params?.activityType === "Field"
          ? "/getMyInProcessByUseridForDRA"
          : "/getMyInProcessByUserid";
      const res = await axios.get(
        `${url}/${params?.userId}/${params?.currentPage}/${params?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allInProgressCases = res?.data?.response
          ?.filter((a) => a?.inProcess === "Y")
          ?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${params?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus:
            userId === params?.userId
              ? allInProgressCases?.includes(data?.loanAccountNumber)
                ? "In Progress"
                : ""
              : "In Progress",
        }));
        return {
          data: finalData,
          InprogressTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesPending = createAsyncThunk(
  "cases/getUnallocatedCasesPending",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(data?.activityType)
        ? "/getCaseAllocationByUseridForUnAllocatedCasesForUnAllocationPendingField"
        : "/getCaseAllocationByUseridForUnAllocatedCasesForUnAllocationPending";
      const res = await axios.get(
        `${url}/${data?.userId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Pending",
        }));
        return {
          data: finalData,
          unalloactedPendingTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesApproved = createAsyncThunk(
  "cases/getUnallocatedCasesApproved",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(data?.activityType)
        ? "/getCaseAllocationByUseridForUnAllocatedCasesForUnAllocationApprovedField"
        : "/getCaseAllocationByUseridForUnAllocatedCasesForUnAllocationApproved";
      const res = await axios.get(
        `${url}/${data?.userId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Approved",
        }));
        return {
          data: finalData,
          unalloactedApproveTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesRejected = createAsyncThunk(
  "cases/getUnallocatedCasesRejected",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url = ["Field"]?.includes(data?.activityType)
        ? "/getCaseAllocationByUseridForUnAllocatedCasesForUnAllocationRejectedField"
        : "/getCaseAllocationByUseridForUnAllocatedCasesForUnAllocationRejected";
      const res = await axios.get(
        `${url}/${data?.userId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};

        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Rejected",
        }));
        return {
          data: finalData,
          unalloactedRejectTotalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesPendingDRA = createAsyncThunk(
  "cases/getUnallocatedCasesPendingDRA",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `getDRACaseAllocationByUseridUnAllocatedPending/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Pending",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesApprovedDRA = createAsyncThunk(
  "cases/getUnallocatedCasesApprovedDRA",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `getDRACaseAllocationByUseridUnAllocatedApproved/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Approved",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesRejectedDRA = createAsyncThunk(
  "cases/getUnallocatedCasesRejectedDRA",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `getDRACaseAllocationByUseridUnallocatedRejected/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};

        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Rejected",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesRejectedCA = createAsyncThunk(
  "cases/getUnallocatedCasesRejectedCA",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `getCACaseAllocationByUseridUnAllocatedRejected/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Rejected",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUnallocatedCasesPendingCA = createAsyncThunk(
  "cases/getUnallocatedCasesPendingCA",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `getCACaseAllocationByUseridUnAllocatedPending/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Pending",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);

export const getUnallocatedCasesApprovedCA = createAsyncThunk(
  "cases/getUnallocatedCasesApprovedCA",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `getCACaseAllocationByUseridUnAllocatedApproved/${data?.userId}/${data?.roleId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Approved",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getSettlementCases = createAsyncThunk(
  "cases/getSettlementCases",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const url =
        data?.activityType === "Field"
          ? "/getCaseAllocationSettlementField"
          : "/getCaseAllocationSettlement";
      const res = await axios.get(
        `${url}/${data?.userId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};
        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });
        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: "Settlement",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getDeallocated = createAsyncThunk(
  "cases/getDeallocated",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const params = {
        page: data?.currentPage,
        size: data?.numberOfDataPerPage,
      };
      const res = await axios.get(`/getDeallocatedByTab/${data?.tab}`, {
        params,
      });
      dispatch(setLoader(false));
      if (res?.data?.messageKey) {
        return {
          data: res?.data?.response?.content,
          totalCount: res?.data?.response?.totalElements,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getClouserRequestPending = createAsyncThunk(
  "cases/getClouserRequestPending",
  async (data, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      let url1 = "/getCaseClosureByTab";
      const mytab =
        data?.currentTab == "Pending"
          ? "Pending"
          : data?.currentTab == "Approved"
          ? "Approved"
          : "Rejected";
      const res = await axios.get(
        `${url1}/${data?.userId}/${mytab}?${data?.currentPage}?${data?.numberOfDataPerPage}`
      ); //  changes here by me added rolecode condition
      dispatch(setLoader(false));
      if (res?.data?.msgKey == "Success") {
        return {
          data: res?.data?.data?.content,
          caseCloaseTotalCount: res?.data?.totalApplicationCount
            ? res?.data?.totalApplicationCount
            : res?.data?.data?.totalElements,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getForeclouserMIS = createAsyncThunk(
  "cases/getForeclouserMIS",
  async (data, { dispatch }) => {
    // try {
    //   dispatch(setLoader(true))
    //   const url = data?.activityType === "Field" ? '/getCaseAllocationForCloserField' : '/getCaseAllocationForCloser'
    //   const res = await axios.get(`${url}/${data?.userId}/${data?.currentPage}/${data?.numberOfDataPerPage}`)
    //   console.log(res, "rereree")
    //   dispatch(setLoader(false))
    //   if (res?.data?.messageKey === "Success") {
    //     return {
    //       data: res?.data?.response,
    //       totalCount: res?.data?.totalApplicationCount
    //     }
    //   }
    // } catch (error) {
    //   dispatch(setLoader(false))
    // }
    try {
      dispatch(setLoader(true));
      const url =
        data?.activityType === "Field"
          ? "/getCaseAllocationForCloserField"
          : "/getCaseAllocationForCloser";
      const res = await axios.get(
        `${url}/${data?.userId}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allInProgressCases = res?.data?.response
          ?.filter((a) => a?.inProcess === "Y")
          ?.map((a) => a?.allLan);
        let userId = res?.data?.response?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};

        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser });
        });

        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus:
            userId === data?.userId
              ? allInProgressCases?.includes(data?.loanAccountNumber)
                ? "In Progress"
                : ""
              : "In Progress",
        }));
        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
// export const getForeclouser = createAsyncThunk('cases/getForeclouser',async(data,{dispatch})=>{
//     try {
//       let url = data?.isCA ? '/getForCloserForCA' : data?.isDRA ? '/getForCloserForDRA' : '/getForCloserForAll'
//       url = (data?.activityType === "Field" && !data?.isDRA) ? `${url}Field` : url
//       url = (data?.isCA || data?.isDRA) ? `${url}/${data?.userId}/${data?.roleId}` : `${url}/${data?.userId}`
//       dispatch(setLoader(true))
//       const res=await axios.get(`${url}/${data?.currentPage}/${data?.numberOfDataPerPage}`)
//       dispatch(setLoader(false))

//       if(res?.data?.messageKey === "Success"){
//         const allLenId = res?.data?.response?.map(a=>a?.allLan)
//         const allocatedUserId={}

//         res?.data?.response?.map(a=>{
//           Object.assign(allocatedUserId,{[a?.allLan]:a?.allocatedUser, [`caseStatus${a?.allLan}`]: a?.forCloserRequestStatus})
//         })

//         dispatch(setLoader(true))
//         const res2 = await axios.post(`/getBulkUploadSuccessByListOfLan/${data?.userId}`,allLenId)
//         dispatch(setLoader(false))

//         const finalData = res2?.data?.data?.map(data=>({
//           ...data,
//           allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
//           caseStatus: allocatedUserId?.[`caseStatus${data?.loanAccountNumber}`]
//         }))

//         return{
//           data: finalData,
//           totalCount: res?.data?.totalApplicationCount
//         }
//       }
//       if(res?.data?.messageKey === "Success"){
//         return{
//           data: res?.data?.response,
//           totalCount: res?.data?.totalApplicationCount
//         }
//       }
//     } catch (error) {
//       dispatch(setLoader(false))
//     }
//   }
// )

export const getForeclouser = createAsyncThunk(
  "cases/getForeclouser",
  async (data, { dispatch }) => {
    try {
      // let url = data?.isCA ? '/getForCloserForCA' : data?.isDRA ? '/getForCloserForDRA' : `/getCaseAllocationForCloser`
      let url = data?.isCA
        ? "/getCaseAllocationForCloser"
        : data?.isDRA
        ? "/getCaseAllocationForCloserField"
        : `/getCaseAllocationForCloser`;
      url =
        data?.activityType === "Field" && !data?.isDRA ? `${url}Field` : url;
      // url = (data?.isCA || data?.isDRA) ? `${url}/${data?.userId}/${data?.roleId}` : `${url}/${data?.userId}`
      url =
        data?.isCA || data?.isDRA
          ? `${url}/${data?.userId}`
          : `${url}/${data?.userId}`;

      dispatch(setLoader(true));
      const res = await axios.get(
        `${url}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false));

      if (res?.data?.messageKey === "Success") {
        const allLenId = res?.data?.response?.map((a) => a?.allLan);
        const allocatedUserId = {};

        res?.data?.response?.map((a) => {
          Object.assign(allocatedUserId, {
            [a?.allLan]: a?.allocatedUser,
            [`caseStatus${a?.allLan}`]: a?.forCloserRequestStatus,
          });
        });

        dispatch(setLoader(true));
        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${data?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));

        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocatedUser: allocatedUserId?.[data?.loanAccountNumber],
          caseStatus: allocatedUserId?.[`caseStatus${data?.loanAccountNumber}`],
        }));

        return {
          data: finalData,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
      if (res?.data?.messageKey === "Success") {
        return {
          data: res?.data?.response,
          totalCount: res?.data?.totalApplicationCount,
        };
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);

export const getActivityHistory = createAsyncThunk(
  "cases/getActivityHistory",
  async (lanId, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `/getAllActivityHistoryByLoanAccountNumber/${lanId}`
      );
      dispatch(setLoader(false));
      return res?.data?.data;
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);

export const getStatCard = createAsyncThunk(
  "cases/getStatCard",
  async (lanId, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getStatsByLan/${lanId}`);
      dispatch(setLoader(false));
      return res?.data?.data;
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);

export const getCommunicationHistory = createAsyncThunk(
  "cases/getCommunicationHistory",
  async (lanId, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/communicationHistoryByLan/${lanId}`);
      dispatch(setLoader(false));
      return res?.data?.data;
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);

export const getCallHistory = createAsyncThunk(
  "cases/getCallHistory",
  async (lanId, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getCallHistoryByLan/${lanId}`);
      dispatch(setLoader(false));
      return res?.data?.data;
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
// const selectCase = (state, lanId) => state.lists
const caseSlice = createSlice({
  name: "cases",
  initialState,
  reducers: {
    setList: (state, action) => {
      state.lists = action.payload;
    },
    setOldValue: (state, action) => {
      state.oldvalue = action.payload;
    },
    setFilterPayload: (state, action) => {
      state.filterPayload = action?.payload;
    },
    setAgencySelected: (state, action) => {
      state.agencySelected = action.payload;
    },

    setReset: (state, action) => {
      state.reset = action.payload;
    },

    // here changes
    setAllTotalCount: (state, action) => {
      state.allTotalCount = action?.payload;
      // state.newTotalCount=0
    },
    setNewTotalCount: (state, action) => {
      state.newTotalCount = action?.payload;
    },
    setAllocatedTotalCount: (state, action) => {
      state.allocatedTotalCount = action?.payload;
    },
    setMyCaseTotalCount: (state, action) => {
      state.mycaseTotalCount = action?.payload;
    },
    setInprogressTotalCount: (state, action) => {
      state.InprogressTotalCount = action?.payload;
    },
    setUnalloctaedPendingTotalCount: (state, action) => {
      state.unalloactedPendingTotalCount = action.payload;
    },
    setUnalloctaedApproveTotalCount: (state, action) => {
      state.unalloactedApproveTotalCount = action.payload;
    },
    setUnalloctaedrejectTotalCount: (state, action) => {
      state.unalloactedRejectTotalCount = action.payload;
    },
    setTotalCount: (state, action) => {
      state.totalCount = action?.payload;
    },
    setFieldVisit: (state, action) => {
      state.currentModule = action.payload;
    },
    setFilterAction: (state, action) => {
      state.isFilter = action.payload;
    },
    setSearchActive: (state, action) => {
      state.isSearch = action.payload;
    },
    setlanderfilterpayload: (state, action) => {
      state.filterpayload = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllCases.fulfilled, (state, action) => {
      state.lists = action.payload.data;
      state.allTotalCount = action?.payload?.allTotalCount;
    });
    builder.addCase(getNewMISCases.fulfilled, (state, action) => {
      state.lists = action.payload.data;
      state.newTotalCount = action?.payload?.newTotalCount;
    });
    builder.addCase(getAllocatedMISCases.fulfilled, (state, action) => {
      state.lists = action.payload.data;
      state.allocatedTotalCount = action?.payload?.allocatedTotalCount;
    });
    builder.addCase(getNewCases.fulfilled, (state, action) => {
      state.lists = action.payload;
    });
    builder.addCase(getCaseByLanId.fulfilled, (state, action) => {
      state.caseProfile = action.payload;
    });
    builder.addCase(getUnallocatedCases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.roleId = action.payload?.roleId;
      state.allTotalCount = action?.payload?.allTotalCount;
    });
    builder.addCase(getNewCasesForOtherRole.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.newTotalCount = action?.payload?.newTotalCount;
    });
    builder.addCase(
      getAllocatedCasesForOtherRole.fulfilled,
      (state, action) => {
        state.lists = action.payload?.data;
        state.allocatedTotalCount = action?.payload?.allocatedTotalCount;
      }
    );
    builder.addCase(getMyCasesForOtherRole.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.mycaseTotalCount = action?.payload?.mycaseTotalCount;
    });
    builder.addCase(getInProgressCases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.InprogressTotalCount = action?.payload?.InprogressTotalCount;
    });
    builder.addCase(getLegaPending.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.totalCount = action?.payload?.totalCount;
    });
    builder.addCase(CACases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.totalCount = action?.payload?.totalCount;
      state.mycaseTotalCount = action?.payload?.mycaseTotalCount;
    });
    builder.addCase(getDRACases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.allTotalCount = action?.payload?.allTotalCount;
      state.mycaseTotalCount = action?.payload?.mycaseTotalCount;
      state.totalCount = action?.payload?.totalCount;
    });
    builder.addCase(getLenderAllCases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.allTotalCount = action?.payload?.allTotalCount;
    });
    builder.addCase(getLenderInprogressCases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.InprogressTotalCount = action?.payload?.InprogressTotalCount;
    });
    builder.addCase(getLenderCaseCloase.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.caseCloaseTotalCount = action?.payload?.caseCloaseTotalCount;
    });
    builder.addCase(getCAInProgressCases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.totalCount = action?.payload?.totalCount;
      state.InprogressTotalCount = action?.payload?.totalCount;
    });
    builder.addCase(getInProgressCasesDRA.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.InprogressTotalCount = action?.payload?.InprogressTotalCount;
    });
    builder.addCase(getUnallocatedCasesPending.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.unalloactedPendingTotalCount =
        action?.payload?.unalloactedPendingTotalCount;
    });
    builder.addCase(getUnallocatedCasesApproved.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.unalloactedApproveTotalCount =
        action?.payload?.unalloactedApproveTotalCount;
    });
    builder.addCase(getUnallocatedCasesRejected.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.unalloactedRejectTotalCount =
        action?.payload?.unalloactedRejectTotalCount;
    });
    builder.addCase(
      getUnallocatedCasesPendingDRA.fulfilled,
      (state, action) => {
        state.lists = action.payload?.data;
        state.totalCount = action?.payload?.totalCount;
      }
    );
    builder.addCase(
      getUnallocatedCasesApprovedDRA.fulfilled,
      (state, action) => {
        state.lists = action.payload?.data;
        state.totalCount = action?.payload?.totalCount;
      }
    );
    builder.addCase(
      getUnallocatedCasesRejectedDRA.fulfilled,
      (state, action) => {
        state.lists = action.payload?.data;
        state.totalCount = action?.payload?.totalCount;
      }
    );
    builder.addCase(getUnallocatedCasesPendingCA.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      // state.unalloactedPendingTotalCount = action?.payload?.totalCount;
      state.totalCount = action?.payload?.totalCount;
    });
    builder.addCase(
      getUnallocatedCasesApprovedCA.fulfilled,
      (state, action) => {
        state.lists = action.payload?.data;
        state.totalCount = action?.payload?.totalCount;
      }
    );
    builder.addCase(
      getUnallocatedCasesRejectedCA.fulfilled,
      (state, action) => {
        state.lists = action.payload?.data;
        state.totalCount = action?.payload?.totalCount;
      }
    );
    builder.addCase(getDeallocated.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.totalCount = action?.payload?.totalCount;
    });
    builder.addCase(getClouserRequestPending.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.caseCloaseTotalCount = action?.payload?.caseCloaseTotalCount;
    });
    builder.addCase(getForeclouserMIS.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.totalCount = action?.payload?.totalCount;
    });
    builder.addCase(getForeclouser.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.totalCount = action?.payload?.totalCount;
    });
    builder.addCase(getSettlementCases.fulfilled, (state, action) => {
      state.lists = action.payload?.data;
      state.totalCount = action?.payload?.totalCount;
    });
    builder.addCase(getActivityHistory.fulfilled, (state, action) => {
      state.activityHistory = action.payload;
    });
    builder.addCase(getStatCard.fulfilled, (state, action) => {
      state.statCardHistory = action.payload;
    });
    builder.addCase(getCommunicationHistory.fulfilled, (state, action) => {
      state.communicationHistory = action.payload;
    });
    builder.addCase(getCallHistory.fulfilled, (state, action) => {
      state.callHistory = action.payload;
    });
  },
});

// export const selectCaseByLanId = (state, lanId) => {
//   return state.cases.lists.filter((c) => c.loanAccountNumber === lanId);
// };

export const {
  setSearchActive,
  setFilterAction,
  setOldValue,
  setFieldVisit,
  setList,
  setFilterPayload,
  setlanderfilterpayload,
  setAgencySelected,
  setTotalCount,
  setAllTotalCount,
  setNewTotalCount,
  setAllocatedTotalCount,
  setInprogressTotalCount,
  setMyCaseTotalCount,
  setUnalloctaedPendingTotalCount,
  setUnalloctaedApproveTotalCount,
  setUnalloctaedrejectTotalCount,
  setReset,
} = caseSlice.actions;
export default caseSlice.reducer;
