import { useFormikContext } from "formik";
import React, { useEffect, useState } from "react";
import { Input } from "reactstrap";
import Select from "react-select";
import cx from "classnames";
import axios from "axios";
import Field from "../../../../components/Field";
import { useDispatch, useSelector } from "react-redux";
import { NUMBER_ONLY } from "../../../../utils/regex";
import { setOldValue } from "../../store";
export default function RequestSubForm({
  requestTypeOptions,
  isView,
  isUpdate,
  lanId,
  geoData,
}) {
  const {
    values,
    errors,
    handleChange,
    handleBlur,
    touched,
    handleSubmit,
    setFieldValue,
  } = useFormikContext();
  // console.log(values, "valuesvalues")
  // console.log(requestTypeOptions, "requesttypeoption")
  const [addressOptions, setAddressOptions] = useState([]);
  const [oldAddress, setOldAddress] = useState("");
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const dispatch = useDispatch();
  const requestMatch = requestTypeOptions
    .filter((e) => e.label === values?.request)[0]
    ?.label.toLowerCase();
  useEffect(() => {
    if (requestMatch?.match("address")) {
      axios
        .get("/getAllAddressType")
        .then(({ data }) => {
          let addType = [];
          data.data.forEach((e) => {
            if (e.isActive === "Y")
              addType.push({ label: e.description, value: e.code });
          });
          setAddressOptions([...addType]);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }, [requestMatch]);
  const handleOldAddressType = async (value) => {
    //  console.log(value, "oldarrdersspayload")
    try {
      const res = await axios.get(
        `/getOldAddressByLan/${lanId}?addressType=${value}`
      );
      // console.log(res, "responsesesee")
      setOldAddress(res?.data?.data);
      dispatch(setOldValue(res?.data?.data));
      // setOldValue
    } catch (error) {
      console.log(error);
    }
  };
  // console.log(caseProfile, "caseProfilecaseProfile")
  if (requestMatch?.match("contact")) {
    return (
      <>
        <Field
          isRequired
          label="Old Contact"
          errorMessage={touched?.oldContact && errors?.oldContact}
        >
          <Input
            bsSize="sm"
            id="oldContact"
            type="textarea"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values?.oldContact}
            // invalid={touched?.oldContact && Boolean(errors?.oldContact)}
            disabled
          />
        </Field>
        <Field
          isRequired
          label="New Contact"
          errorMessage={touched?.newContact && errors?.newContact}
        >
          <Input
            bsSize="sm"
            id="newContact"
            type="textarea"
            onChange={(e) => {
              if (NUMBER_ONLY.test(e?.target?.value) || !e?.target?.value) {
                setFieldValue("newContact", e?.target?.value);
              }
            }}
            onBlur={handleBlur}
            value={values?.newContact}
            invalid={touched?.newContact && Boolean(errors?.newContact)}
            disabled={isView}
            maxLength={10}
          />
        </Field>
      </>
    );
  } else if (requestMatch?.match("address")) {
    return (
      <>
        <Field
          isRequired
          label="Exception Request"
          errorMessage={touched?.addressType && errors?.addressType}
        >
          <Select
            inputId="addressType"
            isClearable={true}
            options={addressOptions}
            closeMenuOnSelect={true}
            hideSelectedOptions={false}
            onChange={(e) => {
              // console.log(e?.value, "e?.valuee?.value" )
              setFieldValue("addressType", e?.value);
              if (e?.value === "AD") {
                // console.log(e?.value, "e?.valuee?.value" )
                // setFieldValue('oldAddress', caseProfile?.secondaryAddress)
                setFieldValue("oldAddress", caseProfile?.secondaryAddress);
                handleOldAddressType(e?.value);
                // console.log(caseProfile, "caseProfile?.secondaryAddress")
              } else if (e?.value === "AD01") {
                // setFieldValue('oldAddress', caseProfile?.officeAddress2)
                setFieldValue("oldAddress", caseProfile?.officeAddress2);
                handleOldAddressType(e?.value);
              } else if (e?.value === "AD02") {
                // setFieldValue('oldAddress', caseProfile?.officeAddress2)
                setFieldValue("oldAddress", caseProfile?.officeAddress2);
                handleOldAddressType(e?.value);
              }
            }}
            value={addressOptions.filter((v) => v.value === values.addressType)}
            className={cx({
              abc: touched.addressType && Boolean(errors.addressType),
            })}
            onBlur={handleBlur}
            menuPosition={"fixed"}
            isDisabled={isView}
            classNamePrefix="react-select"
          />
        </Field>
        <Field
          isRequired
          label="Old Address"
          errorMessage={touched?.oldAddress && errors?.oldAddress}
        >
          <Input
            bsSize="sm"
            id="oldAddress"
            type="textarea"
            onChange={handleChange}
            onBlur={handleBlur}
            value={oldAddress}
            // invalid={touched?.oldAddress && Boolean(errors?.oldAddress)}
            disabled
            maxLength={255}
          />
        </Field>
        <Field
          isRequired
          label="New Address"
          errorMessage={touched?.newAddress && errors?.newAddress}
        >
          <Input
            bsSize="sm"
            id="newAddress"
            type="textarea"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values?.newAddress}
            invalid={touched?.newAddress && Boolean(errors?.newAddress)}
            disabled={isView}
            maxLength={255}
          />
        </Field>
      </>
    );
  } else if (requestMatch?.match("name")) {
    return (
      <>
        <Field
          isRequired
          label="Old Name"
          errorMessage={touched?.oldName && errors?.oldName}
        >
          <Input
            bsSize="sm"
            id="oldName"
            type="textarea"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values?.oldName}
            // invalid={touched?.oldName && Boolean(errors?.oldName)}
            disabled
          />
        </Field>
        <Field
          isRequired
          label="New Name"
          errorMessage={touched?.newName && errors?.newName}
        >
          <Input
            bsSize="sm"
            id="newName"
            type="textarea"
            onChange={handleChange}
            onBlur={handleBlur}
            value={values?.newName}
            invalid={touched?.newName && Boolean(errors?.newName)}
            disabled={isView}
          />
        </Field>
      </>
    );
  } else {
    return null;
  }
}
