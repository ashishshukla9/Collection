import { memo, useEffect, useMemo, useState } from "react"
import { Button, Card, CardBody, Form, Input } from "reactstrap"
import AmountTable from "../Payment/AmountTable"
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import * as yup from "yup";
import { Formik } from "formik";
import Field from "../../../../components/Field";
import styles from './PTP.module.scss'
import { AMOUNT } from "../../../../utils/regex";
import Swal from "sweetalert2";
import axios from "axios";
import { getUserTypeData } from "../../../Master/LookupMaster/lookupSlice";
import { setLoader } from "../../../../reducer/globalReducer";

const PTPForm = (props) => {
    // console.log(props?.geoData, "prprprprprp")
    const [activeBtn, setActiveBtn] = useState('')
    const [message, setmessage] = useState({})
    const caseProfile = useSelector((state) => state.cases.caseProfile);
    const user = useSelector((state) => state.user.data);
    const userTypeData = useSelector(state => state?.lookup?.userTypeData)

    const { lanId } = useParams();
    const { tab } = useParams()

    const dispatch = useDispatch()

    const PAYMENT_TYPE_BUTTON = useMemo(() => ["Foreclosure", "Total Outstanding", "Charges", "Overdue EMI", "Settlement", "Other", "EMI"], [])
    const PAYMENT_MEASURE_BUTTON = useMemo(() => ["Full", "Partial"], [])
    const SUB_TYPE_BUTTON = useMemo(() => ["Other Charges", "DCP/LPP", "Cheque Bounce"], [])
    const isEdit = useMemo(() => props?.formType === "Update", [])
    const isView = useMemo(() => props?.formType === "View", [])
    const checkIsrequestPermission = useMemo(() => ['F', 'E'].includes(user?.masterRole?.requestmanagement_requestmanagement), [user])

    const items = props?.data?.subType?.split(',');
    const obj = {};
    items?.forEach(item => {
        if (item.includes("Other")) {
          obj["Other"] = item;
        } else if (item.includes("DCP")) {
          obj["DCP"] = item;
        } else if (item.includes("Cheque")) {
          obj["Cheque"] = item;
        }
      });
    // console.log(obj, "props?.data?.otherCharges")
    const initialValues = {
        ptpType: (isEdit || isView) ? props?.data?.ptpType : 'Foreclosure',
        ptpMode: (isEdit || isView) ? props?.data?.ptpMode : "Full",
        // subType: (isEdit || isView) ? [props?.data?.otherCharges && "Other Charges", props?.data?.dcpLpp && "DCP/LPP", props?.data?.chequeBounce && "Cheque Bounce"].filter(Boolean) : ["Other Charges", "DCP/LPP", "Cheque Bounce"],
        subType: (isEdit || isView) ? [obj?.Other && "Other Charges", obj?.DCP && "DCP/LPP", obj?.Cheque && "Cheque Bounce"].filter(Boolean) : ["Other Charges", "DCP/LPP", "Cheque Bounce"],
        // subType: (isEdit || isView) ? props?.data?.subType : ["Other Charges", "DCP/LPP", "Cheque Bounce"],
        ptpDate: (isEdit || isView) ? props?.data?.ptpDate : '',
        ptpTime: (isEdit || isView) ? props?.data?.ptpTime : '',
        followUp: (isEdit || isView) ? props?.data?.followUpDate : '',
        amount: (isEdit || isView) ? props?.data?.ptpAmount : '',
        remark: (isEdit || isView) ? props?.data?.remark : ''
    }

    // console.log(initialValues, "initialvalues")
    const validationSchema = yup.object({
        ptpType: yup.string().required("Required"),
        ptpMode: yup
            .string()
            .when('ptpType', {
                is: (ptpType) => ["EMI", "Settlement"]?.includes(ptpType),
                then: () => {
                    yup.string().required("Required")
                }
            }),
        subType: yup
            .array()
            .when('ptpType', {
                is: (ptpType) => ['Charges']?.includes(ptpType),
                then: () => yup.array().min(1, 'Required')
            }),
        ptpDate: yup.string().required("Required"),
        followUp: yup
            .string()
            .test('followUp', 'Followup date & time should not be greater than PTP date & time', (value, values) => {
                const val = value?.split('T')
                const date = val[0]
                const time = val[1]

                return !(date === values?.parent?.ptpDate && values?.parent?.ptpTime && time >= values?.parent?.ptpTime)
            })
            .required("Required"),
        amount: yup.string().required("Required"),
        // amount:yup.string().when("ptpType", {
        //     is:(ptpType)=>['Charges']?.includes(ptpType),
        //     then:() => yup.string().min(1, 'Required')
        // }),
        remark: yup.string().required("Required")
    })

    const handleSubmit = async (values) => {
        // const checkIsrequestPermission = ['F', 'E'].includes(user?.masterRole?.requestmanagement_requestmanagement)
        const checkIsrequestPermission = ["F", "E"].includes(
            user?.masterRole?.requestmanagement_requestmanagement
          );
        const payload = {
            totalOverdueAmount: parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(2),
            pendingEmiAmount: parseFloat(caseProfile?.pendingEmiAmount)?.toFixed(2),
            charges: values?.ptpType === "Charges" ? Number(parseFloat(caseProfile?.otherCharges)?.toFixed(2)) + Number(parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(2)) + Number(parseFloat(caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty)?.toFixed(2)) : null,
            settlementAmount: parseFloat(caseProfile?.settlementAmount)?.toFixed(2),
            emiAmount: parseFloat(caseProfile?.emiAmount)?.toFixed(2),
            remark: values?.remark,
            ptpAmount: values?.amount,
            ptpType: values?.ptpType,
            ptpMode: values?.ptpMode,
            otherCharges: values?.ptpType === "Charges" && values?.subType?.includes('Other Charges') ? Number(parseFloat(caseProfile?.otherCharges)?.toFixed(2))?.toString() : null,
            dcpLpp: values?.ptpType === "Charges" && values?.subType?.includes('DCP/LPP') ? Number(parseFloat(caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty)?.toFixed(2))?.toString() : null,
            chequeBounce: values?.ptpType === "Charges" && values?.subType?.includes('Cheque Bounce') ? Number(parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(2))?.toString() : null,
            ptpDate: values?.ptpDate,
            ptpTime: values?.ptpTime,
            followUpDate: values?.followUp,
            loanAccountNumber: lanId,
             subType: values?.ptpType === "Charges" ? values?.subType?.join(",") : "",
        //   paymentCategory: props?.paymentCategory,
        //   demandDraftNumber: values.demandDraftNumber,
            // status: checkIsrequestPermission ? "Success" : "Pending",
            status: "Pending",
            paymentCategory: props?.paymentCategory,
            user: {
                userId: user?.userId
            },
            fieldPickup: !checkIsrequestPermission && activeBtn === "Field Pick" ? 'true' : ''
        }

        // console.log(payload, "payloadpayloadpayloadpayloadpayloadpayload")
        try {
            if (isEdit) {
                dispatch(setLoader(true))
                const res = await axios.put(`/updatePtpDetails/${props?.data?.ptpId}`, { ...payload, status: isEdit ? "Pending" : checkIsrequestPermission ? "Success" : "Pending" })
                setmessage({msg: res?.data?.message, msgkey: res?.data?.msgKey})
                dispatch(setLoader(false))
                Swal.fire({
                    position: "top-end",
                    icon: res?.data?.msgKey== "Failure" ? "error" : "success",
                    title: res?.data?.message,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
                if (res?.data?.msgKey != "Failure") {
                    props?.onSuccess()
                }
            } else {
                if (props?.isContactCenter) {
                    props?.onSuccess('/addPtpDetails', payload)
                } else {
                    dispatch(setLoader(true))
                    const res = await axios.post('/addPtpDetails', {...payload, geoCoordinates:`${props?.geoData?.lat}, ${props?.geoData?.long}`}, null, (!checkIsrequestPermission && activeBtn === "Field Pick"))
                    setmessage({ msg: res?.data?.message, msgkey: res?.data?.msgKey })
                    dispatch(setLoader(false))

                    if (!checkIsrequestPermission && activeBtn === "Field Pick") {
                        const userType = {}
                        userTypeData?.map(a => Object.assign(userType, { [a?.code]: `${a?.description}_Agent` }))
                        const userRole = user?.role?.map(a => a?.roleCode?.toLowerCase())

                        const requestPayload = {
                            activityId: res?.data?.data?.ptpId,
                            activityType: "PTP",
                            lan: lanId,
                            status: res?.data?.data?.status,
                            remark: '',
                            selectedFieldAgentId: '',
                            requestRaisedUserId: user?.userId,
                            reportingManagerOfUser: '',
                            userType: userRole?.includes('ca') ? 'CA' : userRole?.includes('dra') ? 'DRA' : userRole.includes('atl') ? 'ATL' : userType[user?.userType],
                            requestid: new Date().getTime().toString().slice(-5),
                        }
                        dispatch(setLoader(true))
                        const requestRes = await axios.post('/addRequestManagement', requestPayload)
                        dispatch(setLoader(false))
                    }
                    Swal.fire({
                        position: "top-end",
                        icon: res?.data?.msgKey== "Failure" ? "error" : "success",
                        title:  res?.data?.message,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });

                    if (res?.data?.msgKey != "Failure") {
                        props?.onSuccess()
                    }
                }
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }
    useEffect(() => {
        dispatch(getUserTypeData())
    }, [])
    return (
        <Card>
            <CardBody>
                <AmountTable />
                <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={handleSubmit}
                >
                    {({ errors, touched, values, handleSubmit, setFieldValue, handleBlur, handleChange }) => {
                        return (
                            <Form onSubmit={handleSubmit}>
                                <Field
                                    isRequired
                                    label="PTP Type"
                                    childrenClassName={styles?.inlineButtonContainer}
                                    errorMessage={touched?.ptpType && errors?.ptpType}
                                >
                                    {PAYMENT_TYPE_BUTTON?.map(btn => (
                                        <Button
                                            key={btn}
                                            color="primary"
                                            outline
                                            size="sm"
                                            active={values?.ptpType === btn}
                                            name="ptpType"
                                            onClick={() => {
                                                if (!isView) {
                                                    let ptpMode = values?.ptpMode
                                                    setFieldValue('ptpType', btn)
                                                    if (btn !== "Charges") {
                                                        setFieldValue('subType', [])
                                                    }
                                                    if (btn !== "EMI" && btn !== "Settlement") {
                                                        setFieldValue('ptpMode', "")
                                                    } else {
                                                        setFieldValue('ptpMode', "Full")
                                                        ptpMode = 'Full'
                                                        setFieldValue('amount', parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(2))
                                                    }
                                                    if (["Settlement"]?.includes(btn) && ptpMode === "Full") {
                                                        setFieldValue('amount', parseFloat(caseProfile?.settlementAmount)?.toFixed(2))
                                                    } else if (["Charges"].includes(btn)) {
                                                        const totalCharges = Number(parseFloat(caseProfile?.otherCharges)?.toFixed(2)) + Number(parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(2)) + Number(parseFloat(caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty)?.toFixed(2))
                                                        setFieldValue('amount', totalCharges)
                                                        setFieldValue('subType', ["Other Charges", "DCP/LPP", "Cheque Bounce"])
                                                    } else if (["Foreclosure", "Other"].includes(btn)) {
                                                        setFieldValue('amount', '')
                                                    } else if (btn === "Pending EMI") {
                                                        setFieldValue('amount', parseFloat(caseProfile?.pendingEmiAmount)?.toFixed(2))
                                                    } else if (btn === "EMI") {
                                                        setFieldValue('amount', parseFloat(caseProfile?.emiAmount)?.toFixed(2))
                                                    } else if (btn === "Total Outstanding") {
                                                        setFieldValue('amount', parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(2))
                                                    } else if (btn === "Overdue EMI") {
                                                        setFieldValue('amount', parseFloat(caseProfile?.pendingEmiAmount)?.toFixed(2))
                                                    }
                                                }
                                            }}
                                            onBlur={handleBlur}
                                            invalid={touched?.ptpType && Boolean(errors?.ptpType)}
                                            disabled={isView && values?.ptpType !== btn}
                                        >
                                            {btn}
                                        </Button>
                                    ))}
                                </Field>
                                {["EMI", "Settlement"]?.includes(values?.ptpType) &&
                                    <Field
                                        isRequired
                                        label="PTP Measure"
                                        childrenClassName={styles?.inlineButtonContainer}
                                        errorMessage={touched?.ptpMode && errors?.ptpMode}
                                    >
                                        {PAYMENT_MEASURE_BUTTON?.map(btn => (
                                            <Button
                                                key={btn}
                                                color="primary"
                                                outline
                                                size="sm"
                                                name="ptpMode"
                                                active={values?.ptpMode === btn}
                                                onClick={() => {
                                                    if (!isView) {
                                                        setFieldValue('ptpMode', btn)
                                                        if (btn === "Full") {
                                                            const amount = values?.ptpType === "EMI" ? caseProfile?.emiAmount : values?.ptpType === "Settlement" ? caseProfile?.settlementAmount : caseProfile?.totalOverdueAmount
                                                            setFieldValue('amount', parseFloat(amount)?.toFixed(2))
                                                        }
                                                    }
                                                }}
                                                onBlur={handleBlur}
                                                invalid={touched?.ptpMode && Boolean(errors?.ptpMode)}
                                                disabled={isView && values?.ptpMode !== btn}
                                            >
                                                {btn}
                                            </Button>
                                        ))}
                                    </Field>
                                }
                                {["Charges"].includes(values?.ptpType) &&
                                    <Field
                                        isRequired
                                        label="Sub Type"
                                        childrenClassName={styles?.inlineButtonContainer}
                                        errorMessage={touched?.subType && errors?.subType}
                                    >
                                        {SUB_TYPE_BUTTON?.map(btn => (
                                            <Button
                                                key={btn}
                                                color="primary"
                                                outline
                                                size="sm"
                                                name="subType"
                                                active={values?.subType?.includes(btn)}
                                                onClick={() => {
                                                    if (!isView) {
                                                        const indexOf = values?.subType?.indexOf(btn)
                                                        let latestValue = []
                                                        if (indexOf >= 0) {
                                                            let updatedValue = values?.subType
                                                            updatedValue?.splice(indexOf, 1)
                                                            latestValue = updatedValue
                                                            setFieldValue('subType', updatedValue)
                                                        } else {
                                                            latestValue = [...values?.subType, btn]
                                                            setFieldValue('subType', [...values?.subType, btn])
                                                        }
                                                        let totalCharges = 0;
                                                        latestValue?.map(a => {
                                                            if (a === "Cheque Bounce") {
                                                                totalCharges = totalCharges + Number(parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(2))
                                                            } else if (a === "Other Charges") {
                                                                totalCharges = totalCharges + Number(parseFloat(caseProfile?.otherCharges)?.toFixed(2))
                                                            } else if (a === "DCP/LPP") {
                                                                totalCharges = totalCharges + Number(parseFloat(caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty)?.toFixed(2))
                                                            }
                                                        })
                                                        setFieldValue('amount', totalCharges)
                                                    }
                                                }}
                                                onBlur={handleBlur}
                                                invalid={touched?.subType && Boolean(errors?.subType)}
                                                disabled={isView && !values?.subType?.includes(btn)}
                                            >
                                                {btn}
                                            </Button>
                                        ))}
                                    </Field>
                                }

                                <Field
                                    isRequired
                                    label="PTP Date"
                                    errorMessage={touched?.ptpDate && errors?.ptpDate}
                                >
                                    <Input
                                        type="date"
                                        name="ptpDate"
                                        value={values?.ptpDate}
                                        min={new Date().toISOString().split('T')[0]}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        disabled={isView}
                                    />
                                </Field>

                                <Field
                                    label="PTP Time"
                                >
                                    <Input
                                        type="time"
                                        name="ptpTime"
                                        value={values?.ptpTime}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        disabled={isView}
                                    />
                                </Field>

                                <Field
                                    isRequired
                                    label="Follow Up"
                                    errorMessage={touched?.followUp && errors?.followUp}
                                >
                                    <Input
                                        type="datetime-local"
                                        name="followUp"
                                        value={values?.followUp}
                                        min={new Date().toISOString().split('T')[0] + "T00:00"}
                                        max={values?.ptpTime ? `${values?.ptpDate}T${values?.ptpTime}` : `${values?.ptpDate}T00:00`}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        disabled={isView}
                                    />
                                </Field>

                                <Field
                                    isRequired
                                    label="Amount"
                                    errorMessage={touched?.amount && errors?.amount}
                                >
                                    <Input
                                        bsSize="sm"
                                        // isRequired
                                        // value={values?.amount}
                                        value={(values?.amount == "0.00" || values?.amount == "0") ? "" : values?.amount}
                                        name="amount"
                                        onChange={(e) => {
                                            const decimal = e?.target?.value?.split('.')

                                            if (decimal?.length === 1) {
                                                if (AMOUNT?.test(e?.target?.value)) {
                                                    setFieldValue('amount', e?.target?.value)
                                                }
                                            } else {
                                                if (AMOUNT?.test(e?.target?.value) && decimal[1].length <= 2) {
                                                    setFieldValue('amount', e?.target?.value)
                                                }
                                            }
                                        }}
                                        maxLength={15}
                                        onBlur={handleBlur}
                                        invalid={touched?.amount && Boolean(errors?.amount)}
                                        disabled={(["EMI", "Settlement"]?.includes(values?.ptpType) && values?.ptpMode === "Full") || isView}
                                    />
                                    {(message?.msgKey == "Failure" || !values?.amount || values?.amount == "0.00" || values?.amount == "0") ? <span style={{ color: "red" }}>Amount is mandatory</span> : ""}
                                </Field>

                                <Field
                                    isRequired
                                    label="Remark"
                                    errorMessage={touched?.remark && errors?.remark}
                                >
                                    <Input
                                        type="textarea"
                                        bsSize="sm"
                                        value={values?.remark}
                                        onChange={handleChange}
                                        name="remark"
                                        onBlur={handleBlur}
                                        invalid={touched?.remark && Boolean(errors?.remark)}
                                        disabled={isView}
                                    />
                                </Field>

                                {!isView &&
                                    <div className="d-flex justify-content-end gap-2">
                                        {!checkIsrequestPermission && !isEdit && (tab === "MY_CASE" || tab === "IN_PROGRESS") && (user?.activityType === "Calling" || (user?.activityType === "Both")) &&
                                            <Button
                                                type="submit"
                                                size="sm"
                                                color="primary"
                                                onMouseOver={() => setActiveBtn('Field Pick')}
                                            >
                                                Field Pick
                                            </Button>
                                        }
                                        <Button
                                            type="submit"
                                            size="sm"
                                            color="primary"
                                            onMouseOver={() => setActiveBtn('Save')}
                                        >
                                            Save
                                        </Button>
                                        {!props?.isCancelHidden &&
                                            <Button
                                                type="button"
                                                size="sm"
                                                color="danger"
                                                onClick={() => props?.onClose()}
                                            >
                                                Cancel
                                            </Button>
                                        }
                                    </div>
                                }
                            </Form>
                        )
                    }}
                </Formik>

            </CardBody>
        </Card>
    )
}

export default memo(PTPForm)