import React, { useState, useEffect, Fragment } from "react";
import { Dialog } from "primereact/dialog";
import { Button, ButtonGroup } from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { CardBody } from "reactstrap";
import axios from "axios";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import moment from "moment";
import PTPForm from "./PTPForm";
import { getActivityHistory, updateInProgressCase } from "../../store";
import Payment from "../Payment/Payment";
import styles from './PTP.module.scss'
import { setLoader } from "../../../../reducer/globalReducer";
export const PTP = (props) => {
  const { openPtp, setOpenPtp, access } = props;
  const [ptpTableData, setPtpTableData] = useState([]);
  const [data, setData] = useState({});
  const [openPayment, setOpenPayment] = useState(false);
  const [ptpFormModal, setPtpFormModal] = useState(false);
  const [formType, setFormType] = useState("");
  const user = useSelector((state) => state.user.data);
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const navigate = useNavigate();
  const { lanId } = useParams();
  const dispatch = useDispatch();
  const handleAdd = () => {
    setPtpFormModal(true);
    setFormType("Add");
    setData({});
  };
  const getPTPData = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(
        `/getAllPtpDetailsByLoanAccountNumber/${lanId}`
      );
      dispatch(setLoader(false))

      setPtpTableData(res?.data?.data || []);
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const onSuccess = () => {
    getPTPData();
    dispatch(
      updateInProgressCase({
        userId: user?.userId,
        currentTab: props?.module,
        lanId,
        role: user?.role[0]?.roleCode,
        activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType,
      })
    );
    dispatch(getActivityHistory(lanId));
    setPtpFormModal(false);
  };
  const onSuccessPayment = async () => {
    // try {
    //   const res=await axios.put(`/updatePtpDetailsStatus/${data?.ptpId}/Paid`)
    // } catch (error) {

    // }
    getPTPData();
    dispatch(
      updateInProgressCase({
        userId: user?.userId,
        lanId,
        role: user?.role[0]?.roleCode,
        activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType,
      })
    );
    dispatch(getActivityHistory(lanId));
    setOpenPayment(false);
  };

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  useEffect(() => {
    getPTPData();
  }, []);

  let checkStatus = ["Off Broken", "Offline"]
  return (
    <Dialog
      header="PTP"
      visible={openPtp}
      style={{ minWidth: "60vw" }}
      onHide={() => setOpenPtp(false)}
    >
      <div className="mb-2 d-flex justify-content-end">
        <Button color="primary" onClick={() => handleAdd()} size="sm" disabled={caseProfile?.forCloserRequestStatus === "approved"}>
          Add
        </Button>
      </div>
      <CardBody>
        <DataTable
          value={ptpTableData}
          size={"small"}
          showGridlines
          paginator
          className="commonTable"
          rows={10}
          rowsPerPageOptions={[10, 20, 40, 80, "All"]}
          globalFilterFields={["natureofServiceId", "status"]}
          rowClassName={data => (["Success", "Rejected", "Paid"].includes(data?.status) ? 'p-disabled c-disabled' : (data?.status === "Pending" && data?.payment) ? 'p-disabled c-disabled' : caseProfile?.forCloserRequestStatus === "approved" ? 'p-disabled c-disabled' : '')}
        >
          <Column
            field="name"
            header="Name"
            body={(rowData) => {
              return `${rowData.user.firstName} ${rowData.user.lastName}`;
            }}
          />
          <Column field="ptpId" header="PTP ID" />
          <Column
            // field="ptpTime"
            header="PTP Date/Time"
            body={(rowData) => {
              const dateTimeString = `${rowData.ptpDate}T${rowData?.ptpTime}`;
              const date = new Date(dateTimeString);
              // { console.log(date, "datettete") }
              const day = String(date.getDate()).padStart(2, '0');
              const month = String(date.getMonth() + 1).padStart(2, '0');
              const year = String(date.getFullYear());
              const hours = String(date.getHours() % 12 || 12).padStart(2, '0'); // Convert to 12-hour format
              const minutes = String(date.getMinutes()).padStart(2, '0');
              const ampm = date.getHours() < 12 ? 'AM' : 'PM';
              const formattedDate = `${day}-${month}-${year}`;
              const formattedTime = `${hours}:${minutes} ${ampm}`;

              return (`${formattedDate}  ${formattedTime}`)
              // return new Date(`${rowData.ptpDate}T${rowData?.ptpTime}`).toLocaleString()


            }}

          />
          {/* {console.log(ptpTableData, "rtowdata")} */}



          <Column field="ptpAmount" header="Amount" body={(rowData) => {
            return rowData?.ptpAmount?.toLocaleString('en-IN', {
              style: 'currency',
              currency: 'INR'
            })
          }} />
          <Column field="ptpType" header="Type" />
          <Column field="ptpMode" header="Mode" />
          <Column
            field="status"
            header="Status"
          />
          <Column
            // field="code"
            header="Action"
            body={(rowData) => (
              <ButtonGroup style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <i
                  className={`bi bi-eye-fill text-primary ${styles?.ptpViewIcon}`}
                  style={{ cursor: "pointer" }}
                  onClick={(e) => {
                    setData({ ...rowData });
                    setPtpFormModal(true);
                    setFormType("View");
                  }}
                />
                {!(["Off Broken", "Offline"].includes(rowData?.status)) &&
                  <Fragment>
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        if (rowData?.status !== "Offline") {
                          setData({ ...rowData });
                          setPtpFormModal(true);
                          setFormType("Update");
                        }
                      }}
                    />
                  </Fragment>
                }

              </ButtonGroup>
            )}
          />
          <Column
            // field="code"
            header="Payment"
            body={(rowData) => (
              <Button
                color="primary"
                size="sm"
                type="button"
                onClick={() => {
                  setData(rowData);
                  setOpenPayment(true);
                }}
                disabled={rowData?.status == 'Offline' || rowData?.status == 'Off Broken'}
              // disabled={rowData?.fieldPickup || new Date(`${rowData.ptpDate}T${rowData?.ptpTime}`)?.valueOf() <= new Date().valueOf()}
              >
                Payment
              </Button>
            )}
          />
        </DataTable>
      </CardBody>

      <Dialog
        header={`${formType} PTP`}
        visible={ptpFormModal}
        style={{ minWidth: "40vw" }}
        onHide={() => setPtpFormModal(false)}
      >
        <PTPForm
          geoData={props?.geoData}
          onClose={() => setPtpFormModal(false)}
          formType={formType}
          data={data}
          onSuccess={onSuccess}
        />
      </Dialog>
      <Dialog
        header="Payment"
        visible={openPayment}
        style={{ minWidth: "50vw" }}
        onHide={() => setOpenPayment(false)}
      >
        <Payment
          geoData={props?.geoData}
          cancelModal={setOpenPayment}
          onSuccess={onSuccessPayment}
          paymentCategory="PTP"
          data={data}
        />
      </Dialog>
    </Dialog>
  );
};
