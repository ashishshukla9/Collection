import React, { memo, useEffect, useMemo, useState } from "react";
import { Dialog } from "primereact/dialog";
import { Form, Input, Button, Card, CardBody, ButtonGroup } from "reactstrap";
import cx from "classnames";
import { Formik } from "formik";
import Select from "react-select";
import RequestSubForm from "./RequestSubForm";
import styles from './Request.module.scss'
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import Field from "../../../../components/Field";
import * as yup from "yup";
import axios from "axios";
import Swal from "sweetalert2";
import { DownloadFile } from "../../../../utils/DownloadFile";
import classNames from "classnames";
import { getUserTypeData } from "../../../Master/LookupMaster/lookupSlice";
import { setLoader } from "../../../../reducer/globalReducer";


const Request = (props) => {
  // console.log(props?.data?.oldValue, "myprops")
  // console.log(props, "check the address type ")

  const [documentDetail, setDocumentDetail] = useState();
  const [editModal, setEditModal] = useState(false);
  const [evidanceFile, setEvidanceFile] = useState();

  const user = useSelector((state) => state.user.data);
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const oldAddress = useSelector((state) => state.cases.oldvalue);

  const userTypeData = useSelector(state => state?.lookup?.userTypeData)
  const { lanId } = useParams();

  const dispatch = useDispatch()

  const isEdit = useMemo(() => props?.formType === "Edit", [])
  const isView = useMemo(() => props?.formType === "View", [])
  const isCreate = useMemo(() => props?.formType === "Create", [])

  const initialValues = {
    request: props?.data?.requestType || '',
    remark: props?.data?.remark || '',
    evidance: props?.data?.evidance || '',
    oldContact: props?.data?.requestType === "Contact Change" ? props?.data?.oldValue : '' || caseProfile?.mobile,
    newContact: props?.data?.requestType === "Contact Change" ? props?.data?.newValue : '' || '',
    addressType: props?.data?.requestType === "Address Change" ? props?.data?.addressType : '' || '',
    oldAddress: props?.data?.requestType === "Address Change" ? props?.data?.oldValue : '' || '',
    newAddress: props?.data?.requestType === "Address Change" ? props?.data?.newValue : '' || '',
    oldName: props?.data?.requestType === "Name Change" ? props?.data?.oldValue : '' || caseProfile?.name,
    newName: props?.data?.requestType === "Name Change" ? props?.data?.newValue : '' || ''
  }

  const validationSchema = yup.object({
    request: yup.string().required("Required"),
    remark: yup.string().max(250, "Too Long.").required("Required"),
    addressType: yup.string().when('request', {
      is: (request) => request === "Address Change",
      then: () => yup.string().required('Required')
    }),
    newName: yup.string().when('request', {
      is: (request) => request === "Name Change",
      then: () => yup.string().required("Required")
    }),
    newAddress: yup.string().when('request', {
      is: (request) => request === "Address Change",
      then: () => yup.string().required("Required")
    }),
    newContact: yup.string().when('request', {
      is: (request) => request === "Contact Change",
      then: () => yup.string().required("Required")
    }),
    // evidance: yup.mixed().when('remark', {
    //   is: () => isCreate,
    //   then: () => yup.mixed().required('Required')
    // })
  })

  const handleSubmit = async (values) => {
    // console.log(values?.request?.toLowerCase(), "nnn")
    try {
      // 
      const checkRequest = ['legal', "repossession", "unallocate", "Case Close"].includes(values?.request?.toLowerCase())
      // console.log(checkRequest, "checkrequest")
      const checkIsrequestPermission = ['E'].includes(user?.masterRole?.requestmanagement_requestmanagement)
// console.log( checkRequest, "checkIsrequestPermission")
      const payload = {
        requestType: values?.request,
        oldValue: values?.request === "Name Change" ? values?.oldName : values?.request === "Contact Change" ? values?.oldContact : values?.request === "Address Change" && oldAddress,
        newValue: values?.request === "Name Change" ? values?.newName : values?.request === "Contact Change" ? values?.newContact : values?.request === "Address Change" && values?.newAddress,
        addressType: values?.addressType,
        isDocument: values?.evidance ? "yes": "No",
        remark: values?.remark,
        loanAccountNumber: lanId,
        // status: checkIsrequestPermission ? checkRequest ? "Pending" : "Approved" : "Pending",
        status: (checkIsrequestPermission || checkRequest || values?.request=="Case Close") ? "Pending" : "Approved" ,
        user
      }
      if (isEdit) {
        try {
          dispatch(setLoader(true))
          const res = await axios.put(`/updateRequest/${props?.data?.requestId}`, payload)
          dispatch(setLoader(false))

          if (["success", "Success"].includes(res?.data?.msgKey)) {
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: "Updated Succefully.",
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });

            props?.onClose()
            props?.onSuccess()
          }
        } catch (error) {
          dispatch(setLoader(false))
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      } else {
        dispatch(setLoader(true))
        const res = await axios.post(`createRequest`, {...payload, geoCoordinates:`${props?.geoData?.lat}, ${props?.geoData?.long}`})
        dispatch(setLoader(false))
        if (["success", "Success"].includes(res?.data?.msgKey)) {
          // console.log(values, "values?.evidance")
          if (values?.evidance) {
            const formData = new FormData();
            formData.append('rfile', values?.evidance)
            // console.log(values?.evidance, "formData")

            const url = `/upload-document-request/${res?.data?.data?.requestId}`
            const headers = {
              "Content-Type": "multipart/form-data", // Set the Content-Type header
            }

            dispatch(setLoader(true))
            const uploadDoc = await axios.post(url, formData, { headers })
            dispatch(setLoader(false))
          }

          if (checkRequest) {
            const userType = {}
            userTypeData?.map(a => Object.assign(userType, { [a?.code]: `${a?.description}_Agent` }))
            const userRole = user?.role?.map(a => a?.roleCode?.toLowerCase())
            const subString = "AA"
            const requestPayload = {
              activityId: res?.data?.data?.requestId,
              activityType: values?.request === "Case Closure" ? "Foreclouser" : "Request",
              lan: lanId,
              status: "Pending",
              remark: '',
              isDocument: values?.evidance ? "yes": "No",
              selectedFieldAgentId: '',
              requestRaisedUserId: user?.userId,
              userType: userRole?.includes('ca') ? 'CA' : userRole?.includes('dra') ? 'DRA' : userRole.includes('atl') ? 'ATL' : userRole?.includes('aa') ? 'AA' : userRole?.includes('prm') ? 'PRM' : userType[user?.userType],
              requestid: new Date().getTime().toString().slice(-5),
              repoAndLegal: ["Legal", "Repossession"]?.includes(values?.request) ? values?.request : '',
              unAllocate: values?.request === "Unallocate" ? values?.request : '',
              agencyAdminField: (userRole?.includes(subString.toLowerCase()) && props?.currentModule) ? "Y" : "N"
            }
            dispatch(setLoader(true))
            const requestRes = await axios.post('/addRequestManagement', requestPayload)
            dispatch(setLoader(false))
            if (values?.request?.toLowerCase() === "unallocate") {
              const url = (user?.activityType === "Field" || user?.activityType === "Both" && props?.currentModule ) ? '/unallocateCasePendingField' : '/unallocateCasePending'
              dispatch(setLoader(true))
              const unallocateRes = await axios.post(`${url}/${lanId}`)
              dispatch(setLoader(false))
            }
          }

          props?.onClose()
          props?.onSuccess()
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Record Created.",
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const handleFileUpate = async () => {
    const formData = new FormData();
    formData.append("rfile", evidanceFile);

    try {
      const url = `/update-document-request/${documentDetail?.requestId}/${documentDetail?.documentRequestId}`
      const headers = {
        "Content-Type": "multipart/form-data", // Set the Content-Type header
      }
      dispatch(setLoader(true))
      const res = await axios.put(url, formData, { headers })
      dispatch(setLoader(false))
      setEvidanceFile();
      setEditModal(!editModal);
      setDocumentDetail(res?.data?.data);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: "File Updated Succefully.",
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const getDocument = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/documentRequestByRequestId/${props?.data?.requestId}`)
      dispatch(setLoader(false))
      setDocumentDetail(res?.data)
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  useEffect(() => {
    if (Object.keys(props?.data).length) {
      getDocument()
    }
  }, []);

  useEffect(() => {
    dispatch(getUserTypeData())
  }, [])

  return (
    <Dialog
      header={`${props?.formType} Request`}
      visible={props?.visible}
      onHide={() => props?.onClose()}
      className={styles?.modalContainer}
    >
      <Card className="mx-3 bg-light ">
        <CardBody>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({
              values,
              errors,
              handleChange,
              handleBlur,
              touched,
              handleSubmit,
              setFieldValue,
              resetForm
            }) => (
              <Form
                onSubmit={handleSubmit}
                className={styles.formContainer}
              >
                <Field
                  isRequired
                  label="Request"
                  errorMessage={touched?.request && errors?.request}
                >
                  <Select
                    inputId="request"
                    name="request"
                    isClearable={true}
                    options={props?.requestTypeOptions}
                    closeMenuOnSelect={true}
                    hideSelectedOptions={false}
                    onChange={(e) => {
                      resetForm({
                        values: {
                          oldContact: caseProfile?.mobile,
                          newContact: '',
                          addressType: '',
                          oldAddress: '',
                          newAddress: '',
                          oldName: caseProfile?.name,
                          newName: '',
                          remark: values?.remark,
                          evidance: values?.evidance
                        }
                      })
                      setFieldValue("request", e?.label);
                      // console.log(values.request, "values.request")
                    }}
                    value={props?.requestTypeOptions.filter(
                      (v) => v.label === values.request
                    )}
                    className={cx({
                      abc: touched?.request && Boolean(errors?.request),
                    })}
                    onBlur={handleBlur}
                    menuPosition={"fixed"}
                    isDisabled={isView}
                    classNamePrefix="react-select"
                    disabled={isView}
                  />
                </Field>

                <RequestSubForm requestTypeOptions={props?.requestTypeOptions} lanId={props?.lanId} isView={isView} geoData={props?.geoData} />

                <Field
                  isRequired
                  label="Remarks"
                  errorMessage={touched?.remark && errors?.remark}
                >
                  <Input
                    bsSize="sm"
                    id="remark"
                    type="textarea"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.remark}
                    invalid={touched?.remark && Boolean(errors?.remark)}
                    disabled={isView}
                  />
                </Field>
                {(isView || isEdit) ?
                  <ButtonGroup>
                    {documentDetail && (
                      <Button
                        color="success"
                        size="sm"
                        outline
                        onClick={
                          () =>
                            DownloadFile(
                              `/download-request-file/${documentDetail?.documentRequestId}`,
                              documentDetail?.name
                            )
                        }
                      >
                        <i className="bi bi-download me-3"></i>
                        Download - {documentDetail?.name}
                      </Button>
                    )}
                    {(isCreate || isEdit) && (
                      <Button
                        size="sm"
                        color="primary"
                        outline
                        onClick={() => {
                          setEditModal(!editModal);
                        }}
                      >
                        <i className="bi bi-pencil-square"></i>
                        Edit
                      </Button>
                    )}
                  </ButtonGroup> :
                  <label
                    htmlFor="evidence"
                    className={classNames({
                      "btn-outline-primary": !(
                        touched?.evidance && Boolean(errors?.evidance)
                      ),
                      "btn btn-sm upload-button": true,
                      "is-invalid btn-outline-danger":
                        touched?.evidance && Boolean(errors?.evidance),
                    })}
                  >
                    <i className="bi bi-upload uploadIcon"></i>
                    <span>{values?.evidance?.name || "Evidence"}</span>
                    <input
                      type="file"
                      id="evidence"
                      style={{ display: "none" }}
                      onChange={(event) => {
                        const file = event.target?.files[0];
                        // Handle the selected file here
                        setFieldValue("evidance", file);
                      }}
                    />
                  </label>
                }
                {(isCreate || isEdit) && (
                  <div className="d-flex justify-content-end">
                    <Button type="submit" color="primary" className="me-1" size="sm">
                      Submit
                    </Button>
                    <Button
                      size="sm"
                      type="button"
                      color="danger"
                      onClick={() => props?.onClose()}
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </Form>
            )}
          </Formik>
        </CardBody>

        <Dialog
          header="Edit Evidence File"
          visible={editModal}
          style={{ width: "20vw" }}
          onHide={() => {
            setEditModal(!editModal);
          }}
        >
          <label
            htmlFor="evidence"
            className="btn-outline-primary btn btn-sm upload-button mb-2"
          >
            <i className="bi bi-upload uploadIcon"></i>
            <span>{evidanceFile?.name || "Evidence"}</span>
            <input
              type="file"
              id="evidence"
              style={{ display: "none" }}
              onChange={(event) => {
                const file = event.target?.files[0];
                // Handle the selected file here
                setEvidanceFile(file);
              }}
            />
          </label>
          {evidanceFile && (
            <Button
              size="sm"
              color="primary"
              className="d-flex ms-auto"
              onClick={handleFileUpate}
            >
              Update
            </Button>
          )}
        </Dialog>
      </Card>
    </Dialog>
  );
};

export default memo(Request);
