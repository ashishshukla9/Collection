import React, { useState, useEffect } from "react";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { CardBody, Button, ButtonGroup } from "reactstrap";
import Payment from "./Payment";
import axios from "axios";
import Swal from "sweetalert2";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  getActivityHistory,
  getCommunicationHistory,
  updateInProgressCase,
  getCaseByLanId,
} from "../../store";
import PaymentReport from "./PaymentReport";
import { PDFDownloadLink } from "@react-pdf/renderer";
import styles from "./Payment.module.scss";
import { Cookies } from "react-cookie";
import { setLoader } from "../../../../reducer/globalReducer";
import { addAudit } from "../../../../utils/commonFun";
const PaymentTable = (props) => {
  const { openPyamentTable, setOpenPaymentTable } = props;
  const [userData, setUserData] = useState();
  const [selectedData, setSelectedData] = useState({});
  const [paymentData, setPaymentData] = useState([]);
  const [openPyament, setOpenPayment] = useState(false);
  const [isEdit, setisEdit] = useState(false);
  // console.log(props?.geoData, "prprprrpr")
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user.data);
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const { lanId } = useParams();
  const cookies = new Cookies();
  const getToken = cookies.get("token");
  axios.defaults.headers.common["Authorization"] = `Bearer ` + getToken;
  const handleAdd = () => {
    setOpenPayment(!openPyament);
  };
  const getAPI = () => {
    dispatch(setLoader(true));
    axios
      .get(`/getAllPaymentByLoanAccountNumber/${lanId}`)
      .then(({ data }) => {
        dispatch(setLoader(false));
        setPaymentData(data?.data || []);
      })
      .catch((error) => {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };
  // console.log(paymentData, "paymentdatata")
  const onSuccess = () => {
    getAPI();
    setOpenPayment(false);
    dispatch(
      updateInProgressCase({
        userId: user?.userId,
        currentTab: props?.module,
        lanId,
        role: user?.role[0]?.roleCode,
        activityType:
          caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType,
      })
    );
    dispatch(getActivityHistory(lanId));
  };
  const handleSMS = async (paymentId, amount) => {
    // console.log(amount, "smsamount")
    try {
      //const URL = process.env.REACT_APP_BASE_URL + window.location.origin + '#' + "/download_Payment_recipt" + `/${paymentId}`;
      // const URL = process.env.REACT_APP_BASE_URL + window.location.origin + window.location.pathname + '#' + "/download_Payment_recipt" + `/${paymentId}`;
      const URL =
        process.env.REACT_APP_BASE_URLS +
        "/#" +
        "/download_Payment_recipt" +
        `/${paymentId}`;
      // console.log(URL, 'vyuvuyvg')
      delete axios.defaults.headers.common["Authorization"];
      // console.log("Checking URL1...", URL);
      dispatch(setLoader(true));
      const shortURLRes = await axios.post(
        "https://api.in.kaleyra.io/v1/HXIN1716198528IN/url-shortner/",
        null,
        {
          headers: {
            "api-key": "A998ed76ca2c9e60c3e4ea39719c7b1ea",
          },
          params: {
            url: URL,
          },
        }
      );
      dispatch(setLoader(false));
      axios.defaults.headers.common["Authorization"] = `Bearer ` + getToken;
      if (!Object.keys(shortURLRes?.data?.error)?.length) {
        // console.log("shortURLRes...", shortURLRes);
        const payload = {
          name: caseProfile?.name,
          amount: amount?.toLocaleString("en-IN"),
          url: shortURLRes?.data?.data[0]?.txtly,
        };
        dispatch(setLoader(true));
        const res = await axios.post(
          `/sendSmsForPayment/${paymentId}/${caseProfile?.mobile}`,
          payload
        );
        dispatch(setLoader(false));
        if (res?.data?.msgKey === "Success") {
          dispatch(getCommunicationHistory(lanId));
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `${res?.data?.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.response?.data?.error?.error || error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  useEffect(() => {
    dispatch(getCaseByLanId(lanId)).then((res) => {
      setUserData(res.payload);
    });
  }, []);
  useEffect(() => {
    getAPI();
  }, []);
  const sendMailforDownloadPaymentRecipt = (item) => {
    // console.log(item, "item")
    const URL =
      window.location.origin +
      window.location.pathname +
      "#" +
      "/download_Payment_recipt" +
      `/${item?.paymentId}`;
    const payload = {
      paymentId: item?.paymentId,
      name: userData?.name,
      email: userData?.email,
      // email: "akash.kumar@gofintech.co.in",
      amount: item?.amount?.toLocaleString("en-IN"),
      url: URL,
      date: item?.paymentDate,
    };
    try {
      dispatch(setLoader(true));
      axios.post("/sendPaymentSuccessMail", payload).then((res) => {
        dispatch(setLoader(false));
        if (res?.data?.msgKey === "Success") {
          dispatch(getCommunicationHistory(lanId));
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `${res?.data?.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      });
    } catch (error) {
      dispatch(setLoader(false));
    }
  };
  // console.log(paymentData, "paymentDatapaymentDatapaymentData")
  // date formate function
  function formatDate(inputDate) {
    const parts = inputDate.split("-");
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return day + "-" + month + "-" + year;
  }
  return (
    <Dialog
      header="Payment Details"
      visible={openPyamentTable}
      style={{ minWidth: "60vw" }}
      onHide={() => setOpenPaymentTable(false)}
    >
      <div
        className="mb-2 d-flex justify-content-end"
        style={{ marginLeft: "30%" }}
      >
        {/* <Button  color="success">Send Repayment Information</Button> */}
        <Button
          size="sm"
          color="primary"
          onClick={() => handleAdd()}
          disabled={caseProfile?.forCloserRequestStatus === "approved"}
        >
          Add
        </Button>
      </div>
      {/* {console.log(paymentData, 'gyugy')} */}
      <div typeof="Box">
        <CardBody>
          <DataTable
            showGridlines
            value={paymentData}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80, "All"]}
            tableStyle={{ minWidth: "50rem" }}
            globalFilterFields={["natureofServiceId", "status"]}
          >
            <Column
              field="name"
              header="Name"
              className="text-nowrap"
              body={(rowData) => {
                return `${rowData?.user?.firstName} ${rowData?.user?.lastName}`;
              }}
            />
            <Column
              field="code"
              header="Date/Time"
              className="text-nowrap"
              body={(rowData) => {
                return new Date(rowData?.lastModifiedTime).toLocaleString();
                // return moment(rowData?.lastModifiedTime).format(
                //   "YYYY-MM-DD HH:mm:ss"
                // );
              }}
            />
            <Column
              // field="amount"
              header="Amount"
              className="text-nowrap"
              body={(rowData) => {
                return rowData?.amount?.toLocaleString("en-IN", {
                  style: "currency",
                  currency: "INR",
                });
              }}
            />
            <Column field="paymentType" header="Type" className="text-nowrap" />
            <Column
              field="paymentCategory"
              header="Category"
              className="text-nowrap"
            />
            <Column
              field="chequeNumber"
              header="Cheque Number"
              className="text-nowrap"
            />
            {/* <Column
              field="referenceNumber"
              header="Reference number"
              className="text-nowrap"
            />
            <Column
              field="demandDraftNumber"
              header="Demand draft number"
              className="text-nowrap"
            /> */}
            <Column
              field="paymentMode"
              header="Payment Mode"
              className="text-nowrap"
            />
            <Column
              // field="paymentDate"
              header="Date Of Payment"
              className="text-nowrap"
              body={(rowData) => {
                return formatDate(rowData?.paymentDate);
              }}
            />
            {/* <Column
              field="timeOfPayment"
              header="Time Of Payment"
              className="text-nowrap"
            /> */}
            <Column
              field="paymentStatus"
              header="Status"
              className="text-nowrap"
            />
            <Column
              header="Download"
              className="text-nowrap"
              align={"center"}
              body={(row) => {
                if (row?.paymentStatus === "Pending") {
                  return (
                    <i
                      className="bi bi-download text-primary"
                      role="button"
                    ></i>
                  );
                } else {
                  // console.log(row, "payment uuu")
                  return (
                    <PDFDownloadLink
                      document={<PaymentReport paymentId={row?.paymentId} />}
                      fileName="paymentReceipt"
                      onClick={() => {
                        const payload = {
                          userName: user?.userName,
                          module: "Cases",
                          activity: `${user?.userName} download payment receipt of application number: ${lanId}`,
                        };
                        addAudit(payload);
                      }}
                    >
                      {/* {({ loading }) =>
                        loading ? (
                          // <button>text</button>
                          <></>
                        ) : ( */}
                      <i
                        className="bi bi-download text-primary"
                        role="button"
                      ></i>
                      {/* )
                      } */}
                    </PDFDownloadLink>
                  );
                }
              }}
            />
            <Column
              header="Send Receipt"
              className="text-nowrap"
              body={(item) => (
                <Button
                  size="sm"
                  color="info"
                  className="d-flex mx-auto text-white"
                  onClick={() =>
                    sendMailforDownloadPaymentRecipt(
                      // item?.amount,
                      // item?.paymentId,
                      // item?.paymentDate
                      item
                    )
                  }
                  disabled={
                    !["Success", "Approved"].includes(item.paymentStatus) ||
                    caseProfile?.forCloserRequestStatus === "approved"
                  }
                >
                  Email
                </Button>
              )}
            />
            <Column
              header="SMS Receipt"
              className="text-nowrap"
              body={(item) => {
                return (
                  <Button
                    size="sm"
                    color="info"
                    className="d-flex mx-auto text-white"
                    onClick={() => {
                      handleSMS(item?.paymentId, item?.amount);
                    }}
                    disabled={
                      !["Success", "Approved"].includes(item.paymentStatus) ||
                      caseProfile?.forCloserRequestStatus === "approved"
                    }
                  >
                    SMS
                  </Button>
                );
              }}
            />
            <Column
              field="userGeoCoOrdinates"
              header="Location"
              className="text-nowrap"
            />
            <Column
              header="Action"
              body={(rowData) => {
                return (
                  <ButtonGroup>
                    {/* <i
                      className={`bi bi-eye-fill text-primary`}
                      style={{ cursor: "pointer" }}
                      onClick={(e) => {
                        // setData({ ...rowData });
                        // setPtpFormModal(true);
                        // setFormType("View");
                      }}
                    />
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b> */}
                    <i
                      className={`bi bi-pencil-square text-danger ${
                        ["Success", "Approved", "Rejected", "Offline"].includes(
                          rowData?.paymentStatus
                        ) || caseProfile?.forCloserRequestStatus === "approved"
                          ? styles.disabledEditBtn
                          : styles?.enableEditBtn
                      }`}
                      onClick={() => {
                        if (
                          !(
                            [
                              "Success",
                              "Approved",
                              "Rejected",
                              "Offline",
                            ].includes(rowData?.paymentStatus) ||
                            caseProfile?.forCloserRequestStatus === "approved"
                          )
                        ) {
                          setSelectedData(rowData);
                          setOpenPayment(true);
                          setisEdit(true);
                        }
                      }}
                    />
                  </ButtonGroup>
                );
              }}
            />
          </DataTable>
        </CardBody>
      </div>
      {/* {console.log(Object.keys(selectedData), "selected data")} */}
      <Dialog
        header={isEdit == true ? "Edit Payment" : "Add Payment"}
        visible={openPyament}
        style={{ minWidth: "50vw" }}
        onHide={() => {
          setOpenPayment(false);
          setSelectedData({});
          setisEdit(false);
        }}
      >
        <Payment
          cancelModal={() => {
            setOpenPayment(false);
            setSelectedData({});
          }}
          geoData={props?.geoData}
          isView={false}
          isUpdate={false}
          onSuccess={onSuccess}
          paymentCategory="Payment"
          selectedData={selectedData}
        />
      </Dialog>
    </Dialog>
  );
};
export default PaymentTable;
