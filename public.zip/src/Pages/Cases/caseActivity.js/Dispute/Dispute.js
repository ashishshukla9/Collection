import React, { useEffect, useState } from "react";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Row, Col, Button, ButtonGroup } from "reactstrap";
import axios from "axios";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment/moment";
import { useParams } from "react-router-dom";
import DisputeForm from "./DisputeForm";
import { getActivityHistory, updateInProgressCase } from "../../store";
import { setLoader } from "../../../../reducer/globalReducer";

export const Dispute = ({ openDispute, setOpenDispute, module, geoData }) => {
  // console.log(module, geoData, "disute module")
  const [formModal, setFormModal] = useState(false)
  const [formType, setFormType] = useState('')
  const [data, setData] = useState({});
  const [disputeReasonOptions, setDisputeReasonOptions] = useState([]);
  const [disputeData, setDisputeData] = useState([])

  const dispatch = useDispatch();

  const user = useSelector((state) => state.user.data);
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const { lanId } = useParams();

  const getData = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getByDisputeOrRtpLoanAccountNumber/${lanId}`)
      dispatch(setLoader(false))

      if (res?.data?.data?.length > 0) {
        setDisputeData(res?.data?.data)
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  useEffect(() => {
    getData()

    dispatch(setLoader(true))
    axios
      .get("/getAllDisputeReasonMaster")
      .then(({ data }) => {
        dispatch(setLoader(false))
        // console.log(data);
        let tempDispute = [];
        data.data.forEach((dispute) => {
          if (dispute.isActive === "Y") {
            tempDispute.push({
              value: dispute.code,
              label: dispute.description,
            });
          }
        });
        setDisputeReasonOptions([...tempDispute]);
      })
      .catch((error) => {
        dispatch(setLoader(false))
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  }, []);

  return (
    <Dialog
      header="Dispute History"
      visible={openDispute}
      style={{ minWidth: "60vw" }}
      onHide={() => setOpenDispute(false)}
    >
      <Row>
        <Col className="d-flex flex-row-reverse mb-2">
          <Button
            style={{ width: "120px" }}
            color="primary"
            onClick={() => {
              setFormModal(true)
              setFormType('Create')
            }}
            size="sm"
            disabled={caseProfile?.forCloserRequestStatus === "approved"}
          >
            Add{" "}
          </Button>
        </Col>
      </Row>
      <DataTable
        value={disputeData}
        showGridlines
        paginator
        className="commonTable"
        rows={10}
        rowsPerPageOptions={[10, 20, 40, 80, "All"]}
        tableStyle={{ minWidth: "50rem" }}
      >
        <Column
          field="user.userName"
          header="Name"
          body={(rowData) => {
            return rowData.user.firstName + " " + rowData.user.lastName;
          }}
        />
        <Column field="disputeType" header="Dispute Record" />
        <Column field="amount" header="Amount" />
        <Column
          field="lastModifiedTime"
          header="Time"
          body={(rowData) => {
            return moment(rowData.lastModifiedTime).format(
              "YYYY-MM-DD HH:mm:ss"
            );
          }}
        />
        <Column field="disputeReason" header="Reason" />
        <Column
          header="Action"
          body={(rowData) => {
            return (
              <ButtonGroup>
                {/* {["V", "F"].includes(user?.masterRole[props.access]) && ( */}
                <i
                  className="bi bi-eye-fill text-primary"
                  style={{ cursor: "pointer" }}
                  onClick={(e) => {
                    setData({ ...rowData });
                    setFormModal(true)
                    setFormType('View')
                  }}
                />
                {/* )} */}
                {/* {user?.masterRole[props.access] === "F" && ( */}
                {/* && caseProfile?.forCloserRequestStatus !== "approved" rmove by me added the offline condition */}
                {rowData?.status !== "Approved" || rowData?.status !== "Offline" &&
                  <>
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                    {/* )} */}
                    {/* {["E", "F"].includes(user?.masterRole[props.access]) && ( */}
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={(e) => {
                        setData({ ...rowData });
                        setFormModal(true)
                        setFormType('Edit')
                      }}
                    />
                  </>
                }
                {/* )} */}
              </ButtonGroup>
            );
          }}
        />
        <Column field="status" header="Status" />
      </DataTable>

      {formModal &&
        <DisputeForm
          geoData={geoData}
          formType={formType}
          visible={formModal}
          onClose={() => {
            setFormModal(false)
            setFormType('')
            setData({})
          }}
          disputeReasonOptions={disputeReasonOptions}
          data={data}
          onSuccess={() => {
            getData()
            dispatch(updateInProgressCase(
              { userId: user?.userId, lanId, currentTab: module, role: user?.role[0]?.roleCode, activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType }
            ))
            dispatch(getActivityHistory(lanId))
          }}
        />
      }
    </Dialog>
  );
};
