import { Dialog } from "primereact/dialog"
import { memo, useEffect, useState } from "react"
import { Button, Card, CardBody } from "reactstrap"
import styles from './Dispute.module.scss'
import Swal from "sweetalert2"
import axios from "axios"
import ContactDisputeForm from "../ContactCenter/ContactDisputeForm"
import { setLoader } from "../../../../reducer/globalReducer"
import { useDispatch } from "react-redux"

const DisputeForm = (props) => {
    const [documentDetail, setDocumentDetail] = useState();
    const [editModal, setEditModal] = useState(false);
    const [evidanceFile, setEvidanceFile] = useState();

    const dispatch=useDispatch()
    const handleFileUpate = async () => {
        const formData = new FormData();
        formData.append("disputefile", evidanceFile);

        try {
            const url = `/update-document-dispute/${documentDetail.disputeOrRtpId}`
            const headers = {
                "Content-Type": "multipart/form-data", // Set the Content-Type header
            }
            dispatch(setLoader(true))
            const res = await axios.put(url, formData, { headers })
            dispatch(setLoader(false))
            setEvidanceFile();
            setEditModal(!editModal);
            setDocumentDetail(res?.data?.data);
            Swal.fire({
                position: "top-end",
                icon: "success",
                title: "File Updated Succefully.",
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    };
    
    return (
        <Dialog
            header={`${props?.formType} Dispute Record`}
            visible={props?.visible}
            onHide={() => props?.onClose()}
            className={styles?.modalContainer}
        >
            <Card className="bg-light">
                <CardBody>
                    <ContactDisputeForm 
                    geoData={props?.geoData}
                        formType={props?.formType}
                        data={props?.data}
                        onClose={()=>props?.onClose()}
                        onSuccess={()=>props?.onSuccess()}
                        editModal={editModal}
                        setEditModal={setEditModal}
                        setDocumentDetail={setDocumentDetail}
                        documentDetail={documentDetail}
                    />
                </CardBody>

                <Dialog
                    header="Edit Evidence File"
                    visible={editModal}
                    style={{ width: "20vw" }}
                    onHide={() => {
                        setEditModal(!editModal);
                    }}
                >
                    <label
                        htmlFor="evidence"
                        className="btn-outline-primary btn btn-sm upload-button mb-2"
                    >
                        <i className="bi bi-upload uploadIcon"></i>
                        <span>{evidanceFile?.name || "Evidance"}</span>
                        <input
                            type="file"
                            id="evidence"
                            style={{ display: "none" }}
                            onChange={(event) => {
                                const file = event.target?.files[0];
                                // Handle the selected file here
                                setEvidanceFile(file);
                            }}
                        />
                    </label>
                    {evidanceFile && (
                        <Button
                            size="sm"
                            color="primary"
                            className="d-flex ms-auto"
                            onClick={handleFileUpate}
                        >
                            Update
                        </Button>
                    )}
                </Dialog>
            </Card>
        </Dialog>
    )
}

export default memo(DisputeForm)