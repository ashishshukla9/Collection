import React, { useEffect, useState } from "react";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Row, Col, Button, ButtonGroup } from "reactstrap";
import axios from "axios";
import Swal from "sweetalert2";
import moment from "moment";
import { useParams } from "react-router-dom";
import ExceptionForm from "./ExceptionForm";
import { getActivityHistory, updateInProgressCase } from "../../store";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../../../reducer/globalReducer";

const RiseException = ({ openException, setCloseException, geoData }) => {
//  console.log(geoData, "vjfdhdfhvh")
  const [formModal, setFormModal] = useState(false)
  const [formType, setFormType] = useState('')
  const [exceptionOptions, setExceptionOptions] = useState([]);
  const [data, setData] = useState();
  const [raisedException, setRaisedException] = useState([])

  const user = useSelector((state) => state.user.data);
  const caseProfile = useSelector((state) => state.cases.caseProfile);

  const { lanId } = useParams();
  const dispatch = useDispatch();

  const getAllExceptionType = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllExceptionType")
      dispatch(setLoader(false))

      const options = res?.data?.data?.map(a => {
        if (a?.isActive === "Y") {
          return {
            label: a?.description,
            value: a?.code
          }
        }
      })

      setExceptionOptions(options)
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  const getRaiseExceptionLoanAccountNumber = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getRaiseExceptionLoanAccountNumber/${lanId}`)
      dispatch(setLoader(false))
      setRaisedException(res?.data?.data || [])
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  useEffect(() => {
    getAllExceptionType()
    getRaiseExceptionLoanAccountNumber()
  }, []);

  return (
    <Dialog
      header="Raise Exception"
      visible={openException}
      style={{ minWidth: "60vw" }}
      onHide={() => setCloseException(false)}
    >
      <Row>
        <Col className="d-flex flex-row-reverse mb-2">
          <Button
            style={{ width: "120px" }}
            color="primary"
            onClick={() => {
              setFormModal(true)
              setFormType('Create')
            }}
            size="sm"
            disabled={caseProfile?.forCloserRequestStatus === "approved"}
          >
            Add
          </Button>
        </Col>
      </Row>
      <DataTable
        showGridlines
        paginator
        className="commonTable"
        rows={10}
        rowsPerPageOptions={[10, 20, 40, 80, "All"]}
        tableStyle={{ minWidth: "50rem" }}
        value={raisedException}
      >
        <Column
          field="user.userName"
          header="Name"
          body={(rowData) => {
            return rowData.user.firstName + " " + rowData.user.lastName;
          }}
        />
        <Column
          field="request"
          header="Request"
          body={(rowData) => {
            return exceptionOptions.filter(
              (e) => e.value === rowData.request
            )[0]?.label;
          }}
        />
        <Column
          field="lastModifiedTime"
          header="Date:Time"
          body={(rowData) => {
            return moment(rowData.lastModifiedTime).format(
              "YYYY-MM-DD HH:mm:ss"
            );
          }}
        />
        <Column
          header="Action"
          body={(rowData) => {
            return (
              <ButtonGroup>
                {/* {["V", "F"].includes(user?.masterRole[props.access]) && ( */}
                <i
                  className="bi bi-eye-fill text-primary"
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    setData({ ...rowData });
                    setFormModal(true)
                    setFormType('View')
                  }}
                />
                {/* )} */}
                {/* {user?.masterRole[props.access] === "F" && ( */}
                <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                {/* )} */}
                {/* {["E", "F"].includes(user?.masterRole[props.access]) && ( */}
                <i
                  className="bi bi-pencil-square text-danger"
                  style={{ cursor: "pointer" }}
                  onClick={(e) => {
                    setData({ ...rowData });
                    setFormModal(true)
                    setFormType('Edit')
                  }}
                />
                {/* )} */}
              </ButtonGroup>
            );
          }}
        />
      </DataTable>

      {formModal &&
        <ExceptionForm
          formType={formType}
          visible={formModal}
          onClose={() => {
            setFormModal(false)
            setFormType('')
            setData({})
          }}
          geoData={geoData}
          exceptionOptions={exceptionOptions}
          data={data}
          onSuccess={() => {
            getRaiseExceptionLoanAccountNumber()
            dispatch(updateInProgressCase(
              { userId: user?.userId, lanId, role: user?.role[0]?.roleCode, activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType }
            ))
            dispatch(getActivityHistory(lanId))
          }}
        />
      }
    </Dialog>
  );
};

export default RiseException;
