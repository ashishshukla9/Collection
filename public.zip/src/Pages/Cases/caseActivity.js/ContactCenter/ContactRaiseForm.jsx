import { Formik } from "formik";
import { Button, ButtonGroup, Form, Input } from "reactstrap";
import Field from "../../../../components/Field";
import { DownloadFile } from "../../../../utils/DownloadFile";
import classNames from "classnames";
import { memo, useEffect, useMemo, useState } from "react";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import * as yup from "yup";
import Select from "react-select";
import styles from '../Exception/Exception.module.scss'
import axios from "axios";
import { setLoader } from "../../../../reducer/globalReducer";
const ContactRaiseForm = (props) => {
    const [exceptionOptions, setExceptionOptions] = useState([]);
    const [isevidence, setisEvidence] = useState(false)
    const user = useSelector((state) => state.user.data);
    const dispatch = useDispatch()
    const { lanId } = useParams();
    const isEdit = useMemo(() => props?.formType === "Edit", [])
    const isView = useMemo(() => props?.formType === "View", [])
    const isCreate = useMemo(() => props?.formType === "Create", [])
    const initialValues = {
        request: props?.data?.request || "",
        remark: props?.data?.remark || "",
        evidance: props?.data?.evidance || ""
    }
    const validationSchema = yup.object({
        request: yup.string().required("Required"),
        remark: yup.string().max(250, "Too Long.").required("Required"),
        // evidance: yup.mixed().when('remark', {
        //     is: () => isCreate,
        //     then: () => yup.mixed().required('Required')
        // })
    })
    const handleSubmit = async (values) => {
        const payload = {
            request: values?.request,
            remark: values?.remark,
            isDocument: values?.evidance ? "yes" : "No",
            loanAccountNumber: lanId,
            user
        }
        if (isEdit) {
            try {
                dispatch(setLoader(true))
                const res = await axios.put(`/updateRaiseException/${props?.data?.raiseExceptionId}`, payload)
                dispatch(setLoader(false))
                if (["success", "Success"].includes(res?.data?.msgKey)) {
                    Swal.fire({
                        position: "top-end",
                        icon: "success",
                        title: "Updated Succefully.",
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                    if (!props?.isCancelHidden) {
                        props?.onClose()
                    }
                    props?.onSuccess()
                }
            } catch (error) {
                dispatch(setLoader(false))
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            }
        } else {
            if (props?.isContactCenter) {
                props?.onSuccess('/createRaiseException', payload, values?.evidance)
            } else {
                try {
                    dispatch(setLoader(true))
                    const res = await axios.post('/createRaiseException', { ...payload, geoCoordinates: `${props?.geoData?.lat}, ${props?.geoData?.long}` })
                    dispatch(setLoader(false))
                    if (["success", "Success"].includes(res?.data?.msgKey)) {
                        const formData = new FormData();
                        formData.append('exceptionfile', values?.evidance)
                        if (isevidence == true) {
                            const url = `/upload-document-raise-exception/${res?.data?.data?.raiseExceptionId}`
                            const headers = {
                                "Content-Type": "multipart/form-data", // Set the Content-Type header
                            }
                            dispatch(setLoader(true))
                            const uploadDoc = await axios.post(url, formData, { headers })
                            dispatch(setLoader(false))
                            setisEvidence(false)
                        }
                        Swal.fire({
                            position: "top-end",
                            icon: "success",
                            title: "Record Created.",
                            showConfirmButton: false,
                            toast: true,
                            timer: 3000,
                        });
                        if (!props?.isCancelHidden) {
                            props?.onClose()
                        }
                        props?.onSuccess()
                    }
                } catch (error) {
                    dispatch(setLoader(false))
                    Swal.fire({
                        position: "top-end",
                        icon: "error",
                        title: `${error.message}`,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                }
            }
        }
    }
    const getDocument = async () => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getdocumentRaiseExceptionByRaiseExceptionId/${props?.data?.raiseExceptionId}`)
            dispatch(setLoader(false))
            props?.setDocumentDetail(res?.data)
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }
    useEffect(() => {
        if (props?.data && Object.keys(props?.data).length) {
            getDocument()
        }
    }, []);
    useEffect(() => {
        const getOptions = async () => {
            try {
                dispatch(setLoader(true));
                const res = await axios.get("/getAllExceptionType");
                dispatch(setLoader(false));
                const options = res?.data?.data?.map(a => {
                    if (a?.isActive === "Y") {
                        return {
                            label: a?.description, // Ensure this is defined
                            value: a?.code // Ensure this is defined
                        };
                    }
                    return null; // Return null if not active
                }).filter(Boolean); // Filter out null values
                setExceptionOptions(options);
            } catch (error) {
                dispatch(setLoader(false));
                console.error('Error fetching options:', error);
            }
        };
        getOptions();
    }, []);
    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                handleChange,
                handleBlur,
                touched,
                handleSubmit,
                setFieldValue,
            }) => {
                return (
                    <Form
                        onSubmit={handleSubmit}
                        className={styles.formContainer}
                    >
                        {/* <Field
                            isRequired
                            label="Exception Request"
                            errorMessage={touched.request && errors.request}
                        >
                            <Select
                                inputId="request"
                                name="request"
                                isClearable={true}
                                options={exceptionOptions}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                onChange={(e) => {
                                    setFieldValue("request", e?.value);
                                }}
                                value={exceptionOptions.filter(
                                    (v) => v.value === values.request
                                )}
                                className={classNames({
                                    abc: touched.request && Boolean(errors.request),
                                })}
                                onBlur={handleBlur}
                                menuPosition={"fixed"}
                                isDisabled={isView}
                                classNamePrefix="react-select"
                            />
                        </Field> */}
                        <Field
                            isRequired
                            label="Exception Request"
                            errorMessage={touched.request && errors.request}
                        >
                            <Select
                                inputId="request"
                                name="request"
                                isClearable={true}
                                options={exceptionOptions} // Ensure this is an array with valid objects
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                onChange={(selectedOption) => {
                                    // console.log('Selected option:', selectedOption);
                                    setFieldValue("request", selectedOption ? selectedOption.value : "");
                                }}
                                value={exceptionOptions.find(option => option.value === values.request) || null} // Use find to get the selected option or null
                                className={classNames({
                                    abc: touched.request && Boolean(errors.request), // Apply class based on validation state
                                })}
                                onBlur={handleBlur}
                                menuPosition={"fixed"}
                                isDisabled={isView} // Disable if in view mode
                                classNamePrefix="react-select"
                            />
                        </Field>
                        <Field
                            isRequired
                            label="Remarks"
                            errorMessage={touched.remark && errors.remark}
                        >
                            <Input
                                bsSize="sm"
                                id="remark"
                                type="textarea"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.remark}
                                invalid={touched.remark && Boolean(errors.remark)}
                                disabled={isView}
                            />
                        </Field>
                        {(isView || isEdit) ? (
                            <ButtonGroup style={{ width: "100%" }}>
                                {props?.documentDetail && (
                                    <Button
                                        size="sm"
                                        color="success"
                                        outline
                                        onClick={
                                            () =>
                                                DownloadFile(
                                                    `/downloadDocumentRaiseExceptionByRaiseExceptionId/${props?.documentDetail?.raiseExceptionId}`,
                                                    props?.documentDetail?.name
                                                )
                                        }
                                    >
                                        <i className="bi bi-download me-3"></i>
                                        Download - {props?.documentDetail?.name}
                                    </Button>
                                )}
                                {isView || (
                                    <Button
                                        size="sm"
                                        color="primary"
                                        outline
                                        onClick={() => {
                                            props?.setEditModal(!props?.editModal);
                                        }}
                                    >
                                        <i className="bi bi-pencil-square"></i>
                                        Edit
                                    </Button>
                                )}
                            </ButtonGroup>
                        ) : (
                            <label
                                htmlFor="evidence"
                                className={classNames({
                                    "btn-outline-primary": !(
                                        touched.evidance
                                    ),
                                    "btn btn-sm upload-button": true,
                                    "is-invalid btn-outline-primary":
                                        touched.evidance
                                })}
                            >
                                <i className="bi bi-upload uploadIcon"></i>
                                <span>{values.evidance?.name || "Evidence"}</span>
                                <input
                                    type="file"
                                    id="evidence"
                                    style={{ display: "none" }}
                                    onChange={(event) => {
                                        const file = event.target?.files[0];
                                        setFieldValue("evidance", file);
                                        setisEvidence(true)
                                    }}
                                />
                            </label>
                        )}
                        {(isCreate || isEdit) && (
                            <div className="d-flex justify-content-end">
                                <Button type="submit" color="primary" className="me-1" size="sm">
                                    Submit
                                </Button>
                                {!props?.isCancelHidden &&
                                    <Button
                                        size="sm"
                                        type="button"
                                        color="danger"
                                        onClick={() => props?.onClose()}
                                    >
                                        Cancel
                                    </Button>
                                }
                            </div>
                        )}
                    </Form>
                )
            }}
        </Formik>
    )
}
export default memo(ContactRaiseForm)