import { Formik } from "formik";
import { memo, useEffect, useMemo, useState } from "react";
import { Button, ButtonGroup, Form, Input } from "reactstrap";
import Field from "../../../../components/Field";
import classNames from "classnames";
import Select from "react-select";
import * as yup from "yup";
import Swal from "sweetalert2";
import axios from "axios";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import styles from "../Dispute/Dispute.module.scss";
import { DownloadFile } from "../../../../utils/DownloadFile";
import { getUserTypeData } from "../../../Master/LookupMaster/lookupSlice";
import { setLoader } from "../../../../reducer/globalReducer";

const ContactDisputeForm = (props) => {
  const [disputeReasonOptions, setDisputeReasonOptions] = useState([]);

  const user = useSelector((state) => state.user.data);
  const userTypeData = useSelector((state) => state?.lookup?.userTypeData);

  const { lanId } = useParams();

  const dispatch = useDispatch();

  const isEdit = useMemo(() => props?.formType === "Edit", []);
  const isView = useMemo(() => props?.formType === "View", []);
  const isCreate = useMemo(() => props?.formType === "Create", []);

  const initialValues = {
    amount: props?.data?.amount || "",
    disputeType: props?.data?.disputeType || "",
    disputeReason: props?.data?.disputeReason || "",
    remark: props?.data?.remark || "",
    evidance: props?.data?.evidance || "",
  };

  const validationSchema = yup.object({
    amount: yup.number().required("Required"),
    disputeType: yup.string().required("Required"),
    disputeReason: yup.string().required("Required"),
    remark: yup.string().max(250, "Too Long.").required("Required"),
    // evidance: yup.mixed().when('remark', {
    //     is: () => isCreate,
    //     then: () => yup.mixed().required('Required')
    // })
  });

  const handleSubmit = async (values) => {
    const isAddRequest = Boolean(
      disputeReasonOptions?.filter(
        (a) =>
          a?.value === values?.disputeReason &&
          a?.label?.toLowerCase() === "Wants to speak to manager"?.toLowerCase()
      )?.length
    );
    const checkIsrequestPermission = ["F", "E"].includes(
      user?.masterRole?.requestmanagement_requestmanagement
    );

    const payload = {
      amount: values?.amount,
      disputeType: values?.disputeType,
      disputeReason: values?.disputeReason,
      remark: values?.remark,
      loanAccountNumber: lanId,
      isDocument: values?.evidance ? "yes" : "No",
      user,
      status:
        isAddRequest && !checkIsrequestPermission ? "Pending" : "Approved",
    };

    if (isEdit) {
      try {
        dispatch(setLoader(true));
        const res = await axios.put(
          `/updateDisputeOrRtp/${props?.data?.disputeOrRtpId}`,
          payload
        );
        dispatch(setLoader(false));

        if (["success", "Success"].includes(res?.data?.msgKey)) {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Updated Succefully.",
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });

          if (!props?.isCancelHidden) {
            props?.onClose();
          }
          props?.onSuccess();
        }
      } catch (error) {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } else {
      if (props?.isContactCenter) {
        props?.onSuccess(
          "/createDisputeOrRtp",
          payload,
          values?.evidance,
          isAddRequest
        );
      } else {
        try {
          dispatch(setLoader(true));
          const res = await axios.post("/createDisputeOrRtp", {
            ...payload,
            geoCoordinates: `${props?.geoData?.lat}, ${props?.geoData?.long}`,
          });
          dispatch(setLoader(false));
          if (["success", "Success"].includes(res?.data?.msgKey)) {
            if (values?.evidance) {
              const formData = new FormData();
              formData.append("disputefile", values?.evidance);
              const url = `/upload-document-dispute/${res?.data?.data?.disputeOrRtpId}`;
              const headers = {
                "Content-Type": "multipart/form-data", // Set the Content-Type header
              };

              dispatch(setLoader(true));
              const uploadDoc = await axios.post(url, formData, { headers });
              dispatch(setLoader(false));
            }

            if (isAddRequest) {
              if (!checkIsrequestPermission) {
                const userType = {};
                userTypeData?.map((a) =>
                  Object.assign(userType, {
                    [a?.code]: `${a?.description}_Agent`,
                  })
                );
                const userRole = user?.role?.map((a) =>
                  a?.roleCode?.toLowerCase()
                );
                const requestPayload = {
                  activityId: res?.data?.data?.disputeOrRtpId,
                  activityType: "Dispute",
                  lan: lanId,
                  status: checkIsrequestPermission ? "Success" : "Pending",
                  remark: "",
                  isDocument: values?.evidance ? "yes" : "No",
                  selectedFieldAgentId: "",
                  requestRaisedUserId: user?.userId,
                  reportingManagerOfUser: "",
                  userType: userRole?.includes("ca")
                    ? "CA"
                    : userRole?.includes("dra")
                    ? "DRA"
                    : userRole.includes("atl")
                    ? "ATL"
                    : userType[user?.userType],
                  requestid: new Date().getTime().toString().slice(-5),
                };

                dispatch(setLoader(true));
                const requestRes = await axios.post(
                  "/addRequestManagement",
                  requestPayload
                );
                dispatch(setLoader(false));
              }
            }

            if (!props?.isCancelHidden) {
              props?.onClose();
            }
            props?.onSuccess();

            Swal.fire({
              position: "top-end",
              icon: "success",
              title: "Record Created.",
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } catch (error) {
          dispatch(setLoader(false));
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      }
    }
  };

  const getDocument = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `/getdocumentDisputeByDisputeOrRtpId/${props?.data?.disputeOrRtpId}`
      );
      dispatch(setLoader(false));
      props?.setDocumentDetail(res?.data);
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  useEffect(() => {
    if (props?.data && Object.keys(props?.data).length) {
      getDocument();
    }
  }, []);

  useEffect(() => {
    const getDisputeReasonOptions = async () => {
      try {
        dispatch(setLoader(true));
        const res = await axios.get("/getAllDisputeReasonMaster");
        dispatch(setLoader(false));
        const options = [];
        res?.data?.data?.map((a) => {
          options?.push({
            value: a?.code,
            label: a?.description,
          });
        });
        setDisputeReasonOptions(options);
      } catch (error) {
        dispatch(setLoader(false));
      }
    };

    getDisputeReasonOptions();
  }, []);

  useEffect(() => {
    dispatch(getUserTypeData());
  }, []);

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({
        values,
        errors,
        handleChange,
        handleBlur,
        touched,
        handleSubmit,
        setFieldValue,
      }) => {
        return (
          <Form onSubmit={handleSubmit} className={styles.formContainer}>
            <Field
              isRequired
              label="Amount"
              errorMessage={touched.amount && errors.amount}
            >
              <Input
                bsSize="sm"
                id="amount"
                type="number"
                value={values?.amount}
                onChange={(e) => {
                  if (e?.target?.value?.length < 19) {
                    setFieldValue("amount", Number(e.target.value));
                  }
                }}
                onBlur={handleBlur}
                invalid={touched?.amount && Boolean(errors?.amount)}
                disabled={isView}
              />
            </Field>
            <Field
              isRequired
              label="Dispute Record"
              errorMessage={touched.disputeType && errors.disputeType}
            >
              <div className={styles?.disputeTypeBtnGrp}>
                <Button
                  name="disputeType"
                  color="primary"
                  outline
                  type="button"
                  value={"RTP"}
                  onClick={handleChange}
                  active={values?.disputeType === "RTP"}
                  size="sm"
                  disabled={isView}
                >
                  RTP
                </Button>
                <Button
                  name="disputeType"
                  color="primary"
                  outline
                  type="button"
                  value={"Dispute"}
                  onClick={handleChange}
                  active={values?.disputeType === "Dispute"}
                  size="sm"
                  disabled={isView}
                >
                  Dispute
                </Button>
              </div>
            </Field>
            <Field
              isRequired
              label="Dispute Reason"
              errorMessage={touched.disputeReason && errors.disputeReason}
            >
              <Select
                // inputId="disputeReason"
                name="disputeReason"
                isClearable={true}
                options={disputeReasonOptions}
                closeMenuOnSelect={true}
                hideSelectedOptions={false}
                onChange={(e) => {
                  setFieldValue("disputeReason", e?.value);
                }}
                value={disputeReasonOptions.filter(
                  (v) => v.value === values.disputeReason
                )}
                className={classNames({
                  abc: touched.disputeReason && Boolean(errors.disputeReason),
                })}
                onBlur={handleBlur}
                menuPosition={"fixed"}
                isDisabled={isView}
                classNamePrefix="react-select"
              />
            </Field>
            <Field
              isRequired
              label="Remarks"
              errorMessage={touched.remark && errors.remark}
            >
              <Input
                bsSize="sm"
                id="remark"
                type="textarea"
                value={values?.remark}
                onChange={handleChange}
                onBlur={handleBlur}
                invalid={touched.remark && Boolean(errors.remark)}
                disabled={isView}
              />
            </Field>

            {isView || isEdit ? (
              <ButtonGroup>
                {props?.documentDetail && (
                  <Button
                    color="success"
                    size="sm"
                    outline
                    onClick={() =>
                      DownloadFile(
                        `/download-Dispute-file/${props?.documentDetail?.disputeOrRtpId}`,
                        props?.documentDetail?.name
                      )
                    }
                  >
                    <i className="bi bi-download me-3"></i>
                    Download - {props?.documentDetail?.name}
                  </Button>
                )}
                {(isCreate || isEdit) && (
                  <Button
                    size="sm"
                    color="primary"
                    outline
                    onClick={() => {
                      props?.setEditModal(!props?.editModal);
                    }}
                  >
                    <i className="bi bi-pencil-square"></i>
                    Edit
                  </Button>
                )}
              </ButtonGroup>
            ) : (
              <label
                htmlFor="evidence"
                className={classNames({
                  "btn-outline-primary": !(
                    touched?.evidance && Boolean(errors?.evidance)
                  ),
                  "btn btn-sm upload-button": true,
                  "is-invalid btn-outline-danger":
                    touched?.evidance && Boolean(errors?.evidance),
                })}
              >
                <i className="bi bi-upload uploadIcon"></i>
                <span>{values.evidance?.name || "Evidence"}</span>
                <input
                  type="file"
                  id="evidence"
                  style={{ display: "none" }}
                  onChange={(event) => {
                    const file = event.target?.files[0];
                    // Handle the selected file here
                    setFieldValue("evidance", file);
                  }}
                />
              </label>
            )}
            {(isCreate || isEdit) && (
              <div className="d-flex justify-content-end">
                <Button
                  type="submit"
                  color="primary"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>
                {!props?.isCancelHidden && (
                  <Button
                    size="sm"
                    type="button"
                    color="danger"
                    onClick={() => props?.onClose()}
                  >
                    Cancel
                  </Button>
                )}
              </div>
            )}
          </Form>
        );
      }}
    </Formik>
  );
};

export default memo(ContactDisputeForm);
