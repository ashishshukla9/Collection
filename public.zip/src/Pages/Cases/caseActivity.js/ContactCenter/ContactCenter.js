import React, { useEffect, useState } from "react";
import { Dialog } from "primereact/dialog";
import { Row, Col } from "reactstrap";
import ContactSummary from "./ContactSummary";
import ConnectedTable from "./ConnectedTable";
import ContactAddress from "./ContactAddress";
import axios from "axios";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import ContactEmail from "./ContactEmail";
import ContactReference from "./ContactReference";
import {
  getActivityHistory,
  getCallHistory,
  updateInProgressCase,
} from "../../store";
import { setLoader } from "../../../../reducer/globalReducer";
const ContactCenter = (props) => {
  const { openContect, setCloseContect } = props;
  const [openContectSummary, setopenContectSummary] = useState(false);
  const [contactCenterId, setContactCenterId] = useState("");
  const { lanId } = useParams();
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user.data);
  const onSuccess = () => {
    dispatch(
      updateInProgressCase({
        userId: user?.userId,
        lanId,
        role: user?.role[0]?.roleCode,
        activityType: user?.activityType,
      })
    );
    dispatch(getActivityHistory(lanId));
    dispatch(getCallHistory(lanId));
  };
  useEffect(() => {
    async function getAllContactCenters() {
      try {
        dispatch(setLoader(true));
        const res = await axios.get("/getAllContactCentres");
        dispatch(setLoader(false));
        const allLanId = res?.data?.data?.map((a) => a?.loanAccountNumber);
        if (!allLanId?.includes(lanId)) {
          const payload = {
            loanAccountNumber: lanId,
            user: {
              userId: user?.userId,
              firstName: user?.firstName,
              lastName: user?.lastName,
              mobileno: user?.mobileNo,
              email: user?.email,
              organisationName: user?.organisationName,
              userType: user?.userType,
              reportingManager: user?.reportingManager,
              status: user?.status,
              designation: user?.designation,
              sendWelcome: user?.sendWelcome,
              userName: user?.userName,
              password: user?.password,
              isActive: user?.isActive,
              expired: user?.expired,
              createdTime: user?.createdTime,
              lastModifiedTime: user?.lastModifiedTime,
              succsessfulLoginCount: user?.succsessfulLoginCount,
              failedLoginCount: user?.failedLoginCount,
              lastLoggedOn: user?.lastLoggedOn,
              lender: user?.lender,
              activityType: user?.activityType,
              maxTicketSize: user?.maxTicketSize,
              minTicketSize: user?.minTicketSize,
              maxBucket: user?.maxBucket,
              minBucket: user?.minBucket,
            },
          };
          dispatch(setLoader(true));
          const res2 = await axios.post("/addContactCentre", payload);
          dispatch(setLoader(false));
          setContactCenterId(res2?.data?.data?.contactCentreId);
        } else {
          const ccId = res?.data?.data
            ?.filter((a) => a?.loanAccountNumber === lanId)
            ?.map((a) => a?.contactCentreId)[0];
          setContactCenterId(ccId);
        }
      } catch (error) {
        dispatch(setLoader(false));
      }
    }
    getAllContactCenters();
  }, []);
  return (
    <Dialog
      header="Contact Centre"
      visible={openContect}
      onHide={() => setCloseContect(false)}
      style={{ width: "700px" }}
    >
      <ConnectedTable
        contactCenterId={contactCenterId}
        onSuccess={onSuccess}
        masking={props?.masking}
      />
      <ContactAddress contactCenterId={contactCenterId} onSuccess={onSuccess} />
      <Row lg={12} md={12} sm={12}>
        <Col lg={6} md={6} sm={6}>
          <ContactEmail
            contactCenterId={contactCenterId}
            onSuccess={onSuccess}
          />
        </Col>
        <Col lg={6} md={6} sm={6}>
          <ContactReference
            contactCenterId={contactCenterId}
            onSuccess={onSuccess}
          />
        </Col>
      </Row>
      {openContectSummary && (
        <ContactSummary
          openContectSummary={openContectSummary}
          setopenContectSummary={setopenContectSummary}
        />
      )}
    </Dialog>
  );
};
export default ContactCenter;