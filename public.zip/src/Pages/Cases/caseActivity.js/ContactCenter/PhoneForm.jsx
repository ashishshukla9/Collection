import { Formik } from "formik";
import { memo } from "react";
import { Button, Form, Input } from "reactstrap";
import * as yup from "yup";
import Field from "../../../../components/Field";
import { NUMBER_ONLY } from "../../../../utils/regex";
import axios from "axios";
import Swal from "sweetalert2";
const PhoneForm = (props) => {
  const validationSchema = yup.object({
    contactNumber: yup
      .string()
      //   .matches(/^[0-9]{10}$/, "Invalid mobile number") // Matches only 10 digits
      .required("Mobile number is required")
      .max(10, "Please enter only 10 digits"), // Max 10 digits validation
    contactName: yup.string().required("Contact Name is Required"),
  });
  const handleSubmit = async (values) => {
    try {
      const payload = {
        contactNumber: values?.contactNumber,
        contactName: values?.contactName,
        contactCentre: props?.contactCentre,
      };
      const res = await axios.post("/addContactCentreMobileNumbers", payload);
      props?.onSuccess();
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  return (
    <Formik
      initialValues={{
        contactNumber: "",
        contactName: "",
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({
        values,
        errors,
        touched,
        handleSubmit,
        onSubmit,
        setFieldValue,
        handleBlur,
        handleChange,
        isSubmitting,
      }) => {
        return (
          <Form onSubmit={handleSubmit} autoComplete="off">
            <Field
              isRequired
              label="Contact Number"
              errorMessage={touched?.contactNumber && errors?.contactNumber}
            >
              <Input
                bsSize="sm"
                id="contactNumber"
                placeholder="Enter Mobile Number"
                value={values?.contactNumber}
                onChange={(e) => {
                  if (NUMBER_ONLY?.test(e?.target?.value)) {
                    setFieldValue("contactNumber", e?.target?.value);
                  } else if (!e?.target?.value) {
                    setFieldValue("contactNumber", e?.target?.value);
                  }
                }}
                invalid={
                  touched?.contactNumber && Boolean(errors?.contactNumber)
                }
                onBlur={handleBlur}
                maxLength={10}
              />
            </Field>
            <Field
              isRequired
              label="Contact Name"
              errorMessage={touched?.contactName && errors?.contactName}
            >
              <Input
                bsSize="sm"
                id="contactName"
                placeholder="Enter Contact Name"
                value={values?.contactName}
                onChange={handleChange}
                invalid={touched?.contactName && Boolean(errors?.contactName)}
                onBlur={handleBlur}
                maxLength={10}
              />
            </Field>
            <div className="d-flex justify-content-end gap-2">
              <Button type="submit" color="primary" size="sm">
                Save
              </Button>
              <Button
                type="button"
                size="sm"
                onClick={() => props?.handleClose()}
              >
                Cancel
              </Button>
            </div>
          </Form>
        );
      }}
    </Formik>
  );
};
export default memo(PhoneForm);