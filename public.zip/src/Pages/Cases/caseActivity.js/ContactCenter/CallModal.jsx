import { Formik, useFormik } from "formik"
import { Fragment, memo, useEffect, useMemo, useState } from "react"
import { Button, Form, Input } from "reactstrap"
import Field from "../../../../components/Field"
import * as yup from "yup";
import styles from './ContactCenter.module.scss'
import { NUMBER_ONLY } from "../../../../utils/regex";
import Select, { components } from "react-select";
import classNames from "classnames";
import PTPForm from "../PTP/PTPForm";
import Payment from "../Payment/Payment";
import Swal from "sweetalert2";
import axios from "axios";
import ContactDisputeForm from "./ContactDisputeForm";
import ContactRaiseForm from "./ContactRaiseForm";
import PaymentInfoData from "../PaymentInfo/PaymentInfoData";
import { useDispatch, useSelector } from "react-redux";
import { getActivityHistory, getCallHistory, updateInProgressCase } from "../../store";
import { useParams } from "react-router-dom";
import { getUserTypeData } from "../../../Master/LookupMaster/lookupSlice";
import { setLoader } from "../../../../reducer/globalReducer";

const CallModal = (props) => {
    const [documentDetail, setDocumentDetail] = useState({});

    const dispatch = useDispatch()

    const user = useSelector((state) => state.user.data);
    const caseProfile = useSelector((state) => state.cases.caseProfile);
    const userTypeData = useSelector(state => state?.lookup?.userTypeData)

    const { lanId } = useParams();

    const callStatus = useMemo(() => [
        { label: 'Connected', value: "Connected" },
        { label: 'Not Connected', value: "Not Connected" }
    ], [])
    const connectedCallOutcome = useMemo(() => [
        { label: 'PTP', value: "PTP" },
        { label: 'Payment', value: "Payment" },
        { label: 'Dispute/RTP', value: "Dispute/RTP" },
        { label: 'Raise Exception', value: "Raise Exception" },
        { label: 'Repayment Info', value: "Repayment Info" },
        { label: 'Call Back', value: "Call Back" },
        { label: 'Left Message', value: "Left Message" },
        { label: 'Broken Settlement', value: "Broken Settlement" },
        { label: 'Broken Foreclosure', value: "Broken Foreclosure" },

       


    ], [])
    
    
    const notConnectedCallOutcome = useMemo(() => [
        { label: 'WRONG NUMBER', value: "WRONG NUMBER" },
        // { label: 'LEFT MESSAGE', value: "LEFT MESSAGE" },
        { label: 'NOT REACHABLE', value: "NOT REACHABLE" },
        { label: 'CUSTOMER BUSY', value: "CUSTOMER BUSY" },
        { label: 'VISIT PENDING', value: "VISIT PENDING" },
        { label: 'NOT SERVICEABLE AREA', value: "NOT SERVICEABLE AREA" },
        { label: 'ADDRESS NOT FOUND // SHORT ADD/ WRONG ADD', value: "ADDRESS NOT FOUND// SHORT ADD/ WRONG ADD" },
        { label: 'OUT OF STATION', value: "OUT OF STATION" },
        { label: 'DOOR LOCK/REVISIT', value: "DOOR LOCK/REVISIT" },
        { label: 'ENTRY RESTRICTED', value: "ENTRY RESTRICTED" },
        { label: 'RINGING NO RESPONSE', value: "RINGING NO RESPONSE" },
        { label: 'SWITCHED OFF', value: "SWITCHED OFF" },
    ], [])

    const validationSchema = yup.object({
        callStatus: yup.object().required("Required"),
        callOutcome: yup.object().required("Required")
    })

    const addCallSummary = async (contactCentreMobileNumbersId, formUrl, formPayload, file, isAddRequest) => {
        try {
            const checkIsrequestPermission = ['F', 'E'].includes(user?.masterRole?.requestmanagement_requestmanagement)
            const { values } = formik;
            let callDuration = [values?.callDuration?.hh?.toString() || '00', values?.callDuration?.mm?.toString() || '00', values?.callDuration?.ss?.toString() || '00']
            callDuration = callDuration?.map(a => ('0' + a)?.toString()?.slice(-2))
            callDuration = callDuration.join(':')

            const payload = {
                callDuration: callDuration,
                callStatus: values?.callStatus?.value,
                callOutcome: values?.callOutcome?.value,
                followUpCall: values?.followUp,
                remark: values?.remark
            }
            const url = `/updateContactCentreMobileByContactCentreMobileNumbersId/${contactCentreMobileNumbersId}`
            dispatch(setLoader(true))
            const res = await axios.put(url, payload)
            dispatch(setLoader(false))

            if (res?.data?.msgKey === "Success") {
                const callHistoryPayload = {
                    name: caseProfile?.name,
                    number: res?.data?.data?.contactNumber,
                    status: values?.callStatus?.value,
                    callDuration: `${values?.callDuration?.hh || '00'}:${values?.callDuration?.mm || '00'}:${values?.callDuration?.ss || '00'}`,
                    callOutcome: values?.callOutcome?.value,
                    contactCentreMobileNumbersId: contactCentreMobileNumbersId,
                    lan: lanId,
                    userId: user?.userId,
                    remark: values?.remark,
                    followUp: values?.followUp
                }

                dispatch(setLoader(true))
                const callHistoryRes = await axios.post('/addCallHistory', callHistoryPayload)
                dispatch(setLoader(false))

                if (callHistoryRes?.data?.msgKey === "Success") {
                    if (formUrl && formPayload) {
                        dispatch(setLoader(true))
                        const formRes = await axios.post(formUrl, { ...formPayload, callHistory: callHistoryRes?.data?.data })
                        dispatch(setLoader(false))

                        const headers = {
                            "Content-Type": "multipart/form-data", // Set the Content-Type header
                        }
                        if (values?.callOutcome?.value === "Payment") {
                            if (["success", "Success"].includes(formRes?.data?.msgKey)) {
                                if (file) {
                                    const formData = new FormData();
                                    formData.append('paymentfile', file)
                                    dispatch(setLoader(true))
                                    const fileRes = await axios.post(`/upload-document-payment/${formRes?.data?.data?.paymentId}`, formData, { headers })
                                    dispatch(setLoader(false))
                                }

                                if (!checkIsrequestPermission) {
                                    const userType = {}
                                    userTypeData?.map(a => Object.assign(userType, { [a?.code]: `${a?.description}_Agent` }))
                                    const userRole = user?.role?.map(a => a?.roleCode?.toLowerCase())

                                    const requestPayload = {
                                        activityId: formRes?.data?.data?.paymentId,
                                        activityType: "Payment",
                                        lan: lanId,
                                        status: formRes?.data?.data?.paymentStatus,
                                        remark: '',
                                        selectedFieldAgentId: '',
                                        requestRaisedUserId: user?.userId,
                                        reportingManagerOfUser: '',
                                        userType: userRole?.includes('ca') ? 'CA' : userRole?.includes('dra') ? 'DRA' : userRole.includes('atl') ? 'ATL' : userType[user?.userType],
                                        requestid: new Date().getTime().toString().slice(-5)
                                    }

                                    dispatch(setLoader(true))
                                    const requestRes = await axios.post('/addRequestManagement', requestPayload)
                                    dispatch(setLoader(false))
                                }
                            }
                        } else if (values?.callOutcome?.value === "Dispute/RTP") {
                            if (["success", "Success"].includes(res?.data?.msgKey)) {
                                if (file) {
                                    const formData = new FormData();
                                    formData.append('disputefile', file)
                                    const url = `/upload-document-dispute/${formRes?.data?.data?.disputeOrRtpId}`
                                    dispatch(setLoader(true))
                                    const uploadDoc = await axios.post(url, formData, { headers })
                                    dispatch(setLoader(false))
                                }

                                if (isAddRequest && !checkIsrequestPermission) {
                                    const userType = {}
                                    userTypeData?.map(a => Object.assign(userType, { [a?.code]: `${a?.description}_Agent` }))
                                    const userRole = user?.role?.map(a => a?.roleCode?.toLowerCase())
                                    const requestPayload = {
                                        activityId: formRes?.data?.data?.disputeOrRtpId,
                                        activityType: "Dispute",
                                        lan: lanId,
                                        status: checkIsrequestPermission ? "Success" : "Pending",
                                        remark: '',
                                        selectedFieldAgentId: '',
                                        requestRaisedUserId: user?.userId,
                                        reportingManagerOfUser: '',
                                        userType: userRole?.includes('ca') ? 'CA' : userRole?.includes('dra') ? 'DRA' : userRole.includes('atl') ? 'ATL' : userType[user?.userType],
                                        requestid: new Date().getTime().toString().slice(-5)
                                    }

                                    dispatch(setLoader(true))
                                    const requestRes = await axios.post('/addRequestManagement', requestPayload)
                                    dispatch(setLoader(false))
                                }
                            }
                        } else if (values?.callOutcome?.value === "Raise Exception") {
                            if (["success", "Success"].includes(res?.data?.msgKey)) {
                                if (file) {
                                    const formData = new FormData();
                                    formData.append('exceptionfile', file)
                                    const url = `/upload-document-raise-exception/${formRes?.data?.data?.raiseExceptionId}`
                                    dispatch(setLoader(true))
                                    const uploadDoc = await axios.post(url, formData, { headers })
                                    dispatch(setLoader(false))
                                }
                            }
                        } else if (values?.callOutcome?.value === "PTP") {
                            if (["success", "Success"].includes(formRes?.data?.message)) {
                                if (isAddRequest) {
                                    const userType = {}
                                    userTypeData?.map(a => Object.assign(userType, { [a?.code]: `${a?.description}_Agent` }))
                                    const userRole = user?.role?.map(a => a?.roleCode?.toLowerCase())

                                    const requestPayload = {
                                        activityId: formRes?.data?.data?.ptpId,
                                        activityType: "PTP",
                                        lan: lanId,
                                        status: formRes?.data?.data?.status,
                                        remark: '',
                                        selectedFieldAgentId: '',
                                        requestRaisedUserId: user?.userId,
                                        reportingManagerOfUser: '',
                                        userType: userRole?.includes('ca') ? 'CA' : userRole?.includes('dra') ? 'DRA' : userRole.includes('atl') ? 'ATL' : userType[user?.userType],
                                        requestid: new Date().getTime().toString().slice(-5)
                                    }

                                    dispatch(setLoader(true))
                                    const requestRes = await axios.post('/addRequestManagement', requestPayload)
                                    dispatch(setLoader(false))
                                }
                            }
                        }
                    }
                    dispatch(updateInProgressCase({ userId: user?.userId, lanId, role: user?.role[0]?.roleCode, activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType}))
                    dispatch(getActivityHistory(lanId))
                    dispatch(getCallHistory(lanId))
                    props?.onSuccess()
                    Swal.fire({
                        position: "top-end",
                        icon: "success",
                        title: `Contact center call summary updated successfully.`,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                }
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }
    const updateContact = async (url, formPayload, file, isAddRequest) => {
        try {
            if (!props?.contactData?.contactCentreMobileNumbersId) {
                const payload = {
                    contactNumber: props?.contactData?.value,
                    contactName: props?.contactData?.contactName,
                    contactCentre: props?.contactCentreId
                }
                dispatch(setLoader(true))
                const res = await axios.post('addContactCentreMobileNumbers', payload)
                dispatch(setLoader(false))
                if (res?.data?.msgKey === "Success") {
                    addCallSummary(res?.data?.data?.contactCentreMobileNumbersId, url, formPayload, file, isAddRequest)
                }
            } else {
                addCallSummary(props?.contactData?.contactCentreMobileNumbersId, url, formPayload, file, isAddRequest)
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    const formik = useFormik({
        initialValues: {
            callDuration: {
                hh: '',
                mm: '',
                ss: ''
            },
            callStatus: '',
            callOutcome: '',
            followUp: '',
            remark: ''
        },
        validationSchema: validationSchema,
        onSubmit: () => updateContact()
    })

    useEffect(() => {
        dispatch(getUserTypeData())
    }, [])

    return (
        <>
            <Form onSubmit={formik?.handleSubmit} autoComplete="off">
                <Field
                    label="Call Duration"
                    childrenClassName={styles?.callDurationContainer}
                >
                    <Input
                        bsSize="sm"
                        placeholder="hh"
                        name="callDuration.hh"
                        value={formik?.values?.callDuration?.hh}
                        onChange={(e) => {
                            if (NUMBER_ONLY?.test(e?.target?.value) && e.target.value <= 24) {
                                formik?.setFieldValue('callDuration.hh', e?.target?.value)
                            } else if (!e?.target?.value) {
                                formik?.setFieldValue('callDuration.hh', e?.target?.value)
                            }
                        }}
                    />
                    <span>:</span>
                    <Input
                        bsSize="sm"
                        placeholder="mm"
                        name="callDuration.mm"
                        value={formik?.values?.callDuration?.mm}
                        onChange={(e) => {
                            if (NUMBER_ONLY?.test(e?.target?.value) && e.target.value <= 59) {
                                formik?.setFieldValue('callDuration.mm', e?.target?.value)
                            } else if (!e?.target?.value) {
                                formik?.setFieldValue('callDuration.mm', e?.target?.value)
                            }
                        }}
                    />
                    <span>:</span>
                    <Input
                        bsSize="sm"
                        placeholder="ss"
                        name="callDuration.ss"
                        value={formik?.values?.callDuration?.ss}
                        onChange={(e) => {
                            if (NUMBER_ONLY?.test(e?.target?.value) && e.target.value <= 59) {
                                formik?.setFieldValue('callDuration.ss', e?.target?.value)
                            } else if (!e?.target?.value) {
                                formik?.setFieldValue('callDuration.ss', e?.target?.value)
                            }
                        }}
                    />
                </Field>
                <Field
                    isRequired
                    label="Call Status"
                    errorMessage={formik?.touched?.callStatus && formik?.errors?.callStatus}
                >
                    <Select
                        id="callStatus"
                        inputId="callStatus"
                        name="callStatus"
                        label={"Call Status"}
                        isClearable={true}
                        options={callStatus}
                        closeMenuOnSelect={true} // Keep the dropdown open after selection
                        hideSelectedOptions={false}
                        onChange={(selectedOptions) => {
                            formik?.setFieldValue("callStatus", selectedOptions)
                            formik?.setFieldValue('callOutcome', "")
                        }}
                        value={formik?.values?.callStatus}
                        className={classNames({
                            abc: formik?.touched?.callStatus && Boolean(formik?.errors?.callStatus),
                        })}
                        invalid={formik?.touched?.callStatus && Boolean(formik?.errors?.callStatus)}
                        onBlur={formik?.handleBlur}
                        menuPosition="fixed"
                        classNamePrefix="react-select"
                    />
                </Field>
                <Field
                    isRequired
                    label="Call Outcome"
                    errorMessage={formik?.touched?.callOutcome && formik?.errors?.callOutcome}
                >
                    <Select
                        id="callOutcome"
                        inputId="callOutcome"
                        name="callOutcome"
                        label={"Call Outcome"}
                        isClearable={true}
                        options={formik?.values?.callStatus?.value === "Connected" ? connectedCallOutcome : formik?.values?.callStatus?.value === "Not Connected" ? notConnectedCallOutcome : []}
                        closeMenuOnSelect={true} // Keep the dropdown open after selection
                        hideSelectedOptions={false}
                        onChange={(selectedOptions) => {
                            if (Object.keys(documentDetail).length) {
                                setDocumentDetail({})
                            }
                            formik?.setFieldValue("callOutcome", selectedOptions)
                        }}
                        value={formik?.values?.callOutcome}
                        className={classNames({
                            abc: formik?.touched?.callOutcome && Boolean(formik?.errors?.callOutcome),
                        })}
                        invalid={formik?.touched?.callOutcome && Boolean(formik?.errors?.callOutcome)}
                        onBlur={formik?.handleBlur}
                        menuPosition="fixed"
                        classNamePrefix="react-select"
                    />
                </Field>
                <Field
                    label="Follow Up"
                >
                    <Input
                        type="datetime-local"
                        name="followUp"
                        value={formik?.values?.followUp}
                        min={new Date().toISOString().split('T')[0] + "T00:00"}
                        onChange={formik?.handleChange}
                        onBlur={formik?.handleBlur}
                    />
                </Field>
                <Field
                    label="Remarks"
                >
                    <Input
                        name="remark"
                        value={formik?.values?.remark}
                        onChange={formik?.handleChange}
                        onBlur={formik?.handleBlur}
                    />
                </Field>
                {(!formik?.values?.callOutcome || !formik?.values?.callStatus || formik?.values?.callStatus?.value === "Not Connected" || formik?.values?.callOutcome?.value === "Call Back") &&
                    <Button
                        type="submit"
                        size="sm"
                        color="primary"
                    >
                        Save
                    </Button>
                }
            </Form>
            {formik?.values?.callOutcome?.value === "PTP" &&
                <Fragment>
                    <p className={styles?.contactCenterHeader}>{formik?.values?.callOutcome?.value}</p>
                    <PTPForm
                        onSuccess={updateContact}
                        isCancelHidden={true}
                        isContactCenter={true}
                    />
                </Fragment>
            }
            {formik?.values?.callOutcome?.value === "Payment" &&
                <Fragment>
                    <p className={styles?.contactCenterHeader}>{formik?.values?.callOutcome?.value}</p>
                    <Payment
                        onSuccess={updateContact}
                        isCancelHidden={true}
                        isContactCenter={true}
                    />
                </Fragment>
            }
            {formik?.values?.callOutcome?.value === "Dispute/RTP" &&
                <Fragment>
                    <p>{formik?.values?.callOutcome?.value}</p>
                    <ContactDisputeForm
                        formType={"Create"}
                        onSuccess={updateContact}
                        isCancelHidden={true}
                        setDocumentDetail={setDocumentDetail}
                        documentDetail={documentDetail}
                        isContactCenter={true}
                    />
                </Fragment>
            }
            {formik?.values?.callOutcome?.value === "Raise Exception" &&
                <Fragment>
                    <p className={styles?.contactCenterHeader}>{formik?.values?.callOutcome?.value}</p>
                    <ContactRaiseForm
                        formType={"Create"}
                        onSuccess={updateContact}
                        isCancelHidden={true}
                        setDocumentDetail={setDocumentDetail}
                        documentDetail={documentDetail}
                        isContactCenter={true}
                    />
                </Fragment>
            }
            {formik?.values?.callOutcome?.value === "Repayment Info" &&
                <Fragment>
                    <p className={styles?.contactCenterHeader}>{formik?.values?.callOutcome?.value}</p>
                    <PaymentInfoData
                        isContactCenter={true}
                        onSuccess={updateContact}
                    />
                </Fragment>
            }
        </>
    )
}

export default memo(CallModal)