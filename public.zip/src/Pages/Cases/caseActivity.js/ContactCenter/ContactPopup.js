import React from "react";
import { Dialog } from "primereact/dialog";
import { Form, FormGroup, Label, Input, Row, Col, Button } from "reactstrap";

const ContactPopup = (props) => {
  const {
    openPopUp,
    setClosePopUp,
    openPhoneAddPop,
    openAddressAddPop,
    openEmailAddPop,
    openRefreanceAddPop,
  } = props;
  
  return (
    <Dialog
      // header="Raise Exception"
      visible={openPopUp}
      style={{ minWidth: "500px", width: "400px" }}
      onHide={() => setClosePopUp(false)}
    >
      {openPhoneAddPop && (
        <>
          <Form>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="exampleEmail">
                    <span className="text-danger">*</span>Contact Number
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    prefix="+91"
                    size="sm"
                    id="number"
                    name="Contact Number"
                    placeholder="Contact Number"
                    type="text"
                  />
                </Col>
              </Row>
            </FormGroup>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="examplePassword">
                    {" "}
                    <span className="text-danger">*</span>Contact Name
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    size="sm"
                    id="name"
                    name="Contact Name"
                    placeholder="Contact Name"
                    type="text"
                  />
                </Col>
              </Row>
            </FormGroup>
            <Row>
              <Col></Col>
              <Col className="d-flex justify-content-end">
                <Button color="primary"size="sm">Save</Button>
                <Button
                  className="ms-1"
                  color="danger"
                  onClick={() => {
                    setClosePopUp(false);
                  }}
                  size="sm"
                >
                  Cancel
                </Button>
              </Col>
            </Row>
          </Form>
        </>
      )}
      {openAddressAddPop && (
        <>
          <Form>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="exampleEmail">
                    <span className="text-danger">*</span>Address
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    prefix="+91"
                    size="sm"
                    id="Address"
                    name="Address"
                    placeholder="Address"
                    type="textarea"
                  />
                </Col>
              </Row>
            </FormGroup>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="examplePassword">
                    {" "}
                    <span className="text-danger">*</span>Contact Name
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  {/* <Row>
            <ToggleButton onLabel='Home Secondary Address' offLabel='Home Secondary Address' style={{height:'30px'}} checked={checkedHoome} onChange={(e) => setCheckedHome(e.value)} className="w-8rem" />
                  </Row>
                  <Row className="my-1">
            <ToggleButton onLabel=' Office Secondary Address' offLabel=' Office Secondary Address' style={{height:'30px'}} checked={checkedOffice} onChange={(e) => setCheckedOffice(e.value)} className="w-8rem" />
                  </Row> */}
                  <FormGroup>
                    <Input id="exampleSelect" name="select" type="select">
                      <option> Home Secondary Address</option>
                      <option> Office Secondary Address</option>
                    </Input>
                  </FormGroup>
                  <FormGroup></FormGroup>
                  {/* <SelectButton style={{height:'40px'}} value={value} onChange={(e) => setValue(e.value)} optionLabel="name" options={items} multiple /> */}
                </Col>
              </Row>
            </FormGroup>
            <Row>
              <Col></Col>
              <Col className="d-flex justify-content-end">
                <Button color="primary"size="sm">Save</Button>
                <Button
                  className="ms-1"
                  color="danger"
                  onClick={() => {
                    setClosePopUp(false);
                  }}
                  size="sm"
                >
                  Cancel
                </Button>
              </Col>
            </Row>
          </Form>
        </>
      )}
      {openEmailAddPop && (
        <>
          <Form>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="exampleEmail">
                    <span className="text-danger">*</span>Email Address
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    prefix="+91"
                    size="sm"
                    id="exampleEmail"
                    name="exampleEmail"
                    placeholder="Email Addressr"
                    type="text"
                  />
                </Col>
              </Row>
            </FormGroup>
            <Row>
              <Col></Col>
              <Col className="d-flex justify-content-end">
                <Button color="primary" size="sm">Save</Button>
                <Button
                  className="ms-1"
                  color="danger"
                  onClick={() => {
                    setClosePopUp(false);
                  }}
                  size="sm"
                >
                  Cancel
                </Button>
              </Col>
            </Row>
          </Form>
        </>
      )}
      {openRefreanceAddPop && (
        <>
          <Form>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="exampleEmail">
                    <span className="text-danger">*</span>Contact Number
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    prefix="+91"
                    size="sm"
                    id="number"
                    name="Contact Number"
                    placeholder="Contact Number"
                    type="text"
                  />
                </Col>
              </Row>
            </FormGroup>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="examplePassword">
                    {" "}
                    <span className="text-danger">*</span>Address
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    size="sm"
                    id="Address"
                    name="Address"
                    placeholder="Address"
                    type="textarea"
                  />
                </Col>
              </Row>
            </FormGroup>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="examplePassword">
                    {" "}
                    <span className="text-danger">*</span>Mobile
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    size="sm"
                    id="Mobile"
                    name="Mobile"
                    placeholder="Mobile"
                    type="text"
                  />
                </Col>
              </Row>
            </FormGroup>
            <FormGroup>
              <Row>
                <Col lg={4} md={4} sm={12}>
                  <Label className="pt-2" for="exampleEmail">
                    <span className="text-danger">*</span>Email Address
                  </Label>
                </Col>
                <Col lg={8} md={8} sm={12}>
                  <Input
                    prefix="+91"
                    size="sm"
                    id="exampleEmail"
                    name="exampleEmail"
                    placeholder="Email Address"
                    type="text"
                  />
                </Col>
              </Row>
            </FormGroup>
            <Row>
              <Col></Col>
              <Col className="d-flex justify-content-end">
                <Button color="primary" size="sm">Save</Button>
                <Button
                  className="ms-1"
                  color="danger"
                  onClick={() => {
                    setClosePopUp(false);
                  }}
                  size="sm"
                >
                  Cancel
                </Button>
              </Col>
            </Row>
          </Form>
        </>
      )}
    </Dialog>
  );
};

export default ContactPopup;
