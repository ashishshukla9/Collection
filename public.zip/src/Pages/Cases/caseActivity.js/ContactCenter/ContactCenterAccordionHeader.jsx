import { memo } from "react"
import { AccordionHeader, Button } from "reactstrap"
import styles from './ContactCenter.module.scss'

const ContactCenterAccordionHeader = (props) => {
    return(
        <AccordionHeader
            targetId={props?.targetId}
            className={styles?.accordionHeaderContainer}
        >
            <div className={styles?.container}>
                <p className={styles?.header}>{props?.header}</p>
                {props?.btnVisible &&
                    <Button
                        size="sm"
                        color="primary"
                        outline
                        onClick={(e) => {
                            e.stopPropagation();
                            props?.onClick()
                        }}
                        disabled={props?.disabled}
                    >
                        Add
                    </Button>
                }
            </div>
        </AccordionHeader>
    )
}

export default memo(ContactCenterAccordionHeader)