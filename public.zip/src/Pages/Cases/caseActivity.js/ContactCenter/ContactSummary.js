import React, { useEffect, useMemo, useState } from "react";
import { Dialog } from "primereact/dialog";
import {
  Card,
  Col,
  Row,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  FormFeedback,
} from "reactstrap";
import { InputNumber } from "primereact/inputnumber";
import Select from "react-select";
import { Dropdown } from "primereact/dropdown";
import { Formik } from "formik";
import { NUMBER_ONLY } from "../../../../utils/regex";
import { ContactCenterCallSummarySchema, contactCenterCallSummaryValidation } from "../../../../Schema/ContactCenterCallSummarySchema";
import '../../../../scss/contactSummary.scss';

const ContactSummary = (props) => {
  const { openContectSummary, setopenContectSummary } = props;

  const callStatus = useMemo(() => [
    { value: "Connected", label: "Connected" },
    { value: "Not Connected", label: "Not Connected" },
  ], [])

  const connectedOptions = useMemo(() => [
    { value: "PTP", label: "PTP" },
    { value: "Payment", label: "Payment" },
    { value: "Dispute/RTP", label: "Dispute/RTP" },
    { value: "Rise Exception", label: "Rise Exception" },
    { value: "Payment Info", label: "Payment Info" },
  ], [])

  const notConnectedOptions = useMemo(() => [
    { value: "Wrong Number", label: "Wrong Number" },
    { value: "Left Message", label: "Left Message" },
    { value: "Not Reachable", label: "Not Reachable" },
    { value: "Number Busy", label: "Number Busy" },
  ], [])

  const time = useMemo(() => [
    {
      name: "AM",
    },
    {
      name: "PM",
    },
  ], [])

  const handleFormSubmit = (data) => {
  }

  return (
    <Dialog
      header="Please add a call summary."
      visible={openContectSummary}
      style={{ minWidth: "700px", width: "80vw" }}
      onHide={() => setopenContectSummary(false)}
    >
      <Card className="p-2">
        <Formik
          initialValues={ContactCenterCallSummarySchema}
          validationSchema={contactCenterCallSummaryValidation}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit
          }) => {
            return (
              <Form onSubmit={handleSubmit} className="contactSummaryForm">
                <Row style={{height: '100px'}}>
                  <Col
                    lg={4}
                    md={4}
                    sm={4}
                    className=" d-flex align-items-center text-center"
                  >
                    Call Duration
                  </Col>
                  <Col
                    lg={6}
                    md={6}
                    sm={6}
                    className=" d-flex align-items-center bg-light"
                  >
                    <div className="d-flex flex-row sm-8 ">
                      <Input
                        type="text"
                        id="hh"
                        value={values?.hh}
                        onChange={(e) => {
                          if (NUMBER_ONLY.test(e?.target?.value)) {
                            setFieldValue('callDuration.hh', e?.target?.value)
                          } else if (!e?.target?.value) {
                            setFieldValue('callDuration.hh', e?.target?.value)
                          }
                        }}
                        onBlur={handleBlur}
                        maxLength={2}
                        max={12}
                        placeholder="hh"
                        style={{ height: "40px" }}
                      />
                      <span className="m-1">{":"}</span>
                      <Input
                        type="text"
                        id="mm"
                        value={values?.mm}
                        onChange={(e) => {
                          if (NUMBER_ONLY.test(e?.target?.value)) {
                            setFieldValue('callDuration.mm', e?.target?.value)
                          } else if (!e?.target?.value) {
                            setFieldValue('callDuration.mm', e?.target?.value)
                          }
                        }}
                        onBlur={handleBlur}
                        maxLength={2}
                        max={59}
                        placeholder="mm"
                        style={{ height: "40px" }}
                      />
                      <span className="m-1">{":"}</span>
                      <Dropdown
                        options={time}
                        optionLabel="name"
                        optionValue="name"
                        id="time"
                        onChange={(e) => {
                          setFieldValue('callDuration.time', e.value)
                        }}
                        onBlur={handleBlur}
                        value={values?.callDuration?.time}
                        className="w-full md:w-14rem mx-2"
                        style={{ height: "40px" }}
                      />
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col lg={4} md={4} sm={12}>
                    <Label>
                      <span className="text-danger">*</span>Call Status
                    </Label>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Select
                      id="callStatus"
                      placeholder="select an option"
                      options={callStatus}
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false}
                      value={values?.callStatus}
                      onChange={(e) => {
                        setFieldValue('callStatus', e)
                        setFieldValue('callOutcome', '')
                      }}
                      onBlur={handleBlur}
                      invalid={touched?.callStatus && Boolean(errors?.callStatus)}
                      classNamePrefix="react-select"
                      menuPosition="fixed"
                    />
                    {touched.callStatus && errors.callStatus &&
                      <FormFeedback style={{ display: 'block', marginTop: 0 }}>
                        {touched.callStatus && errors.callStatus}
                      </FormFeedback>
                    }
                  </Col>
                </Row>
                <Row>
                  <Col lg={4} md={4} sm={12}>
                    <Label>
                      <span className="text-danger">*</span>Call Outcome
                    </Label>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Select
                      id="callOutcome"
                      placeholder="select an option"
                      options={values?.callStatus?.value === "Not Connected" ? notConnectedOptions : values?.callStatus?.value === "Connected" ? connectedOptions : []}
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false}
                      value={values?.callOutcome}
                      onChange={(e) => {
                        setFieldValue('callOutcome', e)
                      }}
                      classNamePrefix="react-select"
                      onBlur={handleBlur}
                      invalid={touched?.callOutcome && Boolean(errors?.callOutcome)}
                      menuPosition="fixed"
                    />
                    {touched.callOutcome && errors.callOutcome &&
                      <FormFeedback style={{ display: 'block', marginTop: 0 }}>
                        {touched.callOutcome && errors.callOutcome}
                      </FormFeedback>
                    }
                  </Col>
                </Row>
                <Row>
                  <Col lg={4} md={4} sm={12}>
                    <Label>
                      Followup Call (Date/Time)
                    </Label>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Input
                      id="followUpCall"
                      name="followUpCall"
                      placeholder="date placeholder"
                      type="date"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values?.followUpCall}
                    />
                  </Col>
                </Row>
                <Button type="submit" color="primary" className="me-1 contactSummarySubmitBtn"size="sm">SUBMIT</Button>
              </Form>
            )
          }}
        </Formik>
      </Card>
    </Dialog>
  );
};

export default ContactSummary;
