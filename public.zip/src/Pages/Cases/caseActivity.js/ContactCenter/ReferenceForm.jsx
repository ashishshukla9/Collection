import { Formik } from "formik";
import { memo } from "react";
import { Button, Form, Input } from "reactstrap";
import Field from "../../../../components/Field";
import * as yup from "yup";
import { NUMBER_ONLY } from "../../../../utils/regex";
import axios from "axios";
import Swal from "sweetalert2";
import { setLoader } from "../../../../reducer/globalReducer";
import { useDispatch } from "react-redux";
const ReferenceForm = (props) => {
  const dispatch = useDispatch();
  const validationSchema = yup.object({
    name: yup.string().required("Name is Required"),
    email: yup
      .string()
      .email("Enter a valid email")
      .required("Email is Required")
      .max(50, "Email cannot exceed 50 characters"),
    mobile: yup
      .string()
      //   .matches(/^[0-9]{10}$/, "Invalid mobile number") // Matches only 10 digits
      .required("Mobile number is required")
      .max(10, "Please enter only 10 digits"), // Max 10 digits validation
    // address: yup.string().required("Address is Required"),
    address: yup
      .string()
      .required("Address is Required")
      .max(255, "Address cannot exceed 255 characters"), // Added max length validation for address
    addressType: yup.string().required("Address Type is Required"),
  });
  const handleSubmit = async (values) => {
    try {
      const payload = {
        refrenceName: values?.name,
        referenceAddress: values?.address,
        referenceMobile: values?.mobile,
        referenceEmail: values?.email,
        contactCentre: props?.contactCenter,
      };
      dispatch(setLoader(true));
      const res = await axios.post("/addContactCentreReference", payload);
      dispatch(setLoader(false));
      props?.onSuccess();
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  return (
    <Formik
      initialValues={{
        name: "",
        email: "",
        mobile: "",
        address: "",
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({
        values,
        errors,
        touched,
        handleSubmit,
        onSubmit,
        setFieldValue,
        handleBlur,
        handleChange,
        isSubmitting,
      }) => {
        return (
          <Form onSubmit={handleSubmit} autoComplete="off">
            <Field
              isRequired
              label="Name"
              errorMessage={touched?.name && errors?.name}
            >
              <Input
                bsSize="sm"
                id="name"
                placeholder="Enter name"
                value={values?.name}
                onChange={handleChange}
                invalid={touched?.name && Boolean(errors?.name)}
                onBlur={handleBlur}
              />
            </Field>
            <Field
              isRequired
              label="Email"
              errorMessage={touched?.email && errors?.email}
            >
              <Input
                bsSize="sm"
                id="email"
                placeholder="Enter Email"
                value={values?.email}
                onChange={handleChange}
                invalid={touched?.email && Boolean(errors?.email)}
                onBlur={handleBlur}
              />
            </Field>
            <Field
              isRequired
              label="Mobile"
              errorMessage={touched?.mobile && errors?.mobile}
            >
              <Input
                bsSize="sm"
                id="mobile"
                placeholder="Enter mobile"
                value={values?.mobile}
                onChange={(e) => {
                  if (NUMBER_ONLY.test(e.target.value)) {
                    setFieldValue("mobile", e.target.value);
                  } else if (!e.target.value) {
                    setFieldValue("mobile", e.target.value);
                  }
                }}
                invalid={touched?.mobile && Boolean(errors?.mobile)}
                onBlur={handleBlur}
              />
            </Field>
            <Field
              isRequired
              label="Address"
              errorMessage={touched?.address && errors?.address}
            >
              <Input
                type="textarea"
                bsSize="sm"
                id="address"
                placeholder="Enter address"
                value={values?.address}
                onChange={handleChange}
                invalid={touched?.address && Boolean(errors?.address)}
                onBlur={handleBlur}
              />
            </Field>
            <div className="d-flex justify-content-end gap-2">
              <Button type="submit" color="primary" size="sm">
                Save
              </Button>
              <Button
                type="button"
                size="sm"
                onClick={() => props?.handleClose()}
              >
                Cancel
              </Button>
            </div>
          </Form>
        );
      }}
    </Formik>
  );
};
export default memo(ReferenceForm);