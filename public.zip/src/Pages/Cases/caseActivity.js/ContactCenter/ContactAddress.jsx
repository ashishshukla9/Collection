import { Fragment, memo, useEffect, useState } from 'react'
import styles from './ContactCenter.module.scss'
import { useDispatch, useSelector } from 'react-redux';
import { Accordion, AccordionBody, AccordionItem } from 'reactstrap';
import ContactCenterAccordionHeader from './ContactCenterAccordionHeader';
import { Dialog } from 'primereact/dialog';
import AddressForm from './AddressForm';
import axios from 'axios';
import { setLoader } from '../../../../reducer/globalReducer';

const ContactAddress = (props) => {
    const [addressData, setAddressData] = useState([])
    const [addressModal, setAddressModal] = useState(false)
    const [openAddress, setOpenAddress] = useState("0");
    const caseProfile = useSelector((state) => state.cases.caseProfile);
    const dispatch=useDispatch()

    const toggleAddress = (id) => {
        setOpenAddress(openAddress === id ? '' : id)
    };

    const getAddress = async () => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getContactCentreAddressBycontactCentreId/${props?.contactCenterId}`)
            dispatch(setLoader(false))
            const addressData = res?.data?.data || []

    
    const keys = Object.keys(caseProfile)
            const data = []
            if (keys?.length) {
                
                data?.push({
                    id: 1,
                    name: "Home Address",
                    value: caseProfile?.primaryAddress
                })

                const homeSecondaryAddress = keys?.filter(a => a.includes('secondaryAddress'))
                homeSecondaryAddress?.map(a => {
                    data?.push({
                        id: data?.length + 1,
                        name: "Home Secondary Address: ",
                        value: caseProfile[a]
                    })
                })
                const officeAddress = keys?.filter(a => a?.includes('officeAddress'))
                officeAddress?.map(a => {
                    data?.push({
                        id: data?.length + 1,
                        name: "Office Address",
                        value: caseProfile[a]
                    })
                })
            }
            if (addressData?.length) {
                addressData?.map(a => {
                    data.push({
                        id: data?.length + 1,
                        name: `${a?.addressType}:-  `,
                        value: a?.address
                    })
                })
            }
            setAddressData(data)
        } catch (error) {
            dispatch(setLoader(false))
        }
    }

    const onSuccess = async () => {
        props?.onSuccess()
        setAddressModal(false)
        getAddress()
    }

    useEffect(() => {
        if(props?.contactCenterId){
            getAddress()
        }
    }, [caseProfile,props?.contactCenterId])

    return (
        <Fragment>
            <Accordion
                open={openAddress}
                toggle={toggleAddress}
            >
                <AccordionItem>
                    <ContactCenterAccordionHeader
                        targetId="1"
                        header="Address"
                        btnVisible
                        onClick={() => setAddressModal(true)}
                        disabled={caseProfile?.forCloserRequestStatus === "approved"}
                    />
                    <AccordionBody accordionId="1">
                        <div className={styles?.addressContainer}>
                            {addressData?.map(a => (
                                <div className={styles?.addresRow}>
                                    <p className={styles?.key}>{a?.name || '-'}</p>
                                    <p className={styles?.value}>{a?.value || '-'}</p>
                                </div>
                            ))}
                        </div>
                    </AccordionBody>
                </AccordionItem>
            </Accordion>

            {addressModal &&
                <Dialog
                    header="Add Address"
                    visible={addressModal}
                    onHide={() => setAddressModal(false)}
                    style={{ width: '500px' }}
                >
                    <AddressForm
                        handleClose={() => setAddressModal(false)}
                        contactCenter={props?.contactCenterId}
                        onSuccess={onSuccess}
                    />
                </Dialog>
            }
        </Fragment>

    )
}

export default memo(ContactAddress)