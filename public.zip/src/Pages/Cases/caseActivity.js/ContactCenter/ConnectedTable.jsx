import { Fragment, memo, useEffect, useState } from "react";
import { BsEye, BsEyeSlash } from "react-icons/bs";
import { useDispatch, useSelector } from "react-redux";
import cx from "classnames";
import {
  Accordion,
  AccordionBody,
  AccordionItem,
  Input,
  Row,
  Table,
} from "reactstrap";
import styles from "./ContactCenter.module.scss";
import { CgPhone } from "react-icons/cg";
import classNames from "classnames";
import axios from "axios";
import ContactCenterAccordionHeader from "./ContactCenterAccordionHeader";
import { Dialog } from "primereact/dialog";
import PhoneForm from "./PhoneForm";
import CallModal from "./CallModal";
import { setLoader } from "../../../../reducer/globalReducer";

const ConnectedTable = (props) => {
  const [connectedNumber, setConnectedNumber] = useState([]);
  const [newdata, setnewdata] = useState([])
  const [open, setOpen] = useState("1");
  const [openConnected, setOpenConnected] = useState("1");
  const [addPhoneModal, setAddPhoneModal] = useState(false);
  const [callModal, setCallModal] = useState(false);
  const [contactData, setContactData] = useState({});
  const [showPhoneNumber, setShowPhoneNumber] = useState({});

  const caseProfile = useSelector((state) => state.cases.caseProfile);

  const dispatch = useDispatch()
  const onEyeClick = (i) => {
    const duplicate = [...connectedNumber];

    duplicate[i] = { ...duplicate[i], visible: !duplicate[i]?.visible };
    setConnectedNumber(duplicate);
  };

  const toggle = (id) => {
    setOpen(open === id ? "" : id);
  };
  const toggleConnected = (id) => {
    setOpenConnected(openConnected === id ? "" : id);
  };

  const getMobile = async () => {
    if (props?.contactCenterId) {
      try {
        dispatch(setLoader(true))
        const res = await axios.get(
          `/getContactCentreMobileNumbersBycontactCentreId/${props?.contactCenterId}`
        );
        // console.log(res, "resrssrss")
        dispatch(setLoader(false))
        // if (res?.data?.msgKey === "Success") {

        const contactNumber = res?.data?.data || [];
        const allContactNumber = res?.data?.data?.map((a) => a?.contactNumber?.toString()) || [];
        // const allContactName = res?.data?.data?.map((a) => a?.contactName?.toString()) || [];
        // console.log(allContactNumber, "allContactName")

        // const allContactNumber =res?.map((a) => a?.contactNumber?.toString()) || [];
  //  console.log(caseProfile, "caseProfile")
        const keys = Object.keys(caseProfile);
        let data = [];
        if (keys?.length) {
          // console.log(caseProfile?.mobile, "caseProfile?.mobile")
          if (!allContactNumber?.length || !allContactNumber?.includes(caseProfile?.mobile?.toString())) {
            data.push({
              id: 1,
              name: "Mobile",
              value: caseProfile?.mobile?.toString(),
              visible: false,
              contactCentreMobileNumbersId: null,
              contactName: caseProfile?.name,
            });
          }
          // "additionalMobile"
          const alternateNumber = keys?.filter((a) =>
            a.includes("alternateMobile")
          );

          const additionalNumber = keys?.filter((a)=> a.includes("additionalMobile"))
          alternateNumber?.map((a) => {
            if (allContactNumber?.length ||!allContactNumber?.includes(caseProfile[a]?.toString())
            ) {
              data.push({
                id: data?.length + 1,
                name: "Alternate Number.",
                value: caseProfile[a]?.toString(),
                visible: false,
                contactCentreMobileNumbersId: null,
                contactName: "", 

              });
            }
          });


          // addition number 
          additionalNumber?.map((a) => {
            if (allContactNumber?.length ||!allContactNumber?.includes(caseProfile[a]?.toString())
            ) {
              data.push({
                id: data?.length + 1,
                name: "Additional Number ",
                value: caseProfile[a]?.toString(),
                visible: false,
                contactCentreMobileNumbersId: null,
                contactName: "", 

              });
            }
          });
        }
        if (contactNumber?.length) {
          contactNumber?.map((a) => {
            data?.push({
              id: data?.length + 1,
              name: a?.contactNumber?.toString() === caseProfile?.mobile?.toString() ? "Mobile" : "Alternate No.",
              value: a?.contactNumber?.toString(),
              contactName: a?.contactName,
              visible: false,
              contactCentreMobileNumbersId: a?.contactCentreMobileNumbersId,
            });
          });
        }

       

        data = data?.sort((a, b) => (b?.name > a?.name ? 1 : -1));
        setConnectedNumber(data);
      } catch (error) {
        dispatch(setLoader(false))
      }
    }
  };

  const onSuccess = () => {
    props?.onSuccess();
    setAddPhoneModal(false);
    getMobile();
  };

  const handleCall = (data) => {
    if (caseProfile?.forCloserRequestStatus !== "approved") {
      setContactData(data);
      setCallModal(!callModal);
    }
  };

  const callSummarySuccess = () => {
    getMobile();
    setCallModal(false);
  };

  useEffect(() => {
    if (props?.contactCenterId) {
      getMobile();
    }
  }, [props?.contactCenterId, caseProfile]);

  const togglePhoneNumberVisibility = (id) => {
    setShowPhoneNumber({
      ...showPhoneNumber,
      [id]: !showPhoneNumber?.[id]
    });
  };
  return (
    <Fragment>
      <Accordion open={open} toggle={toggle}>
        <AccordionItem>
          <ContactCenterAccordionHeader
            targetId="1"
            header="Phone"
            btnVisible
            onClick={() => setAddPhoneModal(true)}
            disabled={caseProfile?.forCloserRequestStatus === "approved"}
          />
          <AccordionBody accordionId="1">
            <Row>
              <Accordion open={openConnected} toggle={toggleConnected}>
                <AccordionItem>
                  <ContactCenterAccordionHeader
                    targetId="2"
                    header="Connected"
                  />
                  <AccordionBody accordionId="2">
                    <Table
                      borderless
                      responsive
                      className={styles.contactCenterTableContainer}
                    >
                      <thead >
                        <tr style={{ marginRight: "10px" }}>
                          <th></th>
                          <th></th>
                          <th></th>
                          <th>Success Count</th>
                          <th>Failed Count</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody className={styles?.tableBody}>
                        {/* {console.log(connectedNumber, "connectedNumber")} */}
                        {connectedNumber?.map((number, i) => {
                          
                          let mobNumber = "";
                          const num = number?.value?.toString()
                          for (let index = 1; index <= props?.masking; index++) {
                            mobNumber = mobNumber + "*";
                          }
                          mobNumber = num?.slice(0, num.length - props?.masking) + mobNumber;
                          return (
                            <tr key={number?.id}>
                              <td
                                className={classNames(
                                  styles?.tableData,
                                  styles?.nameCol
                                )}
                              >
                                {/* {console.log(number?.name, "contactname")} */}
                                {number?.name}
                              </td>

                              <td className={classNames(styles?.tableData, styles?.numberCol)}>
                                <div className={styles?.numberBox}>
                                  <p className={styles?.number}>{number?.contactName ? number?.contactName : "--"}</p>
                                </div>
                              </td>

                              <td className={classNames(styles?.tableData, styles?.numberCol)}>
                                <div className={styles?.numberBox}>
                                  <p className={styles?.number}>{showPhoneNumber?.[number?.id] ? number?.value : mobNumber}</p>
                                  <i className={cx({ bi: true, "bi-eye-fill": showPhoneNumber?.[number?.id], "bi-eye-slash-fill": !showPhoneNumber?.[number?.id], })}
                                    onClick={() =>
                                      togglePhoneNumberVisibility(number?.id)
                                    }
                                  ></i>
                                </div>
                              </td>

                              <td
                                className={classNames(
                                  styles?.tableData,
                                  styles?.countCol
                                )}
                              >
                                <p className={styles?.successCount}>0</p>
                              </td>
                              <td
                                className={classNames(
                                  styles?.tableData,
                                  styles?.countCol
                                )}
                              >
                                <p className={styles?.failedCount}>0</p>
                              </td>
                              <td className={classNames(styles?.tableData)}>
                                <CgPhone
                                  className={styles?.phoneIcon}
                                  onClick={() => handleCall(number)}
                                />
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </Table>
                  </AccordionBody>
                </AccordionItem>
              </Accordion>
            </Row>
          </AccordionBody>
        </AccordionItem>
      </Accordion>

      {addPhoneModal && (
        <Dialog
          header="Add Phone"
          visible={addPhoneModal}
          onHide={() => setAddPhoneModal(false)}
          style={{ width: "500px" }}
        >
          <PhoneForm
            handleClose={() => setAddPhoneModal(false)}
            contactCentre={props?.contactCenterId}
            onSuccess={onSuccess}
          />
        </Dialog>
      )}

      {callModal && (
        <Dialog
          header="Please add a call summary."
          visible={callModal}
          onHide={handleCall}
          style={{ width: "800px" }}
        >
          <CallModal
            contactData={contactData}
            onSuccess={callSummarySuccess}
            contactCentreId={props?.contactCenterId}
          />
        </Dialog>
      )}
    </Fragment>
  );
};

export default memo(ConnectedTable);
