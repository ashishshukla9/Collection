import { Formik } from "formik";
import { memo } from "react";
import { Button, Form, Input } from "reactstrap";
import Field from "../../../../components/Field";
import * as yup from "yup";
import Swal from "sweetalert2";
import axios from "axios";
import { setLoader } from "../../../../reducer/globalReducer";
import { useDispatch } from "react-redux";
const EmailForm = (props) => {
  const dispatch = useDispatch();
  // const validationSchema=yup.object({
  //     email: yup
  //         .string()
  //         .email("Enter a valid email")
  //         .required("Email is Required")
  // })
  const validationSchema = yup.object({
    email: yup
      .string()
      .email("Enter a valid email")
      .required("Email is Required")
      .max(50, "Email cannot exceed 50 characters"), // Added max length validation
  });
  const handleSubmit = async (values) => {
    try {
      const payload = {
        emailAddress: values?.email,
        contactCentre: props?.contactCentre,
      };
      dispatch(setLoader(true));
      const res = await axios.post("/addContactCentreEmail", payload);
      dispatch(setLoader(false));
      props?.onSuccess();
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  return (
    <Formik
      initialValues={{
        email: "",
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({
        values,
        errors,
        touched,
        handleSubmit,
        onSubmit,
        setFieldValue,
        handleBlur,
        handleChange,
        isSubmitting,
      }) => {
        return (
          <Form onSubmit={handleSubmit} autoComplete="off">
            <Field
              isRequired
              label="Email"
              errorMessage={touched?.email && errors?.email}
            >
              <Input
                bsSize="sm"
                id="email"
                placeholder="Enter Email"
                value={values?.email}
                onChange={handleChange}
                invalid={touched?.email && Boolean(errors?.email)}
                onBlur={handleBlur}
                // maxLength={50}
              />
            </Field>
            <div className="d-flex justify-content-end gap-2">
              <Button type="submit" color="primary" size="sm">
                Save
              </Button>
              <Button
                type="button"
                size="sm"
                onClick={() => props?.handleClose()}
              >
                Cancel
              </Button>
            </div>
          </Form>
        );
      }}
    </Formik>
  );
};
export default memo(EmailForm);