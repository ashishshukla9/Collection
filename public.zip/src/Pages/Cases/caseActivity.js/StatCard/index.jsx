import { Document, Page, StyleSheet, Text, View } from "@react-pdf/renderer";
import axios from "axios";
import { memo, useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { MdOutlineCurrencyRupee } from "react-icons/md";
import rupees from "../../../../assets/images/indian-currency.webp";

const Index = ({
  caseProfile,
  activityHistory,
  raiseException,
  disputeReason,
  statsData,
  applicationDetails,
  loanHistory,
}) => {
  const [collectionStatusData, setCollectionStatusData] = useState([]);
  const collectionStatus = useMemo(
    () => activityHistory?.[0],
    [activityHistory]
  );
  // console.log(activityHistory?.[0], "vcghchgvcgh12");

  const delinquencyString = useMemo(
    () =>
      caseProfile?.delinquencyString?.split(",").length
        ? caseProfile?.delinquencyString?.split(",")
        : [],
    []
  );
  const Styles = StyleSheet.create({
    page: {
      display: "flex",
      flexDirection: "column",
      // gap: "2px",
      fontSize: "9px",
      padding: "15px",
    },
    flexCol: {
      display: "flex",
      flexDirection: "column",
      width: "100%",
      border: "1px solid lightgray",
      padding: "8px",
      borderRadius: "10px",
      rowGap: "5px",
      // marginTop:"2px"
    },
    container: {
      display: "flex",
      flexDirection: "column",
      // padding:"2px"
      marginTop: "5px",
    },
    flex: {
      display: "flex",
      gap: "20px",
      flexDirection: "row",
    },
    title: {
      textAlign: "center",
      fontWeight: "bold",
      fontSize: "15px",
      marginBottom: "2px",
    },
    header: {
      fontSize: "12px",
      fontWeight: "bold",
      width: "100%",
      // paddingTop:"2px"
      marginLeft: "2px",
      marginTop: "2px",
      marginBottom: "2px",
    },
    subheader: {
      marginBottom: "9px",
    },
    bold: {
      fontWeight: "bold",
    },
    keyValue: {
      display: "flex",
      flexDirection: "row",
      fontSize: "9px",
    },
    key: {
      fontWeight: "bold",
      minWidth: "110px",
      maxWidth: "110px",
    },
    value: {
      maxWidth: "800px",
    },
    w100: {
      width: "100%",
      marginBottom: "10px",
      marginLeft: "2px",
    },
    delinquencyMain: {
      display: "flex",
      flexDirection: "row",
      flexWrap: "wrap",
      alignItems: "center",
      gap: "10px",
      color: "#666",
    },
    delinquencyCircle: {
      minWidth: "30px",
      minHeight: "30px",
      display: "flex",
      flexDirection: "column",
      flexWrap: "wrap",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "#e3e3e3",
      borderRadius: "50%",
      textAlign: "center",
      position: "relative",
    },
    delinquencyCircleText: {
      position: "absolute",
      top: "8px",
      left: "11px",
      fontSize: "10px",
    },
    tableHeader: {
      display: "flex",
      borderBottom: "1px solid",
      flexDirection: "row",
      // paddingLeft:"2px"
    },
    tableTh6: {
      fontWeight: "bold",
      width: "calc(100% / 6)",
    },
    tableRow: {
      display: "flex",
      flexDirection: "row",
    },
    tableTd6: {
      width: "calc(100% / 6)",
    },
    tableTh3: {
      fontWeight: "bold",
      width: "calc(100% / 3)",
    },
    tableTd3: {
      width: "calc(100% / 3)",
    },
    collateralFlex: {
      display: "flex",
      flexDirection: "row",
      width: "100%",
      border: "1px solid lightgray",
      padding: "10px",
      borderRadius: "10px",
      flexWrap: "wrap",
      rowGap: "10px",
    },
    collateralBox: {
      width: "25%",
    },
    collateralBox2: {
      width: "45%",
      marginRight: "25px",
    },
    collateralHeader: {
      fontWeight: "bold",
    },
  });
  useEffect(() => {
    if (collectionStatus) {
      const data = JSON.parse(collectionStatus?.data);
      let finalData = [];
      switch (collectionStatus?.activityType) {
        case "PaymentInfo":
          finalData = [
            { id: 1, name: "Amount", value: data?.amount },
            { id: 2, name: "Mobile", value: data?.phoneNumber },
            { id: 3, name: "Remark", value: data?.remark },
            { id: 4, name: "Payment Type", value: data?.paymentType },
            { id: 5, name: "Payment Status", value: data?.paymentStatus },
          ];
          break;
        case "PtpDetail":
          finalData = [
            { id: 1, name: "PTP Amount", value: data?.ptpAmount },
            { id: 2, name: "PTP Date", value: data?.ptpDate },
            { id: 3, name: "PTP Status", value: data?.status },
            { id: 4, name: "PTP Time", value: data?.ptpTime },
            { id: 5, name: "PTP Type", value: data?.ptpType },
          ];
          break;
        case "RaiseException":
          finalData = [
            { id: 1, name: "Exception Request", value: data?.request },
            { id: 2, name: "Remarks", value: data?.remark },
          ];
          break;
        case "DisputeOrRtp":
          finalData = [
            { id: 1, name: "Amount", value: data?.amount },
            { id: 2, name: "Remarks", value: data?.remark },
            { id: 3, name: "Dispute Type", value: data?.disputeType },
            { id: 4, name: "Dispute Reason", value: data?.disputeReason },
          ];
          break;
        case "Request":
          finalData = [
            { id: 1, name: "Request", value: data?.requestType },
            { id: 2, name: "Remarks", value: data?.remark },
            { id: 3, name: "Old Value", value: data?.oldValue },
            { id: 4, name: "New Value", value: data?.newValue },
          ];
          break;
        case "Payment":
          finalData = [
            { id: 1, name: "Amount", value: data?.amount },
            { id: 2, name: "Mobile", value: data?.phoneNumber },
            { id: 3, name: "Remarks", value: data?.remark },
            { id: 4, name: "Payment Type", value: data?.paymentType },
            { id: 5, name: "Payment Status", value: data?.paymentStatus },
          ];
          break;

        default:
          break;
      }
      setCollectionStatusData(finalData);
    }
  }, [collectionStatus]);
  function formatDate(inputDate) {
    var parts = inputDate.split("-");
    var formattedDate = parts[2] + "-" + parts[1] + "-" + parts[0];
    return formattedDate;
  }
  return (
    <Document title="Collection Status">
      <Page style={Styles?.page} wrap>
        <Text style={Styles?.title}>Stat Card</Text>
        <View style={Styles?.container}>
          <Text style={Styles?.header}>Customer Information</Text>
          <View style={Styles?.flex}>
            <View style={Styles?.flexCol}>
              <View style={Styles.keyValue}>
                <Text style={Styles.bold}>Primary Applicant Name: </Text>
                <Text style={Styles.value}>{caseProfile?.name}</Text>
              </View>
              <View style={Styles.keyValue}>
                <Text style={Styles.key}>Pincode:</Text>
                <Text>{caseProfile?.pincode}</Text>
              </View>
              <View style={Styles.keyValue}>
                <Text style={Styles.key}>Loan Account Number</Text>
                <Text>{caseProfile?.loanAccountNumber}</Text>
              </View>
              <View style={Styles.keyValue}>
                <Text style={Styles.key}>Total Overdue Amount</Text>
                <Text style={Styles.rupees}>
                  {`${caseProfile?.totalOverdueAmount?.toLocaleString(
                    "en-IN"
                  )}`}
                </Text>
              </View>
            </View>
            <View style={Styles?.flexCol}>
              <Text style={Styles.bold}>
                Co Applicant Name: {caseProfile?.coApplicantName}
              </Text>
              <Text>
                Co Applicant Mobile No: {caseProfile?.coApplicantMobile || "-"}
              </Text>
              <Text>
                Co Applicant Email: {caseProfile?.coApplicantEmail || "-"}
              </Text>
            </View>
          </View>
          <View style={{ width: "49%", padding: "2px", marginTop: "1px" }}>
            <View style={Styles?.flexCol}>
              <Text style={Styles.bold}>
                Guarantor Name: {caseProfile?.guarantorName || "-"}
              </Text>
              <Text>
                Guarantor Mobile: {caseProfile?.guarantorMobile || "-"}
              </Text>
              <Text>Guarantor Email: {caseProfile?.guarantorEmail || "-"}</Text>
            </View>
          </View>
        </View>
        <View style={Styles?.container}>
          <Text style={Styles?.header}>Application Details</Text>
          <View>
            <View style={Styles?.flexCol}>
              {applicationDetails?.leftSide?.map((a) => {
                return (
                  <View key={a?.id} style={Styles.keyValue}>
                    <Text style={Styles.key}>{a?.key}</Text>
                    <Text
                      style={[
                        Styles?.value,
                        {
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        },
                      ]}
                      numberOfLines={1}
                    >
                      {a?.value || "-"}
                    </Text>
                  </View>
                );
              })}
            </View>
            <View style={[Styles?.flexCol, { marginTop: "5px" }]}>
              {applicationDetails?.rightSide?.map((a) => {
                return (
                  <View key={a?.id} style={Styles.keyValue}>
                    <Text style={Styles.key}>{a?.key}</Text>
                    <Text style={Styles?.value}>
                      {a?.value == 0 ? "-" : a?.value}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View>
        <View style={Styles?.container}>
          <Text style={Styles?.header}>Loan Repayment History</Text>
          <View style={Styles?.flex}>
            <Text style={Styles.w100}>Disbursement</Text>
            <Text style={Styles.w100}>Repayment</Text>
          </View>
          <View style={Styles?.flex}>
            <View style={Styles?.flexCol}>
              {loanHistory?.leftSide?.map((a) => {
                return (
                  <View key={a?.id} style={Styles.keyValue}>
                    <Text style={Styles.key}>{a?.key}</Text>
                    <Text>
                      {a?.value.toLocaleString("en-IN") == 0
                        ? "-"
                        : a?.value?.toLocaleString("en-IN")}
                    </Text>
                  </View>
                );
              })}
            </View>
            <View style={Styles?.flexCol}>
              {loanHistory?.rightSide?.map((a) => {
                return (
                  <View key={a?.id} style={Styles.keyValue}>
                    <Text style={Styles.key}>{a?.key}</Text>
                    <Text>
                      {a?.value.toLocaleString("en-IN") == 0
                        ? "-"
                        : a?.value.toLocaleString("en-IN")}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View>
        <View style={Styles?.container} break>
          <View style={Styles?.flex}>
            <Text style={Styles?.header}>Delinquency String</Text>
            <Text style={Styles?.header}>Collection Status</Text>
          </View>
          <View style={Styles?.flex}>
            <View style={Styles?.flexCol}>
              <View style={Styles.delinquencyMain}>
                {delinquencyString?.map((a, i) => {
                  return (
                    <View key={i} style={Styles.delinquencyCircle}>
                      <Text style={Styles.delinquencyCircleText}>{a}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
            <View style={Styles?.flexCol}>
              {statsData?.ptpStats?.[0] && (
                <>
                  <View style={Styles.keyValue}>
                    <Text style={Styles.key}>PTP Amount</Text>
                    <Text>
                      {statsData?.ptpStats[0]?.ptpAmount.toLocaleString(
                        "en-IN"
                      )}
                    </Text>
                  </View>
                  <View style={Styles.keyValue}>
                    <Text style={Styles.key}>PTP Date</Text>
                    <Text>{formatDate(statsData?.ptpStats[0]?.ptpDate)}</Text>
                  </View>
                  <View style={Styles.keyValue}>
                    <Text style={Styles.key}>PTP Status</Text>
                    <Text>{statsData?.ptpStats[0]?.ptpStatus}</Text>
                  </View>
                  <View style={Styles.keyValue}>
                    <Text style={Styles.key}>PTP Time</Text>
                    <Text>{statsData?.ptpStats[0]?.ptpCreatedTime}</Text>
                  </View>
                  <View style={Styles.keyValue}>
                    <Text style={Styles.key}>PTP Type</Text>
                    <Text>{statsData?.ptpStats[0]?.ptpType}</Text>
                  </View>
                </>
              )}
            </View>
          </View>
        </View>
        <View style={Styles?.container} wrap={false}>
          <Text style={Styles?.header}>PTP</Text>
          <View style={Styles?.flexCol}>
            <View style={Styles?.tableHeader}>
              <Text style={Styles?.tableTh6}>Date</Text>
              <Text style={Styles?.tableTh6}>Time</Text>
              <Text style={Styles?.tableTh6}>Amount</Text>
              <Text style={Styles?.tableTh6}>Type</Text>
              <Text style={Styles?.tableTh6}>Mode</Text>
              <Text style={Styles?.tableTh6}>Status</Text>
            </View>
            {/* {console.log(statsData?.ptpStats, "vbhjvjhv")} */}
            {statsData?.ptpStats?.map((a, i) => {
              return (
                <View style={Styles?.tableRow} key={i}>
                  <Text style={Styles?.tableTd6}>{formatDate(a?.ptpDate)}</Text>
                  <Text style={Styles?.tableTd6}>{a?.ptpCreatedTime}</Text>
                  <Text style={Styles?.tableTd6}>
                    {a?.ptpAmount.toLocaleString("en-IN")}
                  </Text>
                  <Text style={Styles?.tableTd6}>{a?.ptpType}</Text>
                  <Text style={Styles?.tableTd6}>{a?.ptpMode}</Text>
                  <Text style={Styles?.tableTd6}>{a?.ptpStatus}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={Styles?.container} wrap={false}>
          <Text style={Styles?.header}>Payment</Text>
          <View style={Styles?.flexCol}>
            <View style={Styles?.tableHeader}>
              <Text style={Styles?.tableTh6}>Date</Text>
              <Text style={Styles?.tableTh6}>Time</Text>
              <Text style={Styles?.tableTh6}>Amount</Text>
              <Text style={Styles?.tableTh6}>Type</Text>
              <Text style={Styles?.tableTh6}>Mode</Text>
              <Text style={Styles?.tableTh6}>Status</Text>
            </View>
            {statsData?.paymentStats?.map((a, i) => {
              return (
                <View style={Styles?.tableRow} key={i}>
                  <Text style={Styles?.tableTd6}>
                    {formatDate(a?.paymentDate)}
                  </Text>
                  <Text style={Styles?.tableTd6}>{a?.paymentCreatedTime}</Text>
                  <Text style={Styles?.tableTd6}>
                    {a?.paymentAmount.toLocaleString("en-IN")}
                  </Text>
                  <Text style={Styles?.tableTd6}>{a?.paymentType}</Text>
                  <Text style={Styles?.tableTd6}>{a?.paymentMode}</Text>
                  <Text style={Styles?.tableTd6}>{a?.paymentStatus}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={Styles?.container} wrap={false}>
          <View style={Styles?.flex}>
            <Text style={Styles?.header}>Raise Exception</Text>
            <Text style={Styles?.header}>Dispute/RTP</Text>
          </View>
          <View style={Styles?.flex}>
            <View style={Styles?.flexCol}>
              <View style={Styles?.tableHeader}>
                <Text style={Styles?.tableTh3}>Date</Text>
                <Text style={Styles?.tableTh3}>Time</Text>
                <Text style={Styles?.tableTh3}>Request</Text>
              </View>
              {statsData?.raiseExceptionStats?.map((a, i) => {
                return (
                  <View style={Styles?.tableRow} key={i}>
                    <Text style={Styles?.tableTd3}>
                      {formatDate(
                        new Date(a?.raiseExceptionDate)
                          .toISOString()
                          .substring(0, 10)
                      )}
                      {/* {a?.raiseExceptionDate} */}
                    </Text>
                    <Text style={Styles?.tableTd3}>
                      {new Date(a?.raiseExceptionDate).toLocaleTimeString(
                        "en-US",
                        { hour12: true, hour: "2-digit", minute: "2-digit" }
                      )}
                    </Text>
                    <Text style={Styles?.tableTd3}>
                      {raiseException[a?.request]}
                    </Text>
                  </View>
                );
              })}
            </View>
            <View style={Styles?.flexCol}>
              <View style={Styles?.tableHeader}>
                <Text style={Styles?.tableTh3}>Date</Text>
                <Text style={Styles?.tableTh3}>Time</Text>
                <Text style={Styles?.tableTh3}>Reason</Text>
              </View>
              {statsData?.disputeOrRtpStatsDto?.map((a, i) => {
                return (
                  <View style={Styles?.tableRow} key={i}>
                    <Text style={Styles?.tableTd3}>
                      {new Date(a?.time).toISOString().substring(0, 10)}
                    </Text>
                    <Text style={Styles?.tableTd3}>
                      {new Date(a?.time).toLocaleTimeString("en-US", {
                        hour12: true,
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </Text>
                    <Text style={Styles?.tableTd3}>
                      {disputeReason[a?.reason]}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View>

        {statsData?.collateralDetails?.map((data) => {
          // data?.title === "Vehical Details" || data?.title === "Vehicle Details"
          if (
            data?.title === "Vehical Details" ||
            data?.title === "Vehicle Details"
          ) {
            return (
              <View style={{ marginTop: "2px" }}>
                {/* <Text style={Styles?.header}>Collateral {data?.index}</Text> */}
                <Text style={Styles?.header}>Collateral 1</Text>

                {/* <Text style={Styles?.subheader}>{data?.title == "Vehicle Details" ? data?.title : "Vehicle Details"}</Text> */}
                <Text style={Styles?.subheader}>{"Vehicle Details"}</Text>

                <View style={Styles?.collateralFlex}>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>
                      Registration No.
                    </Text>
                    <br />
                    <Text>{data?.vehicleRegNo}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>Engine No.</Text>
                    <br />
                    <Text>{data?.engineNumber}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>Chassis No.</Text>
                    <br />
                    <Text>{data?.vehicleChassisNumber}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>Manufacturer</Text>
                    <br />
                    <Text>{data?.manufacturer}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>Model</Text>
                    <br />
                    <Text>{data?.makeModelName}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>
                      Manufacturing Year
                    </Text>
                    <br />
                    <Text>{data?.vehicleManufacturingYea}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>New or Used</Text>
                    <br />
                    <Text>{data?.usedOrNew}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>Valuation</Text>
                    <br />
                    <Text>{data?.propertyValue?.toLocaleString("en-IN")}</Text>
                  </View>
                </View>
              </View>
            );
          } else if (data?.title === "Collateral") {
            //data?.title === "Collateral")
            return (
              <View style={{ marginTop: "2px" }}>
                {/* <Text style={Styles?.header}>Collateral 2</Text> */}
                <Text style={Styles?.header}>Collateral {data?.index}</Text>

                <View style={Styles?.collateralFlex}>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>LTV</Text>
                    <br />
                    <Text>{data?.ltv == "0" ? "-" : data?.ltv}</Text>
                  </View>
                  <View style={Styles?.collateralBox2}>
                    <Text style={Styles?.collateralHeader}>
                      Storage Address
                    </Text>
                    <br />
                    <Text>{data?.propertyLocation}</Text>
                  </View>
                  <View style={Styles?.collateralBox}>
                    <Text style={Styles?.collateralHeader}>Valuation</Text>
                    <br />
                    <Text>
                      {data?.ltv.toLocaleString("en-IN") == "0"
                        ? "-"
                        : data?.ltv.toLocaleString("en-IN")}
                    </Text>
                  </View>
                </View>
              </View>
            );
          }
        })}

        {statsData?.ownerDetails?.map((data) => {
          return (
            <View style={{ marginTop: "15px" }}>
              <Text style={Styles?.header}>Owner {data?.index}</Text>
              <View style={Styles?.collateralFlex}>
                <View style={Styles?.collateralBox}>
                  <Text style={Styles?.collateralHeader}>Name</Text>
                  <br />
                  <Text>{data?.ownerName}</Text>
                </View>
                <View style={Styles?.collateralBox}>
                  <Text style={Styles?.collateralHeader}>Mobile Number</Text>
                  <br />
                  <Text>
                    {data?.ownerMobile == "0" ? "-" : data?.ownerMobile}
                  </Text>
                </View>
                <View style={Styles?.collateralBox}>
                  <Text style={Styles?.collateralHeader}>Email</Text>
                  <br />
                  <Text>{data?.ownerEmail}</Text>
                </View>
                <View style={Styles?.collateralBox}>
                  <Text style={Styles?.collateralHeader}>Address</Text>
                  <br />
                  <Text>{data?.ownerAddress}</Text>
                </View>
              </View>
            </View>
          );
        })}
      </Page>
    </Document>
  );
};

export default memo(Index);
