import { Fragment, memo, useState } from "react"
import { useSelector } from "react-redux";
import { Accordion, Button, Card, CardBody, CardTitle } from "reactstrap"
import styles from './CaseProfile.module.scss'
import PaymentInfoActivity from "../../components/Cases/PaymentInfoActivity";
import PtpActivity from "../../components/Cases/PtpActivity";
import ExceptionActivity from "../../components/Cases/ExceptionActivity";
import { AccordionEle } from "../../components/Accordian/Accordian";
import DisputeActivity from "../../components/Cases/DisputeActivity";
import RequestActivity from "../../components/Cases/RequestActivity";
import PaymentActivity from "../../components/Cases/PaymentActivity";
import ScheduleVisitActivity from "../../components/Cases/ScheduleVisitActivity.jsx";

import CommunicationHistory from "./CommunicationHistory";
import { useParams } from "react-router-dom";
import { addAudit } from "../../utils/commonFun";

const History = (props) => {
    console.log(props, "historyprops")
    const [activeButton, setActiveButton] = useState("Activity")
    const [accordionToggle, setAccordionToggle] = useState('')
    const { lanId } = useParams();

    const activityHistory = useSelector((state) => state?.cases?.activityHistory);
    const communicationHistory = useSelector((state) => state?.cases?.communicationHistory);
    const user = useSelector((state) => state.user.data);

    const handleAccordionToggle = (e) => {
        setAccordionToggle(e === accordionToggle ? '' : e)
    }
    // console.log(data, "acacacacca")
    const switchCase = (data, isHistory) => {
        // console.log(data, "acacacacca")

        switch (data?.activityType) {
            case "PaymentInfo":
                return <PaymentInfoActivity obj={JSON.parse(data?.data)} isHistory={isHistory} />
                break;

            case "PtpDetail":
                return <PtpActivity obj={JSON.parse(data?.data)} isHistory={isHistory} />
                break;

            case "Raise Exception":
                return (
                    <ExceptionActivity
                        obj={JSON.parse(data?.data)}
                        isHistory={isHistory}
                        raiseException={props?.raiseException}
                    />
                );
                break;

            case "Dispute/Rtp":
                return (
                    <DisputeActivity
                        obj={JSON.parse(data?.data)}
                        isHistory={isHistory}
                        disputeReason={props?.disputeReason}
                    />
                );
                break;

            case "Request":
                return (
                    <RequestActivity
                        obj={JSON.parse(data?.data)}
                        isHistory={isHistory}
                    />
                );
                break;

            case "Payment":
                return (
                    <PaymentActivity
                        obj={JSON.parse(data?.data)}
                        isHistory={isHistory}
                    />
                );
                break;
            case "Schedule Visit":
                return (
                    <ScheduleVisitActivity
                        data={data}
                        obj={JSON.parse(data?.data)}
                        isHistory={isHistory}
                    />
                );
                break;

            default:
                break;
        }
    }

    const onClickButton = (btn) => {
        setActiveButton(btn)
        const payload = {
            userName: user?.userName,
            module: "Cases",
            activity: `${user?.userName} viewed ${btn} History details of application number: ${lanId}`
        }
        addAudit(payload)
    }
    return (
        <Card>
            <CardBody>
               
                {!props?.showOnlyLastData &&
                    <Fragment>
                        <div className={styles?.buttonGroup}>
                            <Button
                                outline
                                color="primary"
                                active={activeButton === "Activity"}
                                size="sm"
                                onClick={() => onClickButton("Activity")}
                            >
                                Activity History
                            </Button>
                            <Button
                                outline
                                color="primary"
                                active={activeButton === "Communication"}
                                onClick={() => onClickButton("Communication")}
                                size="sm"
                            >
                                Communication History
                            </Button>
                        </div>
                        {/* {console.log(activityHistory, "activityHistory")} */}
                        <Accordion
                            open={accordionToggle}
                            toggle={handleAccordionToggle}
                        >
                            {activeButton === "Activity" ?
                                activityHistory?.map((data, index) => {
                                    let component = switchCase(data);
                                    return (

                                        <AccordionEle
                                            index={index}
                                            heading={data}
                                            bodyComp={component}
                                        // customClassName={styles?.}
                                        />
                                    )
                                })
                                : activeButton === "Communication" ?
                                    communicationHistory?.map(data => (
                                        <CommunicationHistory
                                            data={data}
                                        />
                                    ))
                                    : ''
                            }
                        </Accordion>
                    </Fragment>
                }
                {props?.showOnlyLastData &&
                    <Fragment>
                        <CardTitle className={styles?.title}>
                            {props?.title}
                        </CardTitle>
                        {switchCase(activityHistory?.[0], false)}
                    </Fragment>
                }
            </CardBody>
        </Card>
    )
}

export default memo(History)