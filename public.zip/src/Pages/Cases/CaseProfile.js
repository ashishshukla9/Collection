import React, { useEffect, useState } from "react";
import LoanHistory from "./customerProfile/Loan history/LoanHistory";
import ApplicationData from "./customerProfile/application data/ApplicationData";
import CollateralDetails from "./customerProfile/collateral details/CollateralDetails";
import PaymentInfo from "./caseActivity.js/PaymentInfo/PaymentInfo";
import { PTP } from "./caseActivity.js/PTP/PTP";
import PaymentTable from "./caseActivity.js/Payment/PaymentTable";
import { Dispute } from "./caseActivity.js/Dispute/Dispute";
import RiseException from "./caseActivity.js/Exception/RiseException";
import ContactCenter from "./caseActivity.js/ContactCenter/ContactCenter";
import RequestTable from "./caseActivity.js/Request/RequestTable";
import {
  getActivityHistory,
  getCaseByLanId,
  getCommunicationHistory,
} from "./store";
import { useDispatch, useSelector } from "react-redux";
import {
  Card,
  Modal,
  ModalHeader,
  Button,
  ModalBody,
  CardBody,
  CardTitle,
  Col,
  Row,
} from "reactstrap";
import { useNavigate, useParams } from "react-router-dom";
import APPLICATION_DETAILS from "../../assets/images/logo/applicationDetails.png";
import LOAN_HISTORY from "../../assets/images/logo/loanHistory.png";
import COLLATERAL_DETAILS from "../../assets/images/logo/collateralDetails.png";
import CONTACT_CENTER from "../../assets/images/logo/contactCenter.png";
import PAYMENT_INFO from "../../assets/images/logo/paymentInfo.png";
import PTP_ICON from "../../assets/images/logo/ptp.png";
import PAYMENT from "../../assets/images/logo/payment.png";
import DISPUTE from "../../assets/images/logo/dispute.png";
import RAISE_EXCEPTION from "../../assets/images/logo/raiseExceptions.png";
import REQUEST from "../../assets/images/logo/request.png";
import "./cases.scss";
import ProfileDetails from "./ProfileDetails";
import History from "./History";
import styles from "./CaseProfile.module.scss";
import Swal from "sweetalert2";
import axios from "axios";
import { pdf } from "@react-pdf/renderer";
import StatCard from "./caseActivity.js/StatCard";
import CallHistory from "./CallHistory";
import { setLoader } from "../../reducer/globalReducer";
import { addAudit } from "../../utils/commonFun";
export default function Cases() {
  const user = useSelector((state) => state.user.data);
  const activityHistory = useSelector((state) => state?.cases?.activityHistory);
  const geoData = useSelector((state) => state?.setGeoLocation?.geoData);
  const dispatch = useDispatch();
  const { module } = useParams();
  const { lanId } = useParams();
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const [applicationData, setApplicationData] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [intervalId, setIntervalId] = useState(null);
  const [loanHistoryDig, setLoanHistoryDig] = useState(false);
  const [collatralDig, setCollatralDig] = useState(false);
  const [repaymentInfo, setRepaymentInfo] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [openPtp, setOpenPtp] = useState(false);
  const [openPyamentTable, setOpenPaymentTable] = useState(false);
  const [openDispute, setOpenDispute] = useState(false);
  const [openException, setCloseException] = useState(false);
  const [openContect, setCloseContect] = useState(false);
  const [openRequest, setCloseRequest] = useState(false);
  const [disputeReason, setDisputeReason] = useState({});
  const [raiseException, setRaiseException] = useState({});
  const [statsData, setStatsData] = useState({});
  const [applicationDetails, setApplicationDetails] = useState({});
  const [loanHistory, setLoanHistory] = useState({});
  const [maskingMobileNo, setMaskingMobileNo] = useState(0);
  const navigate = useNavigate();
  let customerProfileFlag = false;
  let caseActivityFlag = false;
  const customerProfileObj = [
    {
      name: "Application Details",
      link: "",
      icon: APPLICATION_DETAILS,
      background: "#ff8004",
      roleType: "customerprofile",
    },
    {
      name: "Loan History",
      link: "",
      icon: LOAN_HISTORY,
      background: "#00c7a7",
      roleType: "customerprofile",
    },
    {
      name: "Collateral Details",
      link: "",
      icon: COLLATERAL_DETAILS,
      background: "#8eda35",
      roleType: "customerprofile",
    },
  ];
  const caseActivity = [
    {
      name: "Contact Centre",
      icon: CONTACT_CENTER,
      background: "#1e97bf",
      roleType: "caseactivity",
    },
    {
      name: "Payment Info",
      icon: PAYMENT_INFO,
      background: "#25ba53",
      roleType: "caseactivity",
    },
    {
      name: "PTP",
      icon: PTP_ICON,
      background: "#dc732e",
      roleType: "caseactivity",
    },
    {
      name: "Payment",
      icon: PAYMENT,
      background: "#b65fc9",
      roleType: "caseactivity",
    },
    {
      name: "Dispute/RTP",
      icon: DISPUTE,
      background: "#8eda35",
      roleType: "caseactivity",
    },
    {
      name: "Raise Exception",
      icon: RAISE_EXCEPTION,
      background: "#e7c819",
      roleType: "caseactivity",
    },
    {
      name: "Request",
      icon: REQUEST,
      background: "#00c7a7",
      roleType: "caseactivity",
    },
    {
      name: "Stat Card",
      icon: REQUEST,
      background: "#00c7a7",
      roleType: true,
    },
  ];
  useEffect(() => {
    dispatch(getCaseByLanId(lanId));
    dispatch(getActivityHistory(lanId));
    dispatch(getCommunicationHistory(lanId));
  }, []);
  const handleClick = (i) => {
    if (i === 0) {
      setApplicationData(!applicationData);
    } else if (i === 1) {
      setLoanHistoryDig(!loanHistoryDig);
    } else if (i == 2) {
      setCollatralDig(!collatralDig);
    }
  };
  const handleClickCaseActivity = (i) => {
    if (i === 0) {
      setCloseContect(!openContect);
    }
    if (i === 1) {
      setRepaymentInfo(!repaymentInfo);
    } else if (i === 2) {
      setOpenPtp(!openPtp);
    } else if (i === 3) {
      setOpenPaymentTable(!openPyamentTable);
    } else if (i === 4) {
      setOpenDispute(!openDispute);
    } else if (i === 5) {
      setCloseException(!openException);
    } else if (i === 6) {
      setCloseRequest(!openRequest);
    }
  };
  const fetchDataAndSetState = () => {
    dispatch(setLoader(true));
    axios
      .get("/getAllDisputeReasonMaster")
      .then(({ data }) => {
        dispatch(setLoader(false));
        const obj = {};
        data?.data?.map((a) => {
          Object.assign(obj, {
            [a?.code]: a?.description,
          });
        });
        setDisputeReason(obj);
      })
      .catch((error) => {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    axios
      .get("/getAllExceptionType")
      .then(({ data }) => {
        dispatch(setLoader(false));
        const obj = {};
        data?.data?.map((a) => {
          Object.assign(obj, {
            [a?.code]: a?.description,
          });
        });
        setRaiseException(obj);
      })
      .catch((err) => {
        dispatch(setLoader(false));
      });
    axios
      .get(`/getApplicationDetailsByLoanAccountNumber/${lanId}`)
      .then((res) => {
        dispatch(setLoader(false));
        const data = res?.data?.data;
        setApplicationDetails({
          leftSide: [
            { id: 1, key: "Lender Id", value: data?.lenderId },
            { id: 2, key: "Lender Name", value: data?.lenderName },
            {
              id: 3,
              key: "LMS ID",
              value: data?.lmsId,
            },
            {
              id: 4,
              key: "Loan Account Number",
              value: data?.loanAccountNumber,
            },
            { id: 5, key: "Customer ID", value: data?.customerId },
          ],
          rightSide: [
            { id: 1, key: "Name", value: data?.customerName },
            { id: 2, key: "Bank Account No", value: data?.bankAccountNumber },
            { id: 3, key: "Pincode", value: data?.pinCode },
            { id: 4, key: "PAN", value: data?.pan },
            { id: 5, key: "Aadhar", value: data?.aadhar },
          ],
        });
      })
      .catch((error) => {
        dispatch(setLoader(false));
      });
    axios
      .get(`/getLoanHistoryByLoanAccountNumber/${lanId}`)
      .then((res) => {
        dispatch(setLoader(false));
        const data = res?.data?.data;
        setLoanHistory({
          leftSide: [
            {
              id: 1,
              key: "Loan Account Number",
              value: data?.loanAccountNumber,
            },
            { id: 2, key: "Loan Product", value: data?.loanProduct },
            { id: 3, key: "Loan Amount", value: data?.loanAmount },
            {
              id: 4,
              key: "Date of Disbursement",
              value: data?.disbursementDate,
            },
            { id: 5, key: "Interest", value: data?.interestRate },
            { id: 6, key: "Tenure", value: data?.tenor },
            { id: 7, key: "Repayment Type", value: data?.repaymentType },
            { id: 8, key: "Collateral", value: data?.collateral },
            { id: 9, key: "Frequency", value: data?.frequency },
            { id: 10, key: "NACH", value: data?.nach },
            { id: 11, key: "Disbursed Amount", value: data?.disbursedAmount },
          ],
          rightSide: [
            { id: 1, key: "Branch Name", value: data?.branchName },
            { id: 2, key: "Bank IFSC", value: data?.bankIFSC },
            { id: 3, key: "Bank UPI Address", value: data?.bankUpiAddress },
            { id: 4, key: "DPD", value: data?.dpd },
            {
              id: 5,
              key: "Total Overdue Amount",
              value: Number(data?.totalOverdueAmount)?.toLocaleString("en-IN"),
            },
            { id: 6, key: "Pending EMI Amount", value: data?.pendingEmiAmount },
            { id: 7, key: "DCP/LPP", value: data?.dcpOrLpp },
            { id: 8, key: "Closure Amount", value: data?.closureAmount },
            { id: 9, key: "Settlement Amount", value: data?.settlementAmount },
            {
              id: 10,
              key: "Last Payment Amount",
              value: data?.lastPaymentAmount,
            },
            { id: 11, key: "Other Charges", value: data?.otherCharges },
            {
              id: 12,
              key: "Pending EMI Principal Amount",
              value: data?.pendingEmiPrincipalAmount,
            },
            {
              id: 13,
              key: "Pending EMI Interest Amount",
              value: data?.pendingEmiInterestAmount,
            },
            { id: 14, key: "EMI Amount", value: data?.emiAmount },
            {
              id: 15,
              key: "Cheques Bounce Charge",
              value: data?.chequeBounceCharges,
            },
          ],
        });
      })
      .catch((error) => {
        dispatch(setLoader(false));
      });
    axios
      .get(`/getStatsByLan/${lanId}`)
      .then((res) => {
        dispatch(setLoader(false));
        const data = res?.data?.data?.collatralDetailsDto;
        const noOfOwners =
          data &&
          Object.keys(data).filter(
            (a) => a?.startsWith("owner") && a?.endsWith("Name")
          ).length;
        const newData = [];
        Array.from({ length: noOfOwners }, (_, i) => i + 1)?.map((a) => {
          newData.push({
            title: "Owner",
            index: a,
            ownerName: data?.[`owner${a}Name`],
            ownerAddress: data?.[`owner${a}Address`],
            ownerMobile: data?.[`owner${a}Mobile`],
            ownerEmail: data?.[`owner${a}Email`],
          });
        });
        const collateralDetails = [];
        collateralDetails?.push({
          title: "Vehicle Details",
          index: collateralDetails.length + 1,
          vehicleRegNo: data?.vehicleRegNo,
          engineNumber: data?.engineNumber,
          vehicleChassisNumber: data?.vehicleChassisNumber,
          manufacturer: data?.manufacturer,
          makeModelName: data?.makeModelName,
          vehicleManufacturingYear: data?.vehicleManufacturingYear,
          VehicleValuation: data?.VehicleValuation,
          usedOrNew: data?.usedOrNew,
        });
        collateralDetails?.push({
          title: "Collateral",
          index: collateralDetails.length + 1,
          ltv: data?.ltv,
          propertyLocation: data?.propertyLocation,
          propertyValue: data?.ltv,
        });
        setStatsData({
          ...res?.data?.data,
          ownerDetails: newData,
          collateralDetails: collateralDetails,
        });
      })
      .catch((err) => {
        dispatch(setLoader(false));
      });
  };
  const handleDownloadClick = async () => {
    setShowPopup(false);
    setIsLoading(true);
    setTimeout(() => {
      const payload = {
        userName: user?.userName,
        module: "Cases",
        activity: `${user?.userName} downloaded stats card of application number: ${lanId}`,
      };
      addAudit(payload);
      const doc = (
        <StatCard
          caseProfile={caseProfile}
          activityHistory={activityHistory}
          raiseException={raiseException}
          disputeReason={disputeReason}
          statsData={statsData}
          applicationDetails={applicationDetails}
          loanHistory={loanHistory}
          delinquencyString={caseProfile?.delinquencyString?.split(",")}
          lanId={lanId}
        />
      );
      pdf(doc)
        .toBlob()
        .then((blob) => {
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.download = "stats-card.pdf"; // You can change the filename here
          link.click(); // Trigger the download
          URL.revokeObjectURL(url);
          setIsLoading(false);
          setDownloadComplete(true); // Mark download as complete
        })
        .catch((error) => {
          console.error("Download failed:", error);
          setIsLoading(false); // Stop loader if there was an error
        });
    }, 500); // Delay before download starts
  };
  const handleCancelClick = () => {
    clearInterval(intervalId); // Clear the interval
    setShowPopup(false);
  };
  const handleCardClick = () => {
    const id = fetchDataAndSetState; // Interval of 10 seconds
    setIntervalId(id);
    setShowPopup(true);
  };
  useEffect(() => {
    fetchDataAndSetState();
  }, [lanId]);
  useEffect(() => {
    if (caseProfile?.lenderId) {
      const getLenderDetails = async () => {
        dispatch(setLoader(true));
        try {
          const res = await axios.get(`/getLender/${caseProfile?.lenderId}`);
          dispatch(setLoader(false));
          setMaskingMobileNo(res?.data?.data?.maskingMobileNo);
        } catch (error) {
          dispatch(setLoader(false));
        }
      };
      getLenderDetails();
    }
  }, [caseProfile]);
  if (caseProfile) {
    return (
      <>
        <Row className="m-0 w-100 g-1">
          <Col lg={6} md={12} sm={12}>
            <div className={styles?.cardColContainer}>
              <Card>
                <CardBody>
                  <ProfileDetails masking={maskingMobileNo} />
                </CardBody>
              </Card>
              <Card>
                <CardBody>
                  <CardTitle className="h4 fw-bold">
                    Delinquency String
                  </CardTitle>
                  {caseProfile?.delinquencyString && (
                    <div className="delinquencyMain">
                      {caseProfile?.delinquencyString
                        ?.split(",")
                        ?.map((a, i) => (
                          <div key={i} className="delinquencyCircle">
                            {a}
                          </div>
                        ))}
                    </div>
                  )}
                </CardBody>
              </Card>
              <History
                showOnlyLastData={true}
                title="Collection Status"
                activityHistory={activityHistory}
                raiseException={raiseException}
                disputeReason={disputeReason}
              />
              <History
                activityHistory={activityHistory}
                raiseException={raiseException}
                disputeReason={disputeReason}
              />
            </div>
          </Col>
          <Col lg={6} md={12} sm={12}>
            <div className={styles?.cardColContainer}>
              <Card>
                <CardBody>
                  <h5 className="fw-bold">Customer Profile</h5>
                  <Row>
                    {customerProfileObj &&
                      customerProfileObj.map((item, i) => {
                        let field = item.name.toLowerCase().replaceAll(" ", "");
                        if (
                          ["V", "F", "E"].includes(
                            user?.masterRole[`${item.roleType}_${field}`]
                          )
                        ) {
                          customerProfileFlag = true;
                          return (
                            <Col
                              lg={6}
                              md={6}
                              sm={12}
                              key={`customerProfile-${item.name}`}
                              className="p-0"
                            >
                              <Card
                                className="m-1"
                                style={{
                                  background: "#f9f9f9",
                                  cursor: "pointer",
                                }}
                              >
                                <CardBody
                                  className="d-flex align-items-center p-2"
                                  onClick={() => handleClick(i)}
                                >
                                  <img
                                    src={item?.icon}
                                    alt="icon"
                                    className="caseProfileIcon"
                                  />
                                  <p className="fw-bold mb-0 ms-3">
                                    {item.name}
                                  </p>
                                </CardBody>
                              </Card>
                            </Col>
                          );
                        }
                      })}
                    {customerProfileFlag || <h1>No Access</h1>}
                  </Row>
                  {applicationData && (
                    <ApplicationData
                      applicationData={applicationData}
                      setApplicationData={setApplicationData}
                    />
                  )}
                  {loanHistoryDig && (
                    <LoanHistory
                      loanHistoryDig={loanHistoryDig}
                      setLoanHistoryDig={setLoanHistoryDig}
                    />
                  )}
                  {collatralDig && (
                    <CollateralDetails
                      collatralDig={collatralDig}
                      setCollatralDig={setCollatralDig}
                    />
                  )}
                </CardBody>
              </Card>
              <Card>
                <CardBody>
                  <h5 className="fw-bold">Case Activity</h5>
                  <Row>
                    {caseActivity &&
                      caseActivity.map((item, i) => {
                        let field = item?.name
                          .toLowerCase()
                          .replace(/[^A-Z0-9]/gi, "");
                        if (
                          ["V", "F", "E"].includes(
                            user?.masterRole[`${item?.roleType}_${field}`]
                          ) ||
                          item?.roleType === true
                        ) {
                          caseActivityFlag = true;
                          return (
                            <Col
                              lg={6}
                              md={6}
                              sm={12}
                              key={`caseActivity-${item.name}`}
                              className="p-0"
                            >
                              {i === 7 ? (
                                <div>
                                  <Card
                                    className="m-1"
                                    style={{
                                      background: "#f9f9f9",
                                      cursor: "pointer",
                                    }}
                                    onClick={handleCardClick} // Handle card click to start interval and show popup
                                  >
                                    <CardBody className="d-flex align-items-center p-2">
                                      <img
                                        src={item?.icon}
                                        alt="icon"
                                        className="caseProfileIcon"
                                      />
                                      <p className="fw-bold mb-0 ms-3">
                                        {item.name}
                                      </p>
                                    </CardBody>
                                  </Card>
                                  <Modal
                                    isOpen={showPopup}
                                    toggle={() => setShowPopup(false)}
                                    className="modal-dialog-centered"
                                  >
                                    <ModalHeader
                                      toggle={() => setShowPopup(false)}
                                    >
                                      Confirm Download
                                    </ModalHeader>
                                    <ModalBody>
                                      {isLoading ? (
                                        <div className="d-flex justify-content-center align-items-center">
                                          <div
                                            className="spinner-border text-primary"
                                            role="status"
                                          >
                                            <span className="visually-hidden">
                                              Loading...
                                            </span>
                                          </div>
                                          <p className="ms-3">
                                            Processing your download...
                                          </p>
                                        </div>
                                      ) : (
                                        <>
                                          <p>
                                            Are you sure you want to download
                                            the stat Card?
                                          </p>
                                          <Button
                                            color="primary"
                                            onClick={handleDownloadClick}
                                          >
                                            Download
                                          </Button>
                                          <Button
                                            color="secondary"
                                            onClick={handleCancelClick}
                                            className="ms-3" // Adds space to the left of the Cancel button
                                          >
                                            Cancel
                                          </Button>
                                        </>
                                      )}
                                    </ModalBody>
                                  </Modal>
                                </div>
                              ) : (
                                <Card
                                  className="m-1"
                                  style={{
                                    background: "#f9f9f9",
                                    cursor: "pointer",
                                  }}
                                  onClick={() => handleClickCaseActivity(i)} // Existing action
                                >
                                  <CardBody className="d-flex align-items-center p-2">
                                    <img
                                      src={item?.icon}
                                      alt="icon"
                                      className="caseProfileIcon"
                                    />
                                    <p className="fw-bold mb-0 ms-3">
                                      {item.name}
                                    </p>
                                  </CardBody>
                                </Card>
                              )}
                            </Col>
                          );
                        }
                      })}
                    {caseActivityFlag || <h1>No Access</h1>}
                  </Row>
                  {repaymentInfo && (
                    <PaymentInfo
                      geoData={geoData}
                      repaymentInfo={repaymentInfo}
                      setRepaymentInfo={setRepaymentInfo}
                    />
                  )}
                  {openPtp && (
                    <PTP
                      openPtp={openPtp}
                      module={module}
                      setOpenPtp={setOpenPtp}
                      geoData={geoData}
                    />
                  )}
                  {openPyamentTable && (
                    <PaymentTable
                      module={module}
                      openPyamentTable={openPyamentTable}
                      geoData={geoData}
                      setOpenPaymentTable={setOpenPaymentTable}
                    />
                  )}
                  {openDispute && (
                    <Dispute
                      module={module}
                      openDispute={openDispute}
                      geoData={geoData}
                      setOpenDispute={setOpenDispute}
                    />
                  )}
                  {openException && (
                    <RiseException
                      geoData={geoData}
                      module={module}
                      openException={openException}
                      setCloseException={setCloseException}
                    />
                  )}
                  {openContect && (
                    <ContactCenter
                      openContect={openContect}
                      setCloseContect={setCloseContect}
                      masking={maskingMobileNo}
                    />
                  )}
                  {openRequest && (
                    <RequestTable
                      module={module}
                      geoData={geoData}
                      lanId={lanId}
                      setCloseRequest={setCloseRequest}
                      openRequest={openRequest}
                      currentModule={caseProfile}
                    />
                  )}
                </CardBody>
              </Card>{" "}
              <Card>
                <CardBody>
                  <h5 className="fw-bold">Call History</h5>
                  <Row>
                    <CallHistory
                      raiseException={raiseException}
                      disputeReason={disputeReason}
                    />
                  </Row>
                </CardBody>
              </Card>
            </div>
          </Col>
        </Row>
      </>
    );
  } else {
    return (
      <>
        <h1>Case not Found</h1>
      </>
    );
  }
}
