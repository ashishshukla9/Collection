import React, { useEffect, useState } from "react";
import { Table } from "reactstrap";
import { Dialog } from "primereact/dialog";
import { Panel } from "primereact/panel";
import axios from "axios";
import { useParams } from "react-router-dom";

const CollateralDetails = (props) => {
  const { collatralDig, setCollatralDig } = props;
  const [collateralDetails, setCollateralDetails] = useState({});
  const { lanId } = useParams();
  useEffect(() => {
    axios
      .get(`/getCollatralDetailsByLoanAccountNumber/${lanId}`)
      .then(({ data }) => {
        setCollateralDetails({ ...data.data });
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);
  const collData = [
    {
      data: [
        {
          column: "Manufacturer",
          row: collateralDetails.manufacturer || "-",
        },
        {
          column: "Vehicle Reg No",
          row: collateralDetails.vehicleRegNo || "-",
        },
        {
          column: "Valuation",
          row: collateralDetails.vehicleValuation || "-",
        },
        {
          column: "Engine No",
          row: collateralDetails.engineNumber || "-",
        },
        {
          column: "Make Model Name",
          row: collateralDetails.makeModelName || "-",
        },
        {
          column: "Used/New",
          row: collateralDetails.usedOrNew || "-",
        },
        {
          column: "Vehicle Chasis No",
          row: collateralDetails.vehicleChassisNumber || "-",
        },
        {
          column: "Vehicle  Manufacturing  Year",
          row: collateralDetails.vehicleManufacturingYear || "-",
        },
      ],
    },
    {
      data: [
        {
          column: "Owner Name 1",
          row: collateralDetails.owner1Name || "-",
        },
        {
          column: "Mobile Number",
          row: collateralDetails.owner1Mobile || "-",
        },
        {
          column: "Email",
          row: collateralDetails.owner1Email || "-",
        },
        {
          column: "Address",
          row: collateralDetails.owner1Address || "-",
        },
      ],
    },
    {
      data: [
        {
          column: "Owner Name 2",
          row: collateralDetails.owner2Name || "-",
        },
        {
          column: "Mobile Number",
          row: collateralDetails.owner2Mobile || "-",
        },
        {
          column: "Email",
          row: collateralDetails.owner2Email || "-",
        },
        {
          column: "Address",
          row: collateralDetails.owner2Address || "-",
        },
      ],
    },
  ];

  const template = (options) => {
    const toggleIcon = options.collapsed ? (
      <i className="bi bi-chevron-down"></i>
    ) : (
      <i className="bi bi-chevron-up"></i>
    );
    const className = `${options.className} justify-content-space-between`;
    const titleClassName = `${options.titleClassName} ml-2 `;
    const style = { fontSize: "1rem", padding: "0px !important" };

    return (
      <div className={className} style={{ height: "40px" }}>
        <span className={titleClassName} style={style}>
          Auto
        </span>
        <button
          className={options.togglerClassName}
          onClick={options.onTogglerClick}
        >
          <span>{toggleIcon}</span>
        </button>
      </div>
    );
  };
  const template1 = (options) => {
    // const toggleIcon = options.collapsed ? 'pi pi-chevron-down' : 'pi pi-chevron-up';
    const toggleIcon = options.collapsed ? (
      <i className="bi bi-chevron-down"></i>
    ) : (
      <i className="bi bi-chevron-up"></i>
    );
    const className = `${options.className} justify-content-space-between`;
    const titleClassName = `${options.titleClassName} ml-2 `;
    const style = { fontSize: "1rem" };

    return (
      <div className={className} style={{ height: "40px" }}>
        <span className={titleClassName} style={style}>
          Housing
        </span>
        <button
          className={options.togglerClassName}
          onClick={options.onTogglerClick}
        >
          <span>{toggleIcon}</span>
        </button>
      </div>
    );
  };
  return (
    <Dialog
      header="Collateral Details"
      visible={collatralDig}
      style={{ width: "60vw" }}
      onHide={() => setCollatralDig(false)}
    >
      {collateralDetails.manufacturer || collateralDetails.ltv ? (
        <>
          {collateralDetails.manufacturer && (
            <Panel headerTemplate={template} toggleable>
              <Table
                size="sm"
                bordered
                responsive={true}
                className="table table-hover table-striped"
              >
                {collData.map((item, i) => {
                  return (
                    <>
                      <tbody>
                        <tr>
                          {item.data.map((item1, index) => {
                            return (
                              <>
                                {item1.column === "Address" ? (
                                  <th
                                    className="px-3 text-center"
                                    style={{
                                      fontSize: "15px",
                                      fontWeight: "800",
                                    }}
                                    colSpan={5}
                                    key={index}
                                  >
                                    {item1.column}
                                  </th>
                                ) : (
                                  <th
                                    className="px-5 text-center text-nowrap"
                                    style={{
                                      fontSize: "15px",
                                      fontWeight: "800",
                                    }}
                                    key={index}
                                  >
                                    {item1.column}
                                  </th>
                                )}
                              </>
                            );
                          })}
                        </tr>
                        <tr>
                          {item.data.map((item1, index) => {
                            return (
                              <>
                                {item1.column === "Address" ? (
                                  <td
                                    className="text-center"
                                    key={index}
                                    colSpan={5}
                                  >
                                    {item1.row}
                                  </td>
                                ) : (
                                  <td className="text-center" key={index}>
                                    {item1.row}
                                  </td>
                                )}
                              </>
                            );
                          })}
                        </tr>
                      </tbody>
                    </>
                  );
                })}
              </Table>
            </Panel>
          )}
          {collateralDetails.ltv && (
            <Panel headerTemplate={template1} className="mt-2" toggleable>
              <Table
                size="sm"
                bordered
                responsive={true}
                className="table table-hover table-striped"
              >
                <tbody>
                  <tr className="text-center">
                    <th>LTV</th>
                    <th>Storage </th>
                    <th colSpan={2}>Valuation</th>
                  </tr>
                  <tr className="text-center">
                    <td>{collateralDetails.ltv || "-"}</td>
                    <td>{collateralDetails.propertyLocation || "-"}</td>
                    <td colSpan={2}>
                      {collateralDetails.propertyValue || "-"}
                    </td>
                  </tr>
                  <tr className="text-center">
                    <th className="text-nowrap px-5">Owner Name 1</th>
                    <th>Mobile Number </th>
                    <th>Email</th>
                    <th className="text-center">Address</th>
                  </tr>
                  <tr className="text-center">
                    <td>{collateralDetails.owner1Name || "-"}</td>
                    <td>{collateralDetails.owner1Mobile || "-"}</td>
                    <td>{collateralDetails.owner1Email || "-"}</td>
                    <td>{collateralDetails.owner1Address || "-"}</td>
                  </tr>
                  <tr className="text-center">
                    <th className="text-nowrap"> Owner Name 2</th>
                    <th>Mobile Number </th>
                    <th>Email</th>
                    <th className="text-center">Address</th>
                  </tr>
                  <tr className="text-center">
                    <td>{collateralDetails.owner2Name || "-"}</td>
                    <td>{collateralDetails.owner2Mobile || "-"}</td>
                    <td>{collateralDetails.owner2Email || "-"}</td>
                    <td>{collateralDetails.owner2Address || "-"}</td>
                  </tr>
                </tbody>
              </Table>
            </Panel>
          )}
        </>
      ) : (
        <p className="h3">Collateral Details doesn't exist for this case.</p>
      )}
    </Dialog>
  );
};

export default CollateralDetails;
