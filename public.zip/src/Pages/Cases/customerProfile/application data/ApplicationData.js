import React, { useEffect, useState } from "react";
import { Col, Row, Table } from "reactstrap";
import { Dialog } from "primereact/dialog";
import axios from "axios";
import Swal from "sweetalert2";
import { useParams } from "react-router-dom";

const ApplicationData = (props) => {
  const { applicationData, setApplicationData } = props;
  const { lanId } = useParams();
  const [applicationDetails, setApplicationDetails] = useState({});

  useEffect(() => {
    axios
      .get(`/getApplicationDetailsByLoanAccountNumber/${lanId}`)
      .then(({ data }) => {
        // console.log(data.data);
        setApplicationDetails({ ...data.data });
      })
      .catch((error) => {
        console.log(error);
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  }, []);
  return (
    <Dialog
      header="Application Details"
      visible={applicationData}
      style={{ width: "60vw" }}
      onHide={() => setApplicationData(false)}
    >
      <Row>
        <Col>
          <div className="border border-secondary-subtle rounded">
            <Table
              size="sm"
              borderless
              className="table table-hover table-striped text-center"
              // style={{ padding: "0px !important" }}
            >
              <thead className="table-light">
                <tr>
                  <th>LENDER ID</th>
                  <th className="fw-normal">{applicationDetails.lenderId}</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Lender Name</td>
                  <td>{applicationDetails.lenderName}</td>
                </tr>
                
                <tr>
                  <td>Loan Account Number</td>
                  <td>{applicationDetails.loanAccountNumber}</td>
                </tr>
                <tr>
                  <td>Customer ID</td>
                  <td>{applicationDetails.customerId}</td>
                </tr>
                {/* <tr>
                  <td>LMS ID</td>
                  <td style={{ wordWrap: "break-word", maxWidth: "50ch" }}>
                    {applicationDetails.lmsId}
                  </td>
                </tr> */}
              </tbody>
            </Table>
          </div>
        </Col>
        <Col>
          <div className="border border-secondary-subtle rounded">
            <Table
              size="sm"
              borderless
              style={{ borderRadius: "10px" }}
              className="table table-hover table-striped text-center"
            >
              <thead className="table-light">
                <tr>
                  <th>Name</th>
                  <th className="fw-normal">
                    {applicationDetails.customerName}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Bank Account No</td>
                  <td>{applicationDetails.bankAccountNumber}</td>
                </tr>
                <tr>
                  <td>Pincode</td>
                  <td>{applicationDetails.pinCode}</td>
                </tr>
                <tr>
                  <td>PAN</td>
                  <td>{applicationDetails.pan}</td>
                </tr>
                <tr>
                  <td>Aadhar</td>
                  <td>{applicationDetails.aadhar}</td>
                </tr>
              </tbody>
            </Table>
          </div>
        </Col>
      </Row>
    </Dialog>
  );
};

export default ApplicationData;
