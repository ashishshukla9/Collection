import React, { useEffect, useState } from "react";
import { Table } from "reactstrap";
import { Dialog } from "primereact/dialog";
import { Panel } from "primereact/panel";
import axios from "axios";
import Swal from "sweetalert2";
import { useParams } from "react-router-dom";

const LoanHistory = (props) => {
  const { loanHistoryDig, setLoanHistoryDig } = props;
  const [loanHistory, setLoanHistory] = useState({});
  const { lanId } = useParams();

  const template = (options) => {
    const toggleIcon = options.collapsed ? (
      <i className="bi bi-chevron-down"></i>
    ) : (
      <i className="bi bi-chevron-up"></i>
    );
    const className = `${options.className} justify-content-space-between`;
    const titleClassName = `${options.titleClassName} ml-2 `;
    const style = { fontSize: "1rem", padding: "0px !important" };

    return (
      <div className={className} style={{ height: "40px" }}>
        <span className={titleClassName} style={style}>
          Disbursement
        </span>
        <button
          className={options.togglerClassName}
          onClick={options.onTogglerClick}
        >
          <span>{toggleIcon}</span>
        </button>
      </div>
    );
  };
  const template1 = (options) => {
    // const toggleIcon = options.collapsed ? 'pi pi-chevron-down' : 'pi pi-chevron-up';
    const toggleIcon = options.collapsed ? (
      <i className="bi bi-chevron-down"></i>
    ) : (
      <i className="bi bi-chevron-up"></i>
    );
    const className = `${options.className} justify-content-space-between`;
    const titleClassName = `${options.titleClassName} ml-2 `;
    const style = { fontSize: "1rem" };

    return (
      <div className={className} style={{ height: "40px" }}>
        <span className={titleClassName} style={style}>
          Repayment
        </span>
        <button
          className={options.togglerClassName}
          onClick={options.onTogglerClick}
        >
          <span>{toggleIcon}</span>
        </button>
      </div>
    );
  };

  useEffect(() => {
    axios
      .get(`/getLoanHistoryByLoanAccountNumber/${lanId}`)
      .then(({ data }) => {
        setLoanHistory({ ...data.data });
      })
      .catch((error) => {
        console.log(error);
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  }, []);
  return (
    <Dialog
      header="Loan History"
      visible={loanHistoryDig}
      style={{ width: "50vw" }}
      onHide={() => setLoanHistoryDig(false)}
    >
      <section>
        <Panel headerTemplate={template} toggleable>
          <Table
            size="sm"
            bordered
            className="table table-hover table-striped text-center"
          >
            <tbody>
              <tr>
                <td>Loan Account Number</td>
                <td>{loanHistory.loanAccountNumber || "-"}</td>
              </tr>
              <tr>
                <td>Loan Product</td>
                <td>{loanHistory.loanProduct || "-"}</td>
              </tr>
              <tr>
                <td>Loan Amount</td>
                <td>{(loanHistory.loanAmount)?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>Date of Disbursement</td>
                <td>{loanHistory.disbursementDate || "-"}</td>
              </tr>
              <tr>
                <td>Interest</td>
                <td>{loanHistory.interestRate || "-"}</td>
              </tr>
              <tr>
                <td>Tenure</td>
                <td>{loanHistory.tenor || "-"}</td>
              </tr>
              <tr>
                <td>Repayment Type</td>
                <td>{loanHistory.repaymentType || "-"}</td>
              </tr>
              <tr>
                <td>Collateral</td>
                <td>{loanHistory.collateral || "-"}</td>
              </tr>
              <tr>
                <td>Frequency</td>
                <td>{loanHistory.frequency || "-"}</td>
              </tr>
              <tr>
                <td>NACH</td>
                <td>{loanHistory.nach || "-"}</td>
              </tr>
              <tr>
                <td>Disbursed Amount</td>
                <td>{loanHistory.disbursedAmount || "-"}</td>
              </tr>
            </tbody>
          </Table>
        </Panel>
        <Panel
          className=" my-2"
          headerTemplate={template1}
          toggleable
          collapsed
        >
          <Table
            size="sm"
            bordered
            className="table table-hover table-striped text-center"
          >
            <tbody>
              <tr>
                <td>Branch Name</td>
                <td>{loanHistory.branchName || "-"}</td>
              </tr>
              <tr>
                <td>Bank IFSC</td>
                <td>{loanHistory.bankIFSC || "-"}</td>
              </tr>
              <tr>
                <td>Bank UPI Address</td>
                <td>{loanHistory.bankUpiAddress || "-"}</td>
              </tr>
              <tr>
                <td>DPD</td>
                <td>{loanHistory.dpd || "-"}</td>
              </tr>
              <tr>
                <td>Total Overdue Amount</td>
                <td>
                  {loanHistory.totalOverdueAmount?.toLocaleString('en-IN', {
                    style: 'currency',
                    currency: 'INR'
                  }) || "-"}
                </td>
              </tr>
              <tr>
                <td>Pending EMI Amount</td>
                <td>{loanHistory.pendingEmiAmount?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>DCP/LPP</td>
                <td>{loanHistory.dcpOrLpp || "-"}</td>
              </tr>
              <tr>
                <td>Closure Amount</td>
                <td>{loanHistory.closureAmount?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>Settlement Amount</td>
                <td>{loanHistory.settlementAmount?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>Last Payment Amount</td>
                <td>{loanHistory.lastPaymentAmount?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>Other Charges</td>
                <td>{loanHistory.otherCharges?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>Pending EMI Principal Amount</td>
                <td>{loanHistory.pendingEmiPrincipalAmount?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>Pending EMI Interest Amount</td>
                <td>{loanHistory.pendingEmiInterestAmount?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>EMI Amount</td>
                <td>{loanHistory.emiAmount?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
              <tr>
                <td>Cheques Bounce Charge</td>
                <td>{loanHistory.chequeBounceCharges?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            }) || "-"}</td>
              </tr>
            </tbody>
          </Table>
        </Panel>
      </section>
    </Dialog>
  );
};

export default LoanHistory;
