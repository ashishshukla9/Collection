import {
  Button,
  Card,
  CardBody,
  Col,
  Collapse,
  Form,
  FormGroup,
  Input,
  Row,
} from "reactstrap";
import MultiSelect from "../../components/Selection/MultiSelect";
import { Formik } from "formik";
import MultiSelectionFormik from "../../components/Selection/MultiSelectionFormik";
import { Fragment, memo, useEffect, useMemo, useState } from "react";
import axios from "axios";
import {
  setAgencySelected,
  setCurrentmodule,
  setFieldVisit,
  setFilterAction,
  setFilterPayload,
  setList,
  setSearchActive,
  setTotalCount,
  setAllTotalCount,
  setNewTotalCount,
  setUnalloctaedPendingTotalCount,
  setAllocatedTotalCount,
  setInprogressTotalCount,
  setMyCaseTotalCount,
  setReset,
  setUnalloctaedApproveTotalCount,
  setUnalloctaedrejectTotalCount,
  setlanderfilterpayload,
} from "./store";
import { useDispatch, useSelector } from "react-redux";
import * as yup from "yup";
import Select from "react-select";
import Field from "../../components/Field";
import Label from "../../components/Field/Label";
import styles from "./CaseProfile.module.scss";
import Swal from "sweetalert2";
import { getProductData } from "../Master/store/productMasterSlice";
import { setAction, setLoader, setReload } from "../../reducer/globalReducer";
import { extendToken } from "../../utils/commonFun";
const CaseFilterForm = (props) => {
  const [activeLender, setActiveLender] = useState([]);
  const [activeportfolio, setActivePortfolio] = useState([]);
  const [activeZone, setActiveZone] = useState([]);
  const [activeRegion, setActiveRegion] = useState([]);
  const [activeState, setActiveState] = useState([]);
  const [activeCities, setActiveCities] = useState([]);
  const [activePincodes, setActivePincodes] = useState([]);
  const [filterDialog, setFilterDialog] = useState(false);
  const [isFilter, setIsFilter] = useState(false);
  const [searchActive, setsearchActive] = useState(true);
  const [pincodeList, setPincodeList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [allocatedOption, setAllocatedOption] = useState([]);
  const [activeButton, setActiveButton] = useState({
    Bucket: false,
    DPD: false,
    POS: false,
    TOS: false,
    Dormancy: false,
  });
  const [productOp, setProductOp] = useState([]);
  const [pagination, setPagination] = useState({});
  const [maxPincodePages, setMaxPincodePages] = useState(0);
  const [currentPincodePage, setCurrentPincodePage] = useState(1);
  const [pincodeId, setPincodeId] = useState("");
  const [maxCityPages, setMaxCityPages] = useState(0);
  const [currentCityPage, setCurrentCityPage] = useState(1);
  const [stateId, setStateId] = useState("");
  const user = useSelector((state) => state.user.data);
  const filterPayload = useSelector((state) => state?.cases?.filterPayload);
  const agencySelected = useSelector((state) => state?.cases?.agencySelected);
  const productData = useSelector((state) => state?.productMaster?.data);
  const loginSessionTimeout = useSelector(
    (state) => state?.global?.loginSessionTimeout
  );
  const roleCode = useMemo(() => user?.role?.map((a) => a?.roleCode), [user]);
  const { reset } = useSelector((state) => state.cases.reset);
  const dispatch = useDispatch();
  const activeTab = useMemo(() => {
    const tab = props?.activeTab;
    return tab?.charAt(0).toUpperCase() + tab.slice(1).toLowerCase();
  }, [props?.activeTab]);
  const filterParameter = {
    product: [],
    portfolio: [],
    zone: [],
    region: [],
    state: [],
    city: [],
    pincode: [],
    paymentStatus: "",
    callStatus: "",
    callingAgent: "",
    fieldAgent: "",
    bucket: {
      min: "",
      max: "",
    },
    POS: {
      min: "",
      max: "",
    },
    TOS: {
      min: "",
      max: "",
    },
    DPD: {
      min: "",
      max: "",
    },
    dormancy: {
      min: "",
      max: "",
    },
  };
  const validationSchema = yup.object({
    bucket: yup.object().shape(
      {
        min: yup.string().when("max", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "min",
                message: "Min value is less than or equal to Max value",
                test: (value, context) =>
                  value <= Number(context?.parent?.max || 0),
              })
              .required("Bucket min is required"),
        }),
        max: yup.string().when("min", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "max",
                message: "Max value is greater than or equal to Min value",
                test: (value, context) =>
                  value >= Number(context?.parent?.min || 0),
              })
              .required("Bucket max is required"),
        }),
      },
      ["min", "max"]
    ),
    POS: yup.object().shape(
      {
        min: yup.string().when("max", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "min",
                message: "Min value is less than or equal to Max value",
                test: (value, context) =>
                  value <= Number(context?.parent?.max || 0),
              })
              .required("POS min is required"),
        }),
        max: yup.string().when("min", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "max",
                message: "Max value is greater than or equal to Min value",
                test: (value, context) =>
                  value >= Number(context?.parent?.min || 0),
              })
              .required("POS max is required"),
        }),
      },
      ["min", "max"]
    ),
    TOS: yup.object().shape(
      {
        min: yup.string().when("max", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "min",
                message: "Min value is less than or equal to Max value",
                test: (value, context) =>
                  value <= Number(context?.parent?.max || 0),
              })
              .required("TOS min is required"),
        }),
        max: yup.string().when("min", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "max",
                message: "Max value is greater than or equal to Min value",
                test: (value, context) =>
                  value >= Number(context?.parent?.min || 0),
              })
              .required("TOS max is required"),
        }),
      },
      ["min", "max"]
    ),
    DPD: yup.object().shape(
      {
        min: yup.string().when("max", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "min",
                message: "Min value is less than or equal to Max value",
                test: (value, context) =>
                  value <= Number(context?.parent?.max || 0),
              })
              .required("DPD min is required"),
        }),
        max: yup.string().when("min", {
          is: (a) => a,
          then: () =>
            yup
              .string()
              .test({
                name: "max",
                message: "Max value is greater than or equal to Min value",
                test: (value, context) =>
                  value >= Number(context?.parent?.min || 0),
              })
              .required("DPD max is required"),
        }),
      },
      ["min", "max"]
    ),
  });
  const otherFilterBtn = useMemo(() => [
    {
      id: 1,
      name: "Bucket",
    },
    {
      id: 2,
      name: "DPD",
    },
    {
      id: 3,
      name: "POS",
    },
    {
      id: 4,
      name: "TOS",
    },
    {
      id: 5,
      name: "Dormancy",
    },
  ]);
  const getAllZone = async () => {
    try {
      const res = await axios.get("/getAllZones");
      const ops = [];
      res?.data?.data?.forEach((data) => {
        if (data?.active === "Y") {
          ops.push({
            label: data.zoneName,
            value: data.zoneCode,
            zoneId: data?.zoneId,
          });
        }
      });
      setActiveZone(ops);
    } catch (error) {
      setActiveZone([]);
    }
  };
  const getAllRegion = async () => {
    try {
      const res = await axios.get("/getAllRegions");
      const ops = [];
      res?.data?.data?.forEach((data) => {
        if (data?.active === "Y") {
          ops.push({
            label: data.regionName,
            value: data.regionCode,
            regionId: data?.regionId,
          });
        }
      });
      setActiveRegion(ops);
    } catch (error) {
      setActiveRegion([]);
    }
  };
  const getAllState = async () => {
    try {
      const res = await axios.get("/getAllStates");
      const ops = [];
      res?.data?.data?.forEach((data) => {
        if (data?.active === "Y") {
          ops.push({
            label: data.stateName,
            value: data.stateCode,
            stateId: data?.stateId,
          });
        }
      });
      setActiveState(ops);
    } catch (error) {
      setActiveState([]);
    }
  };
  const getAllCities = async () => {
    try {
      const res = await axios.get("/getAllCities/1/10");
      const ops = [];
      res?.data?.response?.forEach((data) => {
        if (data?.active === "Y") {
          ops.push({
            label: data.cityName,
            value: data.cityCode,
            cityId: data?.cityId,
          });
        }
      });
      setActiveCities(ops);
    } catch (error) {
      setActiveCities([]);
    }
  };
  const getAllPincodes = async () => {
    try {
      const res = await axios.get("/getAllPincodes/1/10");
      const ops = [];
      res?.data?.response?.forEach((data) => {
        if (data?.active === "Y") {
          ops.push({
            label: data.pincode,
            value: data.pincodeId,
          });
        }
      });
      setActivePincodes(ops);
    } catch (error) {
      setActivePincodes([]);
    }
  };
  const getBulkUploadSuccessByListOfLan = async (data, isNotMIS) => {
    dispatch(setLoader(true));
    try {
      if (data?.length) {
        let allLenId = data?.map((a) => a?.allLan);
        allLenId = [...new Set(allLenId)];
        const allNewCases = data
          ?.filter((a) => a?.newCase === "Y")
          ?.map((a) => a?.allLan);
        const allAllocatedCases = data
          ?.filter((a) => a?.allocated === "Y")
          ?.map((a) => a?.allLan);
        const allMyCases = data
          ?.filter((a) => a?.newCase === "Y")
          ?.map((a) => a?.allLan);
        const allInProgressCases = data
          ?.filter((a) => a?.inProcess === "Y")
          ?.map((a) => a?.allLan);
        const allCases = {
          allNewCases,
          allAllocatedCases,
          allMyCases,
          allInProgressCases,
        };
        let userId = data?.map((a) => a?.userId);
        userId = [...new Set(userId)][0];
        const allocatedUserId = {};
        data?.map((a) => {
          Object.assign(allocatedUserId, {
            [a?.allLan]: a?.allocatedUser,
            [`fieldPickUp${a?.allLan}`]: a?.fieldPickUp,
          });
        });

        const res2 = await axios.post(
          `/getBulkUploadSuccessByListOfLan/${user?.userId}`,
          allLenId
        );
        dispatch(setLoader(false));
        const caseStatus = (allCases, loanAccountNumber) => {
          return allCases?.allNewCases?.includes(loanAccountNumber)
            ? "New"
            : allCases?.allInProgressCases?.includes(loanAccountNumber) ||
              allCases?.allAllocatedCases?.includes(loanAccountNumber) ||
              allCases?.allMyCases?.includes(loanAccountNumber)
            ? "Allocated"
            : "";
        };
        const finalData = res2?.data?.data?.map((data) => ({
          ...data,
          allocateduserid1: data?.allocatedUser,
          allocatedUser: isNotMIS
            ? allocatedUserId?.[data?.loanAccountNumber]
            : data?.allocatedUser,
          caseStatus:
            userId === user?.userId
              ? caseStatus(allCases, data?.loanAccountNumber)
              : "Allocated",
        }));
        // console.log(finalData, "finalDatafinalDatafinalDatafinalDatafinalData")
        dispatch(setList(finalData));
      } else {
        dispatch(setList([]));
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.response?.data?.error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
      console.log(error);
    }
  };

  const filterSearchLogic = async (dummayPayload, pageNumber) => {
    let payload = {};
    let isAgencyAPICalled = false;
    let isFilterAPICalled = false;
    setPagination({
      pageNumber: pageNumber,
      numberOfDataPerPage: props?.numberOfDataPerPage,
    });

    Object.entries(dummayPayload)?.map((a) => {
      if (a[1]?.length) {
        Object.assign(payload, { [a[0]]: a[1] });
      }
    });
    dispatch(setFilterPayload(payload));

    let filterData = [];
    let agencyData = [];

    const timer = setInterval(() => {
      dispatch(setAction(1));
      extendToken(loginSessionTimeout);
    }, 60000);

    try {
      if (Object.keys(payload).length || agencySelected) {
        if (activeTab !== "All") {
          payload = {
            ...payload,
            caseStatus:
              activeTab === "Deallocation" ? "Deallocated" : activeTab,
          };
        }
        const misAllPrimaryUrl =
          props?.currentModule === "Field" || user?.activityType === "Field"
            ? "getFilterBulkUpLoadByMISField"
            : "getFilterBulkUpLoadByMIS";
        const allPrimaryUrl =
          props?.currentModule === "Field" || user?.activityType === "Field"
            ? "getFilterBulkUpLoadByAllField"
            : "getFilterBulkUpLoadByAll";
        const AgencyUserUrl =
          props?.currentModule === "Field" || user?.activityType === "Field"
            ? "getFilterBulkUpLoadByAllFieldDRA"
            : "getFilterBulkUpLoadByAllCA";
        const landerUrl = `getLenderCases/${user?.userId}/${activeTab}/${pageNumber}/${props?.numberOfDataPerPage}`;

        // const LenderUrl = ""
        // previous logic
        // const url = (roleCode?.includes("MIS") || roleCode?.includes("RH") || roleCode?.includes("CH") || roleCode?.includes("OH") ) ? `${misAllPrimaryUrl}/${user?.userId}/${activeTab}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : (roleCode?.includes("CA") || roleCode?.includes("FA")) ? `getFilterBulkUpLoadByAllCA/${user?.userId}/${activeTab}/${roleCode}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : roleCode?.includes('DRA') ? `getFilterBulkUpLoadByAllFieldDRA/${user?.userId}/${activeTab}/${roleCode}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : `${allPrimaryUrl}/${user?.userId}/${activeTab}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}`

        // "current logic "
        // console.log(roleCode, "checking the current role code")
        const misCodes = ["MIS", "RH", "CH", "OH", "OP"];
        const caFaCodes = ["CA", "FA"];

        // const url = (misCodes.some(code => roleCode?.includes(code))) ? `${misAllPrimaryUrl}/${user?.userId}/${activeTab}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : (caFaCodes.some(code => roleCode?.includes(code))) ? `getFilterBulkUpLoadByAllCA/${user?.userId}/${activeTab}/${roleCode}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : roleCode?.includes('DRA') ? `getFilterBulkUpLoadByAllFieldDRA/${user?.userId}/${activeTab}/${roleCode}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : `${allPrimaryUrl}/${user?.userId}/${activeTab}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}`;

        const url = misCodes.some((code) => roleCode?.includes(code))
          ? `${misAllPrimaryUrl}/${user?.userId}/${activeTab}/${
              agencySelected?.value || 0
            }/${pageNumber}/${props?.numberOfDataPerPage}`
          : caFaCodes.some((code) => roleCode?.includes(code))
          ? `${AgencyUserUrl}/${user?.userId}/${activeTab}/${roleCode}/${
              agencySelected?.value || 0
            }/${pageNumber}/${props?.numberOfDataPerPage}`
          : roleCode?.includes("DRA")
          ? `${AgencyUserUrl}/${user?.userId}/${activeTab}/${roleCode}/${
              agencySelected?.value || 0
            }/${pageNumber}/${props?.numberOfDataPerPage}`
          : roleCode?.includes("L01") || roleCode?.includes("L02")
          ? landerUrl
          : `${allPrimaryUrl}/${user?.userId}/${activeTab}/${
              agencySelected?.value || 0
            }/${pageNumber}/${props?.numberOfDataPerPage}`;
        dispatch(setLoader(true));
        const res = await axios.post(`/${url}`, payload);
        dispatch(setLoader(false));
        // console.log(res, "filter response")
        let allCases = {};
        if (!roleCode?.includes("MIS")) {
          const allNewCases = res?.data?.response
            ?.filter((a) => a?.newCase === "Y")
            ?.map((a) => a?.allLan);
          const allAllocatedCases = res?.data?.response
            ?.filter((a) => a?.allocated === "Y")
            ?.map((a) => a?.allLan);
          const allMyCases = res?.data?.response
            ?.filter((a) => a?.newCase === "Y")
            ?.map((a) => a?.allLan);
          allCases = { allNewCases, allAllocatedCases, allMyCases };
        }
        isFilterAPICalled = true;
        filterData = res?.data?.response;
        // console.log(filterData, "all filter final data")
        if (res?.data?.totalApplicationCount >= 0) {
          if (activeTab == "All") {
            dispatch(setAllTotalCount(res?.data?.totalApplicationCount));
          } else if (activeTab == "New") {
            dispatch(setNewTotalCount(res?.data?.totalApplicationCount));
          } else if (activeTab == "Allocated") {
            dispatch(setAllocatedTotalCount(res?.data?.totalApplicationCount));
          } else if (activeTab == "In_progress") {
            dispatch(setInprogressTotalCount(res?.data?.totalApplicationCount));
          } else if (activeTab == "My_case") {
            dispatch(setMyCaseTotalCount(res?.data?.totalApplicationCount));
          } else if (activeTab == "Unallocated_pending") {
            dispatch(
              setUnalloctaedPendingTotalCount(res?.data?.totalApplicationCount)
            );
          } else if (activeTab == "Unallocated_approved") {
            dispatch(
              setUnalloctaedApproveTotalCount(res?.data?.totalApplicationCount)
            );
          } else if (activeTab == "Unallocated_rejected") {
            dispatch(
              setUnalloctaedrejectTotalCount(res?.data?.totalApplicationCount)
            );
          }
          dispatch(setTotalCount(res?.data?.totalApplicationCount));
        }
      }

      // if (agencySelected) {
      //     const agencyPrimaryUrl = (props?.currentModule === "Field" || user?.activityType === "Field") ? 'getFilterBulkUpLoadByAgencyField' : 'getFilterBulkUpLoadByAgency'
      //     const agentRes = await axios.post(`${agencyPrimaryUrl}/${agencySelected?.value}/${user?.userId}/${activeTab}/${pageNumber}/${props?.numberOfDataPerPage}`)
      //     isAgencyAPICalled = true
      //     agencyData = agentRes?.data?.response
      //     if (agentRes?.data?.totalApplicationCount >= 0) {
      //         dispatch(setTotalCount(agentRes?.data?.totalApplicationCount))
      //     }
      // }

      if (isFilterAPICalled && isAgencyAPICalled) {
        const finalData = filterData?.filter((a) =>
          agencyData
            ?.map((b) => b?.allLan)
            .includes(a?.allLan || a?.loanAccountNumber)
        );
        getBulkUploadSuccessByListOfLan(finalData, !roleCode?.includes("MIS"));
      } else if (filterData.length) {
        if (
          roleCode?.includes("MIS") ||
          roleCode?.includes("RH") ||
          roleCode?.includes("CH") ||
          roleCode?.includes("OH") ||
          roleCode?.includes("OP")
        ) {
          dispatch(setList(filterData));
        } else if (roleCode?.includes("L01") || roleCode?.includes("L02")) {
          dispatch(setList(filterData));
        } else {
          getBulkUploadSuccessByListOfLan(
            filterData,
            !roleCode?.includes("MIS")
          );
        }
      } else if (agencyData.length) {
        // if (user?.masterRole?.caseactivity_autoallocation) {
        //     dispatch(setList(agencyData))
        // } else {

        // }
        getBulkUploadSuccessByListOfLan(agencyData, !roleCode?.includes("MIS"));
      } else if (isAgencyAPICalled || isFilterAPICalled) {
        dispatch(setList([]));
      } else {
        props?.setIsFilter(false);
        props?.clearFilter();
      }
    } catch (error) {
      dispatch(setLoader(false));
    }
    clearInterval(timer);
  };

  const handleFilter = async (values) => {
    try {
      const dummayPayload = {
        ...filterPayload,
        // lenderName: props?.lenderSelected?.map(a => a?.label),
        lenderId: props?.searchLAN ? props?.searchLAN?.split(",") : [],
        borrowerName: props?.searchBorrower,
        portfolio: values?.portfolio?.map((a) => a?.value),
        product: values?.product?.map((a) => a?.productCode),
        zone: values?.zone?.map((a) => a?.label),
        region: values?.region?.map((a) => a?.label),
        state: values?.state?.map((a) => a?.label),
        location: values?.city?.map((a) => a?.label),
        pincode: values?.pincode?.map((a) => a?.label),
        bucket: [
          values?.bucket?.min?.toString(),
          values?.bucket?.max?.toString(),
        ]?.filter(Boolean),
        dpd: [
          values?.DPD?.min?.toString(),
          values?.DPD?.max?.toString(),
        ]?.filter(Boolean),
        pos: [
          values?.POS?.min?.toString(),
          values?.POS?.max?.toString(),
        ]?.filter(Boolean),
        tos: [
          values?.TOS?.min?.toString(),
          values?.TOS?.max?.toString(),
        ]?.filter(Boolean),
        paymentStatus: values?.paymentStatus || "NA",
        callStatus: values?.callStatus || "NA",
      };
      // console.log(dummayPayload, "dummayPayload")
      props?.setIsFilter(true);
      filterSearchLogic(dummayPayload, 1);
    } catch (error) {
      console.log(error);
    }
  };
  // console.log("handleFilter",handleFilter);

  const handleResetFilter = (resetForm) => {
    resetForm();
    setActiveButton({
      Bucket: false,
      DPD: false,
      POS: false,
      TOS: false,
      Dormancy: false,
    });
    dispatch(
      setFilterPayload({
        lenderName: filterPayload?.lenderName || [],
        lenderId: filterPayload?.lenderId || [],
      })
    );

    getAllZone();
    getAllRegion();
    getAllState();
    getAllCities();
    getAllPincodes();

    if (
      !filterPayload?.lenderName?.length &&
      !filterPayload?.lenderId?.length &&
      !agencySelected?.value
    ) {
      props?.clearFilter();
    }
    // axios
    //     .post("/getFilterBulkUpLoadByAll", { caseStatus: activeTab === "All" ? '' : activeTab })
    //     .then(({ data }) => {
    //         setIsFilter(false);
    //         dispatch(setList(data?.data))
    //     })
    //     .catch((error) => {
    //         console.log(error);
    //     });
  };

  const onkeyEnterPincode = (event, setFieldValue, preValues) => {
    if (event.key === "Enter") {
      event.preventDefault();
      const filtered_people = activePincodes.filter((person) =>
        pincodeList.includes(person?.label?.toString())
      );
      setFieldValue("pincode", [...preValues, ...filtered_people]);
    }
  };

  const onkeyEnterCity = (event, setFieldValue, preValues) => {
    if (event.key === "Enter") {
      event.preventDefault();
      const filtered_people = activeCities.filter((person) =>
        cityList.includes(person?.label?.toString()?.toLowerCase())
      );
      setFieldValue("city", [...preValues, ...filtered_people]);
    }
  };

  const filterOption = ({ label }, filterValue) => {
    if (filterValue === "") return true;

    const filterValueSplit = filterValue.split(/[, ]+/);
    for (const filterValue of filterValueSplit) {
      if (
        filterValue !== "" &&
        label
          ?.toString()
          ?.toLowerCase()
          ?.includes(filterValue?.toString()?.toLowerCase())
      )
        return true;
    }
    return false;
  };

  const handleSearch = async (values) => {
    // console.log(values?.AllocatedUser?.value, "myyy")
    setsearchActive(true);
    dispatch(setSearchActive(searchActive));
    try {
      const dummayPayload = {
        ...filterPayload,
        portfolio: values?.portfolio?.map((a) => a?.value),
        product: values?.product?.map((a) => a?.productCode),
        borrowerName: props?.searchBorrower,
        zone: values?.zone?.map((a) => a?.label),
        region: values?.region?.map((a) => a?.label),
        state: values?.state?.map((a) => a?.label),
        location: values?.city?.map((a) => a?.label),
        pincode: values?.pincode?.map((a) => a?.label),
        bucket: [
          values?.bucket?.min?.toString(),
          values?.bucket?.max?.toString(),
        ]?.filter(Boolean),
        dpd: [
          values?.DPD?.min?.toString(),
          values?.DPD?.max?.toString(),
        ]?.filter(Boolean),
        pos: [
          values?.POS?.min?.toString(),
          values?.POS?.max?.toString(),
        ]?.filter(Boolean),
        tos: [
          values?.TOS?.min?.toString(),
          values?.TOS?.max?.toString(),
        ]?.filter(Boolean),
        lenderName: props?.lenderSelected?.map((a) => a?.label),
        lenderId: props?.searchLAN ? props?.searchLAN?.split(",") : [],
        paymentStatus: values?.paymentStatus || "NA",
        callStatus: values?.callStatus || "NA",
        allocatedUser: values?.AllocatedUser?.value,
      };
      // console.log(dummayPayload, "dummypayload")
      props?.setIsFilter(true);
      filterSearchLogic(dummayPayload, 1);
    } catch (error) {
      console.log(error);
    }
  };

  // console.log("handleSearch",handleSearch);
  const clearSearch = () => {
    // console.log("passing function");
    dispatch(setAgencySelected(""));
    props?.setLenderSelected([]);
    props?.setSearchLAN("");
    props?.setSelectAllocatedUser("");
    props?.setSearchBorrower("");

    dispatch(
      setFilterPayload({
        ...filterPayload,
        lenderName: [],
        lenderId: [],
      })
    );
    props?.setIsFilter(false);
    props?.clearFilter();
    // axios
    //     .post("/getFilterBulkUpLoadByAll", activeTab === "All" ? {} : { caseStatus: activeTab })
    //     .then(({ data }) => {
    //         setIsFilter(false);
    //         dispatch(setList(data?.data))
    //     })
    //     .catch((error) => {
    //         console.log(error);
    //     });
  };

  useEffect(() => {
    axios
      .get("/getAllActiveLender")
      .then(({ data }) => {
        const tempData = [];
        data?.data?.forEach((lender) => {
          tempData.push({
            label: lender?.lenderName,
            value: lender?.lenderId,
          });
        });
        setActiveLender(tempData);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  useEffect(() => {
    dispatch(getProductData());
  }, []);

  useEffect(() => {
    if (productData?.length) {
      const op = productData?.map((a) => ({
        label: a?.productDescription,
        value: a?.productId,
        productCode: a?.productCode,
        portfolioId: a?.portfolio?.portfolioId,
      }));
      setProductOp(op);
    }
  }, [productData]);

  useEffect(() => {
    if (
      props?.currentPage &&
      props?.numberOfDataPerPage &&
      props?.isFilter &&
      Object.keys(pagination)?.length &&
      (props?.currentPage !== pagination?.pageNumber ||
        props?.numberOfDataPerPage !== pagination?.numberOfDataPerPage)
    ) {
      filterSearchLogic(filterPayload, props?.currentPage);
    }
  }, [props?.currentPage, props?.numberOfDataPerPage, props?.isFilter]);
  useEffect(() => {
    if (props?.isFilter) {
      filterSearchLogic(filterPayload, 1);
    }
  }, [props?.activeTab, props?.currentModule]);

  useEffect(() => {
    if (filterDialog) {
      if (!activeportfolio.lender) {
        axios
          .get("/getAllPortfolio")
          .then(({ data }) => {
            const tempData = [];
            data?.data?.forEach((data) => {
              if (data?.active === "Y")
                tempData.push({
                  label: data?.portfolioDescription,
                  value: data?.portfolioId,
                });
            });
            setActivePortfolio(tempData);
          })
          .catch((error) => {
            console.log(error);
          });

        if (!activeZone.length) getAllZone();
        if (!activeRegion.length) getAllRegion();
        if (!activeState.length) getAllState();
        if (!activeCities.length) getAllCities();
        if (!activePincodes.length) getAllPincodes();
      }
    }
  }, [filterDialog]);

  //  here create the Allocated clear

  const getAllRegionByZone = async (zoneId) => {
    if (zoneId?.length) {
      try {
        const res = await axios.get(`/getRegionByZone/${zoneId}`);

        const ops = res?.data?.data?.map((a) => ({
          label: a.regionName,
          value: a.regionCode,
          regionId: a?.regionId,
        }));

        setActiveRegion(ops);
      } catch (error) {
        setActiveRegion([]);
      }
    } else {
      setActiveRegion([]);
    }
  };

  const getAllStateByRegion = async (regionId) => {
    if (regionId?.length) {
      try {
        const res = await axios.get(`/getStateByRegion/${regionId}`);

        const ops = res?.data?.data?.map((a) => ({
          label: a.stateName,
          value: a.stateCode,
          stateId: a?.stateId,
        }));

        setActiveState(ops);
      } catch (error) {
        setActiveState([]);
      }
    } else {
      setActiveState([]);
    }
  };

  const getAllCityByState = async (stateId, isRestart) => {
    if (stateId?.length) {
      try {
        const res = await axios.get(
          `/getCityByState/${stateId}/${isRestart ? 1 : currentCityPage}/30`
        );

        const ops = res?.data?.response?.map((a) => ({
          label: a.cityName,
          value: a.cityCode,
          cityId: a?.cityId,
        }));

        const maxNumberOfPage = Math.ceil(
          res?.data?.totalApplicationCount / 30 || 0
        );
        setMaxCityPages(maxNumberOfPage);
        if (isRestart) {
          setActiveCities(ops);
        } else {
          setActiveCities([...activeCities, ...ops]);
        }
        setStateId(stateId);
      } catch (error) {
        setStateId("");
        setActiveCities([]);
      }
    } else {
      getAllCities();
      setStateId("");
    }
  };

  const getAllPincodeByCity = async (pincodeId, isRestart) => {
    if (pincodeId?.length) {
      try {
        const res = await axios.get(
          `/getPincodeByCity/${pincodeId}/${
            isRestart ? 1 : currentPincodePage
          }/30`
        );

        const ops = res?.data?.response?.map((a) => ({
          label: a.pincode,
          value: a.pincodeId,
        }));
        const maxNumberOfPage = Math.ceil(
          res?.data?.totalApplicationCount / 30 || 0
        );
        setMaxPincodePages(maxNumberOfPage);
        if (isRestart) {
          setActivePincodes(ops);
        } else {
          setActivePincodes([...activePincodes, ...ops]);
        }
        setPincodeId(pincodeId);
      } catch (error) {
        setPincodeId("");
        setActivePincodes([]);
      }
    } else {
      getAllPincodes();
      setPincodeId("");
    }
  };

  useEffect(() => {
    if (pincodeId && currentPincodePage > 1) {
      getAllPincodeByCity(pincodeId, false);
    }
  }, [currentPincodePage]);

  useEffect(() => {
    if (stateId && currentCityPage > 1) {
      getAllCityByState(stateId, false);
    }
  }, [currentCityPage]);

  useEffect(() => {
    const search = setTimeout(() => {
      if (cityList?.filter(Boolean)?.length) {
        axios
          .get(`/getCityByCityName/${cityList}/0/0`)
          .then(({ data }) => {
            const tempData = [];
            data.response.forEach((data) => {
              if (data.active === "Y")
                tempData.push({
                  label: data.cityName,
                  value: data.cityCode,
                  cityId: data?.cityId,
                });
            });
            setActiveCities(tempData);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    }, 1000);

    return () => {
      clearTimeout(search);
    };
  }, [cityList]);

  useEffect(() => {
    const search = setTimeout(async () => {
      // console.log(pincodeList, "pincodeList")
      if (pincodeList?.filter(Boolean).length) {
        dispatch(setLoader(true));

        // .get(`/getPincodeByPincode/${pincodeList}/0/0`)
        // axios
        //     .get(`/getPincodeByPincode/${pincodeList}/0/0`)
        //     .then(({ data }) => {
        //         const tempData = [];
        //         data.response.forEach((data) => {
        //             if (data.active === "Y")
        //                 tempData.push({
        //                     label: data.pincode,
        //                     value: data.pincodeId,
        //                 });
        //         });
        //         setActivePincodes(tempData);
        //         console.log(activePincodes, "activePincodes")
        //     })
        //     .catch((error) => {
        //         console.log(error);
        //     });
        const payload = {
          pincode: pincodeList.map((str) => parseInt(str, 10)),
        };
        // console.log(payload, "mypayoad")
        await axios
          .post(`/getPincodeByPincodeForCommaSeperated/0/0`, payload)
          .then(({ data }) => {
            dispatch(setLoader(false));
            const tempData = [];
            data.response.forEach((data) => {
              if (data.active === "Y")
                tempData.push({
                  label: data.pincode,
                  value: data.pincodeId,
                });
            });
            setActivePincodes(tempData);
            // console.log(activePincodes, "activePincodes")
          })
          .catch((error) => {
            dispatch(setLoader(false));

            console.log(error);
          });
      }
    }, 1000);

    return () => {
      clearTimeout(search);
    };
  }, [pincodeList]);

  // allocated user

  useEffect(() => {
    const search = setTimeout(async () => {
      try {
        // const response = await axios.get('getAllUserList');
        const response = await axios.get("getUserForAllocation");

        let tempdata = [];
        for (let i = 0; i < response?.data?.data?.length; i++) {
          const element = response?.data?.data[i];
          // console.log(element, "allocated user response")

          if (
            user?.activityType == "Field" ||
            props?.currentModule == "Field"
          ) {
            if (
              element?.activityType == "Field" ||
              element.activityType == "Both"
            ) {
              tempdata.push({
                label: `${element?.firstName} ${element?.lastName}`,
                value: element?.userId,
              });
            }
          } else {
            if (
              element?.activityType == "Calling" ||
              element.activityType == "Both"
            ) {
              tempdata.push({
                label: `${element?.firstName} ${element?.lastName}`,
                value: element?.userId,
              });
            }
          }
        }

        // console.log(tempdata, "filterdata")
        setAllocatedOption(tempdata);
      } catch (error) {
        console.error("Error fetching options:", error);
      }
    }, 1000);

    return () => {
      clearTimeout(search);
    };
  }, [props?.selectAllocatedUser, props?.currentModule]);

  const onFieldVisit = () => {
    props?.onFieldClick(props?.onFieldClick);
  };

  useEffect(() => {
    dispatch(setFieldVisit(props?.currentModule));
  }, [props?.onFieldClick]);

  //  for bydefault paylod
  useEffect(() => {
    const dummayPayload = {
      ...filterPayload,
      portfolio: null,
      product: null,
      borrowerName: null,
      zone: null,
      region: null,
      state: null,
      location: null,
      pincode: null,
      bucket: null,
      dpd: null,
      pos: null,
      tos: null,
      lenderName: null,
      lenderId: null,
      paymentStatus: null,
      callStatus: null,
      allocatedUser: null,
    };
    // props?.setFilterPayload(dummayPayload) // comented code
    dispatch(setlanderfilterpayload(dummayPayload));
    console?.log(dummayPayload, "fh");
  }, []);

  return (
    <Formik
      initialValues={filterParameter}
      validationSchema={validationSchema}
      onSubmit={handleFilter}
    >
      {({
        values,
        errors,
        touched,
        handleChange,
        handleBlur,
        setFieldValue,
        handleSubmit,
        handleReset,
        resetForm,
      }) => {
        // console.log(values, "changing values")
        return (
          <Form onSubmit={handleSubmit}>
            <Card className="mb-1">
              <CardBody className="p-1">
                <div
                  className={
                    user?.userName == "LND01"
                      ? "caseFilterHeader1"
                      : "caseFilterHeader"
                  }
                >
                  <Input
                    bsSize="sm"
                    placeholder="LAN ID.."
                    type="text"
                    value={props?.searchLAN}
                    onChange={(e) => {
                      const tempVal = e.target.value.trim();
                      props?.setSearchLAN(tempVal);
                    }}
                    className="lanIdSearchBox"
                  />
                  <Input
                    bsSize="sm"
                    placeholder="Borrower Name.."
                    type="text"
                    value={props?.searchBorrower}
                    onChange={(e) => {
                      const tempVal = e.target.value;
                      props?.setSearchBorrower(tempVal);
                    }}
                    className="lanIdSearchBox"
                  />
                  {
                    // console.log(user, "finaluser")
                    user?.userName !== "LND01" ? (
                      <>
                        <MultiSelect
                          placeholder="Lender name.."
                          options={activeLender}
                          onChange={(e) => props?.setLenderSelected(e)}
                          closeMenu={false}
                          value={props?.lenderSelected}
                          isClearable
                        />
                        <Select
                          placeholder="Agency name.."
                          options={props?.activeAgency}
                          onChange={(e) => {
                            dispatch(setAgencySelected(e));
                          }}
                          classNamePrefix="react-select"
                          closeMenu={false}
                          value={agencySelected}
                          isClearable={true}
                        />
                      </>
                    ) : (
                      ""
                    )
                  }
                  {/* <Select
                                        placeholder="Search Allocated User..."
                                        options={allocatedUserList?.label}
                                        onChange={(e) => {
                                            
                                            // dispatch(setAlloactedUser(e))
                                            setFieldValue("AllocatedUser", e)
                                        }}
                                        classNamePrefix="react-select"
                                        closeMenu={false}
                                        value={""}
                                        isClearable={true}
                                        isDisabled={true}
                                    /> */}
                  {/*                                     
                                    <Select
                                    placeholder="Allocated User..."
                                    classNamePrefix="react-select"
                                        options={allocatedOption}
                                        value={selectAllocatedUser}
                                        onChange={(e) => {
                                            setFieldValue("AllocatedUser", e)
                                            setSelectAllocatedUser(e?.target?.value)
                                        }}
                                        // isDisabled={true}
                                    /> */}

                  <Button
                    size="sm"
                    color="primary"
                    className="searchBtn"
                    onClick={() => handleSearch(values)}
                    type="button"
                  >
                    Search
                  </Button>
                  <Button
                    size="sm"
                    className="searchBtn"
                    onClick={clearSearch}
                    color="danger"
                    type="button"
                  >
                    Clear
                  </Button>

                  <div className="advFilterBtn">
                    {user?.activityType === "Both" &&
                      user?.role[0]?.roleCode !== "L01" &&
                      user?.role[0]?.roleCode !== "L02" && (
                        <Fragment>
                          <Button
                            outline
                            color="primary"
                            // color={isFilter ? "success" : "primary"}
                            size="sm"
                            className="text-left searchBtn"
                            onClick={() => onFieldVisit()}
                            active={props?.currentModule === "Field"}
                            type="button"
                          >
                            Field Visit
                          </Button>
                        </Fragment>
                      )}
                    <Button
                      outline
                      color={isFilter ? "success" : "primary"}
                      size="sm"
                      className="text-left searchBtn"
                      // onClick={() => {setFilterDialog(!filterDialog), dispatch(setFilterAction(filterDialog))}}
                      onClick={() => {
                        setFilterDialog(!filterDialog);
                        dispatch(setFilterAction(!filterDialog));
                      }}
                      active={filterDialog}
                      type="button"
                    >
                      Filter <i className="bi bi-filter"></i>
                    </Button>
                  </div>
                </div>

                <Collapse isOpen={filterDialog}>
                  <Card>
                    <CardBody>
                      <Row>
                        <Col lg={6} md={6} sm={12}>
                          <MultiSelectionFormik
                            label={"Portfolio"}
                            options={activeportfolio}
                            handleChangeEvent={(e) => {
                              setFieldValue("portfolio", e);
                              setFieldValue("product", []);
                            }}
                            closeMenu={false}
                            value={values.portfolio}
                            ids={"portfolio"}
                          />
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <MultiSelectionFormik
                            label={"Product"}
                            options={productOp
                              ?.map((a) => {
                                const ab = values?.portfolio?.map(
                                  (b) => b?.value
                                );
                                if (ab?.includes(a?.portfolioId)) {
                                  return a;
                                }
                              })
                              ?.filter(Boolean)}
                            handleChangeEvent={(e) =>
                              setFieldValue("product", e)
                            }
                            closeMenu={false}
                            value={values.product}
                            ids={"product"}
                          />
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <MultiSelectionFormik
                            label={"Zone"}
                            options={activeZone}
                            handleChangeEvent={(e) => {
                              setFieldValue("zone", e);
                              getAllRegionByZone(e.map((a) => a?.zoneId));
                              // console.log(e, "mye")
                              if (e.length == 0) {
                                getAllRegion();
                              }
                            }}
                            closeMenu={false}
                            value={values.zone}
                            ids={"zone"}
                          />
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <MultiSelectionFormik
                            label={"Region"}
                            options={activeRegion}
                            handleChangeEvent={(e) => {
                              setFieldValue("region", e);
                              getAllStateByRegion(e?.map((a) => a?.regionId));
                              if (e.length == 0) {
                                getAllState();
                              }
                            }}
                            closeMenu={false}
                            value={values.region}
                            ids={"region"}
                          />
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <MultiSelectionFormik
                            label={"State"}
                            options={activeState}
                            handleChangeEvent={(e) => {
                              setCurrentCityPage(1);
                              setFieldValue("state", e);
                              getAllCityByState(
                                e?.map((a) => a?.stateId),
                                true
                              );
                              if (e.length == 0) {
                                getAllCities();
                              }
                            }}
                            closeMenu={false}
                            value={values.state}
                            ids={"state"}
                          />
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <MultiSelectionFormik
                            label={"City"}
                            options={activeCities}
                            handleChangeEvent={(e) => {
                              setCurrentPincodePage(1);
                              setFieldValue("city", e);
                              getAllPincodeByCity(
                                e?.map((a) => a?.cityId),
                                true
                              );
                            }}
                            closeMenu={false}
                            value={values.city}
                            ids={"city"}
                            onInputChange={(e) => {
                              setCityList(e?.toLowerCase()?.split(","));
                            }}
                            onKeyDown={(e) =>
                              onkeyEnterCity(e, setFieldValue, values?.city)
                            }
                            filterOption={filterOption}
                            onMenuScrollToBottom={(e) => {
                              if (currentCityPage < maxCityPages) {
                                setCurrentCityPage((prev) => prev + 1);
                              }
                            }}
                          />
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <MultiSelectionFormik
                            label={"Pincode"}
                            options={activePincodes}
                            handleChangeEvent={(e) =>
                              setFieldValue("pincode", e)
                            }
                            closeMenu={false}
                            value={values?.pincode}
                            ids={"pincode"}
                            onInputChange={(e) => setPincodeList(e.split(","))}
                            // onInputChange={(e) => setPincodeList(e)}

                            onKeyDown={(e) =>
                              onkeyEnterPincode(
                                e,
                                setFieldValue,
                                values?.pincode
                              )
                            }
                            filterOption={filterOption}
                            onMenuScrollToBottom={(e) => {
                              if (currentPincodePage < maxPincodePages) {
                                setCurrentPincodePage((prev) => prev + 1);
                              }
                            }}
                          />
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <Field label="Payment Status">
                            <Button
                              size="sm"
                              outline
                              color="primary"
                              name="paymentStatus"
                              onClick={() => {
                                if (values.paymentStatus === "Success") {
                                  setFieldValue("paymentStatus", "");
                                } else {
                                  setFieldValue("paymentStatus", "Success");
                                }
                              }}
                              active={values?.paymentStatus === "Success"}
                              type="button"
                              className="me-2"
                            >
                              Approved
                            </Button>
                            <Button
                              size="sm"
                              outline
                              color="primary"
                              name="paymentStatus"
                              onClick={() => {
                                if (values.paymentStatus === "Reject") {
                                  setFieldValue("paymentStatus", "");
                                } else {
                                  setFieldValue("paymentStatus", "Reject");
                                }
                              }}
                              active={values?.paymentStatus === "Reject"}
                              type="button"
                            >
                              Rejected
                            </Button>
                          </Field>
                        </Col>
                        <Col>
                          <Field label="Call Status">
                            <Button
                              size="sm"
                              outline
                              color="primary"
                              name="callStatus"
                              onClick={() => {
                                if (values.callStatus === "Connected") {
                                  setFieldValue("callStatus", "");
                                } else {
                                  setFieldValue("callStatus", "Connected");
                                }
                              }}
                              active={values?.callStatus === "Connected"}
                              type="button"
                              className="me-2"
                            >
                              Connected
                            </Button>

                            <Button
                              size="sm"
                              outline
                              color="primary"
                              name="callStatus"
                              onClick={() => {
                                if (values.callStatus === "Not Connected") {
                                  setFieldValue("callStatus", "");
                                } else {
                                  setFieldValue("callStatus", "Not Connected");
                                }
                              }}
                              active={values?.callStatus === "Not Connected"}
                              type="button"
                              className="me-2"
                            >
                              Not Connected
                            </Button>
                          </Field>
                        </Col>

                        {/* <Col lg={6} md={6} sm={12}>
                                                    <MultiSelectionFormik
                                                        label={"Calling Agent"}
                                                        options={[]}
                                                        handleChangeEvent={(e) => setFieldValue("callingAgent", e)}
                                                        closeMenu={false}
                                                        value={values.callingAgent}
                                                        ids={"callingAgent"}
                                                    />
                                                </Col>
                                                <Col lg={6} md={6} sm={12}>
                                                    <MultiSelectionFormik
                                                        label={"Field Agent"}
                                                        options={[]}
                                                        handleChangeEvent={(e) => setFieldValue("fieldAgent", e)}
                                                        closeMenu={false}
                                                        value={values.fieldAgent}
                                                        ids={"fieldAgent"}
                                                    />
                                                </Col> */}
                        <div className="d-flex justify-content-between mb-2">
                          <div className="d-flex">
                            {otherFilterBtn?.map((data) => (
                              <Button
                                key={data?.id}
                                outline
                                className="me-1"
                                type="button"
                                onClick={() => {
                                  if (activeButton[data?.name]) {
                                    if (data?.name === "Bucket") {
                                      setFieldValue("bucket.max", "");
                                      setFieldValue("bucket.min", "");
                                    } else if (data?.name === "DPD") {
                                      setFieldValue("DPD.max", "");
                                      setFieldValue("DPD.min", "");
                                    } else if (data?.name === "POS") {
                                      setFieldValue("POS.max", "");
                                      setFieldValue("POS.min", "");
                                    } else if (data?.name === "TOS") {
                                      setFieldValue("TOS.max", "");
                                      setFieldValue("TOS.min", "");
                                    } else if (data?.name === "Dormancy") {
                                      setFieldValue("dormancy.max", "");
                                      setFieldValue("dormancy.min", "");
                                    }
                                  }
                                  setActiveButton({
                                    ...activeButton,
                                    [data?.name]: !activeButton[data?.name],
                                  });
                                }}
                                size={"sm"}
                                color="primary"
                                active={activeButton[data?.name]}
                              >
                                {data?.name}
                              </Button>
                            ))}
                          </div>

                          <div className="d-flex justify-content-end">
                            <Button
                              className="me-1"
                              color="primary"
                              type="submit"
                              size="sm"
                            >
                              Filter
                            </Button>
                            <Button
                              type="button"
                              color="danger"
                              onClick={() => {
                                handleResetFilter(handleReset);
                                setIsFilter(false);
                                props?.setIsFilter(false);
                              }}
                              size="sm"
                            >
                              Clear
                            </Button>
                          </div>
                        </div>
                        {activeButton?.Bucket && (
                          <Col lg={6} md={6} sm={12} className="d-flex">
                            <Label label="Bucket" />
                            <div className="d-flex gap-2">
                              <Field
                                label="Min"
                                errorMessage={
                                  touched?.bucket?.min && errors?.bucket?.min
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.bucket?.min}
                                  onChange={handleChange}
                                  name="bucket.min"
                                  onBlur={handleBlur}
                                />
                              </Field>
                              <Field
                                label="Max"
                                errorMessage={
                                  touched?.bucket?.max && errors?.bucket?.max
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.bucket?.max}
                                  onChange={handleChange}
                                  name="bucket.max"
                                  onBlur={handleBlur}
                                />
                              </Field>
                            </div>
                          </Col>
                        )}
                        {activeButton?.DPD && (
                          <Col lg={6} md={6} sm={12} className="d-flex">
                            <Label label="DPD" />
                            <div className="d-flex gap-2">
                              <Field
                                label="Min"
                                errorMessage={
                                  touched?.DPD?.min && errors?.DPD?.min
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.DPD?.min}
                                  onChange={handleChange}
                                  name="DPD.min"
                                  onBlur={handleBlur}
                                />
                              </Field>
                              <Field
                                label="Max"
                                errorMessage={
                                  touched?.DPD?.max && errors?.DPD?.max
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.DPD?.max}
                                  onChange={handleChange}
                                  name="DPD.max"
                                  onBlur={handleBlur}
                                />
                              </Field>
                            </div>
                          </Col>
                        )}
                        {activeButton?.POS && (
                          <Col lg={6} md={6} sm={12} className="d-flex">
                            <Label label="POS" />
                            <div className="d-flex gap-2">
                              <Field
                                label="Min"
                                errorMessage={
                                  touched?.POS?.min && errors?.POS?.min
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.POS?.min}
                                  onChange={handleChange}
                                  name="POS.min"
                                  onBlur={handleBlur}
                                />
                              </Field>
                              <Field
                                label="Max"
                                errorMessage={
                                  touched?.POS?.max && errors?.POS?.max
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.POS?.max}
                                  onChange={handleChange}
                                  name="POS.max"
                                  onBlur={handleBlur}
                                />
                              </Field>
                            </div>
                          </Col>
                        )}
                        {activeButton?.TOS && (
                          <Col lg={6} md={6} sm={12} className="d-flex">
                            <Label label="TOS" />
                            <div className="d-flex gap-2">
                              <Field
                                label="Min"
                                errorMessage={
                                  touched?.TOS?.min && errors?.TOS?.min
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.TOS?.min}
                                  onChange={handleChange}
                                  name="TOS.min"
                                  onBlur={handleBlur}
                                />
                              </Field>
                              <Field
                                label="Max"
                                errorMessage={
                                  touched?.TOS?.max && errors?.TOS?.max
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.TOS?.max}
                                  onChange={handleChange}
                                  name="TOS.max"
                                  onBlur={handleBlur}
                                />
                              </Field>
                            </div>
                          </Col>
                        )}
                        {activeButton?.Dormancy && (
                          <Col lg={6} md={6} sm={12} className="d-flex">
                            <Label label="Dormancy" />
                            <div className="d-flex gap-2">
                              <Field
                                label="Min"
                                errorMessage={
                                  touched?.dormancy?.min &&
                                  errors?.dormancy?.min
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.dormancy?.min}
                                  onChange={handleChange}
                                  name="dormancy.min"
                                  onBlur={handleBlur}
                                />
                              </Field>
                              <Field
                                label="Max"
                                errorMessage={
                                  touched?.dormancy?.max &&
                                  errors?.dormancy?.max
                                }
                                labelClassName={styles.filterLabel}
                              >
                                <Input
                                  bsSize="sm"
                                  type="number"
                                  value={values?.dormancy?.max}
                                  onChange={handleChange}
                                  name="dormancy.max"
                                  onBlur={handleBlur}
                                />
                              </Field>
                            </div>
                          </Col>
                        )}
                      </Row>
                    </CardBody>
                  </Card>
                </Collapse>
              </CardBody>
            </Card>
          </Form>
        );
      }}
    </Formik>
  );
};
export default memo(CaseFilterForm);