import { Fragment, memo, useMemo, useState } from "react"
import { Input } from "reactstrap"
import styles from './CaseProfile.module.scss'
import axios from "axios";
import { useDispatch } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";
const CallHistorySummary = (props) => {
    const [data, setData] = useState({})
    const [show, setShow] = useState(false)
    // console.log(props,"allpropspassinghere")
    const previewDataList = useMemo(() => ["PTP", "Payment", "Dispute/RTP", "Raise Exception"], [])
    const dispatch = useDispatch()
    const handleDetails = async () => {
        setShow(!show)
        dispatch(setLoader(true))
        if (props?.data?.callOutcome === "PTP") {
            try {
                const res = await axios.get(`/getPtpDetailsByCallHistoryId/${props?.data?.callHistoryId}`)
                dispatch(setLoader(false))
                setData(res?.data?.data || {})
            } catch (error) {
                dispatch(setLoader(false))
            }
        } else if (props?.data?.callOutcome === "Payment") {
            try {
                const res = await axios.get(`/getPaymentDetailsByCallHistoryId/${props?.data?.callHistoryId}`)
                dispatch(setLoader(false))
                setData(res?.data?.data || {})
            } catch (error) {
                dispatch(setLoader(false))
            }
        } else if (props?.data?.callOutcome === "Dispute/RTP") {
            try {
                const res = await axios.get(`/getDisputeOrRtpByCallHistory/${props?.data?.callHistoryId}`)
                dispatch(setLoader(false))
                setData(res?.data?.data || {})
            } catch (error) {
                dispatch(setLoader(false))

            }
        } else if (props?.data?.callOutcome === "Raise Exception") {
            try {
                const res = await axios.get(`/getRaiseExceptionByCallHistoryId/${props?.data?.callHistoryId}`)
                dispatch(setLoader(false))
                setData(res?.data?.data || {})
            } catch (error) {
                dispatch(setLoader(false))

            }
        }
        dispatch(setLoader(false))
    }

    function formatDateTime(milliseconds) {
        if (!milliseconds) return null;

        var dateTime = new Date(milliseconds);

        var year = dateTime.getFullYear();
        var month = String(dateTime.getMonth() + 1).padStart(2, '0');
        var day = String(dateTime.getDate()).padStart(2, '0');
        // var hours = String(dateTime.getHours()).padStart(2, '0');
        // var minutes = String(dateTime.getMinutes()).padStart(2, '0');
        // var seconds = String(dateTime.getSeconds()).padStart(2, '0');
        var formattedDateTime = day + '-' + month + '-' + year ;

        return formattedDateTime;
    }

    function formatTime(milliseconds) {
        if (!milliseconds) return null;
    
        var dateTime = new Date(milliseconds);
    
        var hours = String(dateTime.getHours()).padStart(2, '0');
        var minutes = String(dateTime.getMinutes()).padStart(2, '0');
        var seconds = String(dateTime.getSeconds()).padStart(2, '0');
        var formattedTime = hours + ':' + minutes + ':' + seconds;
    
        return formattedTime;
    }
    return (
        <Fragment>
            <div className={styles?.callHistoryInputContainer}>
                <p>Call Duration</p>
                <Input
                    value={props?.data?.callDuration}
                    className={styles?.inputBox}
                    disabled
                />

                <p>Call Status</p>
                <Input
                    value={props?.data?.status}
                    className={styles?.inputBox}
                    disabled
                />

                <p>Call Outcome</p>
                <Input
                    value={props?.data?.callOutcome}
                    className={styles?.inputBox}
                    disabled
                />

                {previewDataList?.includes(props?.data?.callOutcome) && <p className={styles?.previewData} onClick={handleDetails}>View {props?.data?.callOutcome}</p>}

                <p>Followup Date</p>
                <Input
                    value={props?.data?.followUp && formatDateTime(new Date(props?.data?.followUp))}
                    className={styles?.inputBox}
                    disabled
                />

                <p>Followup Time</p>
                <Input
                    value={props?.data?.followUp && formatTime(new Date(props?.data?.followUp))}
                    className={styles?.inputBox}
                    disabled
                />
                <p>Remarks</p>
                <Input
                    value={props?.data?.remark}
                    className={styles?.inputBox}
                    disabled
                />
            </div>

            {Boolean(Object?.keys(data)?.length) ?
                props?.data?.callOutcome === "PTP" && show ?
                    <Fragment>
                        <p className={styles?.subHeader}>PTP Details</p>
                        <div className={styles?.callHistoryInputContainer}>
                            <p>PTP Amount</p>
                            <Input
                                value={data?.ptpAmount.toLocaleString('en-IN')}
                                className={styles?.inputBox}
                                disabled
                            />

                            <p>PTP Date</p>
                            <Input
                                value={data?.ptpDate}
                                className={styles?.inputBox}
                                disabled
                            />

                            <p>PTP Time</p>
                            <Input
                                value={data?.ptpTime}
                                className={styles?.inputBox}
                                disabled
                            />

                            <p>Admin Remarks</p>
                            <Input
                                value={data?.remark}
                                className={styles?.inputBox}
                                disabled
                            />
                        </div>
                    </Fragment> :

                    props?.data?.callOutcome === "Payment" && show ?
                        <Fragment>
                            <p className={styles?.subHeader}>Payment Details</p>
                            <div className={styles?.callHistoryInputContainer}>
                                <p>Payment Type</p>
                                <Input
                                    value={data?.paymentType}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                <p>Sub Type</p>
                                <Input
                                    value={data?.subType || "-"}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                <p>Reference Number</p>
                                <Input
                                    value={data?.referenceNumber || "-"}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                <p>Amount</p>
                                <Input
                                    value={data?.amount}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                <p>Collection Mode</p>
                                <Input
                                    value={data?.paymentMode}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                <p>Date of Payment</p>
                                <Input
                                    value={data?.paymentDate}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                <p>TIme of Payment</p>
                                <Input
                                    value={data?.timeOfPayment}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                <p>Remarks</p>
                                <Input
                                    value={data?.remark}
                                    className={styles?.inputBox}
                                    disabled
                                />

                                {/* <p>Admin Remarks</p>
                        <Input
                            value={data?.remark}
                            className={styles?.inputBox}
                            disabled
                        /> */}
                            </div>
                        </Fragment> :

                        props?.data?.callOutcome === "Dispute/RTP" && show ?
                            <Fragment>
                                <p className={styles?.subHeader}>Dispute/RTP Details</p>
                                <div className={styles?.callHistoryInputContainer}>
                                    <p>Amount</p>
                                    <Input
                                        value={data?.amount}
                                        className={styles?.inputBox}
                                        disabled
                                    />

                                    <p>Record</p>
                                    <Input
                                        value={data?.disputeType}
                                        className={styles?.inputBox}
                                        disabled
                                    />

                                    <p>Reason</p>
                                    <Input
                                        value={props?.disputeReason[data?.disputeReason]}
                                        className={styles?.inputBox}
                                        disabled
                                    />

                                    <p>Remarks</p>
                                    <Input
                                        value={data?.remark}
                                        className={styles?.inputBox}
                                        disabled
                                    />
                                </div>
                            </Fragment> :

                            props?.data?.callOutcome === "Raise Exception" && show ?
                                <Fragment>
                                    <p className={styles?.subHeader}>Raise Exception Details</p>
                                    <div className={styles?.callHistoryInputContainer}>
                                        <p>Request</p>
                                        <Input
                                            value={props?.raiseException[data?.request]}
                                            className={styles?.inputBox}
                                            disabled
                                        />

                                        <p>Remarks</p>
                                        <Input
                                            value={data?.remark}
                                            className={styles?.inputBox}
                                            disabled
                                        />
                                    </div>
                                </Fragment> : '' : ''
            }
        </Fragment>
    )
}

export default memo(CallHistorySummary)