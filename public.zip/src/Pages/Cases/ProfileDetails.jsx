import { memo, useState } from "react";
import { useSelector } from "react-redux";
import cx from "classnames";
import {
  CardImg,
  Carousel,
  CarouselControl,
  CarouselIndicators,
  CarouselItem,
} from "reactstrap";
import { MdPerson } from 'react-icons/md';
const ProfileDetails = (props) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [animating, setAnimating] = useState(false);
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const items = [
    {
      id: 1,
      name: caseProfile?.name,
      mobileNumber: caseProfile?.mobile,
      address: caseProfile?.primaryAddress,
      bucket: caseProfile?.bucket,
      pincode: caseProfile?.pincode,
      LAN: caseProfile?.loanAccountNumber,
      TOA: caseProfile?.totalOverdueAmount,
    },
    {
      id: 2,
      name: caseProfile?.coApplicantName,
      mobileNumber: caseProfile?.coApplicantMobile,
      address: caseProfile?.coApplicantAddress,
      email: caseProfile?.coApplicantEmail,
    },
    {
      id: 3,
      name: caseProfile?.guarantorName,
      mobileNumber: caseProfile?.guarantorMobile,
      address: caseProfile?.guarantorAddress,
      email: caseProfile?.guarantorEmail,
    },
  ];
  const next = () => {
    if (animating) return;
    const nextIndex = activeIndex === items.length - 1 ? 0 : activeIndex + 1;
    setActiveIndex(nextIndex);
  };
  const previous = () => {
    if (animating) return;
    const nextIndex = activeIndex === 0 ? items.length - 1 : activeIndex - 1;
    setActiveIndex(nextIndex);
  };
  const goToIndex = (newIndex) => {
    if (animating) return;
    setActiveIndex(newIndex);
  };
  const [showPhoneNumber, setShowPhoneNumber] = useState(false);
  const togglePhoneNumberVisibility = () => {
    setShowPhoneNumber(!showPhoneNumber);
  };
  const slides = items?.map((a) => {
    let number = "";
    const mobileNumber = a?.mobileNumber?.toString()
    for (let index = 1; index <= props?.masking; index++) {
      number = number + "*";
    }
    number = mobileNumber?.slice(0, mobileNumber.length - props?.masking) + number;
    return (
      <CarouselItem
        key={a?.id}
        tag="div"
        onExiting={() => setAnimating(true)}
        onExited={() => setAnimating(false)}
      >
        <div className="carouselItem">
          <CardImg
            src="/collection/img/user.png"
            alt="User Profile"
            className="userImg"
          />
          {/* <div className="userIconContainer backgroundColor">
            <MdPerson className="userIcon iconColor" />
          </div> */}
          <div>
            <p className="userName">{a?.name}</p>
            <div className="userDetailsContainer">
              <span className="userDetail">
                <p className="heading">Mobile Number</p>
                <p className="value gap-2">
                  {showPhoneNumber ? a?.mobileNumber : number}
                  {/* {a?.mobileNumber } */}

                  <span className="mx-2">
                    <i
                      className={cx({
                        bi: true,
                        "bi-eye-fill": showPhoneNumber,
                        "bi-eye-slash-fill": !showPhoneNumber,
                      })}
                      onClick={togglePhoneNumberVisibility}
                    ></i>
                  </span>
                </p>
              </span>
              <span className="userDetail">
                <p className="heading">Address</p>
                <p className="value">{a?.address}</p>
              </span>
              {a?.email && (
                <span className="userDetail">
                  <p className="heading">Email</p>
                  <p className="value">{a?.email}</p>
                </span>
              )}
              {a?.bucket && (
                <span className="userDetail">
                  <p className="heading">Bucket</p>
                  <p className="value">{a?.bucket}</p>
                </span>
              )}
              {a?.pincode && (
                <span className="userDetail">
                  <p className="heading">Pincode</p>
                  <p className="value">{a?.pincode}</p>
                </span>
              )}
              {a?.LAN && (
                <span className="userDetail">
                  <p className="heading">Loan Account Number</p>
                  <p className="value">{a?.LAN}</p>
                </span>
              )}
              <span className="userDetail">
                <p className="heading">Total Overdue Amount</p>
                <p className="value">
                  {a?.TOA?.toLocaleString('en-IN', {
                    style: 'currency',
                    currency: 'INR'
                  })}
                </p>
              </span>
            </div>
          </div>
        </div>
      </CarouselItem>
    );
  });
  return (
    <Carousel
      activeIndex={activeIndex}
      next={next}
      previous={previous}
      interval={false}
      className="carouselContainer"
    >
      <CarouselIndicators
        items={items}
        activeIndex={activeIndex}
        onClickHandler={goToIndex}
        className="carouselIndecator"
      />
      {slides}
      <CarouselControl
        direction="prev"
        directionText="Previous"
        onClickHandler={previous}
      />
      <CarouselControl
        direction="next"
        directionText="Next"
        onClickHandler={next}
      />
    </Carousel>
  );
};
export default memo(ProfileDetails);
