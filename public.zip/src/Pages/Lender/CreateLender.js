import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import {
  Form,
  FormGroup,
  Input,
  Row,
  Col,
  Button,
  FormFeedback,
  Card,
  CardBody,
  CardHeader,
  Table,
} from "reactstrap";
import { Lender, lenderValidation } from "../../Schema/Lender";
import { Field, FieldArray, Formik } from "formik";
import cx from "classnames";
import Select, { components } from "react-select";
import axios from "axios";
import { scrollToErrorMessage } from "../../utils/commonFun";
import CustomField from "../../components/Field";
import Label from "../../components/Field/Label";
import FileTable from "../../components/FileTable";
import FileUpload from "../../components/FileUpload";
import { searchPinCode } from "../Master/GeographyMaster/Pincode/store";
import { useDispatch, useSelector } from "react-redux";
import MultiSelectComma from "../../components/Selection/MultiSelectComma";
import { setLoader } from "../../reducer/globalReducer";
import { MultiSelect } from "react-multi-select-component";

export default function CreateLender({
  cancelModal,
  isView,
  isUpdate,
  data,
  onSuccess,
}) {
  const [oldUPI, setOldUPI] = useState([]);
  const [lenderUser, setLenderUser] = useState([]);
  const [aggDocument, setAggDocument] = useState([]);
  const [aggDoc, setAggDoc] = useState([]);
  const [editDocument, setEditDocument] = useState({
    visible: false,
    name: "",
  });
  const [addAgg, setAddAgg] = useState(false);
  const [configData, setConfigData] = useState([]);
  const [aggDocEdit, setAggDocEdit] = useState([]);
  const [formik, setFormik] = useState({});
  const [activeState, setActiveState] = useState([]);
  const [activeCity, setActiveCity] = useState([]);
  const [isSearchCity, setIsSearchCity] = useState(false);
  const [searchCity, setSearchCity] = useState("");
  const [menuIsOpenCity, setMenuIsOpenCity] = useState(false);
  const [citySearchIndex, setCitySearchIndex] = useState(0);
  const [activePincode, setActivePincode] = useState([]);
  const [isSearchPincode, setIsSearchPincode] = useState(false);
  const [searchPincode, setSearchPincode] = useState("");
  const [menuIsOpenPincode, setMenuIsOpenPincode] = useState(false);
  const [pincodeSearchIndex, setPincodeSearchIndex] = useState(0);

  const dispatch = useDispatch();
  useEffect(() => {
    if (data?.branches.length > 0) {
      let tempUPI = [];
      data?.branches.forEach((branch) => {
        tempUPI.push(branch.upiDetails.toLowerCase());
      });
      setOldUPI([...tempUPI]);
    }

    if (data?.lenderId) {
      axios
        .get(`/documentLenderAggrementScanningId/${data?.lenderId}`)
        .then((response) => {
          setAggDocument([...response.data]);
        })
        .catch((error) => {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    }
  }, [data]);
  const configureSlabData = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllPayInIncentiveConfiguration");
      dispatch(setLoader(false));
      const configurations =
        res.data.response?.map((data) => ({
          schemeCode: data.schemeCode,
          incPayInConfigId: data.incPayInConfigId,
        })) || [];
      // console.log(configurations, "vhhj");
      setConfigData(configurations);
    } catch (error) {
      dispatch(setLoader(false));
      console.error(error);
    }
  };
  useEffect(() => {
    configureSlabData();
  }, []);

  //lender create
  const CreateNewLender = (values) => {
    values.branches.forEach((branch, idx) => {
      branch.emailId = JSON.stringify(branch.emailId);
      branch.contactNo = JSON.stringify(branch.contactNo);
    });

    let aggFormData = new FormData();
    for (let i = 0; i < values.aggrementScanning.length; i++) {
      aggFormData.append("content", values.aggrementScanning[i]);
    }

    dispatch(setLoader(true));
    axios
      .post("/createLender", values)
      .then(async (response) => {
        dispatch(setLoader(false));
        if (response?.data?.msgKey === "Success") {
          if (aggFormData?.getAll("content")?.length) {
            try {
              dispatch(setLoader(true));
              const aggRes = await axios.post(
                `/upload-document-lender-aggrement-scanning/${response?.data?.data?.lenderId}/ok`,
                aggFormData
              );
              dispatch(setLoader(false));
            } catch (error) {
              dispatch(setLoader(false));
              Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
          }
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Records has been saved",
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          onSuccess();
        }
      })
      .catch((error) => {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: error.code,
          text: error.response.data.error,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  const fileUpload = (value, content) => {
    const formData = new FormData();
    for (let i = 0; i < value.length; i++) {
      formData.append(content, value[i]);
    }
    return formData;
  };

  //update
  const handleUpdate = (values) => {
    console.log(values, "bjjk");
    values.branches.forEach((branch, idx) => {
      branch.emailId = JSON.stringify(branch.emailId);
      branch.contactNo = JSON.stringify(branch.contactNo);
    });
    dispatch(setLoader(true));
    axios
      .put(`/updateLender/${values.lenderId}`, values)
      .then(async (data) => {
        dispatch(setLoader(false));
        let aggFormData = fileUpload(aggDoc, "content");
        if (aggFormData?.getAll("content")?.length) {
          try {
            dispatch(setLoader(true));
            const aggRes = await axios.post(
              `/upload-document-lender-aggrement-scanning/${values.lenderId}/ok`,
              aggFormData
            );
            dispatch(setLoader(false));
            if (aggRes?.data?.msgKey === "Failure") {
              Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${aggRes?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            } else {
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${aggRes?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
          } catch (error) {
            dispatch(setLoader(false));
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        }
        if (aggDocEdit?.length > 0) {
          aggDocEdit?.map(async (kycDoc) => {
            const aggDocFormData = new FormData();
            aggDocFormData.append("content", kycDoc?.data);
            try {
              dispatch(setLoader(true));
              const kycDocRes = await axios.put(
                `/update-document-lender-aggrement-scanning/${values.lenderId}/${kycDoc?.id}/ok`,
                aggDocFormData
              );
              dispatch(setLoader(false));
            } catch (error) {
              dispatch(setLoader(false));
              Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
          });
        }
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Records has been Updated",
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        onSuccess();
      })
      .catch((error) => {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: error.code,
          text: error.response.data.error,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  const onBtnClickAgg = () => {
    setAddAgg(!addAgg);
  };
  const onEditClickAgg = (id, index) => {
    setEditDocument({
      visible: true,
      name: "AGGREMENT",
      index,
      docId: id,
    });
  };

  const onAggSave = (data) => {
    setAggDocument([
      ...aggDocument,
      {
        name: data?.name,
        lastModifiedTime: new Date().toISOString(),
        createdTime: new Date().toISOString(),
      },
    ]);
    setAggDoc([...aggDoc, data]);
    setAddAgg(false);
  };

  const onEditDocSave = (data) => {
    if (editDocument?.name === "AGGREMENT") {
      let duplicateDocKyc = aggDocument;
      duplicateDocKyc[editDocument?.index].name = data?.name;
      setAggDocEdit([...aggDocEdit, { data, id: editDocument?.docId }]);
    }

    setEditDocument({
      visible: false,
      name: "",
    });
  };

  const onSearchCity = async (Id) => {
    try {
      const res = await axios.get(`/getCityByState/${Id}/0/0`);
      const cityData = res?.data?.response;
      const option = [];
      if (res?.data?.messageKey == "Success") {
        cityData.map((val) => {
          if (val?.active == "Y") {
            option.push({
              label: val?.cityName,
              value: val?.cityId,
            });
          }
        });
      }
      setActiveCity(option);

      // console.log(res, "onSearchCity");
    } catch (error) {}
  };

  const onInputChangeCity = (val) => {
    setSearchCity(val);
    setIsSearchCity(true);
  };

  const onInputChangePincode = (val) => {
    setSearchPincode(val);
    setIsSearchPincode(true);
  };

  useEffect(() => {
    const search = setTimeout(() => {
      if (searchCity?.length > 2) {
        const getSearchAPI = async () => {
          try {
            setMenuIsOpenCity(false);
            const payload = [
              formik?.values?.branches[citySearchIndex].state || 0,
            ];
            dispatch(setLoader(true));
            const res = await axios.post(
              `/getCityByCityNameSelectedState/${searchCity}/0/0`,
              payload
            );
            dispatch(setLoader(false));
            if (res?.data?.msgKey === "Success") {
              const op = [];
              res?.data?.data?.map((a) => {
                if (a?.active === "Y") {
                  op?.push({
                    label: a?.cityName,
                    value: a?.cityId,
                  });
                }
              });
              setActiveCity(op);
              setTimeout(() => {
                setMenuIsOpenCity(true);
              }, 1000);
            }
          } catch (error) {
            dispatch(setLoader(false));
          }
        };
        getSearchAPI();
      }
    }, 1000);

    return () => {
      clearTimeout(search);
    };
  }, [searchCity]);

  useEffect(() => {
    const search = setTimeout(() => {
      if (searchPincode?.length > 2) {
        const getSearchAPI = async () => {
          try {
            setMenuIsOpenCity(false);
            const payload = {
              selectedCity: [
                formik?.values?.branches[pincodeSearchIndex]?.city || 0,
              ],
              selectedStates: [formik?.values?.branches[citySearchIndex].state],
            };
            dispatch(setLoader(true));
            const res = await axios.post(
              `/getByPincodeForCityForSelectedState/${searchPincode}/N`,
              payload
            );
            dispatch(setLoader(false));
            if (res?.data?.msgKey === "Success") {
              const op = [];
              res?.data?.data?.map((a) => {
                if (a?.active === "Y") {
                  op?.push({
                    label: a?.pincode,
                    value: a?.pincodeId,
                  });
                }
              });
              setActivePincode(op);
              setTimeout(() => {
                setMenuIsOpenPincode(true);
              }, 1000);
            }
          } catch (error) {
            dispatch(setLoader(false));
          }
        };

        getSearchAPI();
      }
    }, 1000);

    return () => {
      clearTimeout(search);
    };
  }, [searchPincode]);

  useEffect(() => {
    if (isUpdate || isView) {
      var lenderUserList = [];
      dispatch(setLoader(true));
      axios
        .get(`/getUserByLender/${data?.lenderId}`)
        .then((response) => {
          dispatch(setLoader(false));
          for (let i of response?.data?.data) {
            lenderUserList.push(i?.firstName + " " + i?.lastName);
          }
          setLenderUser([...lenderUserList]);
        })
        .catch((error) => {
          dispatch(setLoader(false));
        });
    }
  }, []);

  useEffect(() => {
    const getState = async () => {
      try {
        dispatch(setLoader(true));
        const res = await axios.get("/getAllStates");
        dispatch(setLoader(false));

        const options = [];
        if (res?.data?.data?.length) {
          res?.data?.data?.map((a) => {
            if (a?.active === "Y") {
              options.push({
                label: a?.stateName,
                value: a?.stateId,
              });
            }
          });
        }
        setActiveState(options || []);
      } catch (error) {
        dispatch(setLoader(false));
      }
    };
    getState();
  }, []);
  return (
    <>
      <Formik
        initialValues={
          isUpdate || isView ? { ...data, aggrementScanning: "a" } : Lender
        }
        validationSchema={lenderValidation}
        onSubmit={(values) =>
          isUpdate ? handleUpdate(values) : CreateNewLender(values)
        }
      >
        {({
          values,
          errors,
          handleChange,
          handleBlur,
          touched,
          handleSubmit,
          setFieldValue,
          setFieldError,
          isSubmitting,
        }) => {
          const err = Object.keys(errors)[0];
          scrollToErrorMessage(isSubmitting, err);
          return (
            <Form onSubmit={handleSubmit}>
              <Card className="mb-3">
                <CardBody>
                  <Row>
                    <Col lg={6} md={6} sm={12}>
                      <CustomField
                        isRequired
                        label="Lender Name"
                        errorMessage={touched.lenderName && errors.lenderName}
                      >
                        <Input
                          bsSize="sm"
                          type="text"
                          id="lenderName"
                          placeholder="Lender Name"
                          value={values.lenderName}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={
                            touched.lenderName && Boolean(errors.lenderName)
                          }
                          maxLength={65}
                          disabled={isView || isUpdate}
                        />
                      </CustomField>
                    </Col>

                    <Col lg={6} md={6} sm={12}>
                      <CustomField
                        isRequired
                        label="Short Name"
                        errorMessage={touched.shortName && errors.shortName}
                      >
                        <Input
                          bsSize="sm"
                          type="text"
                          id="shortName"
                          placeholder="Short Name"
                          value={values.shortName}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={
                            touched.shortName && Boolean(errors.shortName)
                          }
                          maxLength={30}
                          disabled={isView}
                        />
                      </CustomField>
                    </Col>

                    <Col lg={6} md={6} sm={12}>
                      <CustomField
                        isRequired
                        label="Mask Mobile"
                        errorMessage={
                          touched.maskingMobileNo && errors.maskingMobileNo
                        }
                      >
                        <Input
                          bsSize="sm"
                          type="number"
                          id="maskingMobileNo"
                          placeholder="Mask Mobile Number"
                          value={values.maskingMobileNo}
                          onChange={(e) => {
                            if (e.target.value.length <= 2)
                              setFieldValue("maskingMobileNo", e.target.value);
                          }}
                          min={0}
                          max={10}
                          onBlur={handleBlur}
                          invalid={
                            touched.maskingMobileNo &&
                            Boolean(errors.maskingMobileNo)
                          }
                          maxLength={2}
                          disabled={isView}
                        />
                      </CustomField>
                    </Col>
                    <Col lg={6}>
                      <CustomField
                        // isRequired
                        label="Payin Scheme"
                        errorMessage={
                          touched.incPayInConfigData &&
                          errors.incPayInConfigData
                        }
                      >
                        <Select
                          id="schemeCode"
                          inputId="schemeCode"
                          placeholder="Payin Scheme"
                          closeMenuOnSelect={false}
                          hideSelectedOptions={false}
                          value={
                            values.incPayInConfigData &&
                            values.incPayInConfigData.length > 0
                              ? values.incPayInConfigData.map((id) => ({
                                  value: id.incPayInConfigId, // The value to identify each option
                                  label: id.schemeCode, // The label to display in the dropdown
                                }))
                              : []
                          }
                          isMulti
                          onChange={(selectedOptions) => {
                            const selectedValues = selectedOptions.map(
                              (option) => option.value
                            );
                            setFieldValue("schemeCode", selectedOptions); // This updates the schemeCode field
                            const incPayInConfigData = selectedValues.map(
                              (id) => ({
                                incPayInConfigId: id,
                                schemeCode: selectedOptions.find(
                                  (option) => option.value === id
                                ).label,
                              })
                            );
                            setFieldValue(
                              "incPayInConfigData",
                              incPayInConfigData
                            );
                          }}
                          options={configData.map((item) => ({
                            label: item.schemeCode, // Display the scheme code as label
                            value: item.incPayInConfigId, // Use incPayInConfigId as the value
                          }))}
                          onBlur={handleBlur}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </CustomField>
                    </Col>
                    <Col lg={6} md={6} sm={12}></Col>
                    <Col lg={6} md={6} sm={12}>
                      <CustomField
                        isRequired
                        label="Start Date"
                        errorMessage={touched.startDate && errors.startDate}
                      >
                        <Input
                          bsSize="sm"
                          type="date"
                          id="startDate"
                          value={values.startDate}
                          max={values.endDate}
                          onChange={(e) => {
                            if (e?.target?.value?.length <= 10) {
                              handleChange(e);
                            }
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.startDate && Boolean(errors.startDate)
                          }
                          disabled={isView}
                        />
                      </CustomField>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <CustomField
                        isRequired
                        label="End Date"
                        errorMessage={touched.endDate && errors.endDate}
                      >
                        <Input
                          bsSize="sm"
                          type="date"
                          id="endDate"
                          value={values.endDate}
                          onChange={(e) => {
                            if (e?.target?.value?.length <= 10) {
                              handleChange(e);
                            }
                          }}
                          onBlur={handleBlur}
                          invalid={touched.endDate && Boolean(errors.endDate)}
                          disabled={isView}
                          min={values.startDate}
                        />
                      </CustomField>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <CustomField
                        isRequired
                        label="Status"
                        errorMessage={touched.status && errors.status}
                      >
                        <FormGroup switch className="ms-2">
                          <Input
                            type="switch"
                            checked={values.status === "Y"}
                            onChange={(e) => {
                              setFieldValue(
                                "status",
                                e.target.checked ? "Y" : "N"
                              );
                            }}
                            id="status"
                            invalid={touched.status && Boolean(errors.status)}
                            disabled={isView}
                          />
                        </FormGroup>
                      </CustomField>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <CustomField
                        isRequired
                        label="Send Welcome Info"
                        errorMessage={
                          touched.shareWelcomeLetter &&
                          errors.shareWelcomeLetter
                        }
                      >
                        <FormGroup switch className="ms-2">
                          <Input
                            id="shareWelcomeLetter"
                            defaultChecked={values.shareWelcomeLetter === "Y"}
                            type="checkbox"
                            onChange={(e) => {
                              setFieldValue(
                                "shareWelcomeLetter",
                                e.target.checked ? "Y" : "N"
                              );
                            }}
                            invalid={
                              touched.shareWelcomeLetter &&
                              Boolean(errors.shareWelcomeLetter)
                            }
                            disabled={isView}
                          />
                        </FormGroup>
                      </CustomField>
                    </Col>
                    {!(isView || isUpdate) ? (
                      <>
                        <Col lg={6} md={6} sm={12} className="d">
                          <label
                            htmlFor="aggrementScanning"
                            className={cx({
                              "btn-outline-primary": !(
                                touched.aggrementScanning &&
                                Boolean(errors.aggrementScanning)
                              ),
                              "btn btn-sm upload-button": true,
                              "is-invalid btn-outline-danger":
                                touched.aggrementScanning &&
                                Boolean(errors.aggrementScanning),
                            })}
                          >
                            <i className="bi bi-upload uploadIcon"></i>
                            <span>
                              {values?.aggrementScanning?.length
                                ? Array?.from(values?.aggrementScanning)
                                    ?.map((a) => a?.name)
                                    ?.join(" , ")
                                : "Agreement Scanning"}
                            </span>
                            <input
                              type="file"
                              id="aggrementScanning"
                              style={{ display: "none" }}
                              onChange={(event) => {
                                const file = event.target?.files;
                                setFieldValue("aggrementScanning", file);
                              }}
                              multiple
                            />
                          </label>
                          {
                            <FormFeedback>
                              {errors?.aggrementScanning}
                            </FormFeedback>
                          }
                        </Col>
                      </>
                    ) : null}
                  </Row>
                </CardBody>
              </Card>
              <Card>
                <CardBody>
                  <FieldArray
                    name="branches"
                    render={(helperMethod) => (
                      <>
                        <Button
                          className="mb-2"
                          color="primary"
                          size="sm"
                          type="button"
                          onClick={() =>
                            helperMethod.push({
                              branchCode: "",
                              branchName: "",
                              address: "",
                              bankAccountNo: "",
                              bankIfscCode: "",
                              upiDetails: "",
                              emailId: [""],
                              contactNo: [""],
                              pincodeId: "",
                              city: "",
                              state: "",
                              isVerified: "N",
                            })
                          }
                          disabled={isView}
                        >
                          ADD BRANCH
                        </Button>
                        {values?.branches &&
                          values?.branches.map((branch, index) => {
                            const cityOp = activeCity.length
                              ? activeCity
                              : !isSearchCity
                              ? [
                                  {
                                    label: branch?.cityName,
                                    value: branch?.city,
                                  },
                                ]
                              : [];
                            const pincodeOp = activePincode.length
                              ? activePincode
                              : !isSearchPincode
                              ? [
                                  {
                                    label: branch?.pincode,
                                    value: branch?.pincodeId,
                                  },
                                ]
                              : [];
                            return (
                              <Card className="mb-3" key={`Branch-${index}`}>
                                <CardBody>
                                  {index > 0 && (
                                    <button
                                      type="button"
                                      className=" ms-auto d-flex"
                                      title="delete"
                                      style={{
                                        borderRadius: "20%",
                                        marginTop: "-14px",
                                        marginRight: "-14px",
                                        color: "red",
                                        border: "none",
                                        background: "none",
                                      }}
                                      onClick={() => {
                                        Swal.fire({
                                          title: "Are you sure?",
                                          text: "You won't be able to revert this!",
                                          icon: "warning",
                                          showCancelButton: true,
                                          confirmButtonColor: "#3085d6",
                                          cancelButtonColor: "#d33",
                                          confirmButtonText: "Yes, delete it!",
                                        }).then((result) => {
                                          if (result.isConfirmed) {
                                            helperMethod.remove(index);
                                          }
                                        });
                                      }}
                                      disabled={isView}
                                    >
                                      <i className="bi bi-x-lg"></i>
                                    </button>
                                  )}
                                  <Row>
                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="Branch Code"
                                        errorMessage={
                                          touched.branches?.[index]
                                            ?.branchCode &&
                                          errors.branches?.[index]?.branchCode
                                        }
                                      >
                                        <Input
                                          bsSize="sm"
                                          className="form-control form-control-sm"
                                          type="text"
                                          placeholder="Branch Code"
                                          id={`branches.${index}.branchCode`}
                                          onChange={handleChange}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.branches?.[index]
                                              ?.branchCode &&
                                            Boolean(
                                              errors.branches?.[index]
                                                ?.branchCode
                                            )
                                          }
                                          value={
                                            values?.branches[index]?.branchCode
                                          }
                                          maxLength={8}
                                          disabled={isView}
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="Branch Name"
                                        errorMessage={
                                          touched.branches?.[index]
                                            ?.branchName &&
                                          errors.branches?.[index]?.branchName
                                        }
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="text"
                                          placeholder=" Branch Name"
                                          onChange={handleChange}
                                          onBlur={handleBlur}
                                          id={`branches.${index}.branchName`}
                                          value={
                                            values.branches[index].branchName
                                          }
                                          invalid={
                                            touched.branches?.[index]
                                              ?.branchName &&
                                            Boolean(
                                              errors.branches?.[index]
                                                ?.branchName
                                            )
                                          }
                                          maxLength={25}
                                          disabled={isView}
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="Account No"
                                        errorMessage={
                                          touched.branches?.[index]
                                            ?.bankAccountNo &&
                                          errors.branches?.[index]
                                            ?.bankAccountNo
                                        }
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="number"
                                          name={`branches.${index}.bankAccountNo`}
                                          placeholder="Bank Account"
                                          // value={values.bankAccountNo}
                                          onChange={(e) => {
                                            if (e.target.value.length <= 20)
                                              setFieldValue(
                                                `branches.${index}.bankAccountNo`,
                                                e.target.value
                                              );
                                          }}
                                          onBlur={handleBlur}
                                          id={`branches.${index}.bankAccountNo`}
                                          value={
                                            values.branches[index].bankAccountNo
                                          }
                                          invalid={
                                            touched.branches?.[index]
                                              ?.bankAccountNo &&
                                            Boolean(
                                              errors.branches?.[index]
                                                ?.bankAccountNo
                                            )
                                          }
                                          disabled={isView}
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="IFSC Code"
                                        errorMessage={
                                          touched.branches?.[index]
                                            ?.bankIfscCode &&
                                          errors.branches?.[index]?.bankIfscCode
                                        }
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="text"
                                          name={`branches.${index}.bankIfscCode`}
                                          placeholder=" IFSC Code"
                                          onChange={handleChange}
                                          onBlur={handleBlur}
                                          id={`branches.${index}.bankIfscCode`}
                                          value={
                                            values.branches[index].bankIfscCode
                                          }
                                          invalid={
                                            touched.branches?.[index]
                                              ?.bankIfscCode &&
                                            Boolean(
                                              errors.branches?.[index]
                                                ?.bankIfscCode
                                            )
                                          }
                                          maxLength={11}
                                          disabled={isView}
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="UPI Details"
                                        errorMessage={
                                          touched.branches?.[index]
                                            ?.upiDetails &&
                                          errors.branches?.[index]?.upiDetails
                                        }
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="text"
                                          name={`branches.${index}.upiDetails`}
                                          placeholder="UPI Details"
                                          onChange={(e) => {
                                            setFieldValue(
                                              `branches.${index}.isVerified`,
                                              "N"
                                            );
                                            handleChange(e);
                                          }}
                                          // onBlur={(e) => {
                                          //   handleBlur(e);
                                          // }}
                                          id={`branches.${index}.upiDetails`}
                                          value={
                                            values.branches[index].upiDetails
                                          }
                                          // invalid={Boolean(
                                          //   errors.branches?.[index]?.isVerified
                                          // )}
                                          maxLength={25}
                                          disabled={isView}
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="Address"
                                        errorMessage={
                                          touched.branches?.[index]?.address &&
                                          errors.branches?.[index]?.address
                                        }
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="textarea"
                                          name={`branches.${index}.address`}
                                          placeholder="Address"
                                          // value={values.address}
                                          onChange={handleChange}
                                          onBlur={handleBlur}
                                          id={`branches.${index}.address`}
                                          value={values.branches[index].address}
                                          invalid={
                                            touched.branches?.[index]
                                              ?.address &&
                                            Boolean(
                                              errors.branches?.[index]?.address
                                            )
                                          }
                                          maxLength={80}
                                          disabled={isView}
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="State"
                                        errorMessage={
                                          touched?.branches?.[index]?.state &&
                                          errors?.branches?.[index]?.state
                                        }
                                      >
                                        <Select
                                          id="state"
                                          bsSize="sm"
                                          inputId="state"
                                          isClearable={true}
                                          options={activeState}
                                          hideSelectedOptions={false}
                                          closeMenuOnSelect={true}
                                          value={activeState.filter(
                                            (e) =>
                                              e.value?.toString() ===
                                              values.branches[
                                                index
                                              ].state?.toString()
                                          )}
                                          onChange={(e) => {
                                            if (e) {
                                              onSearchCity(e.value);
                                            }
                                            setFieldValue(
                                              `branches.${[index]}.state`,
                                              e?.value
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.stateName`,
                                              e?.label
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.city`,
                                              ""
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.cityName`,
                                              ""
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.pincodeId`,
                                              ""
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.pincode`,
                                              ""
                                            );
                                          }}
                                          className={cx({
                                            abc:
                                              touched.branches?.[index]
                                                ?.state &&
                                              Boolean(
                                                errors.branches?.[index]?.state
                                              ),
                                          })}
                                          onBlur={(e) => {
                                            handleBlur(e);
                                          }}
                                          menuPosition={"fixed"}
                                          isDisabled={isView}
                                          classNamePrefix="react-select"
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="City"
                                        errorMessage={
                                          touched?.branches?.[index]?.city &&
                                          errors?.branches?.[index]?.city
                                        }
                                      >
                                        <MultiSelectComma
                                          options={cityOp}
                                          onChange={(
                                            e,
                                            action,
                                            isSelectAll
                                          ) => {
                                            if (!e?.length || isSelectAll) {
                                              setIsSearchCity(false);
                                              setSearchCity("");
                                              // setActiveCity([])
                                            }
                                            setFieldValue(
                                              `branches.${[index]}.city`,
                                              e?.value
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.cityName`,
                                              e?.label
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.pincodeId`,
                                              ""
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.pincode`,
                                              ""
                                            );
                                            setFormik({
                                              values,
                                              setFieldValue,
                                            });
                                          }}
                                          closeMenu={false}
                                          value={cityOp.filter(
                                            (e) =>
                                              e.value?.toString() ===
                                              values.branches[
                                                index
                                              ].city?.toString()
                                          )}
                                          // defaultValue={(isView || isUpdate) && {label:branch?.cityName,value: branch?.city}}
                                          isClearable
                                          isDisabled={isView}
                                          onInputChange={(value) => {
                                            setFormik({
                                              values,
                                              setFieldValue,
                                            });
                                            onInputChangeCity(value);
                                            setCitySearchIndex(index);
                                          }}
                                          searchValue={searchCity}
                                          isSearch={isSearchCity}
                                          setIsSearch={setIsSearchCity}
                                          menuIsOpen={menuIsOpenCity}
                                          isMulti={false}
                                        />
                                      </CustomField>
                                    </Col>
                                    <Col lg={6} md={6} sm={12}>
                                      <CustomField
                                        isRequired
                                        label="Pincode"
                                        errorMessage={
                                          touched.branches?.[index]
                                            ?.pincodeId &&
                                          errors.branches?.[index]?.pincodeId
                                        }
                                      >
                                        <MultiSelectComma
                                          options={pincodeOp}
                                          onChange={(
                                            e,
                                            action,
                                            isSelectAll
                                          ) => {
                                            if (!e?.length || isSelectAll) {
                                              setIsSearchPincode(false);
                                              setSearchPincode("");
                                              setActivePincode([]);
                                            }
                                            setFieldValue(
                                              `branches.${[index]}.pincodeId`,
                                              e?.value
                                            );
                                            setFieldValue(
                                              `branches.${[index]}.pincode`,
                                              e?.label
                                            );
                                            setFormik({
                                              values,
                                              setFieldValue,
                                            });
                                          }}
                                          closeMenu={false}
                                          // value={values?.pincode}
                                          value={pincodeOp.filter(
                                            (e) =>
                                              e.value?.toString() ===
                                              values.branches[
                                                index
                                              ].pincodeId?.toString()
                                          )}
                                          // defaultValue={(isView || isUpdate) && {label:branch?.pincode,value: branch?.pincodeId}}
                                          isClearable
                                          isDisabled={isView}
                                          onInputChange={(value) => {
                                            setFormik({
                                              values,
                                              setFieldValue,
                                            });
                                            onInputChangePincode(value);
                                            setPincodeSearchIndex(index);
                                          }}
                                          searchValue={searchPincode}
                                          isSearch={isSearchPincode}
                                          setIsSearch={setIsSearchPincode}
                                          menuIsOpen={menuIsOpenPincode}
                                          isMulti={false}
                                        />
                                      </CustomField>
                                    </Col>

                                    <Col lg={6} md={6} sm={12}></Col>

                                    <Col lg={6} md={6} sm={12}>
                                      <div className="fieldContainer">
                                        <Label isRequired label="Email" />
                                        <FieldArray
                                          name={`branches.${index}.emailId`}
                                          render={(helperMethod2) => (
                                            <div className="multiFieldMain">
                                              {Array?.isArray(
                                                values.branches[index].emailId
                                              ) &&
                                                values.branches[
                                                  index
                                                ].emailId?.map((email, i) => (
                                                  <div>
                                                    <div
                                                      className="d-flex gap-2"
                                                      key={`branches.${index}.emailId${i}`}
                                                    >
                                                      <Field
                                                        type="email"
                                                        id={`branches.${index}.emailId.${i}`}
                                                        name={`branches.${index}.emailId.${i}`}
                                                        className={cx({
                                                          "form-control": true,
                                                          "form-control-sm": true,
                                                          "is-invalid":
                                                            touched.branches?.[
                                                              index
                                                            ]?.emailId?.[i] &&
                                                            Boolean(
                                                              errors.branches?.[
                                                                index
                                                              ]?.emailId?.[i]
                                                            ),
                                                        })}
                                                        placeholder="Email"
                                                        maxLength={65}
                                                        disabled={isView}
                                                      />
                                                      {i === 0 && (
                                                        <button
                                                          type="button"
                                                          className="btn btn-sm btn-primary mx-auto d-flex"
                                                          onClick={() => {
                                                            helperMethod2.push(
                                                              ""
                                                            );
                                                          }}
                                                          disabled={isView}
                                                        >
                                                          +
                                                        </button>
                                                      )}
                                                      {i > 0 && (
                                                        <button
                                                          type="button"
                                                          className="btn btn-sm btn-danger mx-auto d-flex"
                                                          style={{
                                                            borderRadius: "20%",
                                                            color: "#fff",
                                                          }}
                                                          onClick={() => {
                                                            Swal.fire({
                                                              title:
                                                                "Are you sure?",
                                                              text: "You won't be able to revert this!",
                                                              icon: "warning",
                                                              showCancelButton: true,
                                                              confirmButtonColor:
                                                                "#3085d6",
                                                              cancelButtonColor:
                                                                "#d33",
                                                              confirmButtonText:
                                                                "Yes, delete it!",
                                                            }).then(
                                                              (result) => {
                                                                if (
                                                                  result.isConfirmed
                                                                ) {
                                                                  helperMethod2.remove(
                                                                    index
                                                                  );
                                                                }
                                                              }
                                                            );
                                                          }}
                                                          disabled={isView}
                                                        >
                                                          X
                                                        </button>
                                                      )}
                                                    </div>
                                                    {touched.branches?.[index]
                                                      ?.emailId?.[i] &&
                                                      Boolean(
                                                        errors.branches?.[index]
                                                          ?.emailId?.[i]
                                                      ) && (
                                                        <FormFeedback
                                                          style={{
                                                            display: "block",
                                                          }}
                                                        >
                                                          {
                                                            errors.branches?.[
                                                              index
                                                            ]?.emailId?.[i]
                                                          }
                                                        </FormFeedback>
                                                      )}
                                                  </div>
                                                ))}
                                            </div>
                                          )}
                                        />
                                      </div>
                                    </Col>
                                    <Col lg={6} md={6} sm={12}>
                                      <div className="fieldContainer">
                                        <Label isRequired label="Contact" />
                                        <FieldArray
                                          name={`branches.${index}.contactNo`}
                                          render={(helperMethod2) => (
                                            <div className="multiFieldMain">
                                              {Array.isArray(
                                                values?.branches?.[index]
                                                  ?.contactNo
                                              ) &&
                                                values?.branches?.[
                                                  index
                                                ]?.contactNo?.map(
                                                  (contactNo, i) => (
                                                    <div
                                                      key={`branches.${index}.contactNo${i}`}
                                                    >
                                                      <div className="d-flex gap-2">
                                                        <Field
                                                          type="text" // Use type="text" to allow custom validation
                                                          id={`branches.${index}.contactNo.${i}`}
                                                          name={`branches.${index}.contactNo.${i}`}
                                                          onChange={(e) => {
                                                            const value =
                                                              e.target.value;
                                                            // Allow only digits (0-9) and limit to 10 characters
                                                            if (
                                                              /^\d{0,10}$/.test(
                                                                value
                                                              )
                                                            ) {
                                                              setFieldValue(
                                                                `branches.${index}.contactNo.${i}`,
                                                                value
                                                              );
                                                            }
                                                          }}
                                                          className={cx({
                                                            "form-control": true,
                                                            "form-control-sm": true,
                                                            "is-invalid":
                                                              touched
                                                                .branches?.[
                                                                index
                                                              ]?.contactNo?.[
                                                                i
                                                              ] &&
                                                              Boolean(
                                                                errors
                                                                  .branches?.[
                                                                  index
                                                                ]?.contactNo?.[
                                                                  i
                                                                ]
                                                              ),
                                                          })}
                                                          placeholder="Contact"
                                                          disabled={isView}
                                                        />
                                                        {i === 0 && (
                                                          <button
                                                            type="button"
                                                            className="btn btn-sm btn-primary mx-auto d-flex"
                                                            onClick={() => {
                                                              helperMethod2.push(
                                                                ""
                                                              ); // Add new contact number field
                                                            }}
                                                            disabled={isView}
                                                          >
                                                            +{" "}
                                                            {/* Add button for new contact number */}
                                                          </button>
                                                        )}
                                                        {i > 0 && (
                                                          <button
                                                            type="button"
                                                            className="btn btn-sm btn-danger mx-auto d-flex"
                                                            style={{
                                                              borderRadius:
                                                                "20%",
                                                              color: "#fff",
                                                            }}
                                                            onClick={() => {
                                                              Swal.fire({
                                                                title:
                                                                  "Are you sure?",
                                                                text: "You won't be able to revert this!",
                                                                icon: "warning",
                                                                showCancelButton: true,
                                                                confirmButtonColor:
                                                                  "#3085d6",
                                                                cancelButtonColor:
                                                                  "#d33",
                                                                confirmButtonText:
                                                                  "Yes, delete it!",
                                                              }).then(
                                                                (result) => {
                                                                  if (
                                                                    result.isConfirmed
                                                                  ) {
                                                                    helperMethod2.remove(
                                                                      i
                                                                    ); // Remove contact number field
                                                                  }
                                                                }
                                                              );
                                                            }}
                                                            disabled={isView}
                                                          >
                                                            X{" "}
                                                            {/* Remove button */}
                                                          </button>
                                                        )}
                                                      </div>
                                                      {touched.branches?.[index]
                                                        ?.contactNo?.[i] &&
                                                        Boolean(
                                                          errors.branches?.[
                                                            index
                                                          ]?.contactNo?.[i]
                                                        ) && (
                                                          <FormFeedback
                                                            style={{
                                                              display: "block",
                                                            }}
                                                          >
                                                            {
                                                              errors.branches?.[
                                                                index
                                                              ]?.contactNo?.[i]
                                                            }
                                                          </FormFeedback>
                                                        )}
                                                    </div>
                                                  )
                                                )}
                                            </div>
                                          )}
                                        />
                                      </div>
                                    </Col>
                                  </Row>
                                </CardBody>
                              </Card>
                            );
                          })}
                      </>
                    )}
                  />
                </CardBody>
                {(isView || isUpdate) && (
                  <CardBody>
                    <FileTable
                      onBtnClick={onBtnClickAgg}
                      isView={isView}
                      btnName="Add Agreement Document"
                      docData={aggDocument}
                      id="docLenderAggrementScanningId"
                      downloadURL="/download-lender-aggrement-scanning"
                      onEditClick={onEditClickAgg}
                    />
                  </CardBody>
                )}
              </Card>
              {isView || (
                <div className="d-flex justify-content-end mt-2">
                  <Button
                    color="primary"
                    type="submit"
                    className="me-1"
                    size="sm"
                  >
                    Submit
                  </Button>{" "}
                  <Button
                    size="sm"
                    color="danger"
                    type="button"
                    style={{ color: "#fff" }}
                    onClick={() => {
                      cancelModal(false);
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              )}

              <div className="d-flex gap-md-5">
                {isView ? (
                  <Card className="mt-3 w-50">
                    <CardHeader className="h5">Deals</CardHeader>
                    <CardBody>
                      <Table className="text-center">
                        <thead>
                          <tr>
                            <th>No.</th>
                            <th>Deal Name</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>-</td>
                            <td>-</td>
                          </tr>
                        </tbody>
                      </Table>
                    </CardBody>
                  </Card>
                ) : null}
                {isView ? (
                  <Card className="mt-3 w-50">
                    <CardHeader className="h5">Lender Users</CardHeader>
                    <CardBody>
                      <Table className="text-center">
                        <thead>
                          <tr>
                            <th>No.</th>
                            <th>User Name</th>
                          </tr>
                        </thead>
                        <tbody>
                          {/* <tr> */}
                          {lenderUser.map((value, index) => (
                            <tr>
                              <td>{index + 1}</td>
                              <td>{value}</td>
                            </tr>
                          ))}
                          {/* <td>1</td>
                                  <td>2</td> */}
                          {/* </tr> */}
                        </tbody>
                      </Table>
                    </CardBody>
                  </Card>
                ) : null}
              </div>
            </Form>
          );
        }}
      </Formik>
      {addAgg && (
        <FileUpload
          header="Add Agreement"
          visible={addAgg}
          setVisible={setAddAgg}
          onSave={onAggSave}
        />
      )}
      {editDocument?.visible && (
        <FileUpload
          header={`Edit ${editDocument?.name} Document`}
          visible={editDocument?.visible}
          setVisible={() => {
            setEditDocument({
              visible: false,
              name: "",
            });
          }}
          onSave={onEditDocSave}
        />
      )}
    </>
  );
}
