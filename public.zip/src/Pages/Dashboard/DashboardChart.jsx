import { memo } from "react"
import styles from './Dashboard.module.scss'
import { Bar, Doughnut, Pie } from "react-chartjs-2"
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Colors, CategoryScale, registerables } from 'chart.js';
import classNames from "classnames";

ChartJS.register(ArcElement, Tooltip, Legend, Colors, CategoryScale, ...registerables);

const DashboardChart = (props) => {
    const options = {
        ...props?.options,
        responsive: true,
        aspectRatio: 2,
        plugins: {
            legend: {
                display: true,
                position: "bottom",
                align: 'start'
            },
        },
    };

    const chart = () => {
        switch (props?.chartType) {
            case "Pie":
                return (
                    <Pie
                        data={props?.chartData}
                        options={options}
                    />
                )
                break;

            case "Doughnut":
                return (
                    <Doughnut
                        data={props?.chartData}
                        options={options}
                    />
                )

            case "Bar-Line":
                return (
                    <Bar
                        data={props?.chartData}
                        options={options}
                    />
                )

            default:
                break;
        }
    }

    return (
        <div className={classNames(styles?.chart, props?.chartClassNames )  } >
            <p className={classNames(styles?.header, props.header)}>{props?.chartHeader}</p>
            {Boolean(Object.keys(props?.chartOtherDetails || {})?.length) &&
                <div className={classNames(styles?.otherDetails,props?.chartOtherDetails?.filter ? styles?.spaceBetween : styles?.end)}>
                    {props?.chartOtherDetails?.filter}
                    {props?.chartOtherDetails?.otherChart && <p>{props?.chartOtherDetails?.otherChart}</p>}
                </div>
            }
            {chart()}
        </div>
    )
}

export default memo(DashboardChart)