import { DataTable } from "primereact/datatable"
import { Fragment, memo } from "react"
import Pagination from "../../components/Pagination";
import { Column } from "primereact/column";
import styles from './Audit.module.scss'

const AuditTable=(props)=>{
    return(
        <Fragment>
            <DataTable
                value={props?.data}
                size={"small"}
                className={styles?.tableContainer}
                footer={(
                    <div className="tableCountFooter">
                      <p>Total Audit: {props?.totalCount}</p>
                    </div>
                )}
            >
                <Column header="Activity" field="activity" />
                <Column header="Module" field="module" />
                <Column header="User Name" field="userName" />
                <Column 
                    header="Date"
                    body={rowData=>{
                        const date = new Date(rowData?.createdTime).toISOString().split('T')[0]?.split('-').reverse().join('/')
                        return(
                            <span>{date}</span>
                        )
                    }}
                />
                <Column 
                    header="Time"
                    body={rowData=>{
                        const time = new Date(rowData?.createdTime)?.toLocaleTimeString('en-us',{hour: '2-digit',minute:'2-digit'})
                        return(
                            <span>{time}</span>
                        )
                    }}
                />
            </DataTable>
            <Pagination 
                totalCount={props?.totalCount}
                currentPage={props?.currentPage}
                numberOfDataPerPage={props?.numberOfDataPerPage}
                setCurrentPage={props?.setCurrentPage}
                setNumberOfDataPerPage={props?.setNumberOfDataPerPage}
            />
        </Fragment>
    )
}

export default memo(AuditTable)