import { DataTable } from "primereact/datatable";
import { memo, useEffect, useMemo, useState } from "react";
import styles from "./Reports.module.scss";
import { Column } from "primereact/column";
import classNames from "classnames";
import { Button } from "reactstrap";
import Swal from "sweetalert2";
import axios from "axios";
import { saveAs } from "file-saver";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch, useSelector } from "react-redux";
import { addAudit } from "../../utils/commonFun";

const ReportTable = (props) => {
  const [reportData, setReportData] = useState([]);
  const user = useSelector((state) => state.user.data);
  const dispatch = useDispatch();

  const reportDataSchema = useMemo(
    () => [
      {
        id: 3,
        reportName: "Agency Report",
        permission: user?.masterRole?.reports_agencyreport,
      },
      {
        id: 4,
        reportName: "Lender Report",
        permission: user?.masterRole?.reports_lenderreport,
      },
      {
        id: 5,
        reportName: "Product Report",
        permission: user?.masterRole?.reports_productreport,
      },
      {
        id: 6,
        reportName: "Call Attendance Report",
        permission: user?.masterRole?.reports_callattendancereport,
      },
      {
        id: 7,
        reportName: "Payment Report",
        permission: user?.masterRole?.reports_paymentreport,
      },
      {
        id: 8,
        reportName: "Cash Collected Report",
        permission: user?.masterRole?.reports_cashcollectreport,
      },
      {
        id: 9,
        reportName: "Product Lender Report",
        permission: user?.masterRole?.reports_productlenderreport,
      },
      {
        id: 10,
        reportName: "Lender DPD Report",
        permission: user?.masterRole?.reports_lenderdpdreport,
      },
      {
        id: 11,
        reportName: "Attendance Report",
        permission: user?.masterRole?.reports_attendancereport,
      },
      {
        id: 12,
        reportName: "Monthly Deal Collection Amount Report",
        permission: user?.masterRole?.reports_monthlydealcollectionamountreport,
      },
      {
        id: 13,
        reportName: "Collection Through Cc and Fos Report",
        permission: user?.masterRole?.reports_collectionthroughccandfosreport,
      },
      {
        id: 14,
        reportName: "Settlement & Foreclosure Report",
        permission: user?.masterRole?.reports_settlementandclosurereport,
      },
      {
        id: 15,
        reportName: "Pool Wise PTP & Paid Summary Report",
        permission: user?.masterRole?.reports_poolwiseptpandpaidsummaryreport,
      },
      {
        id: 16,
        reportName: "Login Report",
        permission: user?.masterRole?.reports_loginreport,
      },
      {
        id: 17,
        reportName: "User Portfolio Report",
        permission: user?.masterRole?.reports_userportfolioreport,
      },
      {
        id: 18,
        reportName: "Campaign Report",
        permission: user?.masterRole?.reports_allocationreport,
      },
      {
        id: 19,
        reportName: "User Tracking Hourly Report",
        permission: user?.masterRole?.reports_allocationreport,
      },
      {
        id: 20,
        reportName: "Allocation Report",
        permission: user?.masterRole?.reports_allocationreport,
      },
    ],
    [user]
  );

  useEffect(() => {
    const filteredData = reportDataSchema.filter((a) => a.permission);
    setReportData(filteredData);
  }, [reportDataSchema]);

  const onDownload = async (rowData) => {
    if (!props?.searchValues?.from || !props?.searchValues?.to) return;

    dispatch(setLoader(true));
    let url = getReportUrl(rowData.reportName);
    if (!url) {
      dispatch(setLoader(false));
      return Swal.fire({ icon: "error", title: "Invalid report type" });
    }

    try {
      // Special handling for Campaign Report using POST
      if (rowData.reportName === "Campaign Report") {
        const campaignPayload = {
          campaignName:
            props?.searchValues?.campaignName?.length === 0
              ? props?.searchValues?.campaignName?.map((item) => item?.value)
              : props?.campaignName?.map((item) => item?.value),
          lenderName:
            props?.searchValues?.lenderName?.length === 0
              ? props?.searchValues?.lenderName?.map((item) => item?.value)
              : props?.lenderName?.map((item) => item?.value),
          productCode:
            props?.searchValues?.productCode?.length === 0
              ? props?.searchValues?.productCode?.map((item) => item?.value)
              : props?.productoption?.map((item) => item?.value),
          from: props?.searchValues?.from,
          to: props?.searchValues?.to,
        };

        const res = await axios.post(url, campaignPayload, {
          responseType: "arraybuffer",
        });
        const blob = new Blob([res.data], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        saveAs(blob, `${rowData.reportName.replace(/ /g, "_")}.xlsx`);
      } else {
        const { data } = await axios.get(url, { responseType: "arraybuffer" });
        const blob = new Blob([data], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        saveAs(blob, `${rowData.reportName.replace(/ /g, "_")}.xlsx`);
      }

      // Audit log
      await addAudit({
        userName: user?.userName,
        module: "Report",
        activity: `${user?.userName} downloaded ${rowData.reportName}`,
      });
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: error?.message || "Error downloading report",
      });
    } finally {
      dispatch(setLoader(false));
    }
  };

  const getReportUrl = (reportName) => {
    const formatDate = (date) =>
      date ? date.split(" ")[0] : new Date().toISOString().split("T")[0];
    const startDate = formatDate(props.searchValues?.from);
    const endDate = formatDate(props.searchValues?.to);
    const startDate1 = formatDate1(props.searchValues?.from); // This will be formatted to 00:00:00
    const endDate1 = formatDate1(props.searchValues?.to, true);
    const userId = user?.userId;

    const reportUrls = {
      // "Agency Report": `/getAgencyReport/${startDate}/${endDate}/${userId}`,
      // "Agency Report": `/getAgencyReport/${startDate}/${endDate}/${userId}`,
      // "Agency Report": `/getAgencyReport/${startDate}/${endDate}/${userId}`,
      "Agency Report": `/getAgencyReport/${startDate}/${endDate}/${userId}`, // Updated URL
      "Lender Report": `/getLenderReportsExcel/${startDate}/${endDate}/${userId}`,
      "Product Report": `/getProductReport/${startDate}/${endDate}/${userId}`,
      "Call Attendance Report": `/getCallAttendanceReportsExcel/${startDate}/${endDate}/${userId}`,
      "Payment Report": `/getPaymentReportExcel/${userId}?fromDate=${startDate1}&toDate=${endDate1}`,
      "Cash Collected Report": `/getCashCollectReport/${startDate}/${endDate}/${userId}`,
      "Product Lender Report": `/getProduct_lenderReport/${startDate}/${endDate}/${userId}`,
      "Lender DPD Report": `/getLenderDpdReportsExcel/${startDate}/${endDate}/${userId}`,
      "Attendance Report": `/getAttendanceReport/${startDate}/${endDate}/${userId}`,
      "Monthly Deal Collection Amount Report": `/getMonthlyDealCollAmtReport/${startDate}/${endDate}/${userId}`,
      "Collection Through Cc and Fos Report": `/getCollectionThroughCcFosReport/${startDate}/${endDate}/${userId}`,
      "Settlement & Foreclosure Report": `/getSettlementAndClosureReport/${startDate}/${endDate}/${userId}`,
      "Pool Wise PTP & Paid Summary Report": `/getPoolWisePaidAndPtpReport/${startDate}/${endDate}/${userId}`,
      "Login Report": `/getLoginReport/${startDate}/${endDate}/${userId}`,
      "User Portfolio Report": `/getUserPortFolioReport/${startDate}/${endDate}/${userId}`,
      "Campaign Report": `/getCampaignReport`,
      "User Tracking Hourly Report": `/getUserTrackingHourlyExport/${userId}?startDate=${startDate1}&endDate=${endDate1}`,
      "Allocation Report": `/getAllocationReportExcel/${startDate}/${endDate}/${userId}`,
    };

    return reportUrls[reportName] || null;
  };

  // const formatDate1 = (date) => date ? `${date} 00:00:00` : new Date().toISOString().split('T')[0] + ' 00:00:00';
  const formatDate1 = (date, isEndDate = false) => {
    if (!date) return null; // Handle null or undefined input
    const formattedDate = new Date(date);

    // Format the date as YYYY-MM-DD
    const year = formattedDate.getFullYear();
    const month = String(formattedDate.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const day = String(formattedDate.getDate()).padStart(2, "0");

    // Set time based on whether it's the end date
    const hours = isEndDate ? "23" : "00";
    const minutes = "00";
    const seconds = "00";

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  };
  return (
    <DataTable
      value={
        props?.searchValues?.report?.value
          ? reportData.filter(
              (a) => props?.searchValues?.report?.value === a?.id
            )
          : reportData
      }
      size="small"
      className={styles.reportTable}
    >
      <Column header="Reports" field="reportName" />
      <Column
        header="Action"
        body={(rowData) => (
          <Button
            type="button"
            size="sm"
            className={styles.iconBtn}
            disabled={!props?.searchValues?.from || !props?.searchValues?.to}
          >
            <i
              className={classNames("bi bi-download", styles.downloadIcon)}
              onClick={() => onDownload(rowData)}
            />
          </Button>
        )}
      />
    </DataTable>
  );
};

export default memo(ReportTable);
