import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { Cookies } from "react-cookie";
export const getAgencyDetails = createAsyncThunk("getAgencyDetails", async (args) => {
    try {
        const response = await axios.get(`getUserByUserType/${args}`);
        return response?.data?.data;
    } catch (error) {
        console.log(error);
        throw error;
    }
})
export const getUserListDetails = createAsyncThunk("getUserListDetails", async (args) => {
    try {
        const response = await axios.post(`getUserByFilter/${args}`);
        return response?.data?.data;
    } catch (error) {
        console.log(error);
        throw error;
    }
})
export const mapDataByUserId = createAsyncThunk("mapDataByUserId", async (args) => {
    try {
        const response = await axios.get(`mapDataByUserId/${args}`);
        return response?.data?.data;
    } catch (error) {
        console.log(error);
        throw error;
    }
})
export const getLivelocation = createAsyncThunk("getLiveLocation", async (args) => {
    const payload = args?.userid?.map(item => { return item?.key })
    try {
        const res = await axios.post(`/liveLocation?TRACKER_ID=${args}`, payload)
        return res
    } catch (error) {
        console.log(error)
    }
})
const liveTrackingSlice = createSlice({
    name: "liveTrackingSlice",
    initialState: {
        agencyOption: null,
        userData: [],
        LiveData: []
    },
    reducers: {
    },
    extraReducers: (builder) => {
        builder.addCase(getAgencyDetails.fulfilled, (state, action) => {
            state.agencyOption = action.payload
        });
        builder.addCase(getUserListDetails.fulfilled, (state, action) => {
            state.userData = action.payload
        });
        builder.addCase(mapDataByUserId.fulfilled, (state, action) => {
            state.userData = action.payload
        });
        builder.addCase(getLivelocation.fulfilled, (state, action) => {
            state.LiveData = action.payload
        })
    },
})
export default liveTrackingSlice.reducer;