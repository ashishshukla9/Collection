import React, { useState, useEffect } from 'react';
import Trackingmap from './Trackingmap';
import UserList from './UserList';
import './LiveTracking.css';
import TrackingFilter from './TrackingFilter';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { getUserListDetails } from './LiveTrackingSlice';
import { baseUrl } from '../../App.config';
import Swal from 'sweetalert2';
import Map from './LiveTrackingDetails';
const Index = () => {
  const user = useSelector((state) => state.user.data);
  const [userOfOnline, setuserOfOnline] = useState([])
  const [iddII, setIddII] = useState([])
  const [SwitchMode, setSwitchMode] = useState(true);
  const [userStatus, setUserStatus] = useState("Online");
  const [latestActivities, setLatestActivities] = useState([]);
  const userData = useSelector((state) => state.LiveTrackingSlice.userData);
  const [afterFilterLiveTrackerCount, setAfterFilterLiveTrackerCount] = useState();
  const [liveTrackerCount, setLiveTrackerCount] = useState(null);
  const [userByFilterData, setUserByFilterData] = useState(null);
  const [liveFilterCount, setLiveFilterCount] = useState([]);
  const [userIdsFromFilter, setUserIdsFromFilter] = useState([]);
  const [liveLocationData, setLiveLocationData] = useState([]);
  const [userCoordinates, setUserCoordinates] = useState([]);
  const [trackerId, setTrackerId] = useState(null);
  const dispatch = useDispatch();
  const [sharedValueStartTime, setSharedValueStartTime] = useState("");
  const [sharedValueEndTime, setSharedValueEndTime] = useState("");
  const [sharedValueCurrent, setSharedValueCurrent] = useState("");
  const [onlineuser, setonlineuser] = useState([]);
  const [agencyuserIdsW, setagencyuserIdsW] = useState([]);
  const [AgencyIds, setAgencyIds] = useState([]);
  const [AllAgencyIds, setAllAgencyIds] = useState([]);
  const [ExternalUsers, setExternalUsers] = useState([]);
  const [userListForALL, setuserListForALL] = useState([]);
  const [loginActivities, setLoginActivities] = useState([]);
  const [logoutActivities, setLogoutActivities] = useState([]);
  const [Loginusertransfer, setLoginusertransfer] = useState([]);
  const [logoutusertransfer, setLogoutusertransfer] = useState([]);
  const getDashBoardData = async () => {
    try {
      const res = await axios.post(`/getLiveTrackerDashboard/${user?.userId}`);
      const data = res?.data?.data || {};
      const processedData = {
        completedVisit: data.completedVisit || 0,
        offlineUser: data.offlineUser || 0,
        onlineUser: data.onlineUser || 0,
        pendingVisit: data.pendingVisit || 0,
        rejectedVisit: data.rejectedVisit || 0,
        rescheduledVisit: data.rescheduledVisit || 0,
        scheduleVisit: data.scheduleVisit || 0,
      };
      setLiveTrackerCount(processedData);
    } catch (error) {
      console.log(error);
    }
  };
  const getAgencyForAll = async () => {
    try {
      const response = await axios.get(`/getAgencyByUserId/${user?.userId}`);
      const resp = response.data.data;
      if (response.data.message === "No Agency found") {
        await getAllAgency();
      } else {
        const allAgencyIds = resp.map(agency => agency.agencyId);
        setAgencyIds(allAgencyIds);
        if (allAgencyIds.length > 0) {
          getUserByAgencyForAll(allAgencyIds);
        }
      }
    } catch (error) {
      console.log('getAgency:', error);
    } finally {
    }
  };
  const getAllAgency = async () => {
    try {
      const response = await axios.get('/getAllAgency');
      const agencies = response.data.data || []; // Default to an empty array if data is undefined
      const filteredAgencies = agencies.filter(agency => agency.status === "Y");
      const allAgencyIds = filteredAgencies.map(agency => agency.agencyId);
      const agencyOptions = filteredAgencies.map(agency => ({
        label: agency.agencyName,
        value: agency.agencyId,
      }));
      setAgencyIds(allAgencyIds);
      setExternalUsers(agencyOptions);
      if (allAgencyIds.length > 0) {
        getUserByAgencyForAll(allAgencyIds);
      }
    } catch (error) {
      console.error('Error fetching agencies:', error); // Improved error logging
    } finally {
    }
  };
  const getUserByAgencyForAll = async agencyIds => {
    try {
      const agencyIdsString = agencyIds.join(',');
      const response = await axios.get(`getAllUserByAgencyId/${agencyIdsString}`);
      const userData = response.data.data;
      const filteredUserData = userData.filter(
        user => user.userType === 'U103',
      );
      const formattedUserData = filteredUserData.map(user => ({
        ...user,
        fullName: `${user.firstName} ${user.lastName}`,
      }));
      const extractedUserIds = formattedUserData.map(user => user.userId);
      setagencyuserIdsW(extractedUserIds); // Update state with userIds
      setuserListForALL(formattedUserData); // Update state with user data
    } catch (error) {
      console.log('getUserByAgency:', error);
    } finally {
    }
  };
  useEffect(() => {
    getAgencyForAll();
  }, [])
  const getFilterdData = async () => {
    try {
      const res = await axios.post(`/getLiveTrackerDashboard/${user?.userId}`);
      setLiveFilterCount(res?.data?.data);
    } catch (error) {
      console.log(error);
    }
  };
  const getMapMarkerForONOFF = async () => {
    try {
      const response = await axios.post(`/getUserByFilter/${user?.userId}`);
      // Extract user data from response
      const userData = response.data.data;
      const offlineuser = userData.filter(user => user.status === 'Offline');
      const offlineuserIDWE = new Set(offlineuser.map(user => user.userId))
      const filteredOfflineuser = logoutActivities.filter(activity => offlineuserIDWE.has(activity.userId))
      setLogoutusertransfer(filteredOfflineuser)
      const onlineUsers = userData.filter(user => user.status === 'Online');
      const onlineUserIds = new Set(onlineUsers.map(user => user.userId));
      const filteredLoginActivities = loginActivities.filter(activity =>
        onlineUserIds.has(activity.userId)
      );
      setLoginusertransfer(filteredLoginActivities)
      setuserOfOnline(onlineUsers.map(user => ({
        userId: user.userId,
        fullName: user.fullName
      })));
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  useEffect(() => {
    if (loginActivities.length > 0) {
      getMapMarkerForONOFF();
    }
  }, [loginActivities]);
  const getMapMarker = async () => {
    try {
      const response = await axios.post(`/getUserByFilter/${user?.userId}`);
      const userData = response.data.data;
      const fetchData = userData.map(user => ({
        userId: user.userId,
        fullName: user.fullName
      }));
      const userIds = fetchData.map(user => user.userId);
      setIddII(userIds);
      setonlineuser(fetchData);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  const formatDate = (date) => {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  };
  const mapDataByUserId = async () => {
    if (iddII.length === 0) return; // Avoid calling if id is empty
    const userIds = [...iddII, ...agencyuserIdsW];
    const payload = {
      userIds,
      date: formatDate(new Date()),
      fromTime: '00-00',
      toTime: '24-00',
    };
    try {
      const response = await axios.post(`/mapDataByUserId`, payload);
      const trackerData = response.data.data.tracker;
      const statusMap = userData.reduce((acc, user) => {
        acc[user.userId] = user.status;
        return acc;
      }, {});
      const userMap = onlineuser.reduce((acc, user) => {
        acc[user.userId] = user.fullName;
        return acc;
      }, {});
      const latestActivityMap = {};
      trackerData.forEach(activity => {
        const { userId, activity: activityType, createdTime, coordinates } = activity;
        const [latitude, longitude] = coordinates ? coordinates.split(',').map(Number) : [null, null];
        if (activityType === 'Login' || activityType === 'Logout') {
          if (!latestActivityMap[userId]) {
            latestActivityMap[userId] = {
              userId,
              fullName: userMap[userId] || 'Unknown', // Use fullName from userMap
              status: statusMap[userId] || 'Unknown', // Use status from statusMap
              activityType,
              createdTime,
              latitude,
              longitude
            };
          } else {
            const existingActivityTime = new Date(latestActivityMap[userId].createdTime);
            const newActivityTime = new Date(createdTime);

            if (newActivityTime > existingActivityTime) {
              latestActivityMap[userId] = {
                userId,
                fullName: userMap[userId] || 'Unknown', // Use fullName from userMap
                status: statusMap[userId] || 'Unknown', // Use status from statusMap
                activityType,
                createdTime,
                latitude,
                longitude
              };
            }
          }
        }
      });
      const latestActivities = Object.values(latestActivityMap);
      const logins = latestActivities.filter(activity => activity.activityType === 'Login');
      const logouts = latestActivities.filter(activity => activity.activityType === 'Logout');
      setLoginActivities(logins);
      setLogoutActivities(logouts);
      latestActivities.forEach(activity => {
      });
      setLatestActivities(latestActivities);
    } catch (error) {
      console.error('mapDataByUserId Error:', error);
    }
  };
  useEffect(() => {
    if (iddII && agencyuserIdsW.length > 0) {
      mapDataByUserId();
    }
  }, [iddII, agencyuserIdsW]);
  useEffect(() => {
    getMapMarker()
  }, [])
  const LiveLocationTreminate = async () => {
    try {
      await axios.get(`/trackerTermination?TRACKER_ID=${trackerId}`);
    } catch (error) {
      console.log(error, "termination api error");
    }
  };
  useEffect(() => {
    if (user?.userId) {
      dispatch(getUserListDetails(user?.userId));
    }
  }, [user?.userId, dispatch]);
  useEffect(() => {
    getDashBoardData();
    dispatch(getUserListDetails(user?.userId));
  }, [user?.userId]);
  useEffect(() => {
    getFilterdData();
    dispatch(getUserListDetails(user?.userId));
  }, [user?.userId]);
  useEffect(() => {
    if (afterFilterLiveTrackerCount) {
      setLiveTrackerCount(afterFilterLiveTrackerCount);
    }
  }, [afterFilterLiveTrackerCount]);
  useEffect(() => {
    if (userByFilterData && latestActivities) {
      const filteredUserData = userByFilterData.filter(user =>
        latestActivities.some(location => location.userId === user.userId)
      );
      const mergedData = filteredUserData.map(user => {
        const locationData = latestActivities.find(location => location.userId === user.userId);
        return {
          ...user,
          ...(locationData ? locationData : {}),
        };
      });
      setLiveFilterCount(mergedData.length > 0 ? mergedData : userByFilterData);
      if (mergedData.length === 0) {
      }
    }
  }, [userByFilterData, latestActivities]);
  const getLiveLocationData = () => {
    if (liveFilterCount && liveFilterCount.length) {
      return liveFilterCount;
    } else {
      return userByFilterData || latestActivities;
    }
  };
  return (
    <>
      <TrackingFilter
        setAfterFilterLiveTrackerCount={setAfterFilterLiveTrackerCount}
        setUserByFilterData={setUserByFilterData} // Pass the setter function
        liveTrackerCount={liveTrackerCount}
        userData={userData}
        setSharedValueStartTime={setSharedValueStartTime}
        setSharedValueEndTime={setSharedValueEndTime}
        setSharedValueCurrent={setSharedValueCurrent}
      />
      <div className="Tracking_Container">
        <Trackingmap
          userData={userData}
          liveLocationData={getLiveLocationData()}
        />
        <div className="map-list">
          <UserList
            SwitchMode={SwitchMode}
            setSwitchMode={setSwitchMode}
            setUserStatus={setUserStatus}
            userStatus={userStatus}
            userData={userByFilterData || userData}
            LiveLocationTreminate={LiveLocationTreminate}
            sharedValueStartTime={sharedValueStartTime}
            sharedValueEndTime={sharedValueEndTime}
            sharedValueCurrent={sharedValueCurrent}
          />
        </div>
      </div>
    </>
  );
};
export default Index;