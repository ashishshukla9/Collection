import React, { memo, useState, useEffect, useCallback } from 'react';
import { GoogleMap, InfoWindow, useLoadScript, Marker } from '@react-google-maps/api';
import redDot from '../../assets/images/red-dot.png'; // Import your red dot image
import greenDot from '../../assets/images/green-dot.png'; // Import your green dot image
import { getUserListDetails } from './LiveTrackingSlice';
import { useDispatch, useSelector } from 'react-redux';

const libraries = ['places'];

function Trackingmap(props) {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: 'AIzaSyBuUvhwxGimiUUicIv_O6IvE3xvzRjixhc',
    libraries,
  });
  const user = useSelector((state) => state.user.data);
  const [activeMarkerIndex, setActiveMarkerIndex] = useState(null);
  const dispatch = useDispatch();
  const [activeMarker, setActiveMarker] = useState(null); // Track only one active marker
  const [activeMarkerDetails, setActiveMarkerDetails] = useState(null);
  const [map, setMap] = useState(null);
  const [mapCenter, setMapCenter] = useState({ lat: 22.5937, lng: 78.9629 }); // Initial center
  const allCoordinates = props?.liveLocationData || [];
  useEffect(() => {
    dispatch(getUserListDetails(user?.userId));
  }, [user?.userId, dispatch]);
  const extractTime = (dateTime) => {
    const date = new Date(dateTime);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  useEffect(() => {
    // Log a message with userId, fullName, and activityType for each created marker
    allCoordinates.forEach(val => {
      // console.log(`Marker created for User ID: ${val.userId}, Full Name: ${val.fullName}, Activity Type: ${val.activityType}`);
    });
  }, [allCoordinates]);

  const mapContainerStyle = {
    width: '100%',
    height: '80vh',
  };
  const handleMarkerDoubleClick = useCallback((index) => {
    const { latitude, longitude, status } = allCoordinates[index];

    // Find all markers with the same latitude and longitude
    const matchingMarkers = allCoordinates
      .map((marker, i) => (marker.latitude === latitude && marker.longitude === longitude ? i : null))
      .filter(i => i !== null);

    if (matchingMarkers.length > 0) {
      let newIndex;
      if (activeMarkerIndex === null || !matchingMarkers.includes(activeMarkerIndex)) {
        newIndex = matchingMarkers[0];
      } else {
        const currentIndex = matchingMarkers.indexOf(activeMarkerIndex);
        newIndex = matchingMarkers[(currentIndex + 1) % matchingMarkers.length];
      }

      // Update state with new marker details
      setActiveMarkerIndex(newIndex);
      const markerDetails = allCoordinates[newIndex];
      setActiveMarkerDetails({
        name: markerDetails.fullName,
        createdTime: markerDetails.createdTime,
        userId: markerDetails.userId,
        status: markerDetails.status,
      });
      setActiveMarker(newIndex); // Update activeMarker

      // Center map on the new marker
      if (map) {
        map.setCenter({
          lat: markerDetails.latitude,
          lng: markerDetails.longitude
        });
      }
    } else {
      // Clear active details if no matching markers found
      setActiveMarkerIndex(null);
      setActiveMarkerDetails(null);
      setActiveMarker(null); // Clear active marker
    }
  }, [allCoordinates, activeMarkerIndex, map]);
  const sortedCoordinates = [...allCoordinates].sort((a, b) => {
    // First, sort markers with 'Online' status to appear first
    if (a.status === 'Online' && b.status !== 'Online') {
      return -1;
    }
    if (a.status !== 'Online' && b.status === 'Online') {
      return 1;
    }
    // Then, sort by latitude and longitude if statuses are the same
    if (a.latitude === b.latitude && a.longitude === b.longitude) {
      return 0;
    }
    return 0; // Default sorting if not 'Online'
  });
  if (loadError) return <div>Error loading maps</div>;
  if (!isLoaded) return <div>Loading Maps</div>;

  return (
    <GoogleMap
      mapContainerStyle={{ height: "100vh", width: "100%" }}
      center={mapCenter}
      zoom={5}
      onLoad={mapInstance => setMap(mapInstance)}
      onDragEnd={() => {
        if (map) {
          setMapCenter(map.getCenter().toJSON());
        }
      }}
      options={{
        disableDefaultUI: true,
        zoomControl: true,
        scrollwheel: true,
        streetViewControl: false,
        mapTypeControl: false,
        fullscreenControl: false,
      }}
    >
      {sortedCoordinates.map((val, index) => (
        val.latitude != null && val.longitude != null && (
          <Marker
            key={index}
            position={{ lat: Number(val.latitude), lng: Number(val.longitude) }}
            onClick={() => setActiveMarker(index)}
            onDblClick={() => handleMarkerDoubleClick(index)}
            icon={{
              url: val.status === 'Online' ? greenDot : redDot,
              scaledSize: new window.google.maps.Size(32, 32),
            }}
          >
            {activeMarker === index && (
              <InfoWindow onCloseClick={() => setActiveMarker(null)}>
                <Marker
                  key={index}
                  position={{ lat: Number(val.latitude), lng: Number(val.longitude) }}
                  onClick={() => setActiveMarker(index)}
                  onDblClick={() => handleMarkerDoubleClick(index)}
                  icon={{
                    url: val.status === 'Online' ? greenDot : redDot,
                    scaledSize: new window.google.maps.Size(32, 32),
                  }}
                >
                  <div>
                    <h6 className='fw-bold'>Name: {val.fullName}</h6>
                    <h6>Latitude: {val.latitude}</h6>
                    <h6>Longitude: {val.longitude}</h6>
                    <h6>Time: {extractTime(val.createdTime)}</h6>
                    {val.status === 'Completed' && (
                      <p><strong>Status:</strong> {val.status}</p>
                    )}
                  </div>
                </Marker>

              </InfoWindow>
            )}
          </Marker>
        )
      ))}
    </GoogleMap>
  );
}

export default memo(Trackingmap);
