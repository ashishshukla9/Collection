
import React, { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom';
import {
    Card, CardBody, Col, Input, Row, Dropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem, Button, Collapse, Form, FormGroup, Label
} from 'reactstrap'
import MultiSelectionFormik from "../../components/Selection/MultiSelectionFormik";
import { useFormik } from 'formik';
import Select from 'react-select';
import * as yup from "yup";
import './index.css'
import { Formik } from "formik";
import { useEffect } from "react";
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import { Calendar } from "primereact/calendar";
import { setFilterPayload, setList, setTotalCount, setAllTotalCount, setNewTotalCount, setUnalloctaedPendingTotalCount, setlanderfilterpayload, setAllocatedTotalCount, setInprogressTotalCount, setMyCaseTotalCount, setUnalloctaedApproveTotalCount, setUnalloctaedrejectTotalCount, } from '../Cases/store';
import Swal from "sweetalert2";
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { getProductData } from '../Master/store/productMasterSlice';
import { getAgencyDetails } from './LiveTrackingSlice';
import { setAction, setLoader } from "../../reducer/globalReducer";
import moment from 'moment';
import { extendToken } from "../../utils/commonFun";
import { FaRedo } from 'react-icons/fa';
const TrackingFilter = (props) => {
    const [selectedAgencyId, setSelectedAgencyId] = useState(null);
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const [status, setStatus] = useState(null);
    const [roles, setRoles] = useState([]);
    const { setSharedValueStartTime, setSharedValueEndTime, setSharedValueCurrent } = props;
    const [filterDialog, setFilterDialog] = useState(false)
    const [agencyList, setAgencyList] = useState([]);
    const [allAgencyInternalUser, setAllAgencyInternalUser] = useState([]);
    const [selectedUserType, setSelectedUserType] = useState(null);
    const [agencyInternalUser, setAgencyInternalUser] = useState([]);
    const [showInternalUserList, setShowInternalUserList] = useState(false); // State for User List visibility
    const [showAgencyOptions, setShowAgencyOptions] = useState(false);
    const [userIds, setUserIds] = useState([]);
    const [pincodeId, setPincodeId] = useState('')
    const [filteredAgencies, setFilteredAgencies] = useState([]);
    const user = useSelector((state) => state.user.data);
    const [maxPincodePages, setMaxPincodePages] = useState(0)
    const [productOp, setProductOp] = useState([])
    const [activePincodes, setActivePincodes] = useState([]);
    const [selectedZone, setSelectedZone] = useState([])
    const [currentCityPage, setCurrentCityPage] = useState(1)
    const [activeportfolio, setActivePortfolio] = useState([]);
    const [activeUserList, setActiveUserList] = useState([]);
    const handleAgencyChange = selectedOption => {
        setSelectedAgencyId(selectedOption ? selectedOption.value : null); // Store the selected agencyId
        getAllAgencyInternalUser(selectedOption ? selectedOption.value : null); // Fetch internal users based on selected agency
    };
    const handleRefresh = () => {
        window.location.reload();
    };
    const [allAgencyDetails, setAllAgencyDetails] = useState([]);
    const filterPayload = useSelector(state => state?.cases?.filterPayload)
    const [selecetdRegion, setSelectedRegion] = useState([])
    const [selecetdCities, setSelectedCities] = useState([])
    const currentDate = new Date();
    const yesterdayDate = moment().subtract(1, 'day').toDate();
    const minDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
    const [startDate, setStartDate] = useState(minDate);
    const h = (currentDate.getHours() < 10 ? '0' : '') + currentDate.getHours()
    const m = (currentDate.getMinutes() < 10 ? '0' : '') + currentDate.getMinutes()
    const [startTime, setStartTime] = useState('09:00 AM');
    const [endTime, setEndTime] = useState(`${h}:${m}`);
    const [isFilter, setIsFilter] = useState(false);
    const loginSessionTimeout = useSelector((state) => state?.global?.loginSessionTimeout)
    const [selecetdState, setSelectedState] = useState([])
    const [selectedProduct, setSelectedProduct] = useState([])
    const roleCode = useMemo(() => user?.role?.map(a => a?.roleCode), [user])
    const [cityList, setCityList] = useState([]);
    const [pagination, setPagination] = useState({})
    const [agencySearch, setAgencySearch] = useState("");
    const agencySelected = useSelector(state => state?.cases?.agencySelected)
    const [maxCityPages, setMaxCityPages] = useState(0)
    const [currentPincodePage, setCurrentPincodePage] = useState(1)
    const [pincodeList, setPincodeList] = useState([]);
    const [activeZone, setActiveZone] = useState([])
    const [activeRegion, setActiveRegion] = useState([])
    const [stateId, setStateId] = useState('')
    const [activeState, setActiveState] = useState([])
    const [activeCities, setActiveCities] = useState([])
    const [agencyDetails, setAgencyDetails] = useState([]);
    const dispatch = useDispatch()
    const agencyOption = useSelector((state) => state.LiveTrackingSlice.agencyOption);
    const portfolioData = useSelector((state) => state?.portfolioMaster?.data);
    const productData = useSelector(state => state?.productMaster?.data)
    const [activeButton, setActiveButton] = useState({
        Bucket: false,
        DPD: false,
        POS: false,
        TOS: false,
        Dormancy: false
    })
    const formik = useFormik({
        initialValues: {
            usertype: [], // Assuming usertype is an array for MultiSelectionFormik
            name: '' // Add this for the new input field
        },
        onSubmit: values => {
        },
    });
    useEffect(() => {
        if (typeof props.setSharedValueStartTime === 'function') {
            props.setSharedValueStartTime(startTime);
        } else {
            console.error('setSharedValueStartTime is not a function');
        }
        if (typeof props.setSharedValueEndTime === 'function') {
            props.setSharedValueEndTime(endTime);
        } else {
            console.error('setSharedValueEndTime is not a function');
        }
        if (typeof props.setSharedValueCurrent === 'function') {
            props.setSharedValueCurrent(startDate);
        } else {
            console.error('setSharedValueCurrent is not a function');
        }
    }, [props]);
    const handleSelectChange = (selectedOptions) => {
        handleAgencyChange(selectedOptions);
        if (selectedOptions) {
            setFieldValue("agencyList", selectedOptions.map(option => option.value));
        } else {
            setFieldValue("agencyList", selectedOptions ? selectedOptions.value : null);
        }
    };
    const activeTab = useMemo(() => {
        const tab = props?.activeTab;
        if (typeof tab === 'string') {
            return tab.charAt(0).toUpperCase() + tab.slice(1).toLowerCase();
        }
        return 'DefaultTab'; // Replace with your default behavior
    }, [props?.activeTab]);
    const activityOptions = [
        { value: 'ScheduleVisit', label: 'ScheduleVisit', activity: 1 },
        { value: 'PTP', label: 'PTP', activity: 2 },
        { value: 'Payment', label: 'Payment', activity: 3 },
        { value: 'Dispute/RTP', label: 'Dispute/RTP', activity: 4 },
        { value: 'Raise Exception', label: 'Raise Exception', activity: 5 },
        { value: 'Request', label: 'Request', activity: 6 },
        { value: 'WRONG NUMBER', label: 'WRONG NUMBER', activity: 7 },
        { value: 'LEFT MESSAGE', label: 'LEFT MESSAGE', activity: 8 },
        { value: 'NOT REACHABLE', label: 'NOT REACHABLE', activity: 9 },
        { value: 'CUSTOMER BUSY', label: 'CUSTOMER BUSY', activity: 10 },
        { value: 'VISIT PENDING', label: 'VISIT PENDING', activity: 11 },
        { value: 'NOT SERVICEABLE AREA', label: 'NOT SERVICEABLE AREA', activity: 12 },
        { value: 'ADDRESS NOT FOUND // SHORT ADD/WRONG ADD', label: 'ADDRESS NOT FOUND // SHORT ADD/WRONG ADD', activity: 13 },
        { value: 'OUT OF STATION', label: 'OUT OF STATION', activity: 14 },
        { value: 'DOOR LOCK/REVISIT', label: 'DOOR LOCK/REVISIT', activity: 15 },
        { value: 'ENTRY RESTRICTED', label: 'ENTRY RESTRICTED', activity: 16 },
        { value: 'RINGING NO RESPONSE', label: 'RINGING NO RESPONSE', activity: 17 },
        { value: 'SWITCHED OFF', label: 'SWITCHED OFF', activity: 18 },
        { value: 'Call Back', label: 'Call Back', activity: 19 },
        { value: 'Left Message', label: 'Left Message', activity: 20 }
    ];
    const handleChangeEvent = (selectedOptions) => {
        setFieldValue('usertype', selectedOptions);
    };
    const getAgencyStatus = async () => {
        try {
            const response = await axios.get('/getTrackingConfig'); // Replace with your API URL
            const data = response.data.response[0]; // Access the first item in the response array
            setStatus(data.active); // Update status based on API response
            setRoles(data.roles);  // Set the roles from the 'roles' field
            // console.log(data, 'Data from response');
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };
    useEffect(() => {
        getAgencyStatus();
    }, []);
    const { values, setFieldValue } = formik;
    const usertypeArray = Array.isArray(values.usertype) ? values.usertype : [];
    useEffect(() => {
        if (productData?.length) {
            const op = productData?.map(a => ({
                label: a?.productDescription,
                value: a?.productId,
                productCode: a?.productCode,
                portfolioId: a?.portfolio?.portfolioId
            }))
            setProductOp(op)
        }
    }, [productData])
    const onkeyEnterCity = (event, setFieldValue, preValues) => {
        if (event.key === "Enter") {
            event.preventDefault();
            const filtered_people = activeCities.filter((person) =>
                cityList.includes(person?.label?.toString()?.toLowerCase())
            );
            setFieldValue('city', [...preValues, ...filtered_people])
        }
    };
    const getAllPincodeByCity = async (pincodeId, isRestart) => {
        if (pincodeId?.length) {
            try {
                const res = await axios.get(`/getPincodeByCity/${pincodeId}/${isRestart ? 1 : currentPincodePage}/30`)

                const ops = res?.data?.response?.map(a => (
                    {
                        label: a.pincode,
                        value: a.pincodeId
                    }
                ))
                const maxNumberOfPage = Math.ceil(res?.data?.totalApplicationCount / 30 || 0)
                setMaxPincodePages(maxNumberOfPage)
                if (isRestart) {
                    setActivePincodes(ops)
                } else {
                    setActivePincodes([...activePincodes, ...ops])
                }
                setPincodeId(pincodeId)
            } catch (error) {
                setPincodeId('')
                setActivePincodes([])
            }
        } else {
            setPincodeId('')
        }
    }
    const getAllCityByState = async (stateId, isRestart) => {
        if (stateId?.length) {
            try {
                const res = await axios.get(`/getCityByState/${stateId}/${isRestart ? 1 : currentCityPage}/30`)

                const ops = res?.data?.response?.map(a => (
                    {
                        label: a.cityName,
                        value: a.cityCode,
                        cityId: a?.cityId

                    }
                ))
                const maxNumberOfPage = Math.ceil(res?.data?.totalApplicationCount / 30 || 0)
                setMaxCityPages(maxNumberOfPage)
                if (isRestart) {
                    setActiveCities(ops)
                } else {
                    setActiveCities([...activeCities, ...ops])
                }
                setStateId(stateId)
            } catch (error) {
                setStateId('')
                setActiveCities([])
            }
        } else {
            getAllCities()
            setStateId('')
        }
    }
    const getAllStateByRegion = async (regionId) => {
        if (regionId?.length) {
            try {
                const res = await axios.get(`/getStateByRegion/${regionId}`)
                const ops = res?.data?.data?.map(a => (
                    {
                        label: a.stateName,
                        value: a.stateCode,
                        stateId: a?.stateId
                    }
                ))
                setActiveState(ops)
            } catch (error) {
                setActiveState([])
            }
        } else {
            setActiveState([])
        }
    }
    const getAllRegionByZone = async (zoneId) => {
        if (zoneId?.length) {
            try {
                const res = await axios.get(`/getRegionByZone/${zoneId}`)
                const ops = res?.data?.data?.map(a => (
                    {
                        label: a.regionName,
                        value: a.regionCode,
                        regionId: a?.regionId
                    }
                ))
                setActiveRegion(ops)
            } catch (error) {
                setActiveRegion([])
            }
        } else {
            setActiveRegion([])
        }
    }
    const getBulkUploadSuccessByListOfLan = async (data, isNotMIS) => {
        dispatch(setLoader(true))
        try {
            if (data?.length) {
                let allLenId = data?.map(a => a?.allLan)
                allLenId = [...new Set(allLenId)]
                const allNewCases = data?.filter(a => a?.newCase === "Y")?.map(a => a?.allLan)
                const allAllocatedCases = data?.filter(a => a?.allocated === "Y")?.map(a => a?.allLan)
                const allMyCases = data?.filter(a => a?.newCase === "Y")?.map(a => a?.allLan)
                const allInProgressCases = data?.filter(a => a?.inProcess === "Y")?.map(a => a?.allLan)
                const allCases = { allNewCases, allAllocatedCases, allMyCases, allInProgressCases }
                let userId = data?.map(a => a?.userId)
                userId = [...new Set(userId)][0]
                const allocatedUserId = {}
                data?.map(a => {
                    Object.assign(allocatedUserId, { [a?.allLan]: a?.allocatedUser, [`fieldPickUp${a?.allLan}`]: a?.fieldPickUp })
                })
                const res2 = await axios.post(`/getBulkUploadSuccessByListOfLan/${user?.userId}`, allLenId)
                dispatch(setLoader(false))
                const caseStatus = (allCases, loanAccountNumber) => {
                    return allCases?.allNewCases?.includes(loanAccountNumber) ? "New" : (allCases?.allInProgressCases?.includes(loanAccountNumber) || allCases?.allAllocatedCases?.includes(loanAccountNumber) || allCases?.allMyCases?.includes(loanAccountNumber)) ? "Allocated" : ''
                }
                const finalData = res2?.data?.data?.map(data => ({
                    ...data,
                    allocateduserid1: data?.allocatedUser,
                    allocatedUser: isNotMIS ? allocatedUserId?.[data?.loanAccountNumber] : data?.allocatedUser,
                    caseStatus: userId === user?.userId ? caseStatus(allCases, data?.loanAccountNumber) : "Allocated"
                }))
                dispatch(setList(finalData))
            } else {
                dispatch(setList([]))
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error?.response?.data?.error}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
            console.log(error);
        }
    }
    const filterSearchLogic = async (dummayPayload, pageNumber) => {
        let payload = {}
        let isAgencyAPICalled = false;
        let isFilterAPICalled = false
        setPagination({
            pageNumber: pageNumber,
            numberOfDataPerPage: props?.numberOfDataPerPage
        })

        Object.entries(dummayPayload)?.map(a => {
            if (a[1]?.length) {
                Object.assign(payload, { [a[0]]: a[1] })
            }
        })
        dispatch(setFilterPayload(payload))
        let filterData = []
        let agencyData = []
        const timer = setInterval(() => {
            dispatch(setAction(1))
            extendToken(loginSessionTimeout)
        }, 60000)
        try {
            if (Object.keys(payload).length || agencySelected) {
                if (activeTab !== "All") {
                    payload = { ...payload, caseStatus: activeTab === "Deallocation" ? "Deallocated" : activeTab }
                }
                const misAllPrimaryUrl = (props?.currentModule === "Field" || user?.activityType === "Field") ? 'getFilterBulkUpLoadByMISField' : 'getFilterBulkUpLoadByMIS'
                const allPrimaryUrl = (props?.currentModule === "Field" || user?.activityType === "Field") ? 'getFilterBulkUpLoadByAllField' : 'getFilterBulkUpLoadByAll'
                const AgencyUserUrl = (props?.currentModule === "Field" || user?.activityType === "Field") ? 'getFilterBulkUpLoadByAllFieldDRA' : 'getFilterBulkUpLoadByAllCA'
                const landerUrl = `getLenderCases/${user?.userId}/${activeTab}/${pageNumber}/${props?.numberOfDataPerPage}`
                const misCodes = ["MIS", "RH", "CH", "OH", "OP"];
                const caFaCodes = ["CA", "FA"];
                const url = (misCodes.some(code => roleCode?.includes(code))) ? `${misAllPrimaryUrl}/${user?.userId}/${activeTab}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : (caFaCodes.some(code => roleCode?.includes(code))) ? `${AgencyUserUrl}/${user?.userId}/${activeTab}/${roleCode}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : roleCode?.includes('DRA') ? `${AgencyUserUrl}/${user?.userId}/${activeTab}/${roleCode}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}` : (roleCode?.includes('L01') || roleCode?.includes('L02')) ? landerUrl : `${allPrimaryUrl}/${user?.userId}/${activeTab}/${agencySelected?.value || 0}/${pageNumber}/${props?.numberOfDataPerPage}`;
                dispatch(setLoader(true))
                const res = await axios.post(`/${url}`, payload)
                dispatch(setLoader(false))
                let allCases = {}
                if (!roleCode?.includes("MIS")) {
                    const allNewCases = res?.data?.response?.filter(a => a?.newCase === "Y")?.map(a => a?.allLan)
                    const allAllocatedCases = res?.data?.response?.filter(a => a?.allocated === "Y")?.map(a => a?.allLan)
                    const allMyCases = res?.data?.response?.filter(a => a?.newCase === "Y")?.map(a => a?.allLan)
                    allCases = { allNewCases, allAllocatedCases, allMyCases }
                }
                isFilterAPICalled = true
                filterData = res?.data?.response;
                if (res?.data?.totalApplicationCount >= 0) {
                    if (activeTab == "All") {
                        dispatch(setAllTotalCount(res?.data?.totalApplicationCount))
                    } else if (activeTab == "New") {
                        dispatch(setNewTotalCount(res?.data?.totalApplicationCount))
                    } else if (activeTab == "Allocated") {
                        dispatch(setAllocatedTotalCount(res?.data?.totalApplicationCount))
                    } else if (activeTab == "In_progress") {
                        dispatch(setInprogressTotalCount(res?.data?.totalApplicationCount))
                    } else if (activeTab == "My_case") {
                        dispatch(setMyCaseTotalCount(res?.data?.totalApplicationCount))
                    } else if (activeTab == "Unallocated_pending") {
                        dispatch(setUnalloctaedPendingTotalCount(res?.data?.totalApplicationCount))
                    } else if (activeTab == "Unallocated_approved") {
                        dispatch(setUnalloctaedApproveTotalCount(res?.data?.totalApplicationCount))
                    } else if (activeTab == "Unallocated_rejected") {
                        dispatch(setUnalloctaedrejectTotalCount(res?.data?.totalApplicationCount))
                    }
                    dispatch(setTotalCount(res?.data?.totalApplicationCount))
                }
            }
            if (isFilterAPICalled && isAgencyAPICalled) {
                const finalData = filterData?.filter(a => agencyData?.map(b => b?.allLan).includes(a?.allLan || a?.loanAccountNumber))
                getBulkUploadSuccessByListOfLan(finalData, !roleCode?.includes("MIS"))
            } else if (filterData.length) {
                if (roleCode?.includes("MIS") || roleCode?.includes("RH") || roleCode?.includes("CH") || roleCode?.includes("OH") || roleCode?.includes("OP")) {
                    dispatch(setList(filterData))
                } else if (roleCode?.includes("L01") || roleCode?.includes("L02")) {
                    dispatch(setList(filterData))
                } else {
                    getBulkUploadSuccessByListOfLan(filterData, !roleCode?.includes("MIS"))
                }
            } else if (agencyData.length) {
                getBulkUploadSuccessByListOfLan(agencyData, !roleCode?.includes("MIS"))
            } else if (isAgencyAPICalled || isFilterAPICalled) {
                dispatch(setList([]))
            } else {
                props?.setIsFilter(false)
                props?.clearFilter()
            }
        } catch (error) {
            dispatch(setLoader(false))
        }
        clearInterval(timer)
    }
    useEffect(() => {
        if (props?.currentPage && props?.numberOfDataPerPage && props?.isFilter && Object.keys(pagination)?.length && (props?.currentPage !== pagination?.pageNumber || props?.numberOfDataPerPage !== pagination?.numberOfDataPerPage)) {
            filterSearchLogic(filterPayload, props?.currentPage)
        }
    }, [props?.currentPage, props?.numberOfDataPerPage, props?.isFilter])
    useEffect(() => {
        if (props?.isFilter) {
            filterSearchLogic(filterPayload, 1)
        }
    }, [props?.activeTab, props?.currentModule])
    const validationSchema = yup.object({
        bucket: yup.object().shape({
            min: yup.string().when('max', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'min',
                    message: 'Min value is less than or equal to Max value',
                    test: (value, context) => value <= Number(context?.parent?.max || 0)
                }).required('Bucket min is required')
            }),
            max: yup.string().when('min', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'max',
                    message: 'Max value is greater than or equal to Min value',
                    test: (value, context) => value >= Number(context?.parent?.min || 0)
                }).required('Bucket max is required')
            })
        }, ['min', 'max']),

        POS: yup.object().shape({
            min: yup.string().when('max', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'min',
                    message: 'Min value is less than or equal to Max value',
                    test: (value, context) => value <= Number(context?.parent?.max || 0)
                }).required('POS min is required')
            }),
            max: yup.string().when('min', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'max',
                    message: 'Max value is greater than or equal to Min value',
                    test: (value, context) => value >= Number(context?.parent?.min || 0)
                }).required('POS max is required')
            })
        }, ['min', 'max']),

        TOS: yup.object().shape({
            min: yup.string().when('max', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'min',
                    message: 'Min value is less than or equal to Max value',
                    test: (value, context) => value <= Number(context?.parent?.max || 0)
                }).required('TOS min is required')
            }),
            max: yup.string().when('min', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'max',
                    message: 'Max value is greater than or equal to Min value',
                    test: (value, context) => value >= Number(context?.parent?.min || 0)
                }).required('TOS max is required')
            })
        }, ['min', 'max']),

        DPD: yup.object().shape({
            min: yup.string().when('max', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'min',
                    message: 'Min value is less than or equal to Max value',
                    test: (value, context) => value <= Number(context?.parent?.max || 0)
                }).required('DPD min is required')
            }),
            max: yup.string().when('min', {
                is: a => a,
                then: () => yup.string().test({
                    name: 'max',
                    message: 'Max value is greater than or equal to Min value',
                    test: (value, context) => value >= Number(context?.parent?.min || 0)
                }).required('DPD max is required')
            })
        }, ['min', 'max'])
    })
    const handleSubmit = async (values) => {
        const combinedUserIds = [
            ...(values?.userList?.map(a => a?.value) || []),
            ...(values?.agencyUser?.map(a => a?.value) || []),
        ].filter((value, index, self) => self.indexOf(value) === index);
        let payload = {};
        const convertToNumbers = (array) => array?.map(a => Number(a)) || [];
        if (values?.usertype.includes('U101')) { // 'Internal'
            payload = {
                portfolioIds: values?.portfolio?.map(a => a?.value),
                productIds: values?.product?.map(a => a?.value),
                zoneIds: convertToNumbers(values?.zone?.map(a => a?.value)),
                regionIds: convertToNumbers(values?.region?.map(a => a?.value)),
                activity: values?.activity?.map(a => a?.value),
                stateIds: convertToNumbers(values?.state?.map(a => a?.value)),
                cityIds: convertToNumbers(values?.city?.map(a => a?.value)),
                userType: values?.usertype, // Should already be an array
                userIds: combinedUserIds,
            };
        } else if (values?.usertype.includes('U103')) { // 'Agency'
            payload = {
                activity: values?.activity?.map(a => a?.value),
                userType: values?.usertype, // Should already be an array
                userIds: combinedUserIds,
                agencyIds: selectedAgencyId ? [selectedAgencyId] : [],
            };
        }
        try {
            dispatch(setLoader(true));
            const [liveTrackerResponse, userByFilterResponse] = await Promise.all([
                axios.post(`/getLiveTrackerDashboard/${user?.userId}`, payload),
                axios.post(`/getUserByFilter/${user?.userId}`, payload)
            ]);
            const liveTrackerData = liveTrackerResponse.data?.data;
            const filteredLiveTrackerData = {
                ...liveTrackerData,
                onlineUser: liveTrackerData?.onlineUser !== null ? liveTrackerData.onlineUser : 0,
                offlineUser: liveTrackerData?.offlineUser !== null ? liveTrackerData.offlineUser : 0
            };
            if (typeof props.setAfterFilterLiveTrackerCount === 'function') {
                props.setAfterFilterLiveTrackerCount(filteredLiveTrackerData);
            }
            const userByFilterData = userByFilterResponse.data?.data;
            if (typeof props.setUserByFilterData === 'function') {
                props.setUserByFilterData(userByFilterData);
            }
            dispatch(setLoader(false));
        } catch (error) {
            console.error('Error in handleSubmit:', error);
            dispatch(setLoader(false));
        }
        if (typeof props.setIsFilter === 'function') {
            props.setIsFilter(true);
        }
    };
    useEffect(() => {
        if (filterDialog) {
            if (!activeportfolio.lender) {
                axios
                    .get("/getAllPortfolio")
                    .then(({ data }) => {
                        const tempData = [];
                        data?.data?.forEach((data) => {
                            if (data?.active === "Y")
                                tempData.push({
                                    label: data?.portfolioDescription,
                                    value: data?.portfolioId,
                                });
                        });
                        setActivePortfolio(tempData);
                    })
                    .catch((error) => {
                        console.log(error);
                    });

                if (!activeZone.length) getAllZone()
                if (!activeRegion.length) getAllRegion()
                if (!activeState.length) getAllState()
                if (!activeCities.length) getAllCities()
            }
        }
    }, [filterDialog])
    const fetchUserData = async () => {
        try {
            const response = await axios.get(`/getUserByUserType/${user?.userId}`);
            if (response.data && response.data.data) {
                const formattedUserList = response.data.data.map(user => ({
                    label: user.userName,
                    value: user.userId,
                }));
                setActiveUserList(formattedUserList); // Set formatted user list in state
                setUserIds(formattedUserList.map(user => user.value)); // Set user IDs in state
            } else {
                console.warn("Unexpected response format:", response);
            }
        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    };
    useEffect(() => {
        fetchUserData();
    }, []);
    const getAllAgencyInternalUser = async (agencyId) => {
        if (agencyId) {
            try {
                const res = await axios.get(`/getUserByAgency/${agencyId}`);
                if (res.data && res.data.data) {
                    const formattedUserList = res.data.data
                        .filter(user => user.userType === "U103")
                        .map(user => ({
                            label: `${user.firstName} ${user.lastName}`,
                            value: user.userId,
                        }));
                    setAgencyInternalUser(formattedUserList);
                } else {
                    console.warn("Unexpected response format:", res);
                }
            } catch (error) {
                console.error("Error fetching users by agency:", error);
            }
        } else {
            console.warn('No agencyId found');
        }
    };
    useEffect(() => {
        if (agencyInternalUser.length === 0) {
            getAllAgencyInternalUser();
        }
    }, [user?.userType, user?.agency]);
    const userTypeOptions = [
        { value: 'U101', label: 'Internal' },
        { value: 'U103', label: 'Agency' },
    ];
    const getAllZone = async () => {
        try {
            const res = await axios.get('/getAllZones');
            const ops = []
            res?.data?.data?.forEach(data => {
                if (data?.active === "Y") {
                    ops.push({
                        label: data.zoneName,
                        value: data.zoneCode,
                        zoneId: data?.zoneId
                    })
                }
            })
            setActiveZone(ops)
        } catch (error) {
            setActiveZone([])
        }
    }
    const getAllRegion = async () => {
        try {
            const res = await axios.get('/getAllRegions')
            const ops = []
            res?.data?.data?.forEach(data => {
                if (data?.active === "Y") {
                    ops.push({
                        label: data.regionName,
                        value: data.regionCode,
                        regionId: data?.regionId
                    })
                }
            })
            setActiveRegion(ops)
        } catch (error) {
            setActiveRegion([])
        }
    }
    const [userType, setUserType] = useState(''); // State to track user type
    const handleUserTypeChange = (selectedOption) => {
        setUserType(selectedOption.value);
    };
    const getAllState = async () => {
        try {
            const res = await axios.get('/getAllStates')
            const ops = []
            res?.data?.data?.forEach(data => {
                if (data?.active === "Y") {
                    ops.push({
                        label: data.stateName,
                        value: data.stateCode,
                        stateId: data?.stateId
                    })
                }
            })
            setActiveState(ops)
        } catch (error) {
            setActiveState([])
        }
    }
    const getAllCities = async () => {
        try {
            const res = await axios.get("/getAllCities/1/10");
            // console.log(res, 'bhubuyvgy')
            const ops = []
            res?.data?.response?.forEach(data => {
                if (data?.active === "Y") {
                    ops.push({
                        label: data.cityName,
                        value: data.cityCode,
                        cityId: data?.cityId
                    })
                }
            })
            setActiveCities(ops)
        } catch (error) {
            setActiveCities([])
        }
    }
    useEffect(() => {
        const dummayPayload = {
            ...filterPayload,
            portfolio: null,
            product: null,
            zone: null,
            region: null,
            state: null,
            city: null,
            activity: null,
            usertype: null,
            usertype: null,
        }
        dispatch(setlanderfilterpayload(dummayPayload))
    }, [])
    useEffect(() => {
        getAllZone()
        getAllRegion()
        getAllState()
        getAllCities()
        dispatch(getProductData())
        dispatch(getAgencyDetails(user?.userId))
    }, []);
    const fetchAgencyData = async () => {
        try {
            const res = await axios.get(`/getAgencyByUserId/${user?.userId}`);
            if (res.data && res.data.data) {
                const agencyData = res.data.data;
                if (Array.isArray(agencyData) && agencyData.length === 0) {
                    await fetchAllAgencies();
                } else {
                    const formattedAgencyList = agencyData.map(agency => ({
                        label: agency.agencyName, // Displayed in dropdown
                        value: agency.agencyId,   // Used as the value for selection
                    }));
                    setAgencyList(formattedAgencyList);
                }
            } else {
                console.warn("Unexpected response format:", res);
            }
        } catch (error) {
            console.error("Error fetching agency data:", error);
        }
    };
    const fetchAllAgencies = async () => {
        try {
            const res = await axios.get('/getAllAgency');
            if (res.data && res.data.data) {
                const formattedAgencyList = res.data.data
                    .filter(agency => agency.status === "Y") // Filter agencies with status "Y"
                    .map(agency => ({
                        label: agency.agencyName,
                        value: agency.agencyId,
                    }));
                setAgencyList(formattedAgencyList);
            } else {
                console.warn("Unexpected response format:", res);
            }
        } catch (error) {
            console.error("Error fetching all agencies:", error);
        }
    };
    useEffect(() => {
        if (user?.userId) { // Fetch data when userId changes
            fetchAgencyData();
        }
    }, [user?.userId]);
    const backgroundColor = status ? 'green' : '#e55353';
    const textColor = 'white'; // White text for contrast
    const toggleDropdown = () => setDropdownOpen(prevState => !prevState);
    return (
        <Card className="mb-1" >
            <CardBody className="p-1" >
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-around" }}>
                        <Card style={{ display: "inline-block", textAlign: "center", border: "none", paddingTop: "3px", marginRight: "10px" }}>
                            <Button size="sm" outline color="primary" className="tabBtn no-pointer-events" >Online User:-  <b> {props?.liveTrackerCount?.onlineUser}</b></Button>
                        </Card>
                        <Card style={{ display: "inline-block", textAlign: "center", border: "none", paddingTop: "3px", marginRight: "10px" }}>
                            <Button size="sm" outline color="primary" className="tabBtn no-pointer-events">Offline User:- <b>{props?.liveTrackerCount?.offlineUser}</b></Button>
                        </Card>
                        <Card style={{ display: "inline-block", textAlign: "center", border: "none", paddingTop: "3px", marginRight: "10px" }}>
                            <Button size="sm" outline color="primary" className="tabBtn no-pointer-events">Scheduled Visit:- <b>{props?.liveTrackerCount?.scheduleVisit}</b></Button>
                        </Card>
                        <Card style={{ display: "inline-block", textAlign: "center", border: "none", paddingTop: "3px", marginRight: "10px" }}>
                            <Button size="sm" outline color="primary" className="tabBtn no-pointer-events">Completed Visit:- <b>{props?.liveTrackerCount?.completedVisit}</b></Button>
                        </Card>
                        <Card style={{ display: "inline-block", textAlign: "center", border: "none", paddingTop: "3px", marginRight: "10px" }}>
                            <Button size="sm" outline color="primary" className="tabBtn no-pointer-events">Rescheduled Visit:- <b>{props?.liveTrackerCount?.rescheduledVisit}</b></Button>
                        </Card>
                        <Card style={{ display: "inline-block", textAlign: "center", border: "none", paddingTop: "3px", marginRight: "10px" }}>
                            <Button size="sm" outline color="primary" className="tabBtn no-pointer-events">Cancelled Visit:- <b>{props?.liveTrackerCount?.rejectedVisit}</b></Button>
                        </Card>
                        <Card style={{ display: "inline-block", textAlign: "center", border: "none", paddingTop: "3px", marginRight: "10px" }}>
                            <Button size="sm" outline color="primary" className="tabBtn no-pointer-events">Pending Visit:-<b>{props?.liveTrackerCount?.pendingVisit}</b></Button>
                        </Card>
                    </div>
                    <div className='gap-2' style={{ display: "flex", justifyContent: "space-between" }}>
                        <div>
                            <Card
                                className='access_button'
                                style={{
                                    display: "inline-block",
                                    textAlign: "center",
                                    backgroundColor,
                                    border: `1px solid ${backgroundColor}`,
                                    color: textColor,
                                    borderRadius: '5px',
                                }}
                            >
                                <CardBody className='add_padd'>
                                    {/* Conditionally render Dropdown based on status */}
                                    {status !== null && status && (
                                        <Dropdown isOpen={dropdownOpen} toggle={toggleDropdown}>
                                            <DropdownToggle
                                                caret
                                                style={{
                                                    backgroundColor,
                                                    border: 'none',
                                                    color: textColor,
                                                    cursor: 'pointer'
                                                }}
                                            >
                                                <div className='inline'>
                                                    {status ? 'Tracking :- Enabled' : 'Tracking :- Disabled'}
                                                </div>
                                            </DropdownToggle>
                                            <DropdownMenu className='custom-dropdown-menu'>
                                                {roles.length > 0 ? (
                                                    roles.map((role) => (
                                                        <DropdownItem key={role.roleId} className='custom-dropdown-item'>
                                                            {role.roleName} - {role.roleCode} {/* Display roleName and roleCode */}
                                                        </DropdownItem>
                                                    ))
                                                ) : (
                                                    <DropdownItem disabled>No roles available</DropdownItem>
                                                )}
                                            </DropdownMenu>
                                        </Dropdown>
                                    )}
                                    {status !== null && !status && (
                                        <div className='tracking-disabled'>
                                            Tracking :- Disabled
                                        </div>
                                    )}
                                </CardBody>
                            </Card>
                        </div>
                        <div>
                            <Button
                                outline
                                color={"primary"}
                                size="sm"
                                className="text-left searchBtn"
                                onClick={() => setFilterDialog(!filterDialog)}
                            >
                                Filter <i className="bi bi-filter"></i>
                            </Button>
                        </div>
                        <div>
                            <Button
                                outline
                                color={"primary"}
                                size="sm"
                                className="text-left searchBtn"
                                onClick={handleRefresh}
                            >
                                <FaRedo className="refresh-icon" />
                            </Button>
                        </div>
                    </div>
                </div>
                <Formik
                    initialValues={{
                        zone: [], region: [], state: [], city: [], portfolio: [],
                        product: [], activity: [], user: [], agency: [], startDate: null,
                        startTime: null, endTime: null, usertype: '',
                        userList: [], agencyList: [], agencyUser: [],  // Add these fields to initialValues
                    }}
                    validationSchema={validationSchema}
                    onSubmit={handleSubmit}
                    onReset={(values, actions) => { }}
                >
                    {({
                        values,
                        errors,
                        touched,
                        handleChange,
                        handleBlur,
                        setFieldValue,
                        handleSubmit,
                        handleReset,
                        resetForm,
                    }) => {
                        const isFormValid = () => {
                            return (
                                (values.usertype[0] === 'U101' && (
                                    values.zone.length > 0 || values.region.length > 0 || values.state.length > 0 || values.city.length > 0 ||
                                    values.portfolio.length > 0 || values.product.length > 0 || values.activity.length > 0 ||
                                    values.userList.length > 0 || values.startDate == null || values.startTime == null || values.endTime == null
                                )) ||
                                (values.usertype[0] === 'U103' && (
                                    values.activity.length > 0 || values.startTime == null || values.endTime == null
                                ))
                            );
                        };
                        const handleUserTypeChange = (selectedOption) => {
                            const selectedValue = selectedOption ? selectedOption.value : null;
                            setFieldValue('usertype', selectedValue ? [selectedValue] : []); // Update as an array
                            setSelectedUserType(selectedValue);
                            setShowInternalUserList(selectedValue === 'U101');
                            setShowAgencyOptions(selectedValue === 'U103');
                        };
                        return (
                            <Form onSubmit={handleSubmit}>
                                <CardBody className="p-1">
                                    <Collapse isOpen={filterDialog}>
                                        <Card>
                                            <CardBody>
                                                <Row>
                                                    <Col lg={2} md={2} sm={12}>
                                                        <label className='form-label'>User Type</label>
                                                        <Select
                                                            className="custom-select"
                                                            styles={{
                                                                option: (provided) => ({
                                                                    ...provided,
                                                                    backgroundColor: 'transparent',
                                                                    color: '#000',
                                                                    ':hover': {
                                                                        backgroundColor: '#198cfb',
                                                                        color: 'white',
                                                                    },
                                                                }),
                                                                menu: (provided) => ({
                                                                    ...provided,
                                                                    zIndex: 9999, // Ensure dropdown is above other elements if necessary
                                                                }),
                                                            }}
                                                            options={[
                                                                { value: 'U101', label: 'Internal' },
                                                                { value: 'U103', label: 'Agency' }
                                                            ]}
                                                            onChange={handleUserTypeChange}
                                                            value={values.usertype.length > 0 ? { value: values.usertype[0], label: userTypeOptions.find(option => option.value === values.usertype[0])?.label } : null}
                                                            isSingle
                                                        />
                                                    </Col>
                                                    {values.usertype[0] === 'U101' && (
                                                        <>
                                                            <Col className='mb-3' lg={2} md={2} sm={12}>
                                                                <label className='form-label'>Zone</label>
                                                                <Select
                                                                    ids={"zone"} // Assign the id to the select element
                                                                    className="custom-select"
                                                                    options={activeZone}
                                                                    isMulti // Enable multiple selection
                                                                    onChange={selectedOptions => {
                                                                        const selectedValues = selectedOptions || [];
                                                                        setFieldValue('zone', selectedValues);
                                                                        const zoneIds = selectedValues.map(option => option.value);
                                                                        getAllRegionByZone(zoneIds);
                                                                        if (zoneIds.length === 0) {
                                                                            getAllRegion();
                                                                        }
                                                                    }}
                                                                    value={values.zone} // Bind selected value to Formik state
                                                                />
                                                            </Col>
                                                            <Col className='mb-3' lg={2} md={2} sm={12}>
                                                                <label className='form-label'>Region</label>
                                                                <Select
                                                                    ids={"region"}// Assign the id to the select element
                                                                    className="custom-select"
                                                                    options={activeRegion}
                                                                    isMulti // Enable multiple selection
                                                                    onChange={selectedOptions => {
                                                                        const selectedValues = selectedOptions || [];
                                                                        setFieldValue('region', selectedValues);
                                                                        const regionIds = selectedValues.map(option => option.value);
                                                                        getAllStateByRegion(regionIds);
                                                                        if (regionIds.length === 0) {
                                                                            getAllState();
                                                                        }
                                                                    }}
                                                                    value={values.region} // Bind selected value to Formik state
                                                                />
                                                            </Col>
                                                            <Col className='mb-3' lg={2} md={2} sm={12}>
                                                                <label className='form-label'>State</label>
                                                                <Select
                                                                    label={"State"} // Assign the id to the select element
                                                                    className="custom-select"
                                                                    isMulti
                                                                    options={activeState}
                                                                    onChange={(e) => {
                                                                        setCurrentCityPage(1)
                                                                        setFieldValue("state", e)
                                                                        getAllCityByState(e?.map(a => a?.stateId), true)
                                                                        if (e.length == 0) {
                                                                            getAllCities()
                                                                        }
                                                                    }}
                                                                    value={values.state} // Bind selected value to Formik state
                                                                />
                                                            </Col>
                                                            <Col className='mb-3' lg={2} md={2} sm={12}>
                                                                <label className='form-label'>City</label>
                                                                <Select
                                                                    id="city" // Assign the id to the select element
                                                                    className="custom-select"
                                                                    isMulti // Enable multiple selections
                                                                    options={activeCities}
                                                                    onChange={(selectedOptions) => {
                                                                        setCurrentPincodePage(1);
                                                                        const selectedValues = selectedOptions || [];
                                                                        setFieldValue("city", selectedValues);
                                                                        getAllPincodeByCity(selectedValues.map(option => option.value), true);
                                                                    }}
                                                                    value={values.city} // Bind selected value to Formik state
                                                                    onInputChange={(inputValue) => {
                                                                        setCityList(inputValue.toLowerCase().split(","));
                                                                    }}
                                                                    onMenuScrollToBottom={() => {
                                                                        if (currentCityPage < maxCityPages) {
                                                                            setCurrentCityPage(prev => prev + 1);
                                                                        }
                                                                    }}
                                                                />
                                                            </Col>
                                                            <Col className='mb-3' lg={2} md={2} sm={12}>
                                                                <label className='form-label'>Portfolio</label>
                                                                <Select
                                                                    id="portfolio"
                                                                    label={"Portfolio"} // Assign the id to the select element
                                                                    className="custom-select"
                                                                    isMulti // Enable multiple selections
                                                                    options={activeportfolio}
                                                                    onChange={(selectedOptions) => {
                                                                        setFieldValue("portfolio", selectedOptions || []);
                                                                    }}
                                                                    value={values.portfolio}
                                                                />
                                                            </Col>
                                                            <Col className='mb-3' lg={2} md={2} sm={12}>
                                                                <label className='form-label'>Product</label>
                                                                <Select
                                                                    id="product" // Assign the id to the select element
                                                                    className="custom-select"
                                                                    isMulti // Enable multiple selections if needed
                                                                    options={
                                                                        values.portfolio && values.portfolio.length > 0
                                                                            ? productOp.filter(a =>
                                                                                values.portfolio.some(p => p.value === a.portfolioId)
                                                                            )
                                                                            : productOp
                                                                    }
                                                                    onChange={(selectedOptions) => {
                                                                        setFieldValue("product", selectedOptions || []);
                                                                    }}
                                                                    value={values.product}
                                                                />
                                                            </Col>
                                                            <Col lg={2} md={2} sm={12}>
                                                                <FormGroup>
                                                                    <Label for="activity">Activity</Label>
                                                                    <Select
                                                                        styles={{
                                                                            option: (provided) => ({
                                                                                ...provided,
                                                                                backgroundColor: 'transparent',
                                                                                color: '#000',
                                                                                ':hover': {
                                                                                    backgroundColor: '#198cfb',
                                                                                    color: 'white',
                                                                                },
                                                                            }),
                                                                            menu: (provided) => ({
                                                                                ...provided,
                                                                                zIndex: 9999, // Ensure dropdown is above other elements if necessary
                                                                            }),
                                                                        }}
                                                                        isMulti
                                                                        options={activityOptions}
                                                                        closeMenuOnSelect={false}
                                                                        value={values.activity}
                                                                        onChange={(selectedOptions) => {
                                                                            setFieldValue("activity", selectedOptions);
                                                                        }}
                                                                    />
                                                                </FormGroup>
                                                            </Col>
                                                            <Col lg={2} md={2} sm={12}>
                                                                <label className='form-label'>User List</label>
                                                                <Select
                                                                    options={activeUserList}
                                                                    isMulti
                                                                    onChange={selectedOptions => {
                                                                        setFieldValue("userList", selectedOptions);
                                                                    }}
                                                                    value={values.userList}
                                                                    closeMenuOnSelect={false}
                                                                />
                                                            </Col>
                                                        </>
                                                    )}
                                                    {values.usertype[0] === 'U103' && (
                                                        <>
                                                            <Col lg={2} md={2} sm={12}>
                                                                <label className='form-label'>Agency List</label>
                                                                <Select
                                                                    options={agencyList}
                                                                    onChange={handleAgencyChange}
                                                                    closeMenuOnSelect={false} // Set value to match selected option
                                                                />
                                                            </Col>
                                                            <Col lg={2} md={2} sm={12}>
                                                                <label className='form-label'>Agency User</label>
                                                                <Select
                                                                    options={agencyInternalUser}
                                                                    isMulti
                                                                    onChange={selectedOptions => {
                                                                        setFieldValue("agencyUser", selectedOptions);
                                                                    }}
                                                                    value={values.agencyUser}
                                                                    closeMenuOnSelect={false}
                                                                />
                                                            </Col>
                                                            <Col lg={2} md={2} sm={12}>
                                                                <FormGroup>
                                                                    <Label for="activity">Activity</Label>
                                                                    <Select
                                                                        styles={{
                                                                            option: (provided) => ({
                                                                                ...provided,
                                                                                backgroundColor: 'transparent',
                                                                                color: '#000',
                                                                                ':hover': {
                                                                                    backgroundColor: '#198cfb',
                                                                                    color: 'white',
                                                                                },
                                                                            }),
                                                                            menu: (provided) => ({
                                                                                ...provided,
                                                                                zIndex: 9999, // Ensure dropdown is above other elements if necessary
                                                                            }),
                                                                        }}
                                                                        isMulti
                                                                        options={activityOptions}
                                                                        closeMenuOnSelect={false}
                                                                        value={values.activity}
                                                                        onChange={(selectedOptions) => {
                                                                            setFieldValue("activity", selectedOptions);
                                                                        }}
                                                                    />
                                                                </FormGroup>
                                                            </Col>
                                                        </>
                                                    )}
                                                    <Col lg={2} md={2} sm={12}>
                                                        <FormGroup>
                                                            <Label for="startDate" className="Field_label__3FkNk line-height-0">
                                                                Date
                                                            </Label>
                                                            <Calendar
                                                                className="startEndDate"
                                                                id="startDate"
                                                                value={startDate} // Should be a Date object
                                                                onChange={(e) => {
                                                                    setStartDate(e.value); // Make sure e.value is a Date object
                                                                    setFieldValue('startDate', e.value); // Update Formik state
                                                                }}
                                                                dateFormat="dd-mm-yy"
                                                                showIcon
                                                                placeholder="Select Date"
                                                                maxDate={moment().toDate()} // Set maxDate to today
                                                            />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col lg={2} md={2} sm={12}>
                                                        <FormGroup>
                                                            <Label className='Field_label__3FkNk' htmlFor="startTime">Start Time</Label>
                                                            <TimePicker
                                                                id="startTime"
                                                                value={startTime}
                                                                openClockOnFocus={false}
                                                                isOpen={false}
                                                                onChange={(time) => {
                                                                    setStartTime(time);
                                                                    setFieldValue('startTime', time); // Update Formik state
                                                                }}
                                                                format="hh:mm a" // AM/PM format
                                                                clearIcon={null}
                                                                clockIcon={null} // Optional: hides the clear icon
                                                            />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col lg={2} md={2} sm={12}>
                                                        <FormGroup>
                                                            <Label className='Field_label__3FkNk' htmlFor="endTime">End Time</Label>
                                                            <TimePicker
                                                                id="endTime"
                                                                value={endTime}
                                                                openClockOnFocus={false}
                                                                isOpen={false}
                                                                onChange={(time) => {
                                                                    setEndTime(time);
                                                                    setFieldValue('endTime', time); // Update Formik state
                                                                }}
                                                                clearIcon={null}
                                                                clockIcon={null} // Optional: hides the clear icon
                                                            />
                                                        </FormGroup>
                                                    </Col>
                                                    <div className="d-flex justify-content-between mt-2 mb-2">
                                                        <div className="d-flex justify-content-end">
                                                            <Button
                                                                className="me-1"
                                                                color="primary"
                                                                type="submit"
                                                                size="sm"
                                                            >
                                                                Search
                                                            </Button>
                                                            <Button
                                                                type="button"
                                                                color="danger"
                                                                onClick={async () => {
                                                                    resetForm();
                                                                    setFieldValue('usertype', []); // Reset user type
                                                                    const now = new Date();
                                                                    const currentDate = now.toISOString().split('T')[0]; // YYYY-MM-DD
                                                                    const formattedDate = new Date(currentDate);
                                                                    const currentTime = now.toTimeString().split(' ')[0].substring(0, 5);
                                                                    setStartDate(formattedDate); // Reset start date to current date
                                                                    setStartTime(currentTime); // Reset start time to current time
                                                                    setEndTime(currentTime); // Reset end time to current time
                                                                    try {
                                                                        dispatch(setLoader(true)); // Show loader
                                                                        const [liveTrackerResponse, userByFilterResponse] = await Promise.all([
                                                                            axios.post(`/getLiveTrackerDashboard/${user?.userId}`),
                                                                            axios.post(`/getUserByFilter/${user?.userId}`)
                                                                        ]);
                                                                        const liveTrackerData = liveTrackerResponse.data?.data;
                                                                        const filteredLiveTrackerData = {
                                                                            ...liveTrackerData,
                                                                            onlineUser: liveTrackerData?.onlineUser !== null ? liveTrackerData.onlineUser : 0,
                                                                            offlineUser: liveTrackerData?.offlineUser !== null ? liveTrackerData.offlineUser : 0
                                                                        };
                                                                        if (typeof props?.setAfterFilterLiveTrackerCount === 'function') {
                                                                            props.setAfterFilterLiveTrackerCount(filteredLiveTrackerData);
                                                                        }
                                                                        const userByFilterData = userByFilterResponse.data?.data;
                                                                        if (typeof props?.setUserByFilterData === 'function') {
                                                                            props.setUserByFilterData(userByFilterData);
                                                                        }
                                                                    } catch (error) {
                                                                        console.error('Error fetching data:', error);
                                                                    } finally {
                                                                        dispatch(setLoader(false)); // Hide loader
                                                                    }
                                                                    if (typeof props?.setIsFilter === 'function') {
                                                                        props.setIsFilter(true); // Set filter state to true
                                                                    }
                                                                }}
                                                                size="sm"
                                                            >
                                                                Clear
                                                            </Button>
                                                        </div>
                                                    </div>
                                                </Row>
                                            </CardBody>
                                        </Card>
                                    </Collapse>
                                </CardBody>
                            </Form>
                        );
                    }}
                </Formik>
            </CardBody>
        </Card>
    )
}
export default TrackingFilter