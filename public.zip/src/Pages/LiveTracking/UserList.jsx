import React, { useState, useEffect } from "react";
import { memo } from "react";
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import trackExport from "../../assets/images/trackerexport.png";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Table,
  TabContent,
  TabPane,
} from "reactstrap";
import { Timeline } from "primereact/timeline";
import {
  Accordion,
  AccordionBody,
  AccordionHeader,
  AccordionItem,
} from "reactstrap";
import track from "../../assets/images/Tracking.jpg";
import "./LiveTracking.css";
import { Link } from "react-router-dom";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import { mapDataByUserId } from "./LiveTrackingSlice";
const UserList = (props) => {
  const [map, setMap] = useState([]);
  const [hideDiv, setHideDiv] = useState(false);
  const dispatch = useDispatch();
  const [selectedUserType, setSelectedUserType] = useState('internal');
  const user = useSelector((state) => state.user.data);
  const userData = useSelector((state) => state.LiveTrackingSlice.userData);
  const { locationDetail, customizedOpposite, userDetail, customizedMarker, customizedContent, sharedValueStartTime, sharedValueCurrent, sharedValueEndTime } = props;
  const [openAccordionId, setOpenAccordionId] = useState(null);
  const [activeTab, setActiveTab] = useState("1");
  const handleUserTypeChange = (e) => {
    setSelectedUserType(e.target.value);
  };
  const convertTo24HourFormat = (time) => {
    const [timePart, modifier] = time.split(' ');
    let [hours, minutes] = timePart.split(':');

    if (modifier === 'PM' && hours !== '12') {
      hours = parseInt(hours, 10) + 12;
    } else if (modifier === 'AM' && hours === '12') {
      hours = '00';
    }
    return `${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}:00`;
  };
  const userTypeMap = {
    "internal": "U101",
    "external": "U103"
  };
  const filteredUserData = props?.userData?.filter(
    (item) => item.userType === userTypeMap[selectedUserType]
  );
  const toggle = (id) => {
    setOpenAccordionId(openAccordionId === id ? null : id);
  };
  const toggleTab = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };
  const handleStatus = () => {
    if (typeof props.setSwitchMode === 'function') {
      const newMode = !props.SwitchMode;
      props.setSwitchMode(newMode);
      props.setUserStatus(newMode ? "Online" : "Offline");
      setActiveTab(newMode ? "1" : "2");
    } else {
      console.error('setSwitchMode is not a function');
    }
  };
  useEffect(() => {
    handleStatus();
  }, []);
  const handleSingleUserExport = async (userId) => {
    const now = new Date(sharedValueCurrent);
    const startDate = new Date(now);
    startDate.setDate(now.getDate() + 1);
    const startTime = convertTo24HourFormat(sharedValueStartTime);
    const endTime = sharedValueEndTime.length === 5
      ? `${sharedValueEndTime}:00`
      : sharedValueEndTime;
    const endDate = new Date(now);
    endDate.setDate(now.getDate() + 1);
    const endDateString = endDate.toISOString().split('T')[0];
    const startDateString = startDate.toISOString().split('T')[0];
    const queryParams = new URLSearchParams({
      startDate: `${startDateString} ${startTime}`,
      endDate: `${endDateString} ${endTime}`
    }).toString();
    const url = `/getUserTrackingExport/${userId}?${queryParams}`;
    try {
      const response = await axios.get(url, {
        responseType: 'arraybuffer' // Ensure binary data is handled properly
      });
      const workbook = XLSX.read(new Uint8Array(response.data), { type: 'array' });
      const excelData = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, 'Tracker Report.xlsx');
    } catch (error) {
      console.error("Error fetching or exporting user tracking data:", error);
    }
  };
  const handleExport = async () => {
    try {
      // Construct query parameters
      const now = new Date(sharedValueCurrent);
      const startDate = new Date(now);
      startDate.setDate(now.getDate() + 1);
      const startTime = convertTo24HourFormat(sharedValueStartTime);
      const endTime = sharedValueEndTime.length === 5
        ? `${sharedValueEndTime}:00`
        : sharedValueEndTime;
      const endDate = new Date(now);
      endDate.setDate(now.getDate() + 1);
      const endDateString = endDate.toISOString().split('T')[0];
      const startDateString = startDate.toISOString().split('T')[0];
      const queryParams = new URLSearchParams({
        startDate: `${startDateString} ${startTime}`,
        endDate: `${endDateString} ${endTime}`
      }).toString();
      // Make the API call with query parameters
      const { data } = await axios.get(`/getLiveTrackingDashboardExport/${user?.userId}?${queryParams}`, {
        responseType: 'arraybuffer' // Assuming the API returns binary data
      });
      // Process and download the Excel file
      const workbook = XLSX.read(new Uint8Array(data), { type: 'array' });
      const excelData = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, 'Tracker Report.xlsx');
    } catch (error) {
      console.error('Error exporting data:', error);
    }
  };
  let particularTrack = () => {
    mapDataByUserId();
  };
  const logFirstLetters = (jobTitle) => {
    const words = jobTitle.split(" ");
    const firstLetters = words.map((word) => word.charAt(0));
    const result = firstLetters.join("");
    return result;
  };
  const onSubmit = async (userId) => {
    setHideDiv(true); // Hide the div when the button is clicked
    const payload = {
      userId: userId,
      date: new Date(),
      fromTime: "09-00",
      toTime: "22-00",
    };
    try {
      const response = await axios.post(`/mapDataByUserId`, payload);
      const mapData = response.data;
      setMap(mapData);
    } catch (error) {
      console.error("Error fetching map data:", error);
    }
  };
  const handleSingelUserExport = async (userId) => {
    const payload = {
      userId: userId,
      date: new Date(),
      fromTime: "09-00",
      toTime: "22-00",
    };
    try {
      const response = await axios.post(`/mapDataForExcelByUserId`, payload);
      console.log(response);
    } catch (error) {
      console.error("Error fetching map data:", error);
    }
  };
  const renderUserItem = (item, index) => (
    <Accordion
      open={openAccordionId === index ? "1" : ""} // Use an empty string instead of null
      key={index}
      toggle={() => toggle(index)}
    >
      <AccordionItem>
        <AccordionHeader targetId="1">{item?.fullName}</AccordionHeader>
        <AccordionBody accordionId="1">
          <Card className="m-1">
            <CardBody>
              <Table striped className="text-center activityHistory mb-0 b-0">
                <tbody>
                  <tr>
                    <td className="fw-bold">Name</td>
                    <td>{item?.fullName}</td>
                    <td className="fw-bold leftBorder">User ID</td>
                    <td>{item?.userName}</td>
                  </tr>
                  <tr>
                    <td className="fw-bold">Role</td>
                    <td>{item?.role}</td>
                    <td className="fw-bold leftBorder">Reporting Authority</td>
                    <td>{item?.reportingAuthority === "0" ? "Self" : item?.reportingAuthority}</td>
                  </tr>
                  {item?.userType === 'U103' && (
                    <tr>
                      <td className="fw-bold">Managed By</td>
                      <td>{item?.managedBy}</td>
                      <td className="fw-bold leftBorder">Agency Name</td>
                      <td>{item?.agencyName}</td>
                    </tr>
                  )}
                  <tr>
                    <td className="fw-bold">Status</td>
                    <td>
                      <b
                        style={{
                          color: item?.status === "Online" ? "green" : "red",
                        }}
                      >
                        {item?.status}
                      </b>
                    </td>
                    <td className="fw-bold leftBorder">
                      {item?.status === "Online" ? "Login Time" : "Logout Time"}
                    </td>
                    <td>{item?.status === "Online" ? item?.loginTime : item?.logoutTime}</td>
                  </tr>
                  {item?.status === "Online" ? (
                    <tr>
                      <td className="fw-bold leftBorder">Track</td>
                      <td>
                        <Link
                          to={{
                            pathname: `/live_tracking/${item?.userName}`,
                            state: {
                              userDetail: item,
                            },
                          }}
                        >
                          <img
                            src={track}
                            alt="Track"
                            onClick={() => onSubmit(item?.userId)}
                            style={{
                              width: "35px",
                              height: "35px",
                              cursor: "pointer",
                              borderRadius: "100%",
                              margin: "auto",
                            }}
                          />
                        </Link>
                      </td>
                    </tr>
                  ) : (
                    <tr>
                      <td className="fw-bold leftBorder">Tracker Export</td>
                      <td>
                        <img
                          onClick={() => handleSingleUserExport(item?.userId)}
                          src={trackExport}
                          alt="Track"
                          style={{
                            width: "35px",
                            height: "35px",
                            cursor: "pointer",
                            borderRadius: "100%",
                            margin: "auto",
                            backgroundColor: "#eee"
                          }}
                        />
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </AccordionBody>
      </AccordionItem>
    </Accordion>
  );
  return (
    <Card>
      <CardBody className="custom-card-body">
        {!locationDetail && !hideDiv && (
          <div className="gap-3" style={{ display: "flex", justifyContent: "flex-end" }}>
            <div>
              <select className="selectlayout" id="userTypeSelect" value={selectedUserType} onChange={handleUserTypeChange}>
                <option value="internal">Internal</option>
                <option value="external">Agency</option>
              </select>
            </div>
            <Button size="sm" outline color="primary" onClick={handleStatus} style={{ marginRight: "5px" }}>
              {props.SwitchMode ? "Offline" : "Online"}
            </Button>
            <Button
              size="sm"
              outline
              style={{
                background: "orange",
                color: "white",
                borderColor: "orange",
              }}
              onClick={handleExport}
            >
              Export
            </Button>
          </div>
        )}
        {locationDetail ? (
          <>
            <Card>
              <CardHeader className="bg-primary text-white flex justify-content-between align-items-center w-full">
                <div>
                  <span>
                    <p>{userDetail?.fullName ? userDetail?.fullName : "User"}</p>
                    <p className="text-xs text-gray-400">{userDetail?.role ? logFirstLetters(userDetail?.role) : "Role"}</p>
                  </span>
                </div>
                <div className="d-flex justify-content-end gap-2">
                  <div className="">
                    <Link
                      to="/live_Tracking"
                      className="btn rounded-0 hover-effect d-flex align-items-center justify-content-center"
                      style={{
                        textDecoration: 'none',
                        padding: '3px 10px',
                        color: '#ffffffde',
                        borderColor: '#ffffffde',
                        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)' // Added box shadow
                      }}
                    >
                      Back
                    </Link>
                  </div>
                  <div>
                    <Button
                      className="rounded-0"
                      size="sm"
                      outline
                      style={{
                        background: "orange",
                        color: "white",
                        borderColor: "orange",
                      }}
                      onClick={() => handleSingleUserExport(userDetail.userId)}
                    >
                      Tracker Report
                    </Button>
                  </div>
                </div>
              </CardHeader>
              {/* {console.log(locationDetail, 'vbhjvbjh')} */}
              <CardBody className="bg-blue-50">
                <Timeline
                  value={locationDetail}
                  opposite={customizedOpposite}
                  className="customized-timeline"
                  marker={customizedMarker}
                  content={customizedContent}
                />
              </CardBody>
            </Card>
          </>
        ) : (
          ""
        )}
        <TabContent activeTab={activeTab}>
          <TabPane tabId="1">
            {filteredUserData &&
              filteredUserData
                .filter((item) => item.status === "Offline")
                .map((item, index) => renderUserItem(item, index))}
          </TabPane>
          <TabPane tabId="2">
            {filteredUserData &&
              filteredUserData
                .filter((item) => item.status === "Online")
                .map((item, index) => renderUserItem(item, index))}
          </TabPane>
        </TabContent>
      </CardBody>
    </Card>
  );
};
export default memo(UserList);