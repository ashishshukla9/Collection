import { Formik } from "formik"
import { memo, useEffect, useMemo, useState } from "react"
import * as yup from "yup";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import { Button, Col, Form, FormGroup, Input, Row } from "reactstrap";
import Select from "react-select";
import Field from "../../../components/Field";
import { AMOUNT, NO_SPACE } from "../../../utils/regex";
import axios from "axios";
import styles from './Configuration.module.scss'
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";

const ConfigurationForm = (props) => {
    const ruleBodyRow = useMemo(() => ({
        id: 1,
        gridType: '',
        conditionType: '',
        condition1: '',
        condition2: '',
        value1: '',
        value2: '',
        payoutPercent: ''
    }))

    const user = useSelector(state => state?.user?.data)

    const dispatch=useDispatch()

    const isView = useMemo(() => props?.formType === "View", [])
    const isEdit = useMemo(() => props?.formType === "Edit", [])
    const incentiveTypeOptions = useMemo(() => [{ label: "Pay Out", value: "Pay Out" }], [])
    const payOutTypeOptions = useMemo(() => [{ label: "Internal", value: "Internal" }, { label: "Agency", value: "Agency" }], [])
    const payoutGridOptions = useMemo(() => [{ label: "ROR", value: "ROR" }], [])
    const conditionOptions = useMemo(() => [{ label: '>=', value: ">=" }, { label: '>', value: ">" }, { label: '<=', value: "<=" }, { label: '<', value: "<" }, { label: '=', value: "=" }, { label: '&&', value: "&&" }], [])
    const condition1Options = useMemo(() => [{ label: '>=', value: ">=" }, { label: '>', value: ">" }], [])
    const condition2Options = useMemo(() => [{ label: '<=', value: "<=" }, { label: '<', value: "<" }], [])

    const initialValues = {
        incConfigId: (isView || isEdit) ? props?.selectedData?.incConfigId : null,
        incentiveType: (isView || isEdit) ? props?.selectedData?.incentiveType : '',
        incentiveCode: (isView || isEdit) ? props?.selectedData?.incentiveCode : '',
        discription: (isView || isEdit) ? props?.selectedData?.discription : '',
        payoutType: (isView || isEdit) ? props?.selectedData?.payoutType : '',
        maxCap: (isView || isEdit) ? props?.selectedData?.maxCap : '',
        payoutGrid: (isView || isEdit) ? props?.selectedData?.payoutGrid : '',
        active: (isView || isEdit) ? props?.selectedData?.active : true,
        masterName: (isView || isEdit) ? props?.selectedData?.masterName : '',
        incentiveSlabs: (isView || isEdit) ? props?.selectedData?.incentiveSlabs?.length ? props?.selectedData?.incentiveSlabs : [ruleBodyRow] : [ruleBodyRow]
    }
    const validationSchema = yup.object().shape({
        incentiveType: yup.string().required("Required"),
        incentiveCode: yup.string().required("Required"),
        discription: yup.string().required("Required"),
        payoutType: yup.string().required("Required"),
        maxCap: yup.string().required("Required"),
        payoutGrid: yup.string().required("Required"),
        masterName: yup.string().required("Required")
    })

    const handleSubmit = async (values) => {
        try {
            const incentiveSlabs = values?.incentiveSlabs?.map(a => {
                if (a?.conditionType === "&&") {
                    return a
                } else {
                    return {
                        ...a,
                        condition1: a?.conditionType,
                        condition2: null,
                        value2: null
                    }
                }
            })
            const payload = {
                ...values,
                uid: user?.userId,
                incentiveSlabs
            }
            dispatch(setLoader(true))
            const res = await axios.post('/addIncentiveConfiguration', payload)
            dispatch(setLoader(false))
            if (res?.data?.messageKey) {
                props?.onSuccess()
                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            } else {
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                touched,
                handleSubmit,
                onSubmit,
                setFieldValue,
                handleBlur,
                handleChange,
                isSubmitting,
            }) => {
                const err = Object.keys(errors)[0];
                scrollToErrorMessage(isSubmitting, err);

                return (
                    <Form onSubmit={handleSubmit} autoComplete="off">
                        <Row>
                            <Col lg={6} md={6} sm={12}>
                                <Field
                                    isRequired
                                    label="Incentive Type"
                                    errorMessage={touched?.incentiveType && errors?.incentiveType}
                                >
                                    <Select
                                        name="incentiveType"
                                        classNamePrefix="react-select"
                                        menuPosition="fixed"
                                        isDisabled={isView}
                                        value={incentiveTypeOptions?.filter(a => a?.value === values?.incentiveType)}
                                        options={incentiveTypeOptions}
                                        onChange={(e) => {
                                            setFieldValue('incentiveType', e?.value)
                                        }}
                                        onBlur={handleBlur}
                                    />
                                </Field>
                            </Col>
                        </Row>
                        {values?.incentiveType !== "Pay In" &&
                            <>
                                <Row>
                                    <Col lg={6} md={6} sm={12}>
                                        <Field
                                            isRequired
                                            label="Incentive Code"
                                            errorMessage={touched?.incentiveCode && errors?.incentiveCode}
                                        >
                                            <Input
                                                bsSize="sm"
                                                value={values?.incentiveCode}
                                                onChange={(e)=>{
                                                    if(NO_SPACE.test(e?.target?.value) || e?.target?.value === ""){
                                                        setFieldValue('incentiveCode',e?.target?.value)
                                                    }
                                                }}
                                                name="incentiveCode"
                                                onBlur={handleBlur}
                                                disabled={isView || isEdit}
                                            />
                                        </Field>
                                    </Col>
                                    <Col lg={6} md={6} sm={12}>
                                        <Field
                                            isRequired
                                            label="Incentive Description"
                                            errorMessage={touched?.discription && errors?.discription}
                                        >
                                            <Input
                                                bsSize="sm"
                                                name="discription"
                                                value={values?.discription}
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                disabled={isView}
                                            />
                                        </Field>
                                    </Col>
                                    <Col lg={6} md={6} sm={12}>
                                        <Field
                                            isRequired
                                            label="Payout Type"
                                            errorMessage={touched?.payoutType && errors?.payoutType}
                                        >
                                            <Select
                                                isDisabled={isView}
                                                name="payoutType"
                                                value={payOutTypeOptions?.filter(a => a?.value === values?.payoutType)}
                                                options={payOutTypeOptions}
                                                classNamePrefix="react-select"
                                                menuPosition="fixed"
                                                onChange={(e) => {
                                                    setFieldValue('masterName', "")
                                                    setFieldValue('payoutType', e?.value)
                                                }}
                                                onBlur={handleBlur}
                                            />
                                        </Field>
                                    </Col>
                                    {values?.payoutType &&
                                        <Col lg={6} md={6} sm={12}>
                                            <Field
                                                isRequired
                                                label={values?.payoutType === "Internal" ? "Role" : values?.payoutType === "Agency" && "Agency"}
                                                errorMessage={touched?.masterName && errors?.masterName}
                                                isDisabled={isView}
                                            >
                                                <Select
                                                    isDisabled={isView}
                                                    name="masterName"
                                                    value={values?.payoutType === "Internal" ? props?.roleOptions?.filter(a => a?.value === values?.masterName) : values?.payoutType === "Agency" && props?.agencyOptions?.filter(a => a?.value?.toString() === values?.masterName?.toString())}
                                                    options={values?.payoutType === "Internal" ? props?.roleOptions : values?.payoutType === "Agency" && props?.agencyOptions}
                                                    classNamePrefix="react-select"
                                                    menuPosition="fixed"
                                                    onChange={(e) => {
                                                        setFieldValue('masterName', e?.value)
                                                    }}
                                                    onBlur={handleBlur}
                                                />
                                            </Field>
                                        </Col>
                                    }
                                    <Col lg={6} md={6} sm={12}>
                                        <Field
                                            isRequired
                                            label="Maximum Cap"
                                            errorMessage={touched?.maxCap && errors?.maxCap}
                                        >
                                            <Input
                                                bsSize="sm"
                                                name="maxCap"
                                                value={values?.maxCap}
                                                maxLength={19}
                                                onChange={e => {
                                                    const isDecimal = e?.target?.value?.includes('.')
                                                    const afterDecimalCount = isDecimal ? e.target.value.split('.')[1]?.length > 2 : false
                                                    if ((AMOUNT.test(e?.target?.value) || !e?.target?.value) && !afterDecimalCount) {
                                                        setFieldValue("maxCap", e?.target?.value);
                                                    }
                                                }}
                                                onBlur={handleBlur}
                                                disabled={isView}
                                            />
                                        </Field>
                                    </Col>
                                    <Col lg={6} md={6} sm={12}>
                                        <Field
                                            isRequired
                                            label="Payout Grid"
                                            errorMessage={touched?.payoutGrid && errors?.payoutGrid}
                                        >
                                            <Select
                                                isDisabled={isView}
                                                name="payoutGrid"
                                                value={payoutGridOptions?.filter(a => a?.value === values?.payoutGrid)}
                                                options={payoutGridOptions}
                                                classNamePrefix="react-select"
                                                menuPosition="fixed"
                                                onChange={(e) => {
                                                    setFieldValue('payoutGrid', e?.value)
                                                }}
                                                onBlur={handleBlur}
                                            />
                                        </Field>
                                    </Col>
                                    <Col>
                                        <Field label="Active">
                                            <FormGroup switch className="ms-2">
                                                <Input
                                                    type="switch"
                                                    name="active"
                                                    checked={values?.active}
                                                    onChange={(e)=>{
                                                        setFieldValue('active',e?.target?.checked)
                                                    }}
                                                />
                                            </FormGroup>
                                        </Field>
                                    </Col>
                                </Row>
                                <Row>
                                    <p>Rule Condition</p>
                                    <DataTable
                                        value={values?.incentiveSlabs}
                                        className="commonTable"
                                    >
                                        <Column
                                            header="Grid Type"
                                            headerClassName={styles?.mediumHeader}
                                            body={(rowData, i) => {
                                                return (
                                                    <Select
                                                        name={`incentiveSlabs.${i?.rowIndex}.gridType`}
                                                        classNamePrefix="react-select"
                                                        menuPosition="fixed"
                                                        isDisabled={isView}
                                                        value={payoutGridOptions?.filter(a => a?.value === values?.incentiveSlabs[i?.rowIndex]?.gridType)}
                                                        options={payoutGridOptions}
                                                        onChange={(e) => {
                                                            setFieldValue(`incentiveSlabs.${i?.rowIndex}.gridType`, e?.value)
                                                        }}
                                                        onBlur={handleBlur}
                                                    />
                                                )
                                            }}
                                        />
                                        <Column
                                            header="Condition"
                                            headerClassName={styles?.mediumHeader}
                                            body={(rowData, i) => {
                                                return (
                                                    <Select
                                                        name={`incentiveSlabs.${i?.rowIndex}.conditionType`}
                                                        classNamePrefix="react-select"
                                                        menuPosition="fixed"
                                                        isDisabled={isView}
                                                        value={conditionOptions?.filter(a => a?.value === values?.incentiveSlabs[i?.rowIndex]?.conditionType)}
                                                        options={conditionOptions}
                                                        onChange={(e) => {
                                                            setFieldValue(`incentiveSlabs.${i?.rowIndex}.conditionType`, e?.value)
                                                        }}
                                                        onBlur={handleBlur}
                                                    />
                                                )
                                            }}
                                        />
                                        <Column
                                            header="Value"
                                            body={(rowData, i) => {
                                                return (
                                                    <div className={styles?.ruleValuesCol}>
                                                        {rowData?.conditionType === "&&" &&
                                                            <Select
                                                                name={`incentiveSlabs.${i?.rowIndex}.condition1`}
                                                                classNamePrefix="react-select"
                                                                menuPosition="fixed"
                                                                isDisabled={isView}
                                                                value={condition1Options?.filter(a => a?.value === values?.incentiveSlabs[i?.rowIndex].condition1)}
                                                                options={condition1Options}
                                                                onChange={(e) => {
                                                                    setFieldValue(`incentiveSlabs.${i?.rowIndex}.condition1`, e?.value)
                                                                }}
                                                                onBlur={handleBlur}
                                                                className={styles?.smallHeader}
                                                            />
                                                        }
                                                        <Input
                                                            name={`incentiveSlabs.${i?.rowIndex}.value1`}
                                                            value={values?.incentiveSlabs[i?.rowIndex]?.value1}
                                                            onChange={(e) => {
                                                                const isDecimal = e?.target?.value?.includes('.')
                                                                const afterDecimalCount = isDecimal ? e.target.value.split('.')[1]?.length > 2 : false
                                                                if ((AMOUNT.test(e?.target?.value) || !e?.target?.value) && !afterDecimalCount) {
                                                                    setFieldValue(`incentiveSlabs.${i?.rowIndex}.value1`, e?.target?.value);
                                                                }
                                                            }}
                                                            size={'sm'}
                                                            className={styles?.smallHeader}
                                                            disabled={isView}
                                                        />
                                                        {rowData?.conditionType === "&&" &&
                                                            <>
                                                                <Select
                                                                    name={`incentiveSlabs.${i?.rowIndex}.condition2`}
                                                                    classNamePrefix="react-select"
                                                                    menuPosition="fixed"
                                                                    isDisabled={isView}
                                                                    value={condition2Options?.filter(a => a?.value === values?.incentiveSlabs[i?.rowIndex].condition2)}
                                                                    options={condition2Options}
                                                                    onChange={(e) => {
                                                                        setFieldValue(`incentiveSlabs.${i?.rowIndex}.condition2`, e?.value)
                                                                    }}
                                                                    onBlur={handleBlur}
                                                                    className={styles?.smallHeader}
                                                                />
                                                                <Input
                                                                    name={`incentiveSlabs.${i?.rowIndex}.value2`}
                                                                    value={values?.incentiveSlabs[i?.rowIndex]?.value2}
                                                                    onChange={(e) => {
                                                                        const isDecimal = e?.target?.value?.includes('.')
                                                                        const afterDecimalCount = isDecimal ? e.target.value.split('.')[1]?.length > 2 : false
                                                                        if ((AMOUNT.test(e?.target?.value) || !e?.target?.value) && !afterDecimalCount) {
                                                                            setFieldValue(`incentiveSlabs.${i?.rowIndex}.value2`, e?.target?.value);
                                                                        }
                                                                    }}
                                                                    size={'sm'}
                                                                    className={styles?.smallHeader}
                                                                    disabled={isView}
                                                                />
                                                            </>
                                                        }
                                                    </div>
                                                )
                                            }}
                                        />
                                        <Column
                                            header="Payout %"
                                            headerClassName={styles?.smallHeader}
                                            body={(rowData, i) => {
                                                return (
                                                    <Input
                                                        name={`incentiveSlabs.${i?.rowIndex}.payoutPercent`}
                                                        value={values?.incentiveSlabs[i?.rowIndex]?.payoutPercent}
                                                        onChange={(e) => {
                                                            const isDecimal = e?.target?.value?.includes('.')
                                                            const afterDecimalCount = isDecimal ? e.target.value.split('.')[1]?.length > 2 : false
                                                            if ((AMOUNT.test(e?.target?.value) || !e?.target?.value) && !afterDecimalCount) {
                                                                setFieldValue(`incentiveSlabs.${i?.rowIndex}.payoutPercent`, e?.target?.value);
                                                            }
                                                        }}
                                                        size={'sm'}
                                                        disabled={isView}
                                                    />
                                                )
                                            }}
                                        />
                                        {!isView &&
                                            <Column
                                                header="Action"
                                                headerClassName={styles?.smallHeader}
                                                body={(rowData, i) => {
                                                    return (
                                                        <div className={styles?.ruleActionButtonContainer}>
                                                            <Button
                                                                size="sm"
                                                                type="button"
                                                                color="danger"
                                                                className={styles?.ruleActionButton}
                                                                onClick={() => {
                                                                    if (values?.incentiveSlabs?.length > 1) {
                                                                        let duplicateValues = values?.incentiveSlabs
                                                                        duplicateValues.splice(i?.rowIndex, 1)
                                                                        setFieldValue('incentiveSlabs', duplicateValues)
                                                                    }
                                                                }}
                                                            >
                                                                -
                                                            </Button>
                                                            <Button
                                                                size="sm"
                                                                type="button"
                                                                className={styles?.ruleActionButton}
                                                                color="success"
                                                                onClick={() => {
                                                                    setFieldValue('incentiveSlabs', [...values?.incentiveSlabs, ruleBodyRow])
                                                                }}
                                                            >
                                                                +
                                                            </Button>
                                                        </div>
                                                    )
                                                }}
                                            />
                                        }
                                    </DataTable>
                                </Row>
                                {!isView &&
                                    <div className={styles?.formButtonGrp}>
                                        <Button
                                            size="sm"
                                            type="button"
                                            onClick={props?.onClose}
                                        >
                                            Close
                                        </Button>
                                        <Button
                                            size="sm"
                                            type="submit"
                                            color="primary"
                                        >
                                            Submit
                                        </Button>
                                    </div>
                                }
                            </>
                        }
                    </Form>
                )
            }}
        </Formik>
    )
}

export default memo(ConfigurationForm)