import { ButtonGroup, Card, CardBody, CardHeader, Container } from "reactstrap";
import { useEffect, useState } from "react";
import axios from "axios";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import SearchBarHeader from "../../../components/Header/SearchBarHeader";
import { Dialog } from "primereact/dialog";
import ConfigurationForm from "./ConfigurationForm";
import Swal from "sweetalert2";
import { useDispatch } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";

const Index = () => {
    const [visible, setVisible] = useState(false);
    const [formType, setFormType] = useState("")
    const [data, setData] = useState([])
    const [selectedData, setSelectedData] = useState({})
    const [roleOptions, setRoleOptions] = useState([])
    const [agencyOptions, setAgencyOptions] = useState([])

    const dispatch=useDispatch()

    const getAllIncentiveConfigration = async (val) => {
        try {
            const url = val ? `/getIncConfigList/${val}` : '/getIncConfigList'
            dispatch(setLoader(true))
            const res = await axios.get(url)
            dispatch(setLoader(false))
            setData(res?.data?.response)
        } catch (error) {
            dispatch(setLoader(false))
        }
    }

    const onCreateClick = () => {
        setVisible(true)
        setFormType("Create")
        setSelectedData({})
    }
    const onCloseForm = () => {
        setVisible(false)
        setFormType("")
        setSelectedData({})
    }

    const onSuccess = () => {
        getAllIncentiveConfigration()
        onCloseForm()
    }

    const onHandleAction = async (btnType, rowData) => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getIncentiveConfigById/${rowData?.incConfigId}`)
            dispatch(setLoader(false))
            if (res?.data?.messageKey) {
                setVisible(true)
                setFormType(btnType)
                setSelectedData(res?.data?.response)
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    useEffect(() => {
        getAllIncentiveConfigration()
    }, [])

    useEffect(() => {
        const getOptionsAPI = async () => {
            try {
                dispatch(setLoader(true))
                const roleRes = await axios.get('/getAllRoles')
                dispatch(setLoader(false))
                const roleOp = roleRes?.data?.response?.map(a => ({
                    label: a?.roleName,
                    value: a?.roleCode
                }))
                setRoleOptions(roleOp || [])

                dispatch(setLoader(true))
                const agencyRes = await axios.get('/getAllAgencies')
                dispatch(setLoader(false))
                const agencyOp = agencyRes?.data?.response?.map(a => ({
                    label: a?.agencyName,
                    value: a?.agencyId
                }))
                setAgencyOptions(agencyOp || [])
            } catch (error) {
                dispatch(setLoader(false))
            }
        }

        getOptionsAPI()
    }, [])

    return (
        <Container fluid className="d-flex flex-column flex-grow-1 p-0">
            <SearchBarHeader
                permission={true}
                onClick={onCreateClick}
                getAllAPI={getAllIncentiveConfigration}
                serachAPI={getAllIncentiveConfigration}
            />
            <Card className="flex-grow-1 mb-1">
                <CardHeader className="p-2">Incentive Configuration</CardHeader>
                <CardBody className="tableCardBody p-1">
                    <DataTable
                        value={data}
                        paginator
                        className="commonTable"
                        rows={10}
                        rowsPerPageOptions={[10, 20, 40, 80]}
                        tableStyle={{ minWidth: "50rem" }}
                        sortMode="multiple"
                        removableSort
                    >
                        <Column field="incentiveCode" header="Incentive Code" />
                        <Column field="incentiveType" header="Incentive Type" />
                        <Column field="discription" header="Description" />
                        <Column
                            field="masterName"
                            header="Master Name"
                            body={rowData => {
                                return (
                                    <span>
                                        {rowData?.payoutType === "Internal" ? roleOptions?.filter(a => a?.value === rowData?.masterName)[0]?.value : agencyOptions?.filter(a => a?.value?.toString() === rowData?.masterName?.toString())[0]?.label}
                                    </span>
                                )
                            }}
                        />
                        <Column field="maxCap" header=" Max Cap" />
                        <Column field="payoutGrid" header="Payout Grid" />
                        <Column field="payoutType" header="Payout Type" />
                        <Column
                            field="isActive"
                            header="Status"
                            body={(rowData) =>
                                rowData?.active ? (<b className="text-success">Active</b>) : (<b className="text-secondary">Inactive</b>)
                            }
                        // style={{ width: "25%" }}
                        />
                        <Column
                            body={(rowData) => (
                                <ButtonGroup>
                                    <i
                                        className="bi bi-eye-fill text-primary"
                                        style={{ cursor: "pointer" }}
                                        onClick={() => onHandleAction('View', rowData)}
                                    ></i>
                                    <i
                                        className="bi bi-pencil-square text-danger"
                                        style={{ cursor: "pointer" }}
                                        onClick={() => onHandleAction('Edit', rowData)}
                                    ></i>
                                </ButtonGroup>
                            )}
                            header="Actions"
                        />
                    </DataTable>
                </CardBody>
            </Card>

            {visible &&
                <Dialog
                    header={`${formType} Incentive Configuration`}
                    visible={visible}
                    onHide={onCloseForm}
                    style={{
                        width: "80vw",
                    }}
                >
                    <ConfigurationForm
                        onClose={onCloseForm}
                        formType={formType}
                        selectedData={selectedData}
                        onSuccess={onSuccess}
                        roleOptions={roleOptions}
                        agencyOptions={agencyOptions}
                    />
                </Dialog>
            }
        </Container>
    )
}

export default Index;