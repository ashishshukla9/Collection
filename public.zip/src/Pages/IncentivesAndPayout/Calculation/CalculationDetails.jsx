import { memo, useEffect, useMemo, useState } from "react"
import styles from './Calculation.module.scss'
import CalculationGraph from "./CalculationGraph"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import axios from "axios"
import Swal from "sweetalert2"
import { Input } from "reactstrap"
import { useDispatch } from "react-redux"
import { setLoader } from "../../../reducer/globalReducer"
const CalculationDetails = (props) => {
    const { data } = props
    const [decendentUsers, setDecendentUsers] = useState(data?.decendentUsers)
    const [search, setSearch] = useState('')
    const overallTotalPercentage = useMemo(() => (data?.total?.collectedAmount / data?.total?.allocatedPos) * 100, [data])
    const ownTotalPercentage = useMemo(() => (data?.ownTotal?.collectedAmount / data?.ownTotal?.allocatedPos) * 100, [data])
    const teamTotalPercentage = useMemo(() => (data?.allocatedTotal?.collectedAmount / data?.allocatedTotal?.allocatedPos) * 100, [data])
    const dispatch = useDispatch()
    const onClickUser = async (singleData) => {
        // if (!props?.userIds?.includes(singleData?.userId)) {
        dispatch(setLoader(true))
        try {
            const params = props?.params
            const res = await axios.get(`/getIncentiveCalculationByUserId/${singleData?.userId}`, { params })
            dispatch(setLoader(false))
            if (res?.data?.messageKey) {
                props?.onSuccess(res?.data?.response, singleData)
            } else {
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
        // }
    }
    const onSearchUser = (e) => {
        setSearch(e?.target?.value)
    }
    useEffect(() => {
        const searchAPI = setTimeout(() => {
            const api = async () => {
                if (search.length) {
                    try {
                        const params = props?.params
                        dispatch(setLoader(true))
                        const res = await axios.get(`/getDecenderListBySearch/${data?.id}/${search}`, { params })
                        dispatch(setLoader(false))
                        if (res?.data?.messageKey) {
                            setDecendentUsers(res?.data?.response)
                        }
                    } catch (error) {
                        dispatch(setLoader(false))
                        Swal.fire({
                            position: "top-end",
                            icon: "error",
                            title: `${error?.message}`,
                            showConfirmButton: false,
                            toast: true,
                            timer: 3000,
                        });
                    }
                } else {
                    setDecendentUsers([...data?.decendentUsers])
                }
            }
            api()
        }, 1000)
        return (() => {
            clearTimeout(searchAPI)
        })
    }, [search])
    useEffect(() => {
        setDecendentUsers(data?.decendentUsers)
    }, [data?.decendentUsers])
    return (
        <div className={styles?.box} key={data?.id}>
            <div className={styles?.graphContainer}>
                {(decendentUsers?.length > 0 && overallTotalPercentage) ?
                    <CalculationGraph
                        graphType="Doughnut"
                        header="Overall Total"
                        percentage={overallTotalPercentage}
                        amountDetails={data?.total}
                        data={{
                            labels: ['Collected Amount', 'Not Collected Amount'],
                            datasets: [{
                                data: [overallTotalPercentage, 100 - overallTotalPercentage],
                                backgroundColor: ['rgb(54, 162, 235)', '#d3d3d3'],
                                hoverOffset: 4
                            }]
                        }}
                    /> : ''
                }
                {(Object.keys(data?.ownTotal)?.length > 0 && ownTotalPercentage) ?
                    <CalculationGraph
                        graphType="Doughnut"
                        header="Own Total"
                        percentage={ownTotalPercentage}
                        amountDetails={data?.ownTotal}
                        data={{
                            labels: ['Collected Amount', 'Not Collected Amount'],
                            datasets: [{
                                data: [ownTotalPercentage, 100 - ownTotalPercentage],
                                backgroundColor: ['rgb(54, 162, 235)', '#d3d3d3'],
                                hoverOffset: 4
                            }]
                        }}
                    /> : ''
                }
                {(decendentUsers?.length > 0 && teamTotalPercentage) ?
                    <CalculationGraph
                        graphType="Doughnut"
                        header="Team Total"
                        percentage={teamTotalPercentage}
                        amountDetails={data?.allocatedTotal}
                        data={{
                            labels: ['Collected Amount', 'Not Collected Amount'],
                            datasets: [{
                                data: [teamTotalPercentage, 100 - teamTotalPercentage],
                                backgroundColor: ['rgb(54, 162, 235)', '#d3d3d3'],
                                hoverOffset: 4
                            }]
                        }}
                    /> : ''
                }
            </div>
            {data?.ownLenderIncentives?.length > 0 &&
                <DataTable
                    value={data?.ownLenderIncentives}
                    header="Own Lender Incentives"
                    size={"small"}
                    removableSort
                    className="d-flex flex-column flex-grow-1 casesTable"
                >
                    <Column
                        header="Lender Name"
                        field="lenderName"
                    />
                    <Column
                        header="Allocated POS"
                        body={rowData => {
                            return (
                                <span>
                                    ₹ {rowData?.allocatedPos?.toString()?.includes('.') ? rowData?.allocatedPos?.toFixed(2) : rowData?.allocatedPos}
                                </span>
                            )
                        }}
                        field="allocatedPos"
                    />
                    <Column
                        header="Collected Amount"
                        body={rowData => {
                            return (
                                <span>
                                    ₹ {rowData?.collectedAmount?.toString()?.includes('.') ? rowData?.collectedAmount?.toFixed(2) : rowData?.collectedAmount}
                                </span>
                            )
                        }}
                        field="collectedAmount"
                    />
                    <Column
                        header="Incentive Amount"
                        body={rowData => {
                            return (
                                <span>
                                    ₹ {rowData?.incentiveAmount?.toString()?.includes('.') ? rowData?.incentiveAmount?.toFixed(2) : rowData?.incentiveAmount}
                                </span>
                            )
                        }}
                        field="incentiveAmount"
                    />
                    <Column
                        header="Incentive Slab"
                        body={rowData => {
                            return (
                                <span>
                                    {rowData?.incentiveSlab?.toString()?.includes('.') ? rowData?.incentiveSlab?.toFixed(2) : rowData?.incentiveSlab} %
                                </span>
                            )
                        }}
                        field="incentiveSlab"
                    />
                    <Column
                        header="ROR"
                        body={rowData => {
                            return (
                                <span>
                                    {rowData?.ror?.toString()?.includes('.') ? rowData?.ror?.toFixed(2) : rowData?.ror} %
                                </span>
                            )
                        }}
                        field="ror"
                    />
                </DataTable>
            }
            {data?.allocatedLenderIncentives?.length > 0 &&
                <DataTable
                    value={data?.allocatedLenderIncentives}
                    header="Allocated Lender Incentives"
                    size={"small"}
                    removableSort
                    className="d-flex flex-column flex-grow-1 casesTable"
                >
                    <Column
                        header="Lender Name"
                        field="lenderName"
                    />
                    <Column
                        header="Allocated POS"
                        body={rowData => {
                            return (
                                <span>
                                    ₹ {rowData?.allocatedPos?.toString()?.includes('.') ? rowData?.allocatedPos?.toFixed(2) : rowData?.allocatedPos}
                                </span>
                            )
                        }}
                        field="allocatedPos"
                    />
                    <Column
                        header="Collected Amount"
                        body={rowData => {
                            return (
                                <span>
                                    ₹ {rowData?.collectedAmount?.toString()?.includes('.') ? rowData?.collectedAmount?.toFixed(2) : rowData?.collectedAmount}
                                </span>
                            )
                        }}
                        field="collectedAmount"
                    />
                    <Column
                        header="Incentive Amount"
                        body={rowData => {
                            return (
                                <span>
                                    ₹ {rowData?.incentiveAmount?.toString()?.includes('.') ? rowData?.incentiveAmount?.toFixed(2) : rowData?.incentiveAmount}
                                </span>
                            )
                        }}
                        field="incentiveAmount"
                    />
                    <Column
                        header="Incentive Slab"
                        body={rowData => {
                            return (
                                <span>
                                    {rowData?.incentiveSlab?.toString()?.includes('.') ? rowData?.incentiveSlab?.toFixed(2) : rowData?.incentiveSlab} %
                                </span>
                            )
                        }}
                        field="incentiveSlab"
                    />
                    <Column
                        header="ROR"
                        body={rowData => {
                            return (
                                <span>
                                    {rowData?.ror?.toString()?.includes('.') ? rowData?.ror?.toFixed(2) : rowData?.ror} %
                                </span>
                            )
                        }}
                        field="ror"
                    />
                </DataTable>
            }
            {decendentUsers?.length > 0 &&
                <div className={styles?.tableContainer}>
                    <div className={styles?.headerContainer}>
                        <p className={styles?.header}>Decendent Users</p>
                        <Input
                            type="text"
                            size={'sm'}
                            onChange={onSearchUser}
                            placeholder="search"
                            className={styles?.searchBox}
                            value={search}
                        />
                    </div>
                    <div className={styles?.tableData}>
                        {decendentUsers?.map((a, i) => {
                            return (
                                <span>
                                    {i + 1}.
                                    <span
                                        className={styles?.userName}
                                        onClick={() => onClickUser(a)}
                                    >
                                        {a?.firstName} {a?.lastName}
                                    </span>
                                </span>
                            )
                        })}
                    </div>
                </div>
            }
            {!props?.lastIndex && <hr></hr>}
        </div>
    )
}
export default memo(CalculationDetails)