import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  Container,
  Button,
  Input,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import CreateRoles from "./CreateRoles";
import {
  getAllRole,
  setSelected,
  searchRole,
} from "./store";
import { getAllProfile } from "../Profile/store";
import SearchBarHeader from "../../components/Header/SearchBarHeader";

export default function Role({ access }) {
  const [createModal, setCreateModal] = useState(false);
  const [type, setType] = useState("");
  const user = useSelector((state) => state.user.data);
  const profileList = useSelector((state) => state.profile.list);

  const navigate = useNavigate();
  const { list, selected } = useSelector((state) => state.role);

  const dispatch = useDispatch();

  const onSuccess = () => {
    setCreateModal(false)
    setType("")
    dispatch(getAllRole());
  }

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);
  // console.log(user, 'DataGettingdd')

  useEffect(() => {
    (type === "Edit" || type === "Create") && dispatch(getAllProfile());
  }, [type]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data)=> dispatch(searchRole(data))}
        getAllAPI={()=>dispatch(getAllRole())}
        onClick={()=>{
          dispatch(setSelected(null))
          setCreateModal(!createModal);
          setType("Create");
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={list}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="roleCode" header="Role Code" sortable></Column>
            <Column field="roleName" header="Role Name" sortable></Column>
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData.isActive === "Y" ? (
                  <b>
                    <span className="text-success">Active</span>
                  </b>
                ) : (
                  <b>
                    {" "}
                    <span className="text-secondary">Inactive</span>
                  </b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        dispatch(setSelected(rowData));
                        setCreateModal(!createModal);
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setCreateModal(!createModal);
                        dispatch(setSelected(rowData));
                        setType("Edit");
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i className="bi bi-trash" style={{ cursor: "pointer" }} /> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header={`${type} Role Details`}
        visible={createModal}
        style={{ width: "60vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <CreateRoles
          rowData={selected}
          type={type}
          profileList={profileList}
          onSuccess={onSuccess}
          cancelModal={setCreateModal}
        />
      </Dialog>
    </Container>
  );
}
