import {
  CardBody,
  Card,
  Row,
  Form,
  Col,
  Label,
  Input,
  Button,
} from "reactstrap";
import { Formik, ErrorMessage } from "formik";
import * as yup from "yup";
import axios from "axios";
import Swal from "sweetalert2";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import { useEffect, useState } from "react";
import { NUMBER_ONLY } from "../../../utils/regex";
import { useDispatch } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";

const Lock_Policy = () => {
  const [lockID, setLockID] = useState();
  const [initialValues, setInitialValues] = useState({
    accLockEnabled: "",
    accLockThreshold: "",
    accLockDuration: "",
    maxInActivePeriod: "",
    loginSessionTimeout:""
  });

  const dispatch=useDispatch()

  const validation = yup.object({
    accLockEnabled: yup.string().required("Required"),
    accLockThreshold: yup.string().required("Required"),
    accLockDuration: yup.string().required("Required"),
    maxInActivePeriod: yup.string().required("Required"),
    loginSessionTimeout: yup.string().test({
      name: 'loginSessionTimeout',
      message: 'Timeout value is more than 2',
      test:(value,context) => value >= 3
    }).required("Required")
  });

  const getLockup = async () => {
    try {
      dispatch(setLoader(true))
      await axios.get("/GetLockoutPolicy").then((res) => {
        dispatch(setLoader(false))
        setLockID(res?.data?.data?.id);
        setInitialValues({
          accLockEnabled: res.data.data?.accLockEnabled,
          accLockThreshold: res.data.data?.accLockThreshold,
          accLockDuration: res.data.data?.accLockDuration,
          maxInActivePeriod: res.data.data?.maxInActivePeriod,
          loginSessionTimeout: res?.data?.data?.loginSessionTimeout
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  const addLockup = async (values, { resetForm }) => {
    const payload = {
      accLockEnabled: values.accLockEnabled,
      accLockThreshold: values.accLockThreshold,
      accLockDuration: values.accLockDuration,
      maxInActivePeriod: values.maxInActivePeriod,
      loginSessionTimeout: values.loginSessionTimeout,
      id: lockID || "",
    };

    try {
      dispatch(setLoader(true))
      await axios.post("/addLockoutPolicy", payload).then((res) => {
        dispatch(setLoader(false))
        if (res?.data?.msgKey === "Success") {
          resetForm({
            values: {
              accLockEnabled: "",
              accLockThreshold: "",
              accLockDuration: "",
              maxInActivePeriod: "",
              loginSessionTimeout: ""
            },
          });

          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });

          setTimeout(()=>{
            getLockup()
          },[1000])
        }
        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  useEffect(() => {
    getLockup();
  }, []);
  return (
    <>
      <h5>
        <b>Lockout Policy</b>
      </h5>
      <text>
        Account Lockout policy setting are designed to protect accounts in your
        organization by mitingating the threat of brute force guessing of
        account passwords. Account Lockout policy settings enable account
        lockout and control how
      </text>
      <Card>
        <CardBody>
          <Row>
            <Formik
              enableReinitialize={true}
              initialValues={initialValues}
              validationSchema={validation}
              onSubmit={addLockup}
            >
              {({
                values,
                errors,
                handleChange,
                handleBlur,
                touched,
                handleSubmit,
                setFieldValue,
                setFieldError,
                isSubmitting,
              }) => {
                const err = Object.keys(errors)[0];
                scrollToErrorMessage(isSubmitting, err);
                return (
                  <Form onSubmit={handleSubmit}>
                    <Card className="p-3 w-60">
                      <CardBody>
                        <Row>
                          <h5>
                            <b>Timeout Settings</b>
                          </h5>
                          <hr />
                        </Row>
                        <Row>
                          <Col lg={2}>
                            <Label>Account Lockout enable</Label>
                          </Col>

                          <Col lg={6} md={6} sm={12}>
                            {" "}
                            <Input
                              type="checkbox"
                              id="accLockEnabled"
                              checked={values.accLockEnabled === true}
                              onChange={(e) => {
                                setFieldValue(
                                  "accLockEnabled",
                                  e.target.checked ? true : false
                                );
                              }}
                              onBlur={handleBlur}
                              invalid={
                                touched.accLockEnabled &&
                                Boolean(errors.accLockEnabled)
                              }
                            />
                            <ErrorMessage
                              name="accLockEnabled"
                              render={(msg) => (
                                <div className="text-danger">{msg}</div>
                              )}
                            />
                          </Col>
                        </Row>
                        <Row className="mt-3">
                          <Col lg={2} md={6} sm={12}>
                            <Label>Account locked threshold</Label>
                          </Col>

                          <Col lg={6} md={6} sm={12}>
                            {" "}
                            <Input
                              bsSize="sm"
                              type="text"
                              id="accLockThreshold"
                              placeholder="Account locked threshold"
                              value={values.accLockThreshold}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.accLockThreshold &&
                                Boolean(errors.accLockThreshold)
                              }
                            />
                            <ErrorMessage
                              name="accLockThreshold"
                              render={(msg) => (
                                <div className="text-danger">{msg}</div>
                              )}
                            />
                          </Col>
                        </Row>

                        <Row className="mt-3">
                          <Col lg={2} md={6} sm={12}>
                            <Label>Account lockout duration</Label>
                          </Col>

                          <Col lg={6} md={6} sm={12}>
                            {" "}
                            <Input
                              bsSize="sm"
                              type="text"
                              id="accLockDuration"
                              placeholder="Account lockout duration"
                              value={values.accLockDuration}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.accLockDuration &&
                                Boolean(errors.accLockDuration)
                              }
                            />
                            <ErrorMessage
                              name="accLockDuration"
                              render={(msg) => (
                                <div className="text-danger">{msg}</div>
                              )}
                            />
                          </Col>
                        </Row>

                        <Row className="mt-3">
                          <Col lg={2} md={6} sm={12}>
                            <Label>Maximum inactive period for user</Label>
                          </Col>

                          <Col lg={6} md={6} sm={12}>
                            <Input
                              bsSize="sm"
                              type="text"
                              id="maxInActivePeriod"
                              placeholder="Maximum inactive period for user"
                              value={values.maxInActivePeriod}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.maxInActivePeriod &&
                                Boolean(errors.maxInActivePeriod)
                              }
                            />
                            <ErrorMessage
                              name="maxInActivePeriod"
                              render={(msg) => (
                                <div className="text-danger">{msg}</div>
                              )}
                            />
                          </Col>
                        </Row>
                        <Row className="mt-3">
                          <Col lg={2} md={6} sm={12}>
                            <Label>Login Session Timeout<span>(Enter in minutes)</span></Label>
                          </Col>

                          <Col lg={6} md={6} sm={12}>
                            <Input
                              bsSize="sm"
                              type="text"
                              id="loginSessionTimeout"
                              placeholder="Login Session Timeout"
                              value={values?.loginSessionTimeout}
                              onChange={(e)=>{
                                if(NUMBER_ONLY.test(e?.target?.value) || !e?.target?.value){
                                  setFieldValue('loginSessionTimeout',e?.target?.value)
                                }
                              }}
                              onBlur={handleBlur}
                              invalid={
                                touched.loginSessionTimeout &&
                                Boolean(errors?.loginSessionTimeout)
                              }
                            />
                            <ErrorMessage
                              name="loginSessionTimeout"
                              render={(msg) => (
                                <div className="text-danger">{msg}</div>
                              )}
                            />
                          </Col>
                        </Row>

                        {/* <Row className="mt-2">
                          <h5>
                            <b>Unloack Accounts</b>
                          </h5>
                          <hr />
                        </Row> */}

                        {/* <Row >
                          <Col lg={2} md={6} sm={12}>
                            <Label>Enable CAPYCHA to unlock accounts</Label>
                          </Col>

                          <Col lg={10} md={6} sm={12}>
                            <Input type="checkbox" />
                          </Col>
                        </Row> */}

                        <Row>
                          <Col
                            className="d-flex justify-content-end mt-3"
                            lg={8}
                            md={6}
                            sm={12}
                          >
                            <Button
                              size="sm"
                              type="submit"
                              style={{ color: "white" }}
                              color="primary"
                            >
                              Save
                            </Button>
                          </Col>
                        </Row>
                      </CardBody>
                    </Card>
                  </Form>
                );
              }}
            </Formik>
          </Row>
        </CardBody>
      </Card>
    </>
  );
};
export default Lock_Policy;
