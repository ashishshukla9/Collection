import {
  CardBody,
  Card,
  Row,
  Form,
  Col,
  Label,
  Input,
  Button,
} from "reactstrap";
import { Formik, ErrorMessage } from "formik";
import * as yup from "yup";
import { useEffect, useState } from "react";
import Select, { components } from "react-select";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import Swal from "sweetalert2";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";
const Audit_settings = () => {
  const [submit, setSubmit] = useState(false);
  const [initialValues, setInitialValues] = useState({
    fileType: "",
    maxSize: "",
  });
  const user = useSelector((state) => state.user.data);
  const dispatch=useDispatch()

  const validation = yup.object({
    fileType: yup
      .string()
      .trim()
      .required("Required")
      .matches(
        // /^[a-zA-Z0-9;]*$/,
        /^[a-zA-Z0-9; ]+$/,
        "Input must contain only alphanumeric characters and semicolons."
      ),
    maxSize: yup.number().required("Required"),
  });

  const getUploadSettings = async () => {
    try {
      dispatch(setLoader(true))
      await axios.get("/getUploadSetting").then((res) => {
        // console.log("geting upload settings", res.data.data);
        setInitialValues({
          fileType: res.data.data.fileType,
          maxSize: res.data.data.maxSize,
        });
      });
      dispatch(setLoader(false))
    } catch (error) {
      dispatch(setLoader(false))}
  };
  const addUploadSettings = async (values, { resetForm }) => {
    const payload = {
      fileType: values.fileType,
      maxSize: values.maxSize,
      uid: user?.userId,
      active: true,
      submit: submit,
    };
    try {
      dispatch(setLoader(true))
      await axios.post("/addUploadSetting", payload).then((res) => {
        dispatch(setLoader(false))
        // console.log("add upload settings respose", res);

        if (res?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          resetForm({
            values: {
              fileType: "",
              maxSize: "",
            },
          });
          getUploadSettings();
        }
        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  useEffect(() => {
    getUploadSettings();
  }, []);

  return (
    <>
      <Row>
        <h5>
          <b>Audit Settings</b>
        </h5>
        <br />
        <text>
          Establishing audit policy is an important facent of
          security.Monitoring the creation or modification of accounts gives you
          a way to track potential security problem
        </text>
      </Row>
      <Row>
        <Formik
          enableReinitialize={true}
          initialValues={initialValues}
          validationSchema={validation}
          onSubmit={addUploadSettings}
        >
          {({
            values,
            errors,
            handleChange,
            handleBlur,
            touched,
            handleSubmit,
            setFieldValue,
            setFieldError,
            isSubmitting,
          }) => {
            const err = Object.keys(errors)[0];
            scrollToErrorMessage(isSubmitting, err);
            return (
              <Form onSubmit={handleSubmit}>
                <Card className="p-3">
                  <CardBody>
                    <h6>
                      <b>Audit Logon Event</b>
                    </h6>
                    <hr />
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Success</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Failure</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <br />
                    <h6>
                      <b>Audit Account Management</b>
                    </h6>
                    <hr />
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Success</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Failure</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <br />
                    <h6>
                      <b>Audit Business Management</b>
                    </h6>
                    <hr />
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Success</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Failure</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <br />
                    <h6>
                      <b>Audit Switch Profile</b>
                    </h6>
                    <hr />
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Success</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Failure</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <br />
                    <h6>
                      <b>Audit Configuration Changes in Audit Tracker</b>
                    </h6>
                    <hr />
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Success</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Failure</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <br />
                    <h6>
                      <b>Audit Batch Management</b>
                    </h6>
                    <hr />
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Success</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Failure</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <div className="d-flex justify-content-end  p-3">
                        <Button
                          size="sm"
                          type="submit"
                          onMouseOver={() => setSubmit(false)}
                          style={{ color: "white" }}
                        >
                          Save
                        </Button>
                     
                      </div>
                    </Row>
                  </CardBody>
                </Card>
              </Form>
            );
          }}
        </Formik>
      </Row>
    </>
  );
};

export default Audit_settings;
