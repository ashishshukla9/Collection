import {
  Button,
  ButtonGroup,
  Card,
  CardBody,
  Col,
  Container,
  Form,
  FormFeedback,
  FormGroup,
  Input,
  Label,
  Row,
  Table,
} from "reactstrap";
import { Formik, ErrorMessage } from "formik";
import { useEffect, useState } from "react";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import * as yup from "yup";
import Select, { components } from "react-select";
import cx from "classnames";
import Swal from "sweetalert2";
import axios from "axios";
import { useDispatch } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";

const SmsSettings = () => {
  const [submit, setSubmit] = useState(false);
  const [uploadID, setUploadID] = useState();
  const [initialValues, setInitialValues] = useState({
    implementationType: "",
    sid: "",
    httpUrl: "",
    apiKey: "",
    contentType: "",
    sender: "",
  });
  const dispatch=useDispatch()
  const validation = yup.object({
    implementationType: yup.object().required("Required"),
    httpUrl: yup.string().required("Required"),
    apiKey: yup.string().required("Required"),
    contentType: yup.string().required("Required"),
    sid: yup.string().required("Required"),
    sender: yup.string().required("Required"),
  });

  const selectImplementation = [
    { label: "HTTP", value: "HTTP" },
    { label: "HTTPS", value: "HTTPS" },
  ];

  const getSmsSettings = async () => {
    try {
      dispatch(setLoader(true))
      await axios.get("/getSmsPolicy").then((res) => {
        dispatch(setLoader(false))
        setUploadID(res?.data?.data?.id);
        setInitialValues({
          implementationType: {
            label: `${res.data.data.implementationType}`,
            value: `${res.data.data.implementationType}`,
          },

          sid: res.data.data.sid,
          httpUrl: res.data.data.httpUrl,
          apiKey: res.data.data.apiKey,
          contentType: res.data.data.contentType,
          sender: res.data.data.sender,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  const addSmsSettings = async (values, { resetForm }) => {
    const payload = {
      implementationType: values.implementationType?.value,
      sid: values.sid,
      httpUrl: values.httpUrl,
      apiKey: values.apiKey,
      contentType: values.contentType,
      sender: values.sender,
      id: uploadID || "",
    };
    try {
      dispatch(setLoader(true))
      await axios.post("/addSmsPolicy", payload).then((res) => {
        dispatch(setLoader(false))
        if (res?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          resetForm({
            values: {
              implementationType: "",
              sid: "",
              httpUrl: "",
              apiKey: "",
              contentType: "",
              sender: "",
            },
          });
        }

        setTimeout(()=>{
          getSmsSettings();
        },[1000])
       
        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  useEffect(() => {
    getSmsSettings();
  }, []);
  return (
    <>
      <Row>
        <h5>
          <b>SMS Settings</b>
        </h5>
        <br />
        <text>SMS gateway for sending SMS from the application</text>
      </Row>

      <Row>
        <Formik
          enableReinitialize={true}
          initialValues={initialValues}
          validationSchema={validation}
          onSubmit={addSmsSettings}
        >
          {({
            values,
            errors,
            handleChange,
            handleBlur,
            touched,
            handleSubmit,
            setFieldValue,
            setFieldError,
            isSubmitting,
          }) => {
            const err = Object.keys(errors)[0];
            scrollToErrorMessage(isSubmitting, err);
            return (
              <Form onSubmit={handleSubmit}>
                <Card className="mb-3 p-4">
                  <CardBody>
                    <Row>
                      <Col lg={2} md={6} sm={12}>
                        <Label> Select Implementation Type</Label>
                      </Col>
                      <Col lg={4} md={6} sm={12}>
                        <Select
                          id="implementationType"
                          inputId="implementationType"
                          placeholder="Select Implementation Type"
                          options={selectImplementation}
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}
                          value={values.implementationType}
                          onChange={(e) => {
                            setFieldValue("implementationType", e);
                          }}
                          className={cx({
                            abc:
                              touched.implementationType &&
                              Boolean(errors.implementationType),
                          })}
                          onBlur={handleBlur}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />

                        <ErrorMessage
                          name="implementationType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>HTTP URL</Label>
                      </Col>

                      <Col lg={4} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="httpUrl"
                          placeholder="Tamplate Type"
                          value={values.httpUrl}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.httpUrl && Boolean(errors.httpUrl)}
                        />
                        <ErrorMessage
                          name="httpUrl"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>SID</Label>
                      </Col>

                      <Col lg={4} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="sid"
                          placeholder="sid"
                          value={values.sid}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.sid && Boolean(errors.sid)}
                        />
                        <ErrorMessage
                          name="sid"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Sender</Label>
                      </Col>

                      <Col lg={4} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="sender"
                          placeholder="sender"
                          value={values.sender}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.sender && Boolean(errors.sender)}
                        />
                        <ErrorMessage
                          name="sender"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>ApiKey</Label>
                      </Col>

                      <Col lg={4} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="apiKey"
                          placeholder="ApiKey"
                          value={values.apiKey}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.apiKey && Boolean(errors.apiKey)}
                        />
                        <ErrorMessage
                          name="apiKey"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Content Type</Label>
                      </Col>

                      <Col lg={4} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="contentType"
                          placeholder="Content Type"
                          value={values.contentType}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={
                            touched.contentType && Boolean(errors.contentType)
                          }
                        />
                        <ErrorMessage
                          name="contentType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col
                        lg={6}
                        md={6}
                        sm={12}
                        className="d-flex justify-content-end gap-3 p-3"
                      >
                        <Button
                          size="sm"
                          type="submit"
                          color="primary"
                          onMouseOver={() => setSubmit(false)}
                          style={{ color: "white" }}
                        >
                          Save
                        </Button>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>

                {/* <h5>
                  <b>Logon Details</b>
                </h5>
                <Card className="p-4 mt-1">
                  <Row>
                    <Col lg={2} md={6} sm={12}>
                      Server Require Authentication
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input type="checkbox" />
                    </Col>
                  </Row>
                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      User Name
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder="User Name"
                        bsSize="sm"
                        onBlur={handleBlur}
                        invalid={
                          touched.templateName && Boolean(errors.templateName)
                        }
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Password
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input
                        type="password"
                        placeholder="Password"
                        bsSize="sm"
                        onBlur={handleBlur}
                        invalid={
                          touched.templateName && Boolean(errors.templateName)
                        }
                      />
                    </Col>
                  </Row>
                </Card> */}
              </Form>
            );
          }}
        </Formik>
      </Row>
    </>
  );
};
export default SmsSettings;
