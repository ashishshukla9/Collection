import {
  CardBody,
  Card,
  Row,
  Form,
  Col,
  Label,
  Input,
  Button,
} from "reactstrap";
import { Formik, ErrorMessage } from "formik";
import * as yup from "yup";
import { useEffect, useState } from "react";
import Select, { components } from "react-select";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import Swal from "sweetalert2";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";
const Log = () => {
  const [submit, setSubmit] = useState(false);
  const [initialValues, setInitialValues] = useState({
    fileType: "",
    maxSize: "",
  });

  const dispatch=useDispatch()
  const user = useSelector((state) => state.user.data);
  const validation = yup.object({
    fileType: yup
      .string()
      .trim()
      .required("Required")
      .matches(
        // /^[a-zA-Z0-9;]*$/,
        /^[a-zA-Z0-9; ]+$/,
        "Input must contain only alphanumeric characters and semicolons."
      ),
    maxSize: yup.number().required("Required"),
  });

  const getUploadSettings = async () => {
    try {
      dispatch(setLoader(true))
      await axios.get("/getUploadSetting").then((res) => {
        setInitialValues({
          fileType: res.data.data.fileType,
          maxSize: res.data.data.maxSize,
        });
      });
      dispatch(setLoader(false))
    } catch (error) {
      dispatch(setLoader(false))}
  };
  const addUploadSettings = async (values, { resetForm }) => {
    const payload = {
      fileType: values.fileType,
      maxSize: values.maxSize,
      uid: user?.userId,
      active: true,
      submit: submit,
    };
    try {
      dispatch(setLoader(true))
      await axios.post("/addUploadSetting", payload).then((res) => {
        dispatch(setLoader(false))
        if (res?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          resetForm({
            values: {
              fileType: "",
              maxSize: "",
            },
          });
          getUploadSettings();
        }
        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  useEffect(() => {
    getUploadSettings();
  }, []);

  return (
    <>
      <Row>
        <h5>
          <b>Log Settings</b>
        </h5>
        <br />
        <text>
          Application records server error information in error logs.specify the
          error logs settings , includeing whethere to genrerate log messages in
          apache format.Apatche is the standard format and mechanism for
          correlating the diagnostics messages from components.
        </text>
      </Row>
      <Row>
        <Formik
          enableReinitialize={true}
          initialValues={initialValues}
          validationSchema={validation}
          onSubmit={addUploadSettings}
        >
          {({
            values,
            errors,
            handleChange,
            handleBlur,
            touched,
            handleSubmit,
            setFieldValue,
            setFieldError,
            isSubmitting,
          }) => {
            const err = Object.keys(errors)[0];
            scrollToErrorMessage(isSubmitting, err);
            return (
              <Form onSubmit={handleSubmit}>
                <Card className="p-3">
                  <CardBody>
                    <h6>
                      <b>General</b>
                    </h6>
                    <hr />
                    <Row>
                      <Col lg={2}>
                        <Label>Enable trace logging</Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="checkbox"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="pdf; doc; csv; xlsx; png"
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Log level</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="maxSize"
                          placeholder="Log level"
                          value={values.maxSize}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.maxSize && Boolean(errors.maxSize)}
                        />
                        <ErrorMessage
                          name="maxSize"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Log File/Directory</Label>
                      </Col>

                      <Col lg={10} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="maxSize"
                          placeholder="Log File/Directory"
                          value={values.maxSize}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.maxSize && Boolean(errors.maxSize)}
                        />
                        <ErrorMessage
                          name="maxSize"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <br />
                    <h6>
                      <b>Size Based Rotation Policy</b>
                    </h6>
                    <hr />
                    <Row>
                      <Col lg={2}>
                        <Label>Maximum log file size (MB)</Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="text"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="Maximum log file size"
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={2}>
                        <Label>Maximum files to retain</Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="text"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="Maximum files to retain"
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <br />
                    <h6>
                      <b>Log Format</b>
                    </h6>
                    <hr />
                    <Row>
                      <Col lg={2}>
                        <Label>Log Format Pattern</Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="text"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="Log Format Pattern"
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <br />
                    <h6>
                      <b>User Trace Logs</b>
                    </h6>
                    <hr />
                    <p>
                      User this setting to capture HTTP into user wise trace
                      logs.if you enable tracing .you may want the trace logs to
                      go to a certain location. Additionally , you may set the
                      maximum size of the log files and how many such log files
                      to retain . Note:User wise trace log will be created for
                      users who are enabled for tracing.{" "}
                    </p>
                    <br/>
                    <Row>
                      <Col lg={2}>
                        <Label>Enable user trace logs</Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="checkbox"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="Log Format Pattern"
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={2}>
                        <Label>Log directory</Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="text"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="Log directory"
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={2}>
                        <Label>Maximum log file size (MB) </Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="text"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="Maximum log file size "
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={2}>
                        <Label>Maximum files to retain </Label>
                      </Col>
                      <Col lg={10} md={6} sm={12}>
                        <Input
                          type="text"
                          value={values.fileType}
                          id="fileType"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.fileType && Boolean(errors.fileType)}
                          placeholder="Maximum files to retain "
                        />
                        <ErrorMessage
                          name="fileType"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <div className="d-flex justify-content-end gap-3 p-3">
                        <Button
                          size="sm"
                          type="submit"
                          onMouseOver={() => setSubmit(false)}
                          style={{ color: "white" }}
                        >
                          Save
                        </Button>
                      </div>
                    </Row>
                  </CardBody>
                </Card>
              </Form>
            );
          }}
        </Formik>
      </Row>
    </>
  );
};

export default Log;
