import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import axios from "axios";
import { saveAs } from "file-saver";
import { useEffect, useState } from "react";
import { Button, CardBody, Card, Col, Row, Input, FormGroup } from "reactstrap";
import Swal from "sweetalert2";
import React, { useRef } from "react";
import CustomField from "../../components/Field";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";

const ReconciliationTable = ({ list, isUploadDisabled, date, searchLanID, selectedLAN }) => {
  const [isChecked, setIsChecked] = useState(false);
  const [data, setData] = useState(list);
  const fileInputRef = useRef(null);
  const user = useSelector((state) => state.user.data);

  const dispatch=useDispatch()
  const handleFileUploadButton = () => {
    fileInputRef.current.click();
  };
  const headerStyle = {
    position: "sticky",
    top: 0,
    zIndex: 0, // Ensure header stays above the table content
    backgroundColor: "#fff", // Optional: Adds background color
  };

  useEffect(() => {
    setData(list);
  }, [list]);

  const callExport = async () => {
    try {
      await axios
        .post(`/reconciliationPreviewExport`, data, {
          responseType: "arraybuffer",
        })
        .then((response) => {
          const blob = new Blob([response.data], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });
          saveAs(blob, `recon_${list[0]?.lan}_${list[0]?.collectedDate}.xlsx`);
        });
    } catch (error) {
      console.log(error);
    }
  };

  const handleFileUpload = async (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      const params = {
        lan: selectedLAN?.length ? selectedLAN?.map(a=>a?.value)?.join(',') : searchLanID?.map(a=>a?.value)?.join(','),
        date: date
      }
      try {
        const formData = new FormData();
        formData.append("file", selectedFile);

        await axios
          .post("/getReconciliationPreviewCheck", formData, { params })
          .then((response) => {
            setData(response.data.data);

            if (response?.data?.msgKey === "Success") {
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${response.data.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
            Swal.fire({
              position: "top-end",
              icon: response?.data?.msgKey === "Failure" ? "error" : "success",
              title: `${response.data.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          });
      } catch (error) { }
    }
  };
  const updateRecon = () => {
    const payload = data?.map((a) => ({
      ...a,
      uid: user?.userId,
    }));

    try {
      dispatch(setLoader(true))
      axios.post("/addAllReconciliation", payload).then((response) => {
        dispatch(setLoader(false))
        if (response?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{response.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
        Swal.fire({
          position: "top-end",
          icon: response?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${response.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  return (
    <>
      <Card>
        <CardBody>
          <DataTable
            className="commonTable"
            rowsPerPageOptions={[10, 25, 50, 100]}
            rows={10}
            value={data}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
            style={headerStyle}
          >
            <Column field="lan" header="LAN ID" sortable></Column>
            <Column field="pos" header="POS" sortable></Column>
            <Column field="tos" header="TOS" sortable></Column>
            <Column
              field="amountCollected"
              header="Amount Collected"
              sortable
            ></Column>
            {/* <Column
              field="actualAmount"
              header="Actual Amount"
              sortable
            ></Column> */}
            <Column field="lenderId" header="Lender ID" sortable></Column>
            <Column field="assignedUser" header="Assign To" sortable></Column>
          </DataTable>
          <div className="d-flex justify-content-end m-1">
            <Button
              size="sm"
              type="button"
              color="primary"
              onClick={callExport}
            >
              {" "}
              Export
            </Button>
          </div>
        </CardBody>
      </Card>

      <br />
      <Card>
        <CardBody>
          <Row className="w-80 mt-2">
            <Col sm="6" md="4">
              <CustomField isRequired label="Reconciliation Require?">
                <FormGroup switch>
                  <Input
                    type="switch"
                    onChange={(e) => {
                      setIsChecked(e.target.checked ? true : false);
                    }}
                  />
                </FormGroup>
              </CustomField>
            </Col>
            <Col>

              <Button
                size="sm"
                color="primary"
                style={{ color: "white" }}
                onClick={handleFileUploadButton}
                disabled={isUploadDisabled}
              >
                Upload File
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: "none" }}
                  onChange={handleFileUpload}

                />
              </Button>


              {/* <p>{file.name}</p> */}
            </Col>
            <Col>
              <Button
                size="sm"
                type="button"
                color="primary"
                style={{ color: "white" }}
                disabled={!isChecked}
                onClick={updateRecon}
              >
                {" "}
                Update Recon
              </Button>
            </Col>

            <Col>
              <Button
                size="sm"
                type="button"
                color="primary"
                style={{ color: "white" }}
                onClick={callExport}
                disabled={!isChecked}
              >
                {" "}
                Download Final Data
              </Button>
            </Col>
          </Row>
        </CardBody>
      </Card>
    </>
  );
};
export default ReconciliationTable;
