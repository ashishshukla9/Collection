import React from "react";
import { Container } from "reactstrap";

export default function Error404() {
  return (
    <Container className="text-center text-danger p-5">
      <div>
        <i className="bi bi-x-circle display-5"></i>
        <p className="display-3">{atob('NDA0')}</p>
      </div>
      <p className="h1">{atob("UmVxdWVzdGVkIFVSTCBOb3QgRm91bmQh")}</p>
    </Container>
  );
}
