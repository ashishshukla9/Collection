import React, { useEffect, useState, useRef } from "react";

import { Card, CardBody, CardHeader, Progress } from "reactstrap";
import Swal from "sweetalert2";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import axios from "axios";
import { Menu } from "primereact/menu";
import { MdOutlineFileDownloadDone } from "react-icons/md";
import { TiCancelOutline } from "react-icons/ti";
import { BsFileSpreadsheetFill } from "react-icons/bs";
import { downloadCases, downloadExcel1 } from "../../utils/GenerateExcel";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment/moment";
import { useNavigate } from "react-router-dom";
import { baseUrl } from "../../App.config";
import ProgressBar from '../../components/ProgressBar'
import { extendToken } from "../../utils/commonFun";
import { setAction, setLoader } from "../../reducer/globalReducer";
import * as XLSX from 'xlsx';
import { downloadExcel } from "../../utils/GenerateExcel";
import { saveAs } from "file-saver";

export default function BulkDealocation(props) {
    const [statsData, setStatsData] = useState([]);
    const [fileUploadProgress, setFileUploadProgress] = useState({
        percentage: 0,
        uploadedData: 0,
        totalData: 0,
        stage: ''
    })
    const [loaderProgress, setLoaderProgress] = useState(false)
    const fileDetails = useRef(null);
    const downloadMenu = useRef(null);
    const user = useSelector((state) => state.user.data);

    const navigate = useNavigate();

    const dispatch = useDispatch()
    const loginSessionTimeout = useSelector((state) => state?.global?.loginSessionTimeout)

    const getData = async () => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get("/getDeallocationStat")
            dispatch(setLoader(false))
            setStatsData(res?.data?.response)
            if (fileUploadProgress?.percentage !== 0) {
                setFileUploadProgress({
                    percentage: 0,
                    uploadedData: 0,
                    totalData: 0,
                    stage: ''
                })
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    const downloadSuccessCases = (bucketId) => {
        axios
            .get(`/getAllSuccessData/${bucketId}`)
            .then(({ data }) => {
                downloadCases(data.data, "SuccessCases.xlsx");
                Swal.fire({
                    toast: true,
                    position: "top-end",
                    icon: "success",
                    title: "File downloaded.",
                    showConfirmButton: false,
                    timer: 4000,
                    timerProgressBar: true,
                    background: "#125120b5",
                    color: "#fff",
                    iconColor: "#fff",
                });
            })
            .catch((error) => {
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            });
    };

    const downloadFile = async (batchId, type) => {
        try {
            const res = await axios.post(`/getExportDeallocationByBatchId/${batchId}?reportType=${type}`, null, { responseType: "arraybuffer" })
            const blob = new Blob([res.data], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            });
            saveAs(blob, `${type}Cases.xlsx`);
        } catch (error) {
            console.log(error)
        }
    }

    const downloadFailedCases = (bucketId) => {
        axios
            .get(`/getAllErrorData/${bucketId}`)
            .then(({ data }) => {
                downloadCases(data.data, "FailedCases.xlsx");
                Swal.fire({
                    toast: true,
                    position: "top-end",
                    icon: "success",
                    title: "File downloaded.",
                    showConfirmButton: false,
                    timer: 4000,
                    timerProgressBar: true,
                    background: "#125120b5",
                    color: "#fff",
                    iconColor: "#fff",
                });
            })
            .catch((error) => {
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            });
    };

    const downloadOriginalCases = (bucketId) => {
        axios
            .get(`/getAllOriginalData/${bucketId}`)
            .then(({ data }) => {
                
                downloadCases(data.data, "OriginalData.xlsx");
                Swal.fire({
                    toast: true,
                    position: "top-end",
                    icon: "success",
                    title: "File downloaded.",
                    showConfirmButton: false,
                    timer: 4000,
                    timerProgressBar: true,
                    background: "#125120b5",
                    color: "#fff",
                    iconColor: "#fff",
                });
            })
            .catch((error) => {
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            });
    };

    const items = [
        {
            label: "Download Options",
            items: [
                {
                    label: "Original File",
                    icon: <BsFileSpreadsheetFill className="text-primary" />,
                    command: (e) => {
                        let fileBucketId = downloadMenu.current.getTarget().id;
                        // downloadOriginalCases(fileBucketId);
                        downloadFile(fileBucketId, "Original")
                    },
                },
                {
                    label: "Success Cases",
                    icon: <MdOutlineFileDownloadDone className="text-success" />,
                    command: () => {
                        let fileBucketId = downloadMenu.current.getTarget().id;
                        downloadFile(fileBucketId, "Success");
                    },
                },
                {
                    label: "Failed Cases",
                    icon: <TiCancelOutline className="text-danger" />,
                    command: () => {
                        let fileBucketId = downloadMenu.current.getTarget().id;
                        downloadFile(fileBucketId, "Failure");
                    },
                },
            ],
        },
    ];

    const handleClick = (event) => {
        fileDetails.current.click();
    };

    const handleChange = async (e) => {
        Swal.fire({
            title: "Are you sure?",
            text: "You want to upload file!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, Upload it!",
        }).then(async (res) => {
            if (res?.isConfirmed) {
                axios.defaults.timeout = 1000 * 60 * 60 * 8
                axios.defaults.timeoutErrorMessage = 'timeout'
                const formData = new FormData()
                const fileFormData = new FormData()
                fileFormData.append("file", e?.target?.files[0])

                try {
                    setLoaderProgress(true)
                    const eventSource = new EventSource(baseUrl() + '/progressDeallocation')
                    let guidValues = null;


                    eventSource.addEventListener('Deallocation_ID', async (event) => {
                        guidValues = JSON.parse(event?.data)

                        formData.append('guid', guidValues)
                        eventSource.addEventListener('message', (event) => {
                            const result = event?.data?.split('\n')
                            if (result[4] === "uploading" ? fileUploadProgress?.percentage !== parseInt(result[0]) : result[4] === "validating" ? fileUploadProgress?.percentage !== parseInt(result[3]) : false) {
                                setFileUploadProgress({
                                    percentage: result[4] === "uploading" ? parseInt(result[0]) : result[4] === "validating" ? parseInt((result[3] / result[2]) * 100) : result[0],
                                    uploadedData: result[4] === "uploading" ? parseInt(result[1]) : result[4] === "validating" ? parseInt(result[3]) : parseInt(result[1]),
                                    totalData: parseInt(result[2]),
                                    stage: result[4]
                                })
                            }
                            if (parseInt(result[0]) === 100) {
                                eventSource.close()
                                setLoaderProgress(false)
                            }
                        })
                        //api call
                        const timer = setInterval(() => {
                            dispatch(setAction(1))
                            extendToken(loginSessionTimeout)
                        }, 60000)
                        const res = await axios.post(`/deallocateFromMisUpload/${user?.userId}`, fileFormData, {
                            params: {
                                guid: guidValues
                            },
                            headers: {
                                "Content-Type": "multipart/form-data"
                            }
                        })

                        clearInterval(timer)
                        setLoaderProgress(false)
                        getData()

                        Swal.fire({
                            toast: true,
                            position: "top-end",
                            icon: "success",
                            title: "File is Selected to upload",
                            showConfirmButton: false,
                            timer: 4000,
                            timerProgressBar: true,
                            background: "#125120b5",
                            color: "#fff",
                            iconColor: "#fff",
                        });
                    })

                    eventSource.onerror = (event) => {
                        if (event?.target?.readyState === EventSource.CLOSED) {
                        }
                        setLoaderProgress(false)
                        setFileUploadProgress({
                            percentage: 0,
                            uploadedData: 0,
                            totalData: 0,
                            stage: ''
                        })
                        eventSource.close()
                    }

                    eventSource.onopen = () => {
                    }
                } catch (error) {
                    Swal.fire({
                        position: "top-end",
                        icon: "error",
                        title: `${error.message}`,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                }

            }
        })
    }


    useEffect(() => {
        if (user?.masterRole[props?.access] === null) {
            navigate("/dashboard");
        }
    }, [user]);

    useEffect(() => {
        getData()
    }, []);
    return (
        <main id="main">


            {/* case upload */}

            {/* {(user?.masterRole?.bulkdealocation=== "F" || user?.masterRole?.bulkdealocation=== "E") && */}
            <>
                <div style={mainDive} className="form-control">
                    <div
                        style={{
                            display: "flex",
                            flexDirection: "row",
                            background: "#3c4b64",
                            borderRadius: "20px",
                        }}
                        className="bulkUpload"
                        onClick={() => handleClick()}
                    >
                        <input
                            ref={fileDetails}
                            type="file"
                            style={{ display: "none" }}
                            onChange={(e) => handleChange(e)}
                        />
                        <div className="ml-5 btn form-control">
                            <h3 style={{ fontWeight: 600, color: "#fff", paddingTop: "5px" }}>
                                Bulk Deallocation
                            </h3>
                        </div>
                        <div
                            className="mr-5  btn "
                            style={{ fontSize: "2rem", color: "#fff" }}
                        >
                            <i className="bi bi-folder2-open w-100  "></i>
                        </div>
                    </div>
                </div>
            </>
            {/* } */}
            <div
                className="p-3 mb-2 text-primary"
                style={{
                    background: "rgba(0,29,86,0.2)",
                    color: "#155724",
                    borderColor: "#c3e6cd",
                    textAlign: "center",
                    fontSize: "1rem",
                    borderRadius: "10px",
                }}
            >
                Download Sample Template{" "}
                <a className="text-primary" href="/collection/Deallocate.xlsx" download>
                    Click Here
                </a>{" "}
            </div>

            {/* list listing */}
            <Card>
                <CardHeader className="p-2">
                    <span className="h4">Cases Upload</span>
                </CardHeader>
                <CardBody className="p-1">
                    <DataTable
                        value={statsData}
                        paginator
                        className="commonTable"
                        rowsPerPageOptions={[10, 25, 50, 100]}
                        rows={10}
                        tableStyle={{ minWidth: "50rem" }}
                        // align="center"
                        sortMode="multiple"
                        removableSort
                    >
                        <Column
                            // align="center"
                            field="fileName"
                            header="Batch Name"
                            sortable
                        ></Column>
                        <Column
                            // align="center"
                            field="createdTime"
                            header="Upload Date"
                            body={(rowData) => {
                                return moment(rowData.createdTime).format(
                                    "DD-MM-YYYY HH:mm:ss"
                                );
                            }}
                            sortable
                        ></Column>
                        <Column
                            // align="center"
                            field="totalCount"
                            header="Total Case"
                            sortable
                        ></Column>
                        <Column
                            // align="center"
                            field="successCount"
                            header="Success Cases"
                            sortable
                        ></Column>
                        {/* <Column
                            // align="center"
                            header="Pending Cases"
                            body={(rowData) => {
                                return (
                                    rowData.totalCount -
                                    (rowData.successCount + rowData.errorCount)
                                );
                            }}
                            sortable
                        ></Column> */}
                        <Column
                            // align="center"
                            field="errorCount"
                            header="Failed Cases"
                            sortable
                        ></Column>
                        <Column
                            field="description"
                            header="Download File"
                            // align="center"
                            body={(rowData) => {
                                return (
                                    <i
                                        role="button"
                                        id={rowData.batchId}
                                        className="bi bi-three-dots-vertical text-primary"
                                        onClick={(e) => downloadMenu.current.toggle(e)}
                                    ></i>
                                );
                            }}
                            sortable
                        ></Column>
                    </DataTable>
                </CardBody>
            </Card>
            <Menu
                model={items}
                popup
                ref={downloadMenu}
                id="popup_menu_right"
                popupalignment="right"
            />

            {loaderProgress &&
                <ProgressBar
                    progressData={fileUploadProgress}
                />
            }
        </main>
    );
}

const mainDive = {
    width: "70%",
    height: "100px",
    margin: "auto",
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    marginBottom: "2rem",
    border: "0.125rem dashed black",
};
