import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  ButtonGroup,
  Container,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getAllBankBranchMaster, searchBankBranchMaster, setAPIResponse, setSelected } from "./store";
import { getAllPincode } from "../../GeographyMaster/Pincode/store";
import { getAllBankMaster } from "../BankMaster/store";
import BankBranchMasterForm from "./BankBranchMasterForm";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";

export default function BankBranchMaster({ access }) {
  const [formModal, setFormModal] = useState(false);
  const user = useSelector((state) => state.user.data);
  let bankList = useSelector((state) => state?.bankMaster?.list)
  const [pinCodeParams, setpinCodeParams]=useState({
    serchdata:411005,
    currentPage:1,
    numberOfDataPerPage:10
  })

  const [type, setType] = useState('');
  let { list, selected } = useSelector((state) => state.bankBranchMaster)
  const dispatch = useDispatch()

  const navigate = useNavigate();

  const onClose = () => {
    setFormModal(false)
    dispatch(setSelected({}))
    dispatch(setAPIResponse({}))
  }

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  useEffect(() => {
    if (type !== "") {
      dispatch(getAllPincode(pinCodeParams))
    }
  }, [type])
  useEffect(()=>{
    dispatch(getAllBankMaster())
  },[])

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data)=> dispatch(searchBankBranchMaster(data))}
        getAllAPI={()=>dispatch(getAllBankBranchMaster())}
        onClick={()=>{
          setFormModal(true)
          setType('Create');
        }}
        permission={user?.masterRole?.[access]}
      />

      <Card className="flex-grow-1 mb-1">
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={list}
            paginator
            className="commonTable"
            rows={10}
            // rowsPerPageOptions={[10, 20, 40, 80, "All"]}
            tableStyle={{ minWidth: "70rem" }}
            globalFilterFields={["bankBranchMaster", "status"]}
            sortMode="multiple"
            removableSort
          >
            <Column field="bankBranchCode" header="Bank Branch Code" sortable></Column>
            <Column field="bankBranchName" header="Bank Branch Name" sortable></Column>
            <Column field="bankCode" header="Bank Name" sortable
              body={(rowData) => bankList?.filter(e => e?.bankCode === rowData?.bankCode)[0]?.bankName
              }
            // body={(rowData) => console.log('test',bankList)}
            ></Column>

            <Column
              field="cityCode"
              header="City Code"
              sortable
            ></Column>
            <Column
              field="stateCode"
              header="State Code"
              sortable
            ></Column>
            <Column field="ifscCode" header="IFSC" sortable></Column>
            <Column
              field="pincode"
              header="PIN Code"
              sortable
            // body={(rowData) => allPinCodeDetails?.filter(e => e.code === rowData?.pincode)[0]?.pincode}
            ></Column>
            <Column
              field="active"
              header="Status"
              body={(rowData) =>
                rowData.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            >
              1
            </Column>

            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setFormModal(!formModal)
                        dispatch(setSelected(rowData))
                        setType('View');
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setFormModal(!formModal)
                        dispatch(setSelected(rowData))
                        setType('Edit');
                      }}
                    />
                  )}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      {/* create new bank branch master  */}

      {formModal &&
        <BankBranchMasterForm
          visible={formModal}
          type={type}
          onClose={onClose}
          selectedData={selected}
          setpinCodeParams={setpinCodeParams}
        />
      }
    </Container>
  );
}
