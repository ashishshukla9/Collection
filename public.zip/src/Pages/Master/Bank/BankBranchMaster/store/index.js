import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';
import { baseUrl } from '../../../../../App.config';
import { API_STATUS } from '../../../../../utils/Constent';
import { setLoader } from '../../../../../reducer/globalReducer';

export const getAllBankBranchMaster = createAsyncThunk(
  'bankBranchMaster/getAllBankBranchMaster',
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + "/getAllBankBranches");
      // dispatch(getAllPincodeBankBranchMaster)
      dispatch(setLoader(false))
      return {
        list: response?.data?.data,
      }
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch bankBranchMaster data.');
    }
  }
);

export const addBankBranchMaster = createAsyncThunk(
  'bankBranchMaster/addBankBranchMaster',
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true))
      const res = await axios.post(baseUrl() + "/createBankBranch", params);
      dispatch(setLoader(false))
      if (res?.data?.msgKey === API_STATUS.SUCCESS) {
        dispatch(getAllBankBranchMaster())
        return {
          status: API_STATUS.SUCCESS,
          message: res?.data?.message
        }
      }
      return false
    } catch (error) {
      dispatch(setLoader(false))
      return {
        status: API_STATUS.FAILED,
        message: error?.response?.data?.error
      }
    }
  }
);
export const editBankBranchMaster = createAsyncThunk(
  'bankBranchMaster/editBankBranchMaster',
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true))
      const res = await axios.put(baseUrl() + `/updateBankBranch/${params?.bankBranchId}`, params);
      dispatch(setLoader(false))
      if (res?.data?.msgKey === API_STATUS.SUCCESS) {
        dispatch(getAllBankBranchMaster())
        return {
          status: API_STATUS.SUCCESS,
          message: res?.data?.message
        }
      }
      return false
    } catch (error) {
      dispatch(setLoader(false))
      return {
        status: API_STATUS.FAILED,
        message: error?.response?.data?.error
      }
    }
  }
);

export const deleteBankBranchMaster = createAsyncThunk(
  'bankBranchMaster/editBankBranchMaster',
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true))
      await axios.put(baseUrl() + `/deleteProfile/${params?.id}`);
      dispatch(setLoader(false))
      dispatch(getAllBankBranchMaster())
      return true
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch bankBranchMaster data.');
    }
  }
);

export const searchBankBranchMaster = createAsyncThunk(
  'bankBranchMaster/searchBankBranchMaster',
  async (search, { dispatch }) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + `/getBankBranchByBankBranchName/${search}`);
      dispatch(setLoader(false))
      return {
        list: response?.data?.data,
      }
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch State data.');
    }
  }
);

//  fetching all pincode api here call
export const getAllPincodeBankBranchMaster = createAsyncThunk("getAllPincodeBankBranchMaster", async (pincode, { dispatch }) => {
  try {
    dispatch(setLoader(true))
    const response = await axios.get(baseUrl() + `/getPincodeByPincode/${411005}${pincode.pagecount}/${pincode.serchdata}/${pincode.totoldata}`)
    dispatch(setLoader(false))
    return response
  } catch (error) {
    dispatch(setLoader(false))
    throw new Error('Failed to fetch State data')
  }
})

export const bankBranchMaster = createSlice({
  name: 'bankBranchMaster',
  initialState: {
    list: [],
    loader: false,
    error: '',
    selected: null,
    apiResponse: {}
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null ? state.selected = null : state.selected = action.payload
    },
    setLoder: (state, action) => {
      state.loader = action.payload
    },
    setAPIResponse: (state, action) => {
      state.apiResponse = action.payload
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllBankBranchMaster.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.list;
      })
    builder
      .addCase(searchBankBranchMaster.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.list;
      })
    builder.addCase(addBankBranchMaster.fulfilled, (state, action) => {
      state.apiResponse = action.payload
    })
    builder.addCase(editBankBranchMaster.fulfilled, (state, action) => {
      state.apiResponse = action.payload
    })
    builder.addCase(getAllPincodeBankBranchMaster.fulfilled, (state, action)=>{
      state.apiResponse=action.payload
    })
  },
});

export const { setSelected, setLoder, setAPIResponse } = bankBranchMaster.actions;

export default bankBranchMaster.reducer;
