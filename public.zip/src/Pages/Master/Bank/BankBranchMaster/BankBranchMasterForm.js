import { Formik } from "formik";
import { Dialog } from "primereact/dialog";
import { Form } from "react-router-dom";
import axios from "axios";
import {
  Button,
  Col,
  FormFeedback,
  FormGroup,
  Input,
  Label,
  Row,
} from "reactstrap";
import Select, { components } from "react-select";
import { memo, useEffect, useMemo, useState } from "react";
import {
  BankBranchMasterSchema,
  IFSC_Validation,
  validationSchema,
} from "../../../../Schema/BankBranchMasterSchema";
import { useDispatch, useSelector } from "react-redux";
import cx from "classnames";
import {
  CHARACTER_NUMBER_ONLY,
  CHARACTER_ONLY,
  NO_SPACE,
  NUMBER_ONLY,
  SPACE_NOT_ALLOW,
} from "../../../../utils/regex";
import {
  addBankBranchMaster,
  editBankBranchMaster,
  setAPIResponse,
} from "./store";
import { API_STATUS } from "../../../../utils/Constent";
import Swal from "sweetalert2";
import Field from "../../../../components/Field";
import { setLoader } from "../../../../reducer/globalReducer";
import { getAllPincode } from "../../GeographyMaster/Pincode/store";
const BankBranchMasterForm = (props) => {
  const [bankOptions, setBankOptions] = useState([]);
  const [pincodeOptions, setPincodeOptions] = useState([]);
  const [totalApplicationCount, settotalApplicationCount] = useState()
  const [serchData, setSearchData] = useState("")
  const [formik, setFormik] = useState({});
  const [currentPage, setCurrentPage] = useState(1)
  const bankList = useSelector((state) => state?.bankMaster?.list);
  const pincodeList = useSelector((state) => state?.pincode?.list);
  const apiResponse = useSelector(
    (state) => state?.bankBranchMaster?.apiResponse
  );

  const isEdit = useMemo(() =>
    Boolean(Object.keys(props?.selectedData || {}).length)
  );

  const dispatch = useDispatch();

  const handleFormSubmit = (data) => {
    dispatch(setLoader(true))
    isEdit
      ? dispatch(editBankBranchMaster(data))
      : dispatch(addBankBranchMaster(data));
  };

  const onInputChangePincode = (val) => {
    setSearchData(val?.toString())
    setCurrentPage(1)
  }

  useEffect(() => {
    const tempPin = [];
    pincodeList.forEach((type) => {
      type.active === "Y" &&
        tempPin.push({
          label: `${type.areaName} - ${type?.pincode}`,
          value: type?.pincode,
        });
    });
    setPincodeOptions([...tempPin]);



    let tempBank = [];
    bankList.forEach((type) => {
      type.isActive === "Y" &&
        tempBank.push({
          label: `${type?.bankName}`,
          value: type?.bankCode,
        });
    });
    setBankOptions([...tempBank]);
  }, [bankList, pincodeList]);

  useEffect(() => {
    const checkObjLength = Boolean(Object.keys(apiResponse).length);
    dispatch(setLoader(false))
    if (checkObjLength) {
      if (apiResponse?.status === API_STATUS.FAILED) {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${apiResponse.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      } else if (apiResponse?.status === API_STATUS.SUCCESS) {

        Swal.fire({
          position: "top-end",
          icon: "success",
          title: `${apiResponse.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        props?.onClose();
      }

      dispatch(setAPIResponse({}));
    }
  }, [apiResponse]);


  useEffect(() => {
    const search = setTimeout(() => {
      if (serchData?.length > 2) {
        const getSearchAPI = async () => {
          try {
            const res = await axios.get(`/getPincodeByPincode/${serchData}/${currentPage}/10`)
            if (res?.data?.messageKey === "Success") {
              const op = []
              res?.data?.response?.map(a => {
                if (a?.active === "Y") {
                  op?.push({
                    label: `${a?.areaName} - ${a?.pincode}`,
                    value: a?.pincode,
                  });
                }
                const round = res?.data?.totalApplicationCount;
                const totalpages = Math.ceil(round) / 10
                settotalApplicationCount(totalpages)
                if (currentPage === 1) {
                  setPincodeOptions(op)
                } else {
                  setPincodeOptions([...pincodeOptions, ...op])
                }
              })

              setTimeout(() => {
              }, 1000)
            }
          } catch (error) {
            console.log(error)
          }
        }
        getSearchAPI()
      }
    }, 1000)

    return () => {
      clearTimeout(search)
    }
  }, [serchData, currentPage])

  return (
    <Dialog
      header=" Bank Branch  Details"
      visible={props?.visible}
      onHide={props?.onClose}
      style={{ width: "80vw" }}
    >
      <Formik
        initialValues={isEdit ? props?.selectedData : BankBranchMasterSchema}
        validationSchema={validationSchema}
        onSubmit={handleFormSubmit}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          setFieldValue,
        }) => {

          return (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Bank Branch Code"
                    errorMessage={
                      touched.bankBranchCode && errors.bankBranchCode
                    }
                  >
                    <Input
                      disabled={props?.type !== "Create"}
                      bsSize="sm"
                      type="text"
                      maxLength={8}
                      id="bankBranchCode"
                      placeholder="Bank Branch Code"
                      value={values?.bankBranchCode}
                      onChange={e => {
                        if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                          setFieldValue('bankBranchCode', e?.target?.value)
                        }
                      }}
                      onBlur={handleBlur}
                      invalid={
                        touched?.bankBranchCode &&
                        Boolean(errors?.bankBranchCode)
                      }
                    />
                  </Field>
                </Col>

                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Bank Branch Name"
                    errorMessage={
                      touched.bankBranchName && errors.bankBranchName
                    }
                  >
                    <Input
                      disabled={props?.type === "View"}
                      bsSize="sm"
                      type="text"
                      maxLength={35}
                      id="bankBranchName"
                      placeholder="Bank Branch Name"
                      value={values?.bankBranchName}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched?.bankBranchName &&
                        Boolean(errors?.bankBranchName)
                      }
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Bank Name"
                    errorMessage={touched.bankCode && errors.bankCode}
                  >
                    <Select
                      isDisabled={props?.type === "View"}
                      inputId="bankCode"
                      name="bankCode"
                      isClearable={true}
                      options={bankOptions}
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false}
                      onChange={(e) => {
                        setFieldValue("bankCode", e?.value);
                      }}
                      value={bankOptions.filter(
                        (v) => v.value === values?.bankCode
                      )}
                      className={cx({
                        abc: touched?.bankCode && Boolean(errors?.bankCode),
                      })}
                      onBlur={handleBlur}
                      menuPosition={"fixed"}
                      classNamePrefix="react-select"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Address 1"
                    errorMessage={touched.addressLine1 && errors.addressLine1}
                  >
                    <Input
                      disabled={props?.type === "View"}
                      bsSize="sm"
                      type="textarea"
                      id="addressLine1"
                      placeholder=" Address Line 1"
                      value={values?.addressLine1}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.addressLine1 && Boolean(errors.addressLine1)
                      }
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Address 2"
                    errorMessage={touched.addressLine2 && errors.addressLine2}
                  >
                    <Input
                      disabled={props?.type === "View"}
                      bsSize="sm"
                      type="textarea"
                      id="addressLine2"
                      placeholder=" Address Line 2"
                      value={values?.addressLine2}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.addressLine2 && Boolean(errors.addressLine2)
                      }
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Address 3"
                    errorMessage={touched.addressLine3 && errors.addressLine3}
                  >
                    <Input
                      disabled={props?.type === "View"}
                      bsSize="sm"
                      type="textarea"
                      id="addressLine3"
                      placeholder=" Address Line 3"
                      value={values?.addressLine3}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.addressLine3 && Boolean(errors.addressLine3)
                      }
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="PIN Code"
                    errorMessage={touched.pincode && errors.pincode}
                  >
                    <Select
                      isDisabled={props?.type === "View"}
                      inputId="pincode"
                      name="pincode"
                      isClearable={true}
                      options={pincodeOptions}
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false}
                      onInputChange={(value) => {
                        setFormik({ values, setFieldValue })
                        onInputChangePincode(value)
                      }}
                      onChange={(e) => {
                        setFieldValue("pincode", e?.value);
                        setFieldValue(
                          "cityCode",
                          pincodeList.filter(
                            (pin) => pin?.pincode === e?.value
                          )[0]?.city.cityCode
                        );

                        setFieldValue(
                          "stateCode",
                          pincodeList.filter(
                            (pin) => pin?.pincode === e?.value
                          )[0]?.city.state.stateCode
                        );
                      }}
                      value={pincodeOptions.filter(
                        (v) => v.value === values?.pincode
                      )}
                      className={cx({
                        abc: touched?.pincode && Boolean(errors?.pincode),
                      })}
                      onBlur={handleBlur}
                      menuPosition={"fixed"}
                      classNamePrefix="react-select"
                      onMenuScrollToBottom={() => {
                        if (totalApplicationCount >= currentPage && serchData) {
                          setCurrentPage(currentPage + 1)
                        }
                      }}
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="City"
                    errorMessage={touched.cityCode && errors.cityCode}
                  >
                    <Input
                      disabled={props?.type === "Create"}
                      bsSize="sm"
                      type="text"
                      id="cityCode"
                      placeholder="City"
                      value={
                        pincodeList?.filter(
                          (pin) => pin?.pincode === values?.pincode
                        )[0]?.city.cityName
                      }
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched.cityCode && Boolean(errors.cityCode)}
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="State"
                    errorMessage={touched.stateCode && errors.stateCode}
                  >
                    <Input
                      disabled={props?.type === "Create"}
                      bsSize="sm"
                      type="text"
                      id="stateCode"
                      placeholder="State "
                      value={
                        pincodeList?.filter(
                          (pin) => pin?.pincode === values?.pincode
                        )[0]?.city?.state?.stateName
                      }
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched?.stateCode && Boolean(errors.stateCode)}
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Contact"
                    errorMessage={touched.contactNo && errors.contactNo}
                  >
                    <Input
                      disabled={props?.type === "View"}
                      bsSize="sm"
                      id="contactNo"
                      maxLength={10}
                      placeholder="contactNo"
                      value={values?.contactNo}
                      onChange={(e) => {
                        if (NUMBER_ONLY.test(e.target.value)) {
                          setFieldValue("contactNo", e.target.value);
                        } else if (!e.target.value) {
                          setFieldValue("contactNo", e.target.value);
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.code === "Backspace") {
                          setFieldValue("contactNo", e.target.value);
                        }
                      }}
                      onBlur={handleBlur}
                      invalid={touched.contactNo && Boolean(errors.contactNo)}
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="MICR Code"
                    errorMessage={touched.micrCode && errors.micrCode}
                  >
                    <Input
                      disabled={props?.type === "View"}
                      bsSize="sm"
                      // type="number"
                      id="micrCode"
                      placeholder="MICR Code"
                      maxLength={10}
                      value={values?.micrCode}
                      onChange={(e) => {
                        if (NUMBER_ONLY.test(e.target.value)) {
                          setFieldValue("micrCode", e.target.value);
                        } else if (!e.target.value) {
                          setFieldValue("micrCode", e.target.value);
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.code === "Backspace") {
                          setFieldValue("micrCode", e.target.value);
                        }
                      }}
                      onBlur={handleBlur}
                      invalid={touched.micrCode && Boolean(errors.micrCode)}
                    />
                  </Field>
                </Col>

                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="IFSC Code"
                    errorMessage={touched.ifscCode && errors.ifscCode}
                  >
                    <Input
                      disabled={props?.type === "View"}
                      bsSize="sm"
                      type="text"
                      id="ifscCode"
                      placeholder="IFSC Code"
                      value={values?.ifscCode}
                      maxLength={11}
                      onChange={(e) => {
                        const value = e?.target?.value;
                        if (SPACE_NOT_ALLOW.test(value)) {
                          if (value.length <= 4 && CHARACTER_ONLY.test) {
                            setFieldValue("ifscCode", value.toUpperCase());
                          } else if (
                            value.length === 5 &&
                            value.lastIndexOf(0) === 4
                          ) {
                            setFieldValue("ifscCode", value.toUpperCase());
                          } else if (
                            value.length >= 6 &&
                            CHARACTER_NUMBER_ONLY.test(value)
                          ) {
                            setFieldValue("ifscCode", value.toUpperCase());
                          }
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.code === "Backspace") {
                          setFieldValue("ifscCode", e.target.value);
                        }
                      }}
                      onBlur={handleBlur}
                      invalid={touched.ifscCode && Boolean(errors.ifscCode)}
                    />
                  </Field>
                </Col>

                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Active"
                    errorMessage={touched.active && errors.active}
                  >
                    <FormGroup switch className="ms-2">
                      <Input
                        disabled={props?.type === "View"}
                        type="switch"
                        checked={values?.active === "Y"}
                        onChange={(e) => {
                          setFieldValue("active", e.target.checked ? "Y" : "N");
                        }}
                        id="active"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div
                className={`${props?.type === "View" && "d-none"
                  } d-flex justify-content-end`}
              >
                <Button
                  color="primary"
                  type="submit"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>
                <Button
                  size="sm"
                  color="danger"
                  type="button"
                  style={{ color: "#fff" }}
                  onClick={props?.onClose}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          );
        }}
      </Formik>
    </Dialog>
  );
};

export default memo(BankBranchMasterForm);
