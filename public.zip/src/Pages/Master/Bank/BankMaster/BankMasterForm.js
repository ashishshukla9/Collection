import { Formik } from "formik";
import { Dialog } from "primereact/dialog";
import { useEffect, useMemo } from "react";
import { Button, Col, Form, FormFeedback, FormGroup, Input, Label, Row } from "reactstrap";
import { bankMasterSchema, bankValidationSchema } from "../../../../Schema/BankMasterSchema";
import { useDispatch, useSelector } from "react-redux";
import { addBankMaster, editBankMaster, setAPIResponse } from "./store";
import Swal from "sweetalert2";
import { API_STATUS } from "../../../../utils/Constent";
import Field from "../../../../components/Field";
import { NO_SPACE } from "../../../../utils/regex";

const BankMasterForm = (props) => {
    const isEdit = useMemo(() => Boolean(Object.keys(props?.selectedData || {}).length));
    const apiResponse = useSelector((state) => state?.bankMaster?.apiResponse)

    const dispatch = useDispatch();

    const handleFormSubmit = (data) => {
        isEdit ? dispatch(editBankMaster(data)) : dispatch(addBankMaster(data))
    }

    useEffect(() => {
        const checkObjLength = Boolean(Object.keys(apiResponse).length)

        if (checkObjLength) {
            if (apiResponse?.status === API_STATUS.FAILED) {
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${apiResponse.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                })
            } else if (apiResponse?.status === API_STATUS.SUCCESS) {
                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `${apiResponse.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                })
                props?.onClose()
            }

            dispatch(setAPIResponse({}))
        }
    }, [apiResponse])

    return (
        <Dialog
            header={`${isEdit && props?.type === "View" ? 'View' : isEdit ? 'Update' : 'Create'} Bank Details`}
            visible={props?.visible}
            style={{ width: "60vw" }}
            onHide={props?.onClose}
        >
            <Formik
                initialValues={props?.type !== "Add" ? props?.selectedData : bankMasterSchema}
                validationSchema={bankValidationSchema}
                onSubmit={handleFormSubmit}
            >
                {({
                    values,
                    errors,
                    touched,
                    handleChange,
                    handleBlur,
                    setFieldValue,
                    handleSubmit
                }) => (
                    <Form onSubmit={handleSubmit}>
                        <Row>
                            <Col lg={6} md={6} sm={12}>
                                <Field
                                    isRequired
                                    label="Bank Code"
                                    errorMessage={touched.bankCode && errors.bankCode}
                                >
                                    <Input
                                        disabled={props?.type !== "Add"}
                                        bsSize="sm"
                                        type="text"
                                        id="bankCode"
                                        placeholder="Code"
                                        value={values?.bankCode}
                                        onChange={e=>{
                                            if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                                              setFieldValue('bankCode', e?.target?.value)
                                            }
                                        }}
                                        onBlur={handleBlur}
                                        invalid={touched?.bankCode && Boolean(errors?.bankCode)}
                                        autoComplete="off"
                                    />
                                </Field>
                            </Col>
                            <Col lg={6} md={6} sm={12}>
                                <Field
                                    isRequired
                                    label="Bank Name"
                                    errorMessage={touched.bankName && errors.bankName}
                                >
                                    <Input
                                        disabled={props?.type === "View" ? true : false}
                                        bsSize="sm"
                                        type="text"
                                        id="bankName"
                                        name="bankName"
                                        placeholder="Bank Name"
                                        value={values?.bankName}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        invalid={touched.bankName && Boolean(errors.bankName)}
                                        autoComplete="off"
                                    />
                                </Field>
                            </Col>
                            <Col lg={6} md={6} sm={12}>
                                <Field
                                    label="Active"
                                >
                                    <FormGroup switch className="ms-2">
                                        <Input
                                            disabled={props?.type === "View" ? true : false}
                                            type="switch"
                                            checked={values?.isActive === "Y" ? true : false}
                                            onChange={(e) => {
                                                setFieldValue(
                                                    "isActive",
                                                    e.target.checked ? "Y" : "N"
                                                );
                                            }}
                                            id="isActive"
                                            readOnly
                                        />
                                    </FormGroup>
                                </Field>
                            </Col>
                        </Row>
                        <div className={`${props?.type === "View" && 'd-none'} d-flex justify-content-end`}>
                            <Button type="submit" color="primary" className="me-1" size="sm">
                                Submit
                            </Button>
                            <Button
                                size="sm"
                                type="button"
                                color="danger"
                                onClick={props?.onClose}
                            >
                                Cancel
                            </Button>
                        </div>
                    </Form>
                )}
            </Formik>
        </Dialog>
    )
}

export default BankMasterForm