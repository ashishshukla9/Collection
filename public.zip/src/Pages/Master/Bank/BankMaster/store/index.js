import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../../../App.config";
import { API_STATUS } from "../../../../../utils/Constent";
import { setLoader } from "../../../../../reducer/globalReducer";
export const getAllBankMaster = createAsyncThunk(
  "bankMaster/getAllBankMaster",

  async (params, {dispatch}) => {
    dispatch(setLoader(true));
    try {
      const response = await axios.get(baseUrl() + "/getAllBank");
      dispatch(setLoader(false));
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      throw new Error("Failed to fetch bankMaster data.");
    }
  }
);

export const addBankMaster = createAsyncThunk(
  "bankMaster/addBankMaster",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      const res = await axios.post(baseUrl() + "/createBank", params);

      if (res?.data?.msgKey === API_STATUS.SUCCESS) {
        dispatch(setLoader(false));
        dispatch(getAllBankMaster());
        return {
          status: API_STATUS.SUCCESS,
          message: res?.data?.message,
        };
      }
      return false;
    } catch (error) {
      dispatch(setLoader(false));
      return {
        status: API_STATUS.FAILED,
        message: error?.response?.data?.error,
      };
    }
  }
);
export const editBankMaster = createAsyncThunk(
  "bankMaster/editBankMaster",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      const res = await axios.post(
        baseUrl() + `/updateBank/${params?.bankId}`,
        params
      );
      dispatch(setLoader(false));
      if (res?.data?.msgKey === API_STATUS.SUCCESS) {
        dispatch(getAllBankMaster());
        return {
          status: API_STATUS.SUCCESS,
          message: res?.data?.message,
        };
      }
      return false;
    } catch (error) {
      dispatch(setLoader(false));
      return {
        status: API_STATUS.FAILED,
        message: error?.response?.data?.error,
      };
    }
  }
);

export const deleteBankMaster = createAsyncThunk(
  "bankMaster/deleteBankMaster",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      
      await axios.put(baseUrl() + `/deleteBank/${params?.id}`);

      dispatch(getAllBankMaster());
      dispatch(setLoader(false));
      return true;
    } catch (error) {
      dispatch(setLoader(false));
      throw new Error("Failed to fetch bankMaster data.");
    }
  }
);
export const searchBankMaster = createAsyncThunk(
  "bankMaster/searchBankMaster",
  async (search, {dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + `/getBankName/${search}`);
      dispatch(setLoader(false))
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false))
      console.log(error);
      throw new Error("Failed to fetch State data.");
    }
  }
);

export const bankMaster = createSlice({
  name: "bankMaster",
  initialState: {
    list: [],
    loader: false,
    error: "",
    selected: null,
    apiResponse: {},
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null
        ? (state.selected = null)
        : (state.selected = action.payload);
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
    setAPIResponse: (state, action) => {
      state.apiResponse = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllBankMaster.fulfilled, (state, action) => {
      state.loading = false;
      state.list = action.payload.list;
    });
    builder.addCase(searchBankMaster.fulfilled, (state, action) => {
      state.loading = false;
      state.list = action.payload.list;
    });

    builder.addCase(addBankMaster.fulfilled, (state, action) => {
      state.apiResponse = action.payload;
    });

    builder.addCase(editBankMaster.fulfilled, (state, action) => {
      state.apiResponse = action.payload;
    });
  },
});

export const { setSelected, setLoder, setAPIResponse } = bankMaster.actions;

export default bankMaster.reducer;
