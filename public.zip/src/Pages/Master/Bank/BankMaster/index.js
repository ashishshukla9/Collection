import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  Container,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getAllBankMaster, searchBankMaster, setAPIResponse, setSelected } from "./store";
import BankMasterForm from "./BankMasterForm";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";

export default function BankMaster({ access }) {
  const [formModal, setFormModal] = useState(false);
  const [type, setType] = useState('');

  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();
  let { list, selected } = useSelector((state) => state.bankMaster)
  const dispatch = useDispatch()

  const onClose = () => {
    setFormModal(false)
    dispatch(setSelected({}))
    dispatch(setAPIResponse({}))
  }

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data)=> dispatch(searchBankMaster(data))}
        getAllAPI={()=>dispatch(getAllBankMaster())}
        onClick={()=>{
          setFormModal(!formModal)
          setType("Add")
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={list}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column
              field="bankCode"
              header="Bank Code"
              sortable
            // style={{ width: "25%" }}
            ></Column>
            <Column
              field="bankName"
              header="Bank Name"
              sortable
            // style={{ width: "25%" }}
            ></Column>
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData?.isActive === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let state = rowData.state?.stateCode
                        dispatch(setSelected({ ...rowData, state }))
                        setFormModal(!formModal)
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        dispatch(setSelected({ ...rowData }))
                        setFormModal(!formModal)
                        setType("Edit");
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i className="bi bi-trash" style={{ cursor: "pointer" }} /> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      {formModal &&
        <BankMasterForm
          setVisible={setFormModal}
          visible={formModal}
          type={type}
          selectedData={selected}
          onClose={onClose}
        />
      }
    </Container>
  );
}
