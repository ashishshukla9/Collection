import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import Swal from "sweetalert2";
import axios from "axios";

import {
  RejectReasonSchema,
  rejectReasonValidation,
} from "../../../Schema/RejectReason";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import SearchBarHeader from "../../../components/Header/SearchBarHeader";
import { getRejectReasonData, searchRejectReasonData } from "./lookupSlice";
import Field from "../../../components/Field";
import { setLoader } from "../../../reducer/globalReducer";

export default function RejectReasonMaster({ access }) {
  const [createModal, setCreateModal] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  const [viewModal, setViewModal] = useState(false);
  const [data, setData] = useState({});

  const user = useSelector((state) => state.user.data);
  const rejectReasonData = useSelector(
    (state) => state?.lookup?.rejectReasonData
  );
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  const handleFormSubmit = (values) => {
    dispatch(setLoader(true));
    axios
      .post("/createRejectReasonMaster", values)
      .then((res) => {
        if (res?.data?.msgKey === "Success") {
          dispatch(getRejectReasonData());
          dispatch(setLoader(false));
          setCreateModal(!createModal);

          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `${res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        } else {
          dispatch(setLoader(false));
          Swal.fire({
            position: "top-end",
            icon: res?.data?.msgKey === "Failure" ? "error" : "success",
            title: `${res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        dispatch(setLoader(false));
        console.log(error);
      });
  };
  const handleUpdate = (values) => {
    dispatch(setLoader(true));
    axios
      .put(`/updateRejectReasonMaster/${values.id}`, values)
      .then((res) => {
        if (res?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `${res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          dispatch(getRejectReasonData());
          dispatch(setLoader(false));
          setUpdateModal(!updateModal);
        } else {
          dispatch(setLoader(false));
          Swal.fire({
            position: "top-end",
            icon: res?.data?.msgKey === "Failure" ? "error" : "success",
            title: `${res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        dispatch(setLoader(false));
        console.log(error);
      });
  };

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchRejectReasonData(data))}
        getAllAPI={() => dispatch(getRejectReasonData())}
        onClick={() => {
          setCreateModal(!createModal);
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">Rejection Reasons</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={rejectReasonData}
            rows={10}
            paginator
            className="commonTable"
            // rowsPerPageOptions={[10, 20, 40, 80, "All"]}
            tableStyle={{ minWidth: "50rem" }}
          >
            <Column field="code" header="Code"></Column>
            <Column field="description" header="Description"></Column>
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData.isActive === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setViewModal(!viewModal);
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setUpdateModal(!updateModal);
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i className="bi bi-trash" style={{ cursor: "pointer" }} /> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header="Create"
        visible={createModal}
        style={{ width: "60vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={RejectReasonSchema}
          validationSchema={rejectReasonValidation}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Code"
                    errorMessage={touched.code && errors.code}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="code"
                      placeholder="Code"
                      value={values.code}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched.code && Boolean(errors.code)}
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Description"
                    errorMessage={touched.description && errors.description}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="description"
                      placeholder="Description"
                      value={values.description}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.description && Boolean(errors.description)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Active">
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.isActive === "Y"}
                        onChange={(e) => {
                          setFieldValue(
                            "isActive",
                            e.target.checked ? "Y" : "N"
                          );
                        }}
                        id="isActive"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <Button
                  type="submit"
                  color="primary"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setCreateModal(!createModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>

      {/* Modal to Update data */}
      <Dialog
        header="Update Details"
        visible={updateModal}
        style={{ width: "60vw" }}
        onHide={() => setUpdateModal(!updateModal)}
      >
        <Formik
          initialValues={data}
          validationSchema={rejectReasonValidation}
          onSubmit={handleUpdate}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Code"
                    errorMessage={touched.code && errors.code}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="code"
                      placeholder="Code"
                      value={values.code}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched.code && Boolean(errors.code)}
                      autoComplete="off"
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Description"
                    errorMessage={touched.description && errors.description}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="description"
                      placeholder="Description"
                      value={values.description}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.description && Boolean(errors.description)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Active">
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.isActive === "Y"}
                        onChange={(e) => {
                          setFieldValue(
                            "isActive",
                            e.target.checked ? "Y" : "N"
                          );
                        }}
                        id="isActive"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <Button
                  type="submit"
                  color="primary"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setUpdateModal(!updateModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>

      {/* Modal to View data */}
      <Dialog
        header="View Details"
        visible={viewModal}
        style={{ width: "60vw" }}
        onHide={() => setViewModal(!viewModal)}
      >
        <Formik initialValues={data} validationSchema={rejectReasonValidation}>
          {({ values }) => (
            <Form>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field isRequired label="Code">
                    <Input
                      bsSize="sm"
                      type="text"
                      id="code"
                      placeholder="Code"
                      value={values.code}
                      autoComplete="off"
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field isRequired label="Description">
                    <Input
                      bsSize="sm"
                      type="text"
                      id="description"
                      placeholder="Description"
                      value={values.description}
                      autoComplete="off"
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Active">
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.isActive === "Y"}
                        id="isActive"
                        readOnly
                        disabled
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
            </Form>
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}
