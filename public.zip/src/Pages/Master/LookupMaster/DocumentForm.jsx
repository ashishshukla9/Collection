import { Formik } from "formik"
import { memo, useMemo } from "react"
import { scrollToErrorMessage } from "../../../utils/commonFun"
import { Button, Col, Form, FormGroup, Input, Row } from "reactstrap"
import * as yup from "yup";
import Field from "../../../components/Field";
import Swal from "sweetalert2";
import axios from "axios";
import { useDispatch } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";

const DocumentForm = (props) => {
    const dispatch = useDispatch()

    const IS_EDIT = useMemo(() => props?.formType === "Edit", [])
    const IS_VIEW = useMemo(() => props?.formType === "View", [])

    const initialValues = {
        code: (IS_EDIT || IS_VIEW) ? props?.data?.code : "",
        documentName: (IS_EDIT || IS_VIEW) ? props?.data?.description : "",
        isActive: (IS_EDIT || IS_VIEW) ? props?.data?.isActive : "Y"
    }

    const validationSchema = yup.object().shape({
        documentName: yup.string().required("This field is required."),
        code: yup.string().required("This field is required."),
        isActive: yup.string().required("This field is required.")
    })

    const handleSubmit = async (values) => {
        try {
            const payload = {
                code: values?.code,
                description: values?.documentName,
                isActive: values?.isActive
            }
            dispatch(setLoader(true))

            const res = IS_EDIT ? await axios.put( `/updateDocumentType/${props?.data?.id}`,payload) : await axios.post('/createDocumentType', payload)

            dispatch(setLoader(false))

            if (res?.data?.msgKey === "Success") {
                props?.onSuccess()

                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            } else {
                dispatch(setLoader(false))
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                touched,
                handleSubmit,
                onSubmit,
                setFieldValue,
                handleBlur,
                handleChange,
                isSubmitting,
            }) => {
                const err = Object.keys(errors)[0];
                scrollToErrorMessage(isSubmitting, err);

                return (
                    <Form onSubmit={handleSubmit} autoComplete="off">
                        <Row>
                            <Col lg={6} md={6} sm={12}>
                                <Field
                                    isRequired
                                    label="Document Code"
                                    errorMessage={touched?.code && errors?.code}
                                >
                                    <Input
                                        size={'sm'}
                                        name="code"
                                        value={values?.code}
                                        invalid={touched?.code && Boolean(errors?.code)}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        disabled={IS_VIEW || IS_EDIT}
                                    />
                                </Field>
                            </Col>

                            <Col lg={6} md={6} sm={12}>
                                <Field
                                    isRequired
                                    label="Document Name"
                                    errorMessage={touched?.documentName && errors?.documentName}
                                >
                                    <Input
                                        size={'sm'}
                                        name="documentName"
                                        value={values?.documentName}
                                        invalid={touched?.documentName && Boolean(errors?.documentName)}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        disabled={IS_VIEW}
                                    />
                                </Field>
                            </Col>

                            <Col lg={6} md={6} sm={12}>
                                <Field
                                    isRequired
                                    label="Is Active"
                                    errorMessage={touched?.isActive && errors?.isActive}
                                >
                                    <FormGroup switch className="ms-2">
                                        <Input
                                            type="switch"
                                            name="isActive"
                                            checked={values?.isActive === "Y"}
                                            onChange={(e) => {
                                                setFieldValue(
                                                    "isActive",
                                                    e.target.checked ? "Y" : "N"
                                                );
                                            }}
                                            disabled={IS_VIEW}
                                        />
                                    </FormGroup>
                                </Field>
                            </Col>
                        </Row>

                        {!IS_VIEW &&
                            <Button
                                type="submit"
                                size="sm"
                                color="primary"
                                className="documentFormSubmitBtn"
                            >
                                Submit
                            </Button>
                        }
                    </Form>
                )
            }}
        </Formik>
    )
}

export default memo(DocumentForm)