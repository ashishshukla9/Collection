import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";

import {
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  Col,
  Button,
  FormFeedback,
  Card,
  CardBody,
  CardHeader,
  ButtonGroup,
  Container,
} from "reactstrap";
import {
  userDesignamtionSchema,
  validationSchema,
} from "../../../Schema/UserDesignationShema";
import { useFormik, Formik } from "formik";
import axios from "axios";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getUserDesignationData, searchUserDesignationData } from "./lookupSlice";
import SearchBarHeader from "../../../components/Header/SearchBarHeader";
import Field from "../../../components/Field";
import { setLoader } from "../../../reducer/globalReducer";
// import { Dropdown } from "primereact/dropdown";
export default function DisputeReasonMaster({ access }) {
  const [visible, setVisible] = useState(false);
  const [data, setData] = useState(null);
  const [isView, setView] = useState(false);
  const [isEdit, setEdit] = useState(false);

  const user = useSelector((state) => state.user.data);
  const userTypeData = useSelector(state => state?.lookup?.userDesignationData)
  const navigate = useNavigate();
  const dispatch = useDispatch()

  const formik = useFormik({
    initialValues: userDesignamtionSchema,
    validationSchema: validationSchema,
    onSubmit: (values, { resetForm }) => {
      dispatch(setLoader(true)) 
      axios
        .post("/createUserDesignation", values)
        .then((response) => {
          if(response?.data?.msgKey === "Failure"){
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: `${response?.data?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          
            dispatch(setLoader(false)) 
            setVisible(false)
          }else{
            dispatch(setLoader(false)) 
            resetForm()
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: "Records has been saved",
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
            setVisible(false)
            dispatch(getUserDesignationData())
           
            
          }
        })
        .catch((error) => {
          dispatch(setLoader(false)) 
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    },
  });

  const handleUpdate = (formObj) => {
    dispatch(setLoader(true)) 
    axios
      .put(`/updateUserDesignation/${formObj.id}`, formObj)
      .then((res) => {
        if (res?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `${res?.data?.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          dispatch(setLoader(false)) 
          dispatch(getUserDesignationData());
          setEdit(!isEdit);
        }else{
          dispatch(setLoader(false)) 
          Swal.fire({
            position: "top-end",
            icon: res?.data?.msgKey === "Failure" ? "error" : "success",
            title: `${res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });

        }
      })
      .catch((error) => {
        dispatch(setLoader(false)) 
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchUserDesignationData(data))}
        getAllAPI={() => dispatch(getUserDesignationData())}
        onClick={() => {
          setVisible(true)
          setData(null)
        }}
        permission={user?.masterRole?.[access]}
      />

      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">User Designation</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={userTypeData}
            paginator
            className="commonTable"
            rowsPerPageOptions={[10, 25, 50, 100]}
            rows={10}
            tableStyle={{ minWidth: "50rem" }}
          >
            <Column
              field="code"
              header=" Code"
            // style={{ width: "25%" }}
            ></Column>
            <Column
              field="description"
              header="Description "
            // style={{ width: "25%" }}
            ></Column>
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData.isActive === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            // style={{ width: "25%" }}
            >
              1
            </Column>
            <Column
              // field="isActive"
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setView(!isView);
                      }}
                    ></i>
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setEdit(!isEdit);
                      }}
                    ></i>
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i
                    className="bi bi-trash3-fill"
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      deleteRow(rowData.userTypeId);
                    }}
                  ></i> */}
                </ButtonGroup>
              )}
            // style={{ width: "25%" }}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>

      {/* Dialog to view User Designation */}
      <Dialog
        header="User Designation"
        visible={isView}
        // style={{ width: "60vw" }}
        onHide={() => setView(!isView)}
      >
        <section>
          <Row>
            <Col lg={6} md={6} sm={12}>
              <Field isRequired label="Code">
                <Input bsSize="sm" type="text" value={data?.code} disabled />
              </Field>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <Field isRequired label="Description">
                <Input
                  bsSize="sm"
                  type="text"
                  value={data?.description}
                  disabled
                />
              </Field>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <Field label="Active">
                <FormGroup switch className="ms-2">
                  <Input
                    type="switch"
                    checked={data?.isActive === "Y"}
                    id="active"
                    disabled
                  />
                </FormGroup>
              </Field>
            </Col>
          </Row>
        </section>
      </Dialog>

      {/* Dialog to create User Designation */}
      <Dialog
        header="User Designation"
        visible={visible}
        // style={{ width: "60vw" }}
        onHide={() => setVisible(false)}
      >
        <section>
          <Form onSubmit={formik.handleSubmit}>
            <Row>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Code"
                  errorMessage={formik.touched.code && formik.errors.code}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="code"
                    placeholder="Code"
                    value={formik.values.code}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={formik.touched.code && Boolean(formik.errors.code)}
                    autoComplete="off"
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Description"
                  errorMessage={formik.touched.description && formik.errors.description}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="description"
                    placeholder="Description"
                    value={formik.values.description}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={
                      formik.touched.description &&
                      Boolean(formik.errors.description)
                    }
                    autoComplete="off"
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field label="Active">
                  <FormGroup switch className="ms-2">
                    <Input
                      type="switch"
                      checked={formik.values.isActive === "Y"}
                      onChange={(e) => {
                        formik.setFieldValue(
                          "isActive",
                          e.target.checked ? "Y" : "N"
                        );
                      }}
                      id="isActive"
                      readOnly
                    />
                  </FormGroup>
                </Field>
              </Col>
            </Row>
            <div className="d-flex justify-content-end">
              <Button type="submit" color="primary" className="me-1" size="sm">
                Submit
              </Button>{" "}
              <Button
                size="sm"
                color="danger"
                type="button"
                style={{ color: "#fff" }}
                onClick={() => setVisible(false)}
              >
                Cancel
              </Button>
            </div>
          </Form>
        </section>
      </Dialog>

      {/* Dialog to Edit User Designation */}
      <Dialog
        header="User Designation"
        visible={isEdit}
        // style={{ width: "60vw" }}
        onHide={() => setEdit(!isEdit)}
      >
        <section>
          <Formik
            initialValues={data}
            validationSchema={validationSchema}
            onSubmit={(values) => {
              handleUpdate(values);
            }}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
              setFieldValue,
            }) => (
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col lg={6} md={6} sm={12}>
                    <Field isRequired label="Code">
                      <Input
                        bsSize="sm"
                        type="text"
                        id="code"
                        placeholder="code"
                        value={values.code}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={touched.code && Boolean(errors.code)}
                        autoComplete="off"
                        disabled
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Description"
                      errorMessage={touched.description && errors.description}
                    >
                      <Input
                        bsSize="sm"
                        type="text"
                        name="description"
                        id="description"
                        placeholder="Description"
                        value={values.description}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={
                          touched.description && Boolean(errors.description)
                        }
                      />
                    </Field>
                  </Col>

                  <Col lg={6} md={6} sm={12}>
                    <Field label="Active">
                      <FormGroup switch className="ms-2">
                        <Input
                          type="switch"
                          checked={values.isActive === "Y"}
                          onChange={(e) => {
                            setFieldValue(
                              "isActive",
                              e.target.checked ? "Y" : "N"
                            );
                          }}
                          id="active"
                          // readOnly
                        />
                      </FormGroup>
                    </Field>
                  </Col>
                </Row>
                <div className="d-flex justify-content-end">
                  <Button type="submit" color="primary" className="me-1" size="sm">
                    Submit
                  </Button>{" "}
                  <Button
                    size="sm"
                    color="danger"
                    type="button"
                    style={{ color: "#fff" }}
                    onClick={() => setEdit(!isEdit)}
                  >
                    Cancel
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </section>
      </Dialog>
    </Container>
  );
}
