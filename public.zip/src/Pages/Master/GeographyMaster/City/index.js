import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import {
  CitySchema,
  CityValidationSchema,
} from "../../../../Schema/GeographyMaster";
import { setLoader } from "../../../../reducer/globalReducer";
import Select from "react-select";
import cx from "classnames";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  addCity,
  editCity,
  getAllCity,
  setSelected,
  searchCity,
  getStateName,
} from "./store";
import { getAllStates } from "../State/store";
import { getAllRegion } from "../Region/store";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";
import Field from "../../../../components/Field";
import Pagination from "../../../../components/Pagination";
import { NO_SPACE } from "../../../../utils/regex";

export default function City({ access }) {

  const [createModal, setCreateModal] = useState(false);
  const [type, setType] = useState("");

  const [activeRegion, setActiveRegion] = useState([]);
  const [scity, setSCity] = useState([]);
  const [regionId, setRegionId] = useState("");
  const [stateId, setStateId] = useState("");
  const [activeState, setActiveState] = useState([]);
  const [numberOfDataPerPage, setNumberOfDataPerPage] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)
const [editRow, setEditRow]=useState({})
  const [data, setData] = useState({});
  let { list, selected, totalCount } = useSelector((state) => state.city);

  const dispatch = useDispatch();
  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();

  const allStates = useSelector((state) => state.state.list);
  const regionList = useSelector((state) => state.region.list);

  const handleFormSubmit = (values) => {
    let myRegion = regionList.filter((e) => e?.regionCode === values.region);
    let resp = false;

    if (type === "Edit") {
      // console.log(values.active, "akaakakaka")
      const body = {
        active: values.active,
        cityCode: values.cityCode,
        cityName: values.cityName,
        state: {
          stateId: values?.state,
        },
      };
      // body,
      // resp = dispatch(editCity({editRow,   id: selected?.cityId }));
      resp = dispatch(editCity({body,   id: selected?.cityId }));

    } else {
      resp = dispatch(addCity({ ...values, state: { stateId: values?.state } }));
    }
    resp && setCreateModal(false);
  };

  const onRegionSelect = (id, values) => {
    let paramas = id;
    var result = [];
    dispatch(getStateName(paramas)).then((res) => {
      for (let i of res.payload) {
        result.push({
          label: i?.stateName,
          value: i?.stateCode,
          countryName: i?.region?.zone?.country?.countryName,
          id: i.stateId,
        });
      }
      setActiveState([...result]);
    });
  };

  const hanldeRegionChange = (e, values) => {
    setRegionId(e?.value);
    return e?.value;
  };

  const hanldeStateChange = (e, values) => {
    const obj = {
      ...selected,
      state: {
        ...selected?.state,
        stateId: e?.id,
      },
    };
    const obj2 = {
      ...values,
      state: {
        stateId: e?.id,
      },
    };
    setStateId(e?.value);
    return type === "Edit" ? obj.state : obj2.state;
  };

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  useEffect(() => {
    setRegionId(createModal ? regionId : "");
    setStateId(createModal ? stateId : "");
  }, [createModal]);

  useEffect(() => {
    setRegionId(selected?.state?.region?.regionCode);
    setStateId(selected?.state?.stateCode);
    if (type === "Edit" && createModal) {
      onRegionSelect(selected?.state?.region?.regionId);
    }
  }, [selected]);

  useEffect(() => {
    dispatch(getAllStates());
  }, []);

  useEffect(() => {
    if (type === "Add" || type === "Edit") {
      dispatch(getAllRegion());
    }
  }, [type]);

  useEffect(() => {
    let tempRegion = [];
    regionList.forEach((region) => {
      if (region?.active === "Y")
        tempRegion.push({
          label: region.regionName,
          value: region.regionCode,
          id: region.regionId,
        });
    });

    selected = { ...selected, region: tempRegion };
    setActiveRegion([...tempRegion]);
  }, [regionList]);

  useEffect(() => {
    let tempState = [];
    allStates?.forEach((state) => {
      // if (state?.active === "Y")
      tempState.push({
        label: state.stateName,
        value: state.stateCode,
        countryName: state?.region?.zone?.country?.countryName,
        id: state.stateId,
      });
    });
    let state = "ASSAM";
    let cnt = "";

    for (let i = 0; i < tempState.length; i++) {
      if (tempState[i].label === state) {
        cnt = tempState[i].country;
        setSCity(cnt);
      }
    }

    selected = { ...selected, state: tempState };
    setActiveState([...tempState]);
  }, [allStates]);

  // console.log(selected, "CitySchemaCitySchema")
  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchCity(data))}
        getAllAPI={() => dispatch(getAllCity({
          currentPage,
          numberOfDataPerPage
        }))}
        numberOfDataPerPage={numberOfDataPerPage}
        currentPage={currentPage}
        onClick={() => {
          setCreateModal(!createModal);
          setType("Add");
        }}
        permission={user?.masterRole?.[access]}
        isPagination={true}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">Cities</CardHeader>
        <CardBody className="tableCardBody p-1 d-flex flex-column" style={{ minHeight: 400, padding: '5px' }}>
          <DataTable
            value={list}
            className="commonTable casesTable"
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            size={"small"}
            removableSort
          >
            <Column field="cityCode" header="City Code" sortable></Column>
            <Column field="cityName" header="City Name" sortable></Column>
            <Column
              field="region"
              header="Region"
              body={(rowData) => rowData?.state?.region?.regionName || "-"}
              sortable
            ></Column>
            <Column field="state.stateName" header="State Name" sortable></Column>

            {/* <Column
              field="state.country.countryName"
              header="Country Name"
            ></Column> */}
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData?.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            {/* {console.log(list, "rowdatata")} */}
            <Column
              header="Actions"
              body={(rowData) => (

                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let tempData = {
                          active: rowData?.active,
                          cityCode: rowData?.cityCode,
                          cityName: rowData?.cityName,
                          region: rowData.region,
                          stateCode: rowData.state.stateCode,
                          countryName: rowData?.state?.country?.countryName,
                          cityId: rowData.cityId,
                        };
                        console.log(rowData, "tempData")
                        dispatch(
                          setSelected({
                            ...rowData,
                            region: rowData?.region?.regionCode,
                            // stateCode:rowData.state.stateCode
                          })
                        );
                        setData({ ...tempData });
                        setCreateModal(!createModal);
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        // console.log(rowData, "rowdatataat")
                        setEditRow({
                          ...rowData,
                          region: rowData?.state?.region?.regionCode,
                          // stateCode:rowData.state.stateCode
                        })
                        dispatch(
                          setSelected({
                            ...rowData,
                            region: rowData?.state?.region?.regionCode,
                            // stateCode:rowData.state.stateCode
                          })
                        );
                        setCreateModal(!createModal);
                        setType("Edit");
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i className="bi bi-trash" style={{ cursor: "pointer" }} /> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
          <Pagination
            totalCount={totalCount}
            currentPage={currentPage}
            numberOfDataPerPage={numberOfDataPerPage}
            setCurrentPage={setCurrentPage}
            setNumberOfDataPerPage={setNumberOfDataPerPage}
          />
        </CardBody>
      </Card>
      <Dialog
        header="City Details"
        visible={createModal}
        style={{ width: "40vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={type !== "Add" ? { ...selected, state: selected?.state?.stateCode } : CitySchema}
          validationSchema={CityValidationSchema}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => {
            return (
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="City Code"
                      errorMessage={touched.cityCode && errors.cityCode}
                    >
                      <Input
                        disabled={type !== "Add"}
                        bsSize="sm"
                        type="text"
                        id="cityCode"
                        placeholder="Code"
                        value={values?.cityCode}
                        onChange={e => {
                          if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                            setFieldValue('cityCode', e?.target?.value)
                          }
                        }}
                        onBlur={handleBlur}
                        invalid={touched?.cityCode && Boolean(errors?.cityCode)}
                        autoComplete="off"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="City Name"
                      errorMessage={touched.cityName && errors.cityName}
                    >
                      <Input
                        disabled={type !== "Add"}
                        bsSize="sm"
                        type="text"
                        id="cityName"
                        placeholder="City Name"
                        value={values?.cityName}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={touched?.cityName && Boolean(errors?.cityName)}
                        autoComplete="off"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Region Name"
                      errorMessage={touched.region && errors.region}
                    >
                      <Select
                        isDisabled={type === "View"}
                        inputId="region"
                        name="region"
                        isClearable={true}
                        options={activeRegion}
                        closeMenuOnSelect={true}
                        hideSelectedOptions={false}
                        onChange={(e) => {
                          // setFieldValue("region", e?.value);
                          setFieldValue(
                            "region",
                            hanldeRegionChange(e, values)
                          );
                          onRegionSelect(e?.id, values);
                        }}
                        value={activeRegion.filter((v) => v.value === regionId)}
                        className={cx({
                          abc: touched.region && Boolean(errors.region),
                        })}
                        onBlur={handleBlur}
                        menuPosition={"fixed"}
                        classNamePrefix="react-select"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="State Name"
                      errorMessage={touched.state && errors.state}
                    >
                      <Select
                        isDisabled={type === "View"}
                        inputId="state"
                        name="state"
                        isClearable={true}
                        options={activeState}
                        closeMenuOnSelect={true}
                        hideSelectedOptions={false}
                        onChange={(e) => {
                          setFieldValue("state", e?.id);
                        }}
                        value={activeState.filter((v) => (v.id) === values?.state || v?.value === values?.state)}
                        className={cx({
                          abc: touched.state && Boolean(errors.state),
                        })}
                        onBlur={handleBlur}
                        menuPosition={"fixed"}
                        classNamePrefix="react-select"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Active"
                      errorMessage={touched.active && errors.active}
                    >
                      <FormGroup switch className="ms-2">
                        <Input
                          disabled={type === "View"}
                          type="switch"
                          checked={values?.active === "Y"}
                          onChange={(e) => {
                            setFieldValue(
                              "active",
                              e.target.checked ? "Y" : "N"
                            );
                          }}
                          id="active"
                          readOnly
                        />
                      </FormGroup>
                    </Field>
                  </Col>
                </Row>
                <div
                  className={`${type === "View" && "d-none"
                    } d-flex justify-content-end`}
                >
                  <Button type="submit" color="primary" className="me-1" size="sm">
                    Submit
                  </Button>
                  <Button
                    size="sm"
                    type="button"
                    color="danger"
                    onClick={() => setCreateModal(!createModal)}
                  >
                    Cancel
                  </Button>
                </div>
              </Form>
            )
          }}
        </Formik>
      </Dialog>
    </Container>
  );
}
