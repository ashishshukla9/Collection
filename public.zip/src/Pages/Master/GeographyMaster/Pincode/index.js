import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import {
  PincodeValidationSchema,
} from "../../../../Schema/GeographyMaster";
import Select from "react-select";
import cx from "classnames";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { setLoader } from "../../../../reducer/globalReducer";
import {
  addPincode,
  editPincode,
  getAllPincode,
  searchPinCode,
  setSelected,
} from "./store";
import { getAllCity } from "../City/store";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";
import Field from "../../../../components/Field";
import Pagination from "../../../../components/Pagination";
import axios from "axios";

export default function Pincode({ access }) {

  const [createModal, setCreateModal] = useState(false);
  const [type, setType] = useState("");
  const [cityOptions, setCityOptions] = useState([]);
  const [filteredOptions, setFilteredOptions] = useState(cityOptions);
  const [searchInput, setSearchInput] = useState("");
  const [selectedData, setSelectedData] = useState([])
  const [inputValue, setInputValue] = useState("");
  const [searchTerm, setSearchTerm] = useState(null);
  const [numberOfDataPerPage, setNumberOfDataPerPage] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)
  let { list, selected, totalCount } = useSelector((state) => state?.pincode);
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user.data);
  const allCities = useSelector((state) => state?.city?.list);
  const navigate = useNavigate();

  console.log(allCities, "selectes")

  const PincodeSchema = {
    // code: "",
    pincode: (type == "View" || type == "Edit") ? selectedData?.pincode : "",
    cityCode: (type == "View" || type == "Edit") ? { label: selectedData?.city?.cityName, value: selectedData?.city?.cityCode } : "",
    areaName: (type == "View" || type == "Edit") ? selectedData?.areaName : "",
    active: (type == "View" || type == "Edit") ? selectedData?.city?.active : "Y",
  };
  const handleInputChange = (input) => {
    setInputValue(input);
    const filtered = cityOptions.filter(option =>
      option.label.toLowerCase().includes(input.toLowerCase())
    );
    setFilteredOptions(filtered);
  };
  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  const handleFormSubmit = (values) => {
    let myCity = allCities.filter((e) => e?.cityCode === values.cityCode);


    let resp = false;
    dispatch(setLoader(true));
    if (type === "Edit") {
      resp = dispatch(
        editPincode({ ...values, id: selected?.pincodeId, city: myCity[0] })
      );
    } else {
      resp = dispatch(addPincode({ ...values, city: myCity[0] }));
    }
    resp && setCreateModal(false);
  };

  useEffect(() => {
    if (type === "Add" || type === "Edit") {
      dispatch(getAllCity());
    }
  }, [type]);

  // useEffect(() => {
  //   let tempCity = [];
  //   console.log(allCities, 'vbuyvguy')
  //   allCities.forEach((e) => {

  //     if (e?.active === "Y") {
  //       tempCity.push({ label: e.cityName, value: e.cityCode });
  //     }
  //   });
  //   setCityOptions([...tempCity]);
  // }, [allCities]);
  useEffect(() => {
    const tempCity = allCities
      .filter(e => e?.active === "Y")
      .map(e => ({ label: e.cityName, value: e.cityCode }));
    setCityOptions(tempCity);
  }, [allCities]);

  // creating the custom debouncing 
  const debounce = (func, delay) => {
    let timer;
    return function (...args) {
      const context = this;
      clearTimeout(timer);
      timer = setTimeout(() => func.apply(context, args), delay);
    };
  };
  //  implementy the city search functionality 
  const getFindCityByName = async () => {
    try {
      const res = await axios.get(`/getCityByCityName/${searchTerm}/0/0`);
      let tempCity = [];
      res.data?.response.forEach((e) => {
        if (e?.active === "Y") {
          tempCity.push({ label: e.cityName, value: e.cityId });
        }
      });
      setCityOptions([...tempCity]);
    } catch (error) {
      console.log(error, 'finalres');
    }
  };
  // Debounced search function
  const debouncedSearch = debounce(getFindCityByName, 300);
  //  city search functionality 
  useEffect(() => {
    if (searchTerm) {
      debouncedSearch(searchTerm);
    }
    if (!searchTerm) {
      dispatch(getAllCity());
    }
  }, [searchTerm]);
  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchPinCode(data))}
        getAllAPI={() => dispatch(getAllPincode({
          currentPage,
          numberOfDataPerPage
        }))}
        numberOfDataPerPage={numberOfDataPerPage}
        currentPage={currentPage}
        onClick={() => {
          setCreateModal(!createModal);
          setType("Add");
        }}
        permission={user?.masterRole?.[access]}
        isPagination={true}
      />
      <Card className="flex-grow-1 mb-1">
        <CardBody className="tableCardBody p-1 d-flex flex-column" style={{ minHeight: 400, padding: '5px' }}>
          <DataTable
            value={list}
            className="commonTable casesTable"
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            size={"small"}
            removableSort
          >
            <Column field="pincode" header="Pincode" sortable></Column>
            <Column field="city.cityName" header="City Name" sortable></Column>
            <Column field="areaName" header="Area Name" sortable></Column>
            <Column
              field="active"
              header="Status"
              body={(rowData) =>
                rowData?.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let cityCode = rowData.city?.cityCode;
                        dispatch(setSelected({ ...rowData, cityCode }));
                        setCreateModal(!createModal);
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let cityCode = rowData.city?.cityCode;
                        dispatch(setSelected({ ...rowData, cityCode }));
                        setCreateModal(!createModal);
                        setType("Edit");
                      }}
                    />
                  )}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
          <Pagination
            totalCount={totalCount}
            currentPage={currentPage}
            numberOfDataPerPage={numberOfDataPerPage}
            setCurrentPage={setCurrentPage}
            setNumberOfDataPerPage={setNumberOfDataPerPage}
          />
        </CardBody>
      </Card>
      <Dialog
        header="Pincode Details"
        visible={createModal}
        style={{ width: "40vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={type !== "Add" ? selected : PincodeSchema}
          validationSchema={PincodeValidationSchema}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Pin Code"
                    errorMessage={touched?.pincode && errors?.pincode}
                  >
                    <Input
                      disabled={type !== "Add"}
                      bsSize="sm"
                      type="number"
                      id="pincode"
                      placeholder="Pincode"
                      value={values?.pincode}
                      onChange={(e) => {
                        if (e.target.value.length <= 6)
                          setFieldValue("pincode", e.target.value);
                      }}
                      onBlur={handleBlur}
                      invalid={touched?.pincode && Boolean(errors?.pincode)}
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Area Name"
                    errorMessage={touched?.areaName && errors?.areaName}
                  >
                    <Input
                      disabled={type === "View"}
                      bsSize="sm"
                      type="text"
                      id="areaName"
                      placeholder="Area Name"
                      value={values?.areaName}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched?.areaName && Boolean(errors?.areaName)}
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field isRequired label="City">
                    <Select
                      isDisabled={type === "View"}
                      inputId="cityCode"
                      name="cityCode"
                      isClearable={true}
                      options={inputValue ? filteredOptions : cityOptions.slice(0, 10)} // Limit to 10 when not searching
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false}
                      onChange={(e) => setFieldValue("cityCode", e?.value)}
                      value={cityOptions.filter(v => v.value === values?.cityCode)}
                      placeholder={values?.city?.cityName}
                      className={cx(
                        {
                          abc: touched.cityCode && Boolean(errors.cityCode),
                        },
                        "selectTag"
                      )}
                      classNamePrefix="react-select"
                      onBlur={handleBlur}
                      onInputChange={handleInputChange} // Capture input changes
                      menuPosition={"fixed"}
                    />
                  </Field>
                </Col>
                {/* <Col lg={6} md={6} sm={12}>
                  <Field isRequired label="City">
                    <Select
                      isDisabled={type === "View"}
                      inputId="cityCode"
                      name="cityCode"
                      isClearable={true}
                      options={filteredOptions.length > 0 ? filteredOptions : [{ label: 'No options', value: '' }]}
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false} // Changed to false to show selected option
                      onChange={(e) => {
                        setFieldValue("cityCode", e?.value);
                        setInputValue(e?.label); // Optionally set input value to the selected label
                      }}
                      value={filteredOptions.find(option => option.value === values?.cityCode) || null} // Set the selected value
                      placeholder="Select a city..."
                      className={cx({
                        abc: touched.cityCode && Boolean(errors.cityCode),
                      }, "selectTag")}
                      classNamePrefix="react-select"
                      onBlur={handleBlur}
                      menuPosition={"fixed"}
                      onInputChange={(newValue) => {
                        setInputValue(newValue);
                        // Add your filtering logic here if needed to update filteredOptions
                      }} // Update input value
                      noOptionsMessage={() => inputValue ? 'No options' : 'Start typing to search...'} // Custom message for no options
                    />
                  </Field>
                </Col> */}
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Active"
                    errorMessage={touched?.active && errors?.active}
                  >
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        disabled={type === "View"}
                        checked={values?.active === "Y"}
                        onChange={(e) => {
                          setFieldValue("active", e.target.checked ? "Y" : "N");
                        }}
                        id="active"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div
                className={`${type === "View" && "d-none"
                  } d-flex justify-content-end`}
              >
                <Button
                  type="submit"
                  color="primary"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setCreateModal(!createModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}