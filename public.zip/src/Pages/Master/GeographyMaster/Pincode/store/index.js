import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../../../App.config";
import { setLoader } from "../../../../../reducer/globalReducer";
import Swal from "sweetalert2";

export const getAllPincode = createAsyncThunk(
  "pincode/getAllPincode",
  async (pinCodeParams, {dispatch}) => {
    dispatch(setLoader(true));
    try {
      const response = await axios.get(baseUrl() + `/getAllPincodes/${pinCodeParams?.currentPage}/${pinCodeParams?.numberOfDataPerPage}`);
      dispatch(setLoader(false));
      return {
        list: response?.data?.response,
        totalCount: response?.data?.totalApplicationCount
      
      };
    } catch (error) {
      dispatch(setLoader(false));
      throw new Error("Failed to fetch pincode data.");
    }                                                   
  }
);
// console.log(list, 'totalCount');                                                                                        

export const searchPinCode = createAsyncThunk(
  "state/searchPinCode",
  async (data,{dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(
        baseUrl() + `/getPincodeByPincode/${data?.search}/${data?.currentPage}/${data?.numberOfDataPerPage}`
      );
      dispatch(setLoader(false))
      return {
        list: response?.data?.response,
        totalCount: response?.data?.totalApplicationCount
      };
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error("Failed to fetch State data.");
    }
  }
);

export const addPincode = createAsyncThunk(
  
  "pincode/addPincode",
  async (params, { dispatch }) => {
    // console.log(params, 'rrr')
    dispatch(setLoader(true));
    
    try {
      const payload = {
        active:params?.active,
        areaName:params?.areaName,
        city:{
          cityId:params?.city.cityId},
        
        pincode:params?.pincode
      }
      // console.log(params, "fibnalparams")
    const res=  await axios.post(baseUrl() + "/createPincode", payload);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(setLoader(false))
      dispatch(getAllPincode({
        currentPage: 1,
        numberOfDataPerPage: 10
      }));
      return true;
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      throw new Error("Failed to fetch pincode data.");
    }
  }
);

export const editPincode = createAsyncThunk(
  "pincode/editPincode",
  
  async (params, { dispatch }) => {
    // console.log(params, 'vghhghj')
    dispatch(setLoader(true));
    try {
     const res= await axios.put(baseUrl() + `/updatePincode/${params?.id}`, params);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(getAllPincode({
        currentPage: 1,
        numberOfDataPerPage: 10
      }));
      dispatch(setLoader(false));
      return true;
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      throw new Error("Failed to fetch pincode data.");
    }
  }
);

export const pincode = createSlice({
  name: "pincode",
  initialState: {
    list: [],
    loader: false,
    error: "",
    selected: null,
    totalCount: 0
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null
        ? (state.selected = null)
        : (state.selected = action.payload);
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllPincode.fulfilled, (state, action) => {
      state.loading = false;
      state.list = action.payload.list;
      state.totalCount = action.payload?.totalCount
    });
    builder.addCase(searchPinCode.fulfilled, (state, action) => {
      state.loading = false;
      state.list = action.payload.list;
      state.totalCount = action.payload?.totalCount
    });
  },
});

export const { setSelected, setLoder } = pincode.actions;

export default pincode.reducer;
