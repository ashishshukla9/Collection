import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../../../App.config";
import { setLoader } from "../../../../../reducer/globalReducer";
import Swal from "sweetalert2";

export const getAllStates = createAsyncThunk(
  "state/getAllStates",
  async (params, {dispatch}) => {
    dispatch(setLoader(true));
    try {
      const response = await axios.get(baseUrl() + "/getAllStates");
      dispatch(setLoader(false));
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      throw new Error("Failed to fetch state data.");
    }
  }
);

export const addState = createAsyncThunk(
  "state/addState",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      const res =await axios.post(baseUrl() + "/createState", params);
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(getAllStates());
      return true;
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(setLoader(false));
      throw new Error("Failed to fetch state data.");
    }
  }
);
export const editState = createAsyncThunk(
  "state/editState",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      const res =await axios.put(baseUrl() + `/updateState/${params?.id}`, params);
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(getAllStates());
      return true;
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(setLoader(false));
      throw new Error("Failed to fetch state data.");
      
    }
  }
);

export const searchState = createAsyncThunk(
  'state/searchState',
  async(val) => {
    try {
      const res = await axios.get(`/getStateByStateName/${val}`)

      return{
        list: res?.data?.data
      }
    } catch (error) {
      console.log(error);
    }
  }
)

export const state = createSlice({
  name: "state",
  initialState: {
    list: [],
    loader: false,
    error: "",
    selected: null,
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null
        ? (state.selected = null)
        : (state.selected = action.payload);
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllStates.fulfilled, (state, action) => {
      state.loader = false;
      state.list = action.payload.list;
    });
    builder.addCase(searchState.fulfilled, (state, action) => {
      state.list = action.payload.list;
    });
  },
});

export const { setSelected, setLoder } = state.actions;

export default state.reducer;
