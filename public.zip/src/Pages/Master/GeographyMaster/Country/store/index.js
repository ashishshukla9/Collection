import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../../../App.config";
import { setLoader } from "../../../../../reducer/globalReducer";
import Swal from "sweetalert2";

export const getAllCountry = createAsyncThunk(
  "country/getAllCountry",
  async (params, {dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + "/getAllCountries");
      dispatch(setLoader(false))
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error("Failed to fetch country data.");
    }
  }
);

export const addCountry = createAsyncThunk(
  "country/addCountry",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true))
     const res=   await axios.post(baseUrl() + "/createCountry", params);
    //  console.log(res, "country")
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}"`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(getAllCountry());
      dispatch(setLoader(false))
      return true;
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}"`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      throw new Error("Failed to fetch country data.");
      
    }
  }
);
export const editCountry = createAsyncThunk(
  "country/editCountry",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true))
    const res=  await axios.put(baseUrl() + `/updateCountry/${params?.id}`, params);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}"`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(getAllCountry());
      dispatch(setLoader(false))
      return true;
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}"`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      throw new Error("Failed to fetch country data.");
    }
  }
);
export const searchCountry = createAsyncThunk(
  "country/search", 
  async (params , {dispatch}) => {
    try {
      dispatch(setLoader(true))
      const res=await axios.get(`/getCountryByCountryName/${params}`)
      dispatch(setLoader(false))
      return {
        list: res?.data?.data,
      };
    } catch (error) {
      
    }
  }
);

export const country = createSlice({
  name: "country",
  initialState: {
    list: [],
    loader: false,
    error: "",
    selected: null,
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null
        ? (state.selected = null)
        : (state.selected = action.payload);
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllCountry.fulfilled, (state, action) => {
      state.loader = false;
      state.list = action.payload.list;
    });
    builder.addCase(searchCountry.fulfilled, (state, action) => {
      state.list = action.payload.list;
    });
  },
});

export const { setSelected, setLoder } = country.actions;

export default country.reducer;
