import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import {
  ZoneSchema,
  ZoneValidationSchema,
} from "../../../../Schema/GeographyMaster";
import Select from "react-select";
import cx from "classnames";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addZone, editZone, getZone, setSelected, searchZone } from "./store";
import { getAllCountry } from "../Country/store";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";
import Field from "../../../../components/Field";
import { setLoader } from "../../../../reducer/globalReducer";
import { NO_SPACE } from "../../../../utils/regex";
export default function Zone({ access }) {
  const [createModal, setCreateModal] = useState(false);
  const [type, setType] = useState("Add");
  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { list, selected } = useSelector((state) => state.zone);
  const countryList = useSelector((state) => state?.country?.list);

  const [countryOptions, setCountryOptions] = useState([]);

  const handleSubmit = (values) => {
    const payload = {
      zoneCode: values?.zoneCode,
      zoneName: values?.zoneName,
      country: {
        countryId: countryList?.filter(a=>a?.countryCode === values?.country)[0]?.countryId

      },
      active: values?.active
    }
    
    let resp = false;
    dispatch(setLoader(true))
    let msg = "";
    if (type === "Edit") {
      resp = dispatch(editZone({ ...payload, id: selected?.zoneId }));
      msg = "Updated!";
    } else {
      resp = dispatch(addZone({ ...payload }));
      msg = "Created Successfully!";
    }
    
    if (resp) {
      setCreateModal(false);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: msg,
        showConfirmButton: false,
        toast: true,
        timer: 2000,
      });
    }
  };

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  useEffect(() => {
    dispatch(getAllCountry());
  }, []);

  useEffect(() => {
    let temp = [];
    countryList?.forEach((country) => {
      if (country.active === "Y")
        temp.push({ value: country.countryCode, label: country.countryName });
    });
    setCountryOptions([...temp]);
  }, [countryList]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchZone(data))}
        getAllAPI={() => dispatch(getZone())}
        onClick={() => {
          setCreateModal(!createModal);
          setType("Add");
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={list}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="zoneCode" header="Zone Code" sortable></Column>
            <Column field="zoneName" header="Zone Name" sortable></Column>
            <Column
              field="active"
              header="Status"
              body={(rowData) =>
                rowData.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setCreateModal(!createModal);
                        dispatch(setSelected(rowData));
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setCreateModal(!createModal);
                        dispatch(setSelected(rowData));
                        setType("Edit");
                      }}
                    />
                  )}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header="Zone Details"
        visible={createModal}
        style={{ width: "40vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={type !== "Add" ? selected : ZoneSchema}
          validationSchema={ZoneValidationSchema}
          onSubmit={handleSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Zone Code"
                    errorMessage={touched.zoneCode && errors.zoneCode}
                  >
                    <Input
                      disabled={type !== "Add" ? true : false}
                      bsSize="sm"
                      type="text"
                      id="zoneCode"
                      placeholder="Zone Code"
                      value={values.zoneCode}
                      onChange={e=>{
                        if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                          setFieldValue('zoneCode', e?.target?.value)
                        }
                      }}
                      onBlur={handleBlur}
                      invalid={touched.zoneCode && Boolean(errors.zoneCode)}
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Zone Name"
                    errorMessage={touched.zoneName && errors.zoneName}
                  >
                    <Input
                      disabled={type === "View" ? true : false}
                      bsSize="sm"
                      type="text"
                      id="zoneName"
                      placeholder="Zone Name"
                      value={values.zoneName}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched.zoneName && Boolean(errors.zoneName)}
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Country"
                    errorMessage={touched.country && errors.country}
                  >
                    <Select
                      isDisabled={type === "View"}
                      inputId="country"
                      name="country"
                      isClearable={true}
                      options={countryOptions}
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false}
                      onChange={(e) => setFieldValue("country", e?.value)}
                      value={countryOptions.filter(
                        (v) => v.value === values.country
                      )}
                      className={cx({
                        abc: touched.country && Boolean(errors.country),
                      })}
                      onBlur={handleBlur}
                      menuPosition={"fixed"}
                      classNamePrefix="react-select"
                    />
                  </Field>
                </Col>

                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Active"
                    errorMessage={touched.active && errors.active}
                  >
                    <FormGroup switch className="ms-2">
                      <Input
                        disabled={type === "View"}
                        type="switch"
                        checked={values.active === "Y"}
                        onChange={(e) => {
                          setFieldValue(
                            "active",
                            e.target.checked ? "Y" : "N"
                          );
                        }}
                        id="active"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div
                className={`${type === "View" && "d-none"
                  } d-flex justify-content-end`}
              >
                <Button type="submit" color="primary" className="me-1" size="sm">
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setCreateModal(!createModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}
