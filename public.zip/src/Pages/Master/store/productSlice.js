import { apiSlice } from "../../../features/api/apiSlice";

export const productApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getProduct: builder.query({
      query: () => ({
        url: "/getAllProduct",
        method: "GET",
      }),
      providesTags: ["PRODUCT"],
    }),
    addProduct: builder.mutation({
      query: (values) => ({
        url: "/createProduct",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["PRODUCT"],
    }),
    updateProduct: builder.mutation({
      query: (values) => ({
        url: `/updateProduct/${values.productId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["PRODUCT"],
    }),
  }),
});

export const {
  useGetProductQuery,
  useAddProductMutation,
  useUpdateProductMutation,
} = productApiSlice;
