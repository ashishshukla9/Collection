import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getState: builder.query({
      query: () => ({
        url: "/getAllStates",
        // url: "/getStateByRegion",

        method: "GET",
      }),

      providesTags: ["STATES"],
    }),
    getStateByRegion: builder.query({
      query: ({ ids }) => ({
        url: `/getStateByRegion/${ids && ids.length > 0 ? ids.join(",") : ""}`,
        method: "GET",
      }),

      providesTags: ["STATES"],
    }),
    addState: builder.mutation({
      query: (values) => ({
        url: "/createsStates",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["STATES"],
    }),
    updateState: builder.mutation({
      query: (values) => ({
        url: `/updatesStates/${values.statesId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["STATES"],
    }),
  }),
});

export const {
  useGetStateQuery,
  useGetStateByRegionQuery,
  useAddStateMutation,
  useUpdateStateMutation,
} = extendedApiSlice;
