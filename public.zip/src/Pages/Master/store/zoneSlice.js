import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getZone: builder.query({
      query: () => ({
        url: "/getAllZones",
        method: "GET",
      }),
      providesTags: ["ZONE"],
    }),
    addZone: builder.mutation({
      query: (values) => ({
        url: "/createZone",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["ZONE"],
    }),
    updatePortfolio: builder.mutation({
      query: (values) => ({
        url: `/updateZone/${values.zoneId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["ZONE"],
    }),
  }),
});

export const { useGetZoneQuery, useAddZoneMutation, useUpdateZoneMutation } =
  extendedApiSlice;
