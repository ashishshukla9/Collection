import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import axios from "axios";
import { setLoader } from "../../../reducer/globalReducer";
const initialState = {
    data: []
}

export const getProductData = createAsyncThunk(
    'product/getProductData',
    
    async (params,{dispatch}) => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get('/getAllProduct')
            // console.log(res, 'Product Data')
            dispatch(setLoader(false))
            return {
                data: res?.data?.data
            }
        } catch (error) {
            console.log(error);
            dispatch(setLoader(false))
        }
    }
)

export const searchProductData = createAsyncThunk(
    'product/searchProductData',
    async (val,{dispatch}) => {
        
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getProductByProductDescription/${val}`)
            dispatch(setLoader(false))

            return {
                data: res?.data?.data
            }
        } catch (error) {
            dispatch(setLoader(false))
        }
    }
)


const productMasterSlice = createSlice({
    name: 'productMasterSlice',
    initialState,
    extraReducers: (builder) => {
        builder.addCase(getProductData.fulfilled, (state, action) => {
            state.data = action?.payload?.data
        })
        builder.addCase(searchProductData.fulfilled, (state, action) => {
            state.data = action?.payload?.data
        })
    }
})

export default productMasterSlice.reducer;