import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";

import {
  PortfolioMasterSchema,
  portfolioMasterValidation,
} from "../../Schema/PortfolioMaster";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  useAddPortfolioMutation,
  useUpdatePortfolioMutation,
} from "./store/portfolioSlice";
import {
  getPortfolioData,
  searchPortfolioData,
} from "./store/portfolioMasterSlice";
import SearchBarHeader from "../../components/Header/SearchBarHeader";
import Field from "../../components/Field";
import axios from "axios";
import Swal from "sweetalert2";
import { setLoader } from "../../reducer/globalReducer";
import { NO_SPACE } from "../../utils/regex";

export default function PortfolioMaster({ access }) {
  const [createModal, setCreateModal] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  const [viewModal, setViewModal] = useState(false);
  const [data, setData] = useState({});

  const dispatch = useDispatch();
  const [addPortfolio] = useAddPortfolioMutation();
  const [updatePortfolio] = useUpdatePortfolioMutation();

  const user = useSelector((state) => state.user.data);
  const portfolioData = useSelector((state) => state?.portfolioMaster?.data);

  const navigate = useNavigate();

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  const handleFormSubmit = async (values) => {
    try {
      dispatch(setLoader(true))
      const res = await axios.post("/createPortfolio", values);
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        dispatch(getPortfolioData());

        Swal.fire({
          position: "top-end",
          icon: "success",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        setCreateModal(false);
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const handleUpdate = async (values) => {

    try {
      dispatch(setLoader(true))
      const res = await axios.put(
        `/updatePortfolio/${values?.portfolioId}`,
        values
      );
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        dispatch(getPortfolioData());

        Swal.fire({
          position: "top-end",
          icon: "success",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        setUpdateModal(false);
      }
    } catch (error) {
      dispatch(setLoader(false))

      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchPortfolioData(data))}
        getAllAPI={() => dispatch(getPortfolioData())}
        onClick={() => {
          setCreateModal(!createModal);
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">Portfolio Master</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={portfolioData}
            paginator
            className="commonTable"
            rows={10}
            // rowsPerPageOptions={[10, 20, 40, 80, "All"]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="portfolioCode" header="Code" sortable></Column>
            <Column
              field="portfolioDescription"
              header="Description"
              sortable
            ></Column>
            <Column
              field="portfolioCurrency"
              header="Currency"
              sortable
            ></Column>
            <Column
              field="active"
              header="Status"
              body={(rowData) =>
                rowData.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setViewModal(!viewModal);
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setUpdateModal(!updateModal);
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i className="bi bi-trash" style={{ cursor: "pointer" }} /> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header="Create Portfolio"
        visible={createModal}
        style={{ width: "60vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={PortfolioMasterSchema}
          validationSchema={portfolioMasterValidation}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Code"
                    errorMessage={touched.portfolioCode && errors.portfolioCode}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioCode"
                      placeholder="Code"
                      value={values.portfolioCode}
                      onChange={e => {
                        if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                          setFieldValue('portfolioCode', e?.target?.value)
                        }
                      }}
                      onBlur={handleBlur}
                      invalid={
                        touched.portfolioCode && Boolean(errors.portfolioCode)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Description"
                    errorMessage={
                      touched.portfolioDescription &&
                      errors.portfolioDescription
                    }
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioDescription"
                      placeholder="Description"
                      value={values.portfolioDescription}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.portfolioDescription &&
                        Boolean(errors.portfolioDescription)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Currency"
                    errorMessage={
                      touched.portfolioCurrency && errors.portfolioCurrency
                    }
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioCurrency"
                      placeholder="Currency"
                      value={values.portfolioCurrency}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.portfolioCurrency &&
                        Boolean(errors.portfolioCurrency)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Active">
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.active === "Y"}
                        onChange={(e) => {
                          setFieldValue("active", e.target.checked ? "Y" : "N");
                        }}
                        id="active"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <Button
                  type="submit"
                  color="primary"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setCreateModal(!createModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>

      {/* Modal to Update data */}
      <Dialog
        header="Update Portfolio"
        visible={updateModal}
        style={{ width: "60vw" }}
        onHide={() => setUpdateModal(!updateModal)}
      >
        <Formik
          initialValues={data}
          validationSchema={portfolioMasterValidation}
          onSubmit={handleUpdate}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Code"
                    errorMessage={touched.portfolioCode && errors.portfolioCode}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioCode"
                      placeholder="Code"
                      value={values.portfolioCode}
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Description"
                    errorMessage={
                      touched.portfolioDescription &&
                      errors.portfolioDescription
                    }
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioDescription"
                      placeholder="Description"
                      value={values.portfolioDescription}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.portfolioDescription &&
                        Boolean(errors.portfolioDescription)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Currency"
                    errorMessage={
                      touched.portfolioCurrency && errors.portfolioCurrency
                    }
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioCurrency"
                      placeholder="Currency"
                      value={values.portfolioCurrency}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.portfolioCurrency &&
                        Boolean(errors.portfolioCurrency)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Active">
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.active === "Y"}
                        onChange={(e) => {
                          setFieldValue("active", e.target.checked ? "Y" : "N");
                        }}
                        id="active"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <Button
                  type="submit"
                  color="primary"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setUpdateModal(!updateModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>

      {/* Modal to View data */}
      <Dialog
        visible={viewModal}
        style={{ width: "60vw" }}
        onHide={() => setViewModal(!viewModal)}
      >
        <Formik
          initialValues={data}
          validationSchema={portfolioMasterValidation}
        >
          {({ values }) => (
            <Form>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Code">
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioCode"
                      placeholder="Code"
                      value={values.portfolioCode}
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Description">
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioDescription"
                      placeholder="Description"
                      value={values.portfolioDescription}
                      autoComplete="off"
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Currency">
                    <Input
                      bsSize="sm"
                      type="text"
                      id="portfolioCurrency"
                      placeholder="Currency"
                      value={values.portfolioCurrency}
                      autoComplete="off"
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field label="Active">
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.active === "Y"}
                        id="active"
                        readOnly
                        disabled
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
            </Form>
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}
