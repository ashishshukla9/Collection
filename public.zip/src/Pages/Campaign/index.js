import React from "react";
import StatsCard from "../../components/PDFDocument/StatsCard";
import { PDFDownloadLink } from "@react-pdf/renderer";
import { Button } from "reactstrap";

export default function Cases() {
  return (
    <>
      <PDFDownloadLink
        document={<StatsCard title={"1st Pdf"} />}
        fileName="StatsCard"
      >
        {({ loading, error }) =>
          loading ? (
            <Button color="secondary"size="sm">Loading Document.....</Button>
          ) : (
            <Button color="primary"size="sm">Download</Button>
          )
        }
      </PDFDownloadLink>
      <StatsCard title={"1st Pdf"} />
    </>
  );
}
