import {
  Form,
  FormGroup,
  Input,
  Row,
  Col,
  Button,
  Card,
  CardBody,
  Label,
  Nav,
  NavItem,
  NavLink,
  TabContent,
  TabPane,
  CardTitle,
  CardText,
} from "reactstrap";
import { Formik } from "formik";
import classnames from "classnames";
import CustomField from "../../components/Field";
import React, { Fragment, useEffect, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import * as yup from "yup";
import { scrollToErrorMessage } from "../../utils/commonFun";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";
const SceduleCampaginForm = ({
  recurringmodal,
  gteViewData,
  setRecuuringModal,
  campaigSchedule,
  setCampaginSchedule,
  getAllcapaginSchedualList,
  setResetForm,
  data,
  viewIsClicked,
  isEdit,
  onClose
}) => {
  const user = useSelector((state) => state.user.data);
  const dispatch = useDispatch()

  // console.log(data, "dadddadaadaad")
  const Intitalvalues = {
    time: (viewIsClicked || isEdit) ? gteViewData?.time : "",
    startDate: (viewIsClicked || isEdit) ? gteViewData?.startDate : "",
    endType: (viewIsClicked || isEdit) ? gteViewData?.endType : "",
    onDay: (viewIsClicked || isEdit) ? gteViewData?.onDay?.split(",") : [],
    endDate: (viewIsClicked || isEdit) ? gteViewData?.endDate : "",
    scheduleType: (viewIsClicked || isEdit) ? gteViewData?.scheduleType : "",
    active: (viewIsClicked || isEdit) ? gteViewData?.active : true
  };

  const Validation = yup.object({
    startDate: yup.string().required("Required"),
    time: yup.string().required("Required"),

    onDay: yup.array().when("recurringmodal", {
      is: () => recurringmodal,
      then: () => yup.array().required("Required"),
    }),
    endType: yup.string().when("recurringmodal", {
      is: () => recurringmodal,
      then: () => yup.string().required("Required"),
    }),
    endDate: yup.string().when("endType", {
      is: (endType) => recurringmodal && endType === "On a specific date",
      then: () => yup.string().required("Required"),
    }),
  });

  const recurringValidation=yup.object({
    startDate: yup.string().required("Required"),
    time: yup.string().required("Required"),
    onDay: yup.array().when("recurringmodal", {
      is: () => recurringmodal,
      then: () => yup.array().min(1).required("Required"),
    }),
    endType: yup.string().when("recurringmodal", {
      is: () => recurringmodal,
      then: () => yup.string().required("Required"),
    }),
    endDate: yup.string().when("endType", {
      is: (endType) => recurringmodal && endType === "On a specific date",
      then: () => yup.string().required("Required"),
    }),    
  })

  const [selectedButton, setSelectedButton] = useState(
    (viewIsClicked || isEdit) ? gteViewData?.scheduleType : "One Time"
  );

  const switchForm = (e) => {
    // console.log("kya mila", e.target.name);
    setSelectedButton(e?.target?.name);

    if (e?.target?.name === "recurring") {
      setRecuuringModal(true);
    } else {
      setRecuuringModal(false);
      setCampaginSchedule(true);
    }
  };

  useEffect(() => {
    if ((viewIsClicked || isEdit) && gteViewData?.scheduleType === "recurring") {
      setRecuuringModal(true);
    } else {
      setRecuuringModal(false);
    }
  }, []);

  useEffect(() => { }, [setRecuuringModal]);

  const createCampaingScedule = async (values, { resetForm }) => {
    if(isEdit){ 
      try {
        dispatch(setLoader(true))
        const res=await axios.put(`/updateScheduleActivation/${gteViewData?.campaignScheduleId}/${values?.active}`)
        dispatch(setLoader(false))

        if (res?.data?.msgKey === "Success") {
          resetForm({
            values: {
              time: "",
              startDate: "",
              endType: "",
              onDay: "",
              endDate: "",
              scheduleType: "",
            },
          });
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `${res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          getAllcapaginSchedualList();
          setCampaginSchedule(!campaigSchedule);
          setResetForm();
        }

      } catch (error) {
        dispatch(setLoader(false))
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    }else{
      const payload = {
        campaignId: null,
        channel: data?.channel.value,
        campaignName: data?.campaignName,
        templateName: data?.templateName.value,
        campaignFor: data?.campaignFor,
        uid: user?.userId,
        active: values?.active,
        campaignSchedule: {
          scheduleType: values.scheduleType || "One Time",
          time: values.time,
          startDate: values.startDate,
          endDate:
            selectedButton === "One Time" ? values.startDate : values.endDate,
          onDay: values.onDay.join(","),
          endType: values.endType,
        },
      };
  
      try {
        dispatch(setLoader(true))
        await axios.post("/addCampaign", payload).then((res) => {
          if (res?.data?.msgKey === "Success") {
            resetForm({
              values: {
                time: "",
                startDate: "",
                endType: "",
                onDay: "",
                endDate: "",
                scheduleType: "",
              },
            });
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: `{res.data.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
            getAllcapaginSchedualList();
            setCampaginSchedule(!campaigSchedule);
            setResetForm();
          }
  
          Swal.fire({
            position: "top-end",
            icon: res?.data?.msgKey === "Failure" ? "error" : "success",
            title: `${res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
        dispatch(setLoader(false))
      } catch (error) {
        dispatch(setLoader(false))
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    }
    
  };

  const handleCheckboxChange = (e, setFieldValue, values) => {
    let condition = e.target.checked;

    let selectedDay = e.target.value;
    if (condition) {
      setFieldValue("onDay", [...values.onDay, selectedDay]);
    } else {
      const a = values.onDay.indexOf(selectedDay);

      let ondays = values.onDay;
      ondays.splice(a, 1);

      setFieldValue("onDay", ondays);
    }
  };

  return (
    <>
      <Formik
        initialValues={Intitalvalues}
        // Validation
        validationSchema={recurringmodal ? recurringValidation :Validation}
        onSubmit={createCampaingScedule}
      >
        {({
          values,
          errors,
          handleChange,
          handleBlur,
          touched,
          handleSubmit,
          setFieldValue,
          setFieldError,
          isSubmitting,
        }) => {
          
          const err = Object.keys(errors)[0];
          scrollToErrorMessage(isSubmitting, err);
          return (
            <Form onSubmit={handleSubmit}>
              <Card>
                <CardBody>
                  <Row>
                    <h6>Select a date and time to Schedule campaign launch</h6>

                    <div className="d-flex gap-3 p-2 mb-2 mt-2">
                      <Button
                        disabled={(viewIsClicked || isEdit)}
                        className={classnames(
                          "btn",
                          selectedButton === "One Time"
                            ? "btn-success"
                            : "btn-light"
                        )}
                        size="sm"
                        type="button"
                        name="One Time"
                        // onClick={(e) => {
                        //   setFieldValue("scheduleType", e?.target?.name);
                        //   if (e?.target?.name === "One Time") {
                        //     setCampaginSchedule(true);
                        //   }
                        // }}
                        onClick={(e) => {
                          setFieldValue("scheduleType", e?.target?.name);
                          switchForm(e);
                        }}
                      >
                        One Time Only
                      </Button>
                      <Button
                        disabled={(viewIsClicked || isEdit)}
                        size="sm"
                        type="button"
                        name="recurring"
                        className={classnames(
                          "btn",
                          selectedButton === "recurring"
                            ? "btn-success"
                            : "btn-light"
                        )}
                        // onClick={(e) => {
                        //   setFieldValue("scheduleType", e?.target?.name);

                        //   if (e?.target?.name === "recurring") {
                        //     setRecuuringModal(true);

                        //   } else {
                        //     setCampaginSchedule(true);
                        //   }
                        // }}
                        onClick={(e) => {
                          setFieldValue("scheduleType", e?.target?.name);
                          switchForm(e);
                        }}
                      >
                        Recurring
                      </Button>
                    </div>
                  </Row>

                  <Card>
                    <CardBody>
                    {recurringmodal &&
                      <Fragment>
                        <CustomField
                          isRequired
                          label="Recurring"
                          errorMessage={touched.time && errors.time}
                        >
                          <Input
                            bsSize="sm"
                            type="time"
                            id="time"
                            placeholder="HH.MM"
                            value={values.time}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={
                              touched.time && Boolean(errors.time)
                            }
                            disabled={(viewIsClicked || isEdit)}
                          />
                        </CustomField>
                        <CustomField
                          isRequired
                          label="On"
                          errorMessage={touched.onDay && errors.onDay}
                          childrenClassName='campaignOnFieldGrp'
                        >
                          {/* <div className="d-flex justify-conetent-between gap-2"> */}
                          <FormGroup className="campaignOnField">
                            <Label>
                              <Input
                                type="checkbox"
                                value="Sunday"
                                disabled={(viewIsClicked || isEdit)}
                                // onChange={(e) => {
                                //   console.log("543435", e);
                                //   setFieldValue(
                                //     "onDay",
                                //     e.target.value
                                //   );
                                // }}
                                onChange={(e) =>
                                  handleCheckboxChange(
                                    e,
                                    setFieldValue,
                                    values
                                  )
                                }
                                checked={values?.onDay?.includes(
                                  "Sunday"
                                )}
                              />{" "}
                              Sun
                            </Label>
                            {/* <span style={{color: "red"}}>{errors?.onDay}</span> */}
                          </FormGroup>
                          <FormGroup className='campaignOnField'>
                            <Label>
                              <Input
                                disabled={(viewIsClicked || isEdit)}
                                type="checkbox"
                                value="Monday"
                                onChange={(e) =>
                                  handleCheckboxChange(
                                    e,
                                    setFieldValue,
                                    values
                                  )
                                }
                                checked={values?.onDay?.includes(
                                  "Monday"
                                )}
                              />{" "}
                              Mon
                            </Label>
                          </FormGroup>
                          <FormGroup className='campaignOnField'>
                            <Label>
                              <Input
                                disabled={(viewIsClicked || isEdit)}
                                type="checkbox"
                                value="Tuesday"
                                onChange={(e) =>
                                  handleCheckboxChange(
                                    e,
                                    setFieldValue,
                                    values
                                  )
                                }
                                checked={values?.onDay?.includes(
                                  "Tuesday"
                                )}
                              />{" "}
                              Tue
                            </Label>
                          </FormGroup>
                          <FormGroup className='campaignOnField'>
                            <Label>
                              <Input
                                type="checkbox"
                                disabled={(viewIsClicked || isEdit)}
                                value="Wednesday"
                                onChange={(e) =>
                                  handleCheckboxChange(
                                    e,
                                    setFieldValue,
                                    values
                                  )
                                }
                                checked={values?.onDay?.includes(
                                  "Wednesday"
                                )}
                              />{" "}
                              Wed
                            </Label>
                          </FormGroup>
                          <FormGroup className='campaignOnField'>
                            <Label>
                              <Input
                                type="checkbox"
                                value="Thursday"
                                disabled={(viewIsClicked || isEdit)}
                                onChange={(e) =>
                                  handleCheckboxChange(
                                    e,
                                    setFieldValue,
                                    values
                                  )
                                }
                                checked={values?.onDay?.includes(
                                  "Thursday"
                                )}
                              />{" "}
                              Thu
                            </Label>
                          </FormGroup>
                          <FormGroup className='campaignOnField'>
                            <Label>
                              <Input
                                type="checkbox"
                                value="Friday"
                                disabled={(viewIsClicked || isEdit)}
                                onChange={(e) =>
                                  handleCheckboxChange(
                                    e,
                                    setFieldValue,
                                    values
                                  )
                                }
                                checked={values?.onDay?.includes(
                                  "Friday"
                                )}
                              />{" "}
                              Fri
                            </Label>
                          </FormGroup>
                          <FormGroup className='campaignOnField'>
                            <Label>
                              <Input
                                type="checkbox"
                                name="sat"
                                disabled={(viewIsClicked || isEdit)}
                                value="Saturday"
                                onChange={(e) =>
                                  handleCheckboxChange(
                                    e,
                                    setFieldValue,
                                    values
                                  )
                                }
                                checked={values?.onDay?.includes(
                                  "Saturday"
                                )}
                              />{" "}
                              Sat
                            </Label>
                          </FormGroup>
                          {/* </div> */}
                        </CustomField>

                        <CustomField
                          isRequired
                          label="Date"
                          errorMessage={
                            touched.startDate && errors.startDate
                          }
                        >
                          <Input
                            bsSize="sm"
                            type="date"
                            id="startDate"
                            value={values.startDate}
                            disabled={viewIsClicked}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={
                              touched.startDate &&
                              Boolean(errors.startDate)
                            }
                          />
                        </CustomField>

                        <CustomField
                          isRequired
                          label="End "
                          errorMessage={
                            touched.endType && errors.endType
                          }
                        >
                          <FormGroup check>
                            <Label check>
                              <Input
                                type="radio"
                                disabled={viewIsClicked}
                                value="Never keep as on-going campaign"
                                onChange={(e) =>
                                  setFieldValue(
                                    "endType",
                                    e.target.value
                                  )
                                }
                                checked={
                                  values.endType ===
                                  "Never keep as on-going campaign"
                                }
                              />{" "}
                              Never keep as on-going campaign
                            </Label>
                          </FormGroup>
                          <FormGroup check>
                            <Label check>
                              <Input
                                type="radio"
                                disabled={viewIsClicked}
                                value="On a specific date"
                                onChange={(e) =>
                                  setFieldValue(
                                    "endType",
                                    e.target.value
                                  )
                                }
                                checked={
                                  values.endType ===
                                  "On a specific date"
                                }
                              />{" "}
                              On a specific date
                            </Label>
                          </FormGroup>
                        </CustomField>
                        {values?.endType === "On a specific date" ? (
                          <CustomField
                            isRequired
                            label="End Date"
                            errorMessage={
                              touched.endDate && errors.endDate
                            }
                          >
                            <Input
                              type="date"
                              name="endDate"
                              id="endDate"
                              disabled={viewIsClicked}
                              value={values.endDate}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.startDate &&
                                Boolean(errors.startDate)
                              }
                            />
                          </CustomField>
                        ) : ("")}
                        </Fragment>
                      }
                      {campaigSchedule && (
                        <div style={{ display: recurringmodal ? "none" : "block" }}>
                          <CustomField
                            isRequired
                            label="Time"
                            errorMessage={touched.time && errors.time}
                          >
                            <Input
                              bsSize="sm"
                              type="time"
                              id="time"
                              placeholder="HH.MM"
                              disabled={(viewIsClicked || isEdit)}
                              value={values.time}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.time && Boolean(errors.time)
                              }
                            />
                          </CustomField>
                          <CustomField
                            isRequired
                            label="Date"
                            errorMessage={
                              touched.startDate && errors.startDate
                            }
                          >
                            <Input
                              bsSize="sm"
                              type="date"
                              id="startDate"
                              disabled={(viewIsClicked || isEdit)}
                              value={values.startDate}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.startDate &&
                                Boolean(errors.startDate)
                              }
                            />
                          </CustomField>
                        </div>
                      )}
                      <CustomField label="Active">
                        <FormGroup switch className="ms-2">
                          <Input
                            type="switch"
                            checked={values.active === true}
                            onChange={(e) =>
                              setFieldValue(
                                "active",
                                e.target.checked ? true : false
                              )
                            }
                            id="active"
                            // disabled={(viewIsClicked || isEdit)}
                            disabled={gteViewData?.active? false :true}
                            // readOnly
                          />
                        </FormGroup>
                      </CustomField>
                    </CardBody>
                  </Card>
                  <div className="d-flex justify-content-end  p-2">
                    <Button
                      size="sm"
                      color="success"
                      type="submit"
                      disabled={(viewIsClicked)}
                      style={{ color: "#fff" }}
                      className="me-1"
                    onClick={() => {
                      // setCampaginSchedule(!campaigSchedule);
                    }}
                    >
                      Submit
                    </Button>
                    <Button
                      size="sm"
                      color="danger"
                      type="button"
                      style={{ color: "#fff" }}
                      onClick={onClose}
                    >
                      Cancel
                    </Button>
                  </div>
                </CardBody>
              </Card>
              <div></div>
            </Form>
          );
        }}
      </Formik>
    </>
  );
};

export default SceduleCampaginForm;
