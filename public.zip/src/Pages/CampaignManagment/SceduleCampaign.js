import {
  Form,
  FormGroup,
  Input,
  Row,
  Col,
  Button,
  FormFeedback,
  Card,
  CardBody,
  Label,
  CardHeader,
  Table,
  Container,
} from "reactstrap";
import Swal from "sweetalert2";
import React, { useEffect, useState } from "react";
import axios from "axios";
import cx from "classnames";
import { Dialog } from "primereact/dialog";
import * as yup from "yup";
import { Formik } from "formik";
import { scrollToErrorMessage } from "../../utils/commonFun";
import CustomField from "../../components/Field";
import Select, { components } from "react-select";
import MyCapaignTable from "./MyCapaignTable";
import SceduleCampaginForm from "./SceduleCampaignForm";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";

const SceduleCampagin = () => {
  const [allTemplateNameList, setAllTemplateNameList] = useState([]);
  const [campaigSchedule, setCampaginSchedule] = useState(false);
  const [viewIsClicked, setViewIsCliked] = useState(false);
  const [list, getList] = useState([]);
  const [recurringmodal, setRecuuringModal] = useState(false);

  const [gteViewData, setGetViewData] = useState();
  const [data, setData] = useState();
  const [channelType, setChannelType] = useState();
  const [edit,setEdit]=useState(false)

  const dispatch=useDispatch()

  const channelOptions = [
    { label: "Email", value: "Email" },
    { label: "SMS", value: "SMS" },
  ];



  useEffect(() => {
    if(channelType?.value){
      try {
        axios
          .get(`/getCampaignTemplatesByChannel/${channelType?.value}`)
          .then((res) => {
            let options = [];
            res?.data?.data?.map((data) => {
              options.push({
                label: data.templateName,
                value: data.templateName,
                type: data.templateType,
              });
  
              // setCampaignFor(data.templateType)
            });
            setAllTemplateNameList(options);
          });
      } catch (error) {}
    }
  }, [channelType]);
  // Scedule Capagin

  const SceduleCapaginInitialval = {
    channel: "",
    campaignName: "",
    templateName: "",
    campaignFor: "",
    // time: view ? gteViewData.time : "",
    // startDate: "",
    // endType: "",
    // onDay: "",
    // endDate: "",
    // scheduleType: "",
  };

  const SceduleCapaginValidation = yup.object({
    channel: yup.object().required("Required"),
    campaignName: yup.string().required("Required"),
    templateName: yup.object().required("Required"),
    campaignFor: yup.string().required("Required"),
  });

  const getAllcapaginSchedualList = async () => {
    try {
      dispatch(setLoader(true))
      await axios.get("/getAllCampaigns").then((res) => {
        getList(res.data.data);
      });
      dispatch(setLoader(false))
    } catch (error) {
      dispatch(setLoader(false))
      console.log(error);
    }
  };

  const onClose=()=>{
    setCampaginSchedule(false)
    setEdit(false)
    setViewIsCliked(false)
  }

  useEffect(() => {
    getAllcapaginSchedualList();
  }, []);

  const createCampaingScedule = async (values) => {
    setViewIsCliked(false);
    setData(values);
    const requiredFields = [
      "channel",
      "campaignName",
      "templateName",
      "campaignFor",
    ];
    const allFieldsPresent = requiredFields.every((field) => values[field]);

    if (allFieldsPresent) {
      setCampaginSchedule(true);
    } else {
      console.error("Please fill out all required fields.");
    }
  };

  return (
    <Container
      fluid
      className="d-flex flex-column flex-grow-1 p-0 "
      style={{ overflowY: "scroll" }}
    >
      <Formik
        initialValues={SceduleCapaginInitialval}
        validationSchema={SceduleCapaginValidation}
        onSubmit={createCampaingScedule}
      >
        {({
          values,
          errors,
          handleChange,
          handleBlur,
          touched,
          handleSubmit,
          setFieldValue,
          setFieldError,
          isSubmitting,
          resetForm,
        }) => {
          const err = Object.keys(errors)[0];
          scrollToErrorMessage(isSubmitting, err);
          return (
            <Form onSubmit={handleSubmit}>
              <Card className="mb-3 p-3 bg-light">
                <CardBody>
                  <Row>
                    <Col>
                      <CustomField
                        isRequired
                        errorMessage={touched.channel && errors.channel}
                      >
                        <label>Channel</label>

                        <Select
                          id="channel"
                          inputId="channel"
                          placeholder="Channel Type"
                          options={channelOptions}
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}
                          value={values.channel}
                          onChange={(e) => {
                            setFieldValue("channel", e);
                            setChannelType(e);
                          }}
                          className={cx({
                            abc: touched.channel && Boolean(errors.channel),
                          })}
                          onBlur={handleBlur}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </CustomField>
                    </Col>

                    <Col>
                      <CustomField
                        isRequired
                        errorMessage={
                          touched.campaignName && errors.campaignName
                        }
                      >
                        <label>Campaign Name</label>

                        <Input
                          bsSize="sm"
                          type="text"
                          id="campaignName"
                          placeholder="Campaign Name"
                          value={values.campaignName}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={
                            touched.campaignName && Boolean(errors.campaignName)
                          }
                        />
                      </CustomField>
                    </Col>

                    <Col>
                      <CustomField
                        isRequired
                        errorMessage={
                          touched.templateName && errors.templateName
                        }
                      >
                        <label>Template Name</label>

                        <Select
                          id="templateName"
                          inputId="templateName"
                          placeholder="Template Name"
                          options={allTemplateNameList}
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}
                          value={values.templateName}
                          onChange={(e) => {
                            setFieldValue("templateName", e);
                            setFieldValue("campaignFor", e.type);
                          }}
                          className={cx({
                            abc:
                              touched.templateName &&
                              Boolean(errors.templateName),
                          })}
                          onBlur={handleBlur}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </CustomField>
                    </Col>

                    <Col>
                      <CustomField
                        isRequired
                        errorMessage={touched.campaignFor && errors.campaignFor}
                      >
                        <label>Campaign For</label>

                        <Input
                          bsSize="sm"
                          type="text"
                          id="campaignFor"
                          placeholder="Lender Name"
                          value={values.campaignFor}
                          onBlur={handleBlur}
                          invalid={
                            touched.campaignFor && Boolean(errors.campaignFor)
                          }
                          disabled
                        />
                      </CustomField>
                    </Col>

                    <Col>
                      <Button
                        color="success"
                        type="submit"
                        style={{ color: "#fff" }}
                        className="me-1 mt-4"
                      >
                        Campaign Schedule
                      </Button>
                    </Col>
                    {/* <Col>
                      <Button
                        color="primary"
                        type="submit"
                        style={{ color: "#fff" }}
                        className="me-1 mt-4"
                      >
                        Create Campaign
                      </Button>
                    </Col> */}
                  </Row>
                </CardBody>
              </Card>

              <Dialog
                header="Schedule Your Campaign"
                visible={campaigSchedule}
                style={{ width: "35vw" }}
                onHide={onClose}
              >
                <SceduleCampaginForm
                  getAllcapaginSchedualList={getAllcapaginSchedualList}
                  data={data}
                  recurringmodal={recurringmodal}
                  gteViewData={gteViewData}
                  setRecuuringModal={setRecuuringModal}
                  campaigSchedule={campaigSchedule}
                  setCampaginSchedule={setCampaginSchedule}
                  setResetForm={resetForm}
                  viewIsClicked={viewIsClicked}
                  isEdit={edit}
                  onClose={onClose}
                />
              </Dialog>
            </Form>
          );
        }}
      </Formik>

      <br></br>
      <MyCapaignTable
        setCampaginSchedule={setCampaginSchedule}
        setView={setViewIsCliked}
        setEdit={setEdit}
        setGetViewData={setGetViewData}
        list={list}
      />
    </Container>
  );
};

export default SceduleCampagin;
