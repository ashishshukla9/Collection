import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import {
  Row,
  Button,
  Card,
  CardHeader,
  Container,
} from "reactstrap";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import "react-quill/dist/quill.snow.css";
import SceduleCampagin from "./SceduleCampaign";
import { useDispatch } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";
import CampaignForm from "./CampaignForm";
const CampaignManagemnt = () => {
  const [createModal, setCreateModal] = useState(false);
  const [allTemplate, setAllTemplate] = useState();
  const [getVariables, setGetVariables] = useState([]);
  const [agencyData, setAgencyData] = useState([])
  const [stateData, setStateData] = useState([])
  const [pincodeData, setPincodeData] = useState([])
  const [zoneData, setZoneData] = useState([])
  const [regionData, setRegionData] = useState([])
  const [cityData, setCityData] = useState([])
  const [lenderData, setLenderData] = useState([])
  const [productData, setProductData] = useState([])
  const [portfolioData, setPortfolioData] = useState([])
  const [selectedTemplate, setSelectedTemplate] = useState({})
  const dispatch = useDispatch()
  const getTableDetails = () => {
    try {
      dispatch(setLoader(true))
      axios.get("/getAllCampaignTemplates").then((res) => {
        setAllTemplate(res.data.data);
      });
      dispatch(setLoader(false))
    } catch (error) {
      dispatch(setLoader(false))
    }
  };
  useEffect(() => {
    getTableDetails();
  }, []);
  useEffect(() => {
    try {
      dispatch(setLoader(true))
      axios.get("/getAllActiveVariables").then((res) => {
        setGetVariables(res.data.data);
      });
      dispatch(setLoader(false))
    } catch {
      dispatch(setLoader(false))
    }
  }, []);
  const getAllState = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get('/getAllStates')
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        const options = res?.data?.data?.map(a => {
          return {
            label: a.stateName,
            value: a.stateCode,
            stateId: a?.stateId
          }
        })
        setStateData(options)
        // console.log(stateData, 'guyguygg')
      } else {
        setStateData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  const getAllCity = async () => {
    try {
      const response = await axios.get('/getAllCities/1/2815');
      // console.log(response, 'hgvyugfyu')
      const cityArray = response.data.response;
      if (Array.isArray(cityArray)) {
        const cities = cityArray.map(city => ({
          label: city.cityName,
          value: city.cityId
        }));
        setCityData(cities);
        // console.log('Filtered cities:', cityData);
      } else {
        console.error('Unexpected data format:', response.data);
      }
    } catch (error) {
      console.error('Error fetching cities:', error);
    }
  };
  const getAllAgency = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllAgency")
      // console.log(res, 'ghfytftfyu')
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        const options = res?.data?.data?.map(a => {
          return {
            label: a?.agencyName,
            value: a?.agencyId
          }
        })
        setAgencyData(options)
      } else {
        setAgencyData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  const getAllPinCodes = async () => {
    try {
      const response = await axios.get('/getAllPincodes/1/10');
      // console.log(response, 'hgvyugfyufge')
      const cityArray = response.data.response;
      if (Array.isArray(cityArray)) {
        const pincodes = cityArray.map(pincode => ({
          label: pincode.pincode,
          value: pincode.pincode
        }));
        setPincodeData(pincodes);
        // console.log('Filtered cities:', cityData);
      } else {
        console.error('Unexpected data format:', response.data);
      }
    } catch (error) {
      console.error('Error fetching cities:', error);
    }
  };
  const getAllZone = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllZones")
      // console.log(res, 'ghfytftfyu')
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        const options = res?.data?.data?.map(a => {
          return {
            label: a.zoneName,
            value: a.zoneCode,
            zoneId: a?.zoneId
          }
        })
        setZoneData(options)
      } else {
        setZoneData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  const getAllRegion = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllRegions")
      // console.log(res, 'ghfytftfyu')
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        const options = res?.data?.data?.map(a => {
          return {
            label: a.regionName,
            value: a.regionCode,
            regionId: a?.regionId
          }
        })
        setRegionData(options)
      } else {
        setRegionData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  const getAllLender = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get('/getAllLender')
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        const options = res?.data?.data?.map(a => {
          return {
            label: a?.lenderName,
            value: a?.lenderName
          }
        })
        setLenderData(options)
      } else {
        setLenderData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  const getAllPortfolio = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get('/getAllPortfolio')
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        const options = res?.data?.data?.map(a => {
          return {
            label: a?.portfolioDescription,
            value: a?.portfolioDescription
          }
        })
        setPortfolioData(options)
      } else {
        setPortfolioData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  const getAllProduct = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get('/getAllProduct')
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "Success") {
        const options = res?.data?.data?.map(a => {
          return {
            label: a?.productDescription,
            value: a?.productCode
          }
        })
        setProductData(options)
      } else {
        setProductData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  const handleEditForm = async (data) => {
    setSelectedTemplate(data)
    setCreateModal(true)
  }
  const handleClose = () => {
    setCreateModal(!createModal)
    setSelectedTemplate({})
  }
  useEffect(() => {
    getAllCity();
    getAllAgency();
    getAllLender();
    getAllProduct();
    getAllPortfolio();
    getAllZone();
    getAllRegion();
    getAllState();
    getAllPinCodes();
  }, []);
  // console.log(allTemplate, "allTemplate")
  return (
    <Container
      fluid
      className="d-flex flex-column flex-grow-1 p-0 "
      style={{ overflowY: "scroll" }}
    >
      <Card className="flex-grow-1 mb-1 ">
        <CardHeader className="d-flex justify-content-between align-items-center h-20">
          <p className="m-0">Campaign Management</p>
          <Button
            size={"sm"}
            color="primary"
            onClick={() => {
              setCreateModal(true);
            }}
          >
            Create Template
          </Button>
        </CardHeader>
        <DataTable
          value={allTemplate}
          paginator // Enable pagination
          rowsPerPageOptions={[10, 25, 50, 100]} // Options for rows per page
          rows={10} // Default number of rows to display
          tableStyle={{ minWidth: "30rem" }}
          sortMode="multiple"
          removableSort
        >
          <Column field="templateName" header="Template Name" sortable></Column>
          <Column field="templateType" header="Template Type" sortable></Column>
          <Column field="templateBody" header="Template Body" sortable></Column>
          <Column field="channel" header="Channel" sortable></Column>
          <Column field="subject" header="Subject" sortable></Column>
          <Column field="templateId" header="Template Id" sortable></Column>
          <Column
            header="Action"
            body={rowData => {
              return (
                <i
                  className="bi bi-pencil-square text-danger"
                  style={{ cursor: "pointer" }}
                  onClick={() => handleEditForm(rowData)}
                />
              );
            }}
          />
        </DataTable>
        <br />
        <br />
        <Row>
          <h5 className="mb-3">
            <b>Campaign Schedule</b>
          </h5>
        </Row>
        <SceduleCampagin />
      </Card>
      <Dialog
        header="Campaign Template"
        visible={createModal}
        style={{ width: "80vw" }}
        onHide={handleClose}
      >
        {/* {console.log(cityData, 'vyujgyuvuyf')} */}
        <CampaignForm
          getVariables={getVariables}
          getTableDetails={getTableDetails}
          agencyData={agencyData}
          stateData={stateData}
          cityData={cityData}
          regionData={regionData}
          zoneData={zoneData}
          lenderData={lenderData}
          productData={productData}
          portfolioData={portfolioData}
          selectedData={selectedTemplate}
          pincodeData={pincodeData}
          onClose={handleClose}
        />
      </Dialog>
    </Container>
  );
};
export default CampaignManagemnt;