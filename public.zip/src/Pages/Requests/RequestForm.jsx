import { Formik } from "formik"
import { memo, useEffect, useMemo, useState } from "react"
import { Button, Form, Input } from "reactstrap"
import Field from "../../components/Field"
import styles from './Request.module.scss'
import Swal from "sweetalert2"
import axios from "axios"
import { useDispatch, useSelector } from "react-redux"
import { setLoader } from "../../reducer/globalReducer"

const RequestForm = (props) => {
    const [btnName, setBtnName] = useState('')
    const [caseModule, setCaseModule] = useState('')

    const user = useSelector((state) => state.user.data);
    const dispatch=useDispatch()
    const initialValues = {
        request: props?.data?.requestType,
        adminRemarks: props?.data?.remark ? props?.data?.remark :"" ,
        approverRemark: props?.formData?.approverRemark ? props?.formData?.approverRemark :""

    }

    const handleSubmit = async (values) => {
        try {
            const payload={
                ...props?.formData,
                remark: values?.adminRemarks,
                approverRemark:values?.approverRemark,
                status: btnName === "Approve" ? "Approved" : btnName === "Reject" ? "Rejected" : "Pending"
            }
            
            delete payload?.createdTime
            delete payload?.lastModifiedTime
            dispatch(setLoader(true))
            const res = await axios.put(`/updateRequestManagement/${props?.formData?.requestManagementId}`, payload)
            dispatch(setLoader(false))

            if(res?.data?.msgKey === "success"){
                const requestPayload={
                    ...props?.data,
                    status: res?.data?.data?.status,
                    approverRemark:res?.data?.data?.approverRemark
                }

                delete requestPayload?.lastModifiedTime
                delete requestPayload?.createdTime

                dispatch(setLoader(true))
                const requestRes = await axios.put(`/updateRequest/${props?.data?.requestId}`,requestPayload)
                dispatch(setLoader(false))

                if(values?.request === "Unallocate"){
                    const url = (user?.activityType === "Field" || caseModule === "Both" || caseModule === "Field") ? '/unallocateCaseApprovalField' : '/unallocateCaseApproval'
                    const isPRM = res?.data?.data?.userType === "PRM" ? 'Y' : "N"
                    const isDRA = props?.formData?.userType === "DRA" ? 'DRA' : "notDRA"
                    dispatch(setLoader(true))
                    const unallocateRes = await axios.post(`${url}/${props?.data?.loanAccountNumber}/${props?.data?.user?.userId}/${props?.formData?.reportingManagerOfUser}/${payload?.status}/${isDRA}`)
                    dispatch(setLoader(false))
                }else if(values?.request === "Case Closure" && btnName === "Approve"){
                    dispatch(setLoader(true))
                    const url = (user?.activityType === "Field" || caseModule === "Both" || caseModule === "Field") ? '/updateStatusAfterCloserRequestField' : '/updateStatusAfterCloserRequest'
                    const unallocateRes = await axios.post(`${url}/${props?.data?.loanAccountNumber}`)
                    dispatch(setLoader(false))
                }
            }
            //updateRequest/id
            props?.onSuccess()
            Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            }); 
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    useEffect(() => {
        if (props?.data?.loanAccountNumber) {
            const checkCheckModule = async () => {
                try {
                    dispatch(setLoader(true))
                    const res = await axios.get(`/caseInCallingOrField/${props?.data?.loanAccountNumber}`)
                    dispatch(setLoader(false))
                    setCaseModule(res?.data)
                } catch (error) {
                    dispatch(setLoader(false))

                }
            }

            checkCheckModule()
        }
    }, [props?.data?.loanAccountNumber])

    return (
        <Formik
            initialValues={initialValues}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                setFieldValue,
                handleSubmit,
                handleReset,
                resetForm,
            }) => {
                return (
                    <Form onSubmit={handleSubmit}>
                        <Field
                            label="Request"
                        >
                            <Input
                                bsSize="sm"
                                name="request"
                                value={values?.request}
                                disabled
                            />
                        </Field>

                        <Field
                            label="Requester Remarks"
                        >
                            <Input
                                bsSize="sm"
                                type="textarea"
                                name="adminRemarks"
                                onChange={handleChange}
                                value={values?.adminRemarks}
                                disabled={true}
                            />
                        </Field>

                        <Field
                            label="Approver`s Remarks"
                        >
                            <Input
                                bsSize="sm"
                                type="textarea"
                                name="approverRemark"
                                onChange={handleChange}
                                value={values?.approverRemark}
                                disabled={props?.data?.status !== "Pending"}
                            />
                        </Field>

                        
                        
                        {props?.formData?.status === "Pending" &&
                            <div className={styles?.buttonGroup}>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Approve')}
                                >
                                    Approve
                                </Button>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Reject')}
                                >
                                    Reject
                                </Button>
                            </div>
                        }
                    </Form>
                )
            }}
        </Formik>
    )
}

export default memo(RequestForm)