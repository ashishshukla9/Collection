import React, { Fragment, useEffect, useState } from "react";
import styles from './Request.module.scss'
import RequestCount from "./RequestCount";
import RequestFilter from "./RequestFilter";
import RequestTable from "./RequestTable";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";

export default function Request() {
  const [data, setData] = useState([])
  const [numberOfDataPerPage, setNumberOfDataPerPage] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalCount, setTotalCount] = useState(0)
  const [count,setCount]=useState({
    approved: 0,
    pending:0,
    rejected:0,
    total: 0
  })
  const [isFilterActive, setIsFilterActive] = useState(false);
  const [filterParams, setFilterParams] = useState({
    lan:'',
    status: ''
  })

  const user = useSelector((state) => state.user.data);
  const dispatch=useDispatch()

  const getAPI = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getByReportingManager/${user?.userId}/${currentPage}/${numberOfDataPerPage}`)
      dispatch(setLoader(false))
      // console.log(res, "request response ")
      setData(res?.data?.response)
      setTotalCount(res?.data?.totalApplicationCount)
      setCount({
        approved: res?.data?.approved,
        pending:res?.data?.pending,
        rejected:res?.data?.rejected,
        total: res?.data?.total
      })
    } catch (error) {
      dispatch(setLoader(false))

    }
  }

  const getFilterAPI = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getRequestManagementByLanAndStatus/${user?.userId}/${currentPage}/${numberOfDataPerPage}`, { params:filterParams })
      dispatch(setLoader(false))
      if (res?.data?.messageKey === 'success') {
        setData(res?.data?.response)
        setTotalCount(res?.data?.totalApplicationCount)
        setCount({
          approved: res?.data?.approved,
          pending:res?.data?.pending,
          rejected:res?.data?.rejected,
          total: res?.data?.total
        })
      }else if(res?.data?.message === "failure"){
        setData([])
      }
    } catch (error) {
      dispatch(setLoader(false))

    }
  }

  const onSuccessFilter = (data, params) => {
    setData(data?.response)
    setTotalCount(data?.totalApplicationCount)
    setFilterParams(params)
  }
  const onFilterFailed = () => {
    setData([])
  }

  const onPaymentSuccess = () => {
    if (isFilterActive) {
      getFilterAPI()
    } else {
      getAPI()
    }
  }

  useEffect(() => {
    if (user?.userId) {
      if (isFilterActive) {
        getFilterAPI()
      } else {
        getAPI()
      }
    }
  }, [user, currentPage, numberOfDataPerPage])

  // console.log(data, "request data")
  return (
    <Fragment>
      <RequestCount
        count={count}
      />

      <RequestFilter
        onSuccess={onSuccessFilter}
        numberOfDataPerPage={numberOfDataPerPage}
        currentPage={currentPage}
        getAPICall={getAPI}
        isFilterActive={isFilterActive}
        setIsFilterActive={setIsFilterActive}
        onFailed={onFilterFailed}
        userId={user?.userId}
      />

      <RequestTable
        data={data}
        onPaymentSuccess={onPaymentSuccess}
        totalCount={totalCount}
        currentPage={currentPage}
        numberOfDataPerPage={numberOfDataPerPage}
        setCurrentPage={setCurrentPage}
        setNumberOfDataPerPage={setNumberOfDataPerPage}
      />
    </Fragment>
  );
}
