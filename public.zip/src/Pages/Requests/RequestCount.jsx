import { memo } from "react"
import styles from './Request.module.scss'

const RequestCount=(props)=>{
    const data=[
        {id:1,count:props?.count?.total,title: 'Total Requests'},
        {id:2,count:props?.count?.approved,title: 'Approved Requests'},
        {id:3,count:props?.count?.pending,title: 'Pending Requests'},
        {id:4,count:props?.count?.rejected,title: 'Rejected Requests'}
    ]
    return(
        <div className={styles?.requestCountContainer}>
            {data?.map(a=>{
                return(
                    <div key={a?.id} className={styles?.countBox}>
                        <p className={styles?.count}>{a?.count || 0}</p>
                        <p className={styles?.title}>{a?.title}</p>
                    </div>
                )
            })}
        </div>
    )
}

export default memo(RequestCount)