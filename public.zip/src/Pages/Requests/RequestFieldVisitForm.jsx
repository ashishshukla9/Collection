import { Formik } from "formik"
import { memo, useEffect, useMemo, useState } from "react"
import { Button, Form, Input } from "reactstrap"
import Field from "../../components/Field"
import styles from './Request.module.scss'
import { useDispatch, useSelector } from "react-redux"
import { setLoader } from "../../reducer/globalReducer"
import axios from "axios"
import Select from "react-select";
import * as yup from "yup";
import Swal from "sweetalert2"

const RequestFieldVisitForm = (props) => {
    const [btnName, setBtnName] = useState('')
    const [agent, setAgent] = useState([])

    const IS_VIEW = useMemo(() => !["Pending"]?.includes(props?.formData?.status), [])

    const dispatch = useDispatch()

    const initialValues = {
        agent: IS_VIEW ? props?.fieldRes?.name : '',
        adminRemarks: IS_VIEW ? props?.fieldRes?.remark : ''
    }

    const validationSchema = yup.object({
        agent: yup.object().test('required', 'This field is required', function (value) {
            return (btnName !== "Approve" ? true : value?.value)
        })
    })

    const handleSubmit = async (values) => {
        dispatch(setLoader(true))
        try {
            const payload = {
                requestId: props?.formData?.requestManagementId,
                activityType: props?.formData?.activityType,
                remark: values?.adminRemarks,
                status: btnName === 'Approve' ? 'Approved' : 'Rejected',
                misId: values?.agent?.value
            }

            const res = await axios.post('/updateFieldVisitRequest', payload)
            if (res?.data?.messageKey) {
                props?.onSuccess()
                dispatch(setLoader(false))

                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            } else {
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
                dispatch(setLoader(false))

            }
        } catch (error) {
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
            dispatch(setLoader(false))
        }
    }

    const getUserByRoleId = async () => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getUserByRoleCode/MIS`)
            dispatch(setLoader(false))

            const data = []
            res?.data?.data?.map(a => {
                data.push({
                    label: `${a?.firstName} ${a?.lastName}`,
                    value: a?.userId
                })
            })

            setAgent(data)
        } catch (error) {
            dispatch(setLoader(false))
        }
    }

    useEffect(() => {
        getUserByRoleId()
    }, [])

    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                setFieldValue,
                handleSubmit,
                handleReset,
                resetForm,
            }) => {
                return (
                    <Form onSubmit={handleSubmit}>
                        <Field
                            label="Select Agent"
                            errorMessage={touched?.agent && errors?.agent}
                        >
                            {["Pending"]?.includes(props?.formData?.status) ?
                                <Select
                                    bsSize="sm"
                                    name="agent"
                                    options={agent}
                                    onChange={(e) => setFieldValue('agent', e)}
                                    value={values?.agent}
                                    classNamePrefix="react-select"
                                /> :
                                <Input
                                    value={values?.agent}
                                    size={'sm'}
                                    disabled
                                />
                            }
                        </Field>

                        <Field
                            label="Admin Remarks"
                        >
                            <Input
                                bsSize="sm"
                                type="textarea"
                                name="adminRemarks"
                                onChange={handleChange}
                                value={values?.adminRemarks}
                                disabled={props?.formData?.status !== "Pending"}
                            />
                        </Field>

                        {props?.formData?.status === "Pending" &&
                            <div className={styles?.buttonGroup}>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Approve')}
                                >
                                    Approve
                                </Button>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Reject')}
                                >
                                    Reject
                                </Button>
                            </div>
                        }
                    </Form>
                )
            }}
        </Formik>
    )
}

export default memo(RequestFieldVisitForm)