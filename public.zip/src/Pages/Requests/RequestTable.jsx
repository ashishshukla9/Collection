import { DataTable } from "primereact/datatable"
import { Fragment, memo, useEffect, useState } from "react"
import Pagination from "../../components/Pagination"
import { Column } from "primereact/column"
import { useDispatch, useSelector } from "react-redux"
import axios from "axios"
import styles from './Request.module.scss'
import { Dialog } from "primereact/dialog"
import RequestPaymentForm from "./RequestPaymentForm"
import RequestPTPForm from "./RequestPTPForm"
import RequestForm from "./RequestForm"
import { Link } from "react-router-dom"
import RequestDisputeForm from "./RequestDisputeForm"
import { setLoader } from "../../reducer/globalReducer"
import RequestFieldVisitForm from "./RequestFieldVisitForm"
import Swal from "sweetalert2"
import RequestDipositionForm from "./RequestDipositionForm"
import { Button } from "@coreui/coreui"
import { DownloadFile } from "../../utils/DownloadFile"

const RequestTable = (props) => {
    // console.log(props, 'vyhuvuyvuyv')
    const [userNames, setUserNames] = useState({})
    const [form, setForm] = useState({})
    const [paymentData, setPaymentData] = useState({})
    const [dipostionData, setDipostionData] = useState({})
    const [ptpData, setPTPData] = useState({})
    const [requestData, setRequestData] = useState({})
    const [disputeData, setDisputeData] = useState({})
    const [disputeReason, setDisputeReason] = useState({})
    const [userName, setUserName] = useState({})
    const [fieldVisitForm, setFieldVisitForm] = useState(false)
    const [fieldRes, setFieldRes] = useState({})
    const [imageDocument, setImageDocument] = useState("")
    const [imageModal, setImageModal] = useState(false)

    const user = useSelector((state) => state.user.data);
    const dispatch = useDispatch()

    const getUser = async () => {
        try {
            dispatch(setLoader(true))
            // const res = await axios.get('/getAllUserList')
            const res = await axios.get('/getUserForAllocation')
            dispatch(setLoader(false))
            const names = {}
            res?.data?.data?.map(a => {
                Object.assign(names, { [a?.userId]: `${a?.firstName} ${a?.lastName}` })
            })
            setUserNames(names)
        } catch (error) {
            dispatch(setLoader(false))
        }
    }

    const getPaymentById = async (id) => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getPaymentById/${id}`)
            dispatch(setLoader(false))
            setPaymentData(res?.data?.data || {})
        } catch (error) {
            dispatch(setLoader(false))
        }
    }


    const getDipositionById = async (id) => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getDepositionById/${id}`)
            dispatch(setLoader(false))
            setDipostionData(res?.data?.response)
        } catch (error) {
            dispatch(setLoader(false))
        }}


    const getPTPById = async (id) => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getPtpDetailsById/${id}`)
            dispatch(setLoader(false))
            setPTPData(res?.data?.data || {})
        } catch (error) {
            dispatch(setLoader(false))
        }}

    const getRequestById = async (id) => {

        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getByRequestId/${id}`)
            setRequestData(res?.data?.data || {})
            dispatch(setLoader(false))
        } catch (error) {
            dispatch(setLoader(false))
        }
    }

    const getDisputeById = async (id) => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getByDisputeOrRtpId/${id}`)
            setDisputeData(res?.data?.data || {})
            const reason = await axios.get("/getAllDisputeReasonMaster")
            dispatch(setLoader(false))
            const obj = {}
            reason?.data?.data?.map(a => {
                Object.assign(obj, {
                    [a?.code]: a?.description
                })
            })
            setDisputeReason(obj)
        } catch (error) {
            dispatch(setLoader(false))
        }
    }



    const handleEditForm = async (data) => {
        const { activityType } = data
        if (activityType === "Deposition") {
            getDipositionById(data?.activityId)
        }

        if (activityType === "Payment") {
            getPaymentById(data?.activityId)
            // getDipositionById(data?.activityId)
        } else if (activityType === "PTP") {
            if (data?.status !== "Pending" && data?.selectedFieldAgentId) {
                dispatch(setLoader(true))
                const userRes = await axios.get(`/getUserById/${data?.selectedFieldAgentId}`)
                dispatch(setLoader(false))
                setUserName({
                    label: `${userRes?.data?.data?.firstName} ${userRes?.data?.data?.lastName}`,
                    value: userRes?.data?.data?.userId
                })}
            getPTPById(data?.activityId)
        } else if (activityType === "Request" || activityType === "Case Close" || activityType === "Foreclouser") {
            if (data?.status !== "Pending" && data?.selectedFieldAgentId) {
                dispatch(setLoader(true))
                const userRes = await axios.get(`/getUserById/${data?.selectedFieldAgentId}`)
                dispatch(setLoader(false))
                setUserName({
                    label: `${userRes?.data?.data?.firstName} ${userRes?.data?.data?.lastName}`,
                    value: userRes?.data?.data?.userId
                })
            }
            getRequestById(data?.activityId)
        } else if (activityType === "Dispute") {
            getDisputeById(data?.activityId)
        } else if (activityType === "Field Visit") {
            if (data?.status === "Pending") {
                setFieldVisitForm(true)
            } else {
                const fieldRes = await axios.get(`/getFieldVisitRequestById/${data?.requestManagementId}`)
                if (fieldRes?.data?.messageKey) {
                    setFieldVisitForm(true)
                    setFieldRes(fieldRes?.data?.response)
                } else {
                    Swal.fire({
                        position: "top-end",
                        icon: "error",
                        title: `${fieldRes?.data?.message}`,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                }
            }
        }
        setForm(data)
    }
    const onCloseForm = () => {
        setForm({})
        setPaymentData({})
        setDipostionData({})
        setPTPData({})
        setRequestData({})
        setImageModal(false)
        setFieldVisitForm(false)
    }
    const onPaymentSuccess = () => {
        props?.onPaymentSuccess()
        onCloseForm()
    }
    const handleShowDoucument = async (rowData) => {
        try {
            const getDocUrl = (rowData?.activityType == "Request" || rowData?.activityType == "Case Close") ? "/documentRequestByRequestId" : rowData?.activityType == "Dispute" ? "/getdocumentDisputeByDisputeOrRtpId" : rowData?.activityType == "Payment" ? "/getDocumentByPaymentId" : rowData?.activityType == "Deposition" ? "getDepositionEvidenceByDepositionId" : " "
            const res = await axios.get(`${getDocUrl}/${rowData?.activityId}`)
            if (rowData?.activityType == "Request" || rowData?.activityType == "Case Close") {
                const response = await axios({
                    url: `/download-request-file/${res?.data?.documentRequestId}`,
                    method: "GET",
                    responseType: "blob",
                });
                const link = document.createElement("a");
                link.href = URL.createObjectURL(new Blob([response.data]));
                if (link.href) {
                    setImageDocument(link.href)
                    setImageModal(true)
                }
            } else if (rowData?.activityType == "Dispute") {
                const response = await axios({
                    url: `/download-Dispute-file/${res?.data?.disputeOrRtpId}`,
                    method: "GET",
                    responseType: "blob",
                });
                const link = document.createElement("a");
                link.href = URL.createObjectURL(new Blob([response.data]));
                if (link.href) {
                    setImageDocument(link.href)
                    setImageModal(true)
                }

            } else if (rowData?.activityType == "Payment") {
                const response = await axios({
                    url: `/download-payment-file/${res?.data?.paymentId}`,
                    method: "GET",
                    responseType: "blob",
                });

                const link = document.createElement("a");
                link.href = URL.createObjectURL(new Blob([response.data]));
                if (link.href) {
                    setImageDocument(link.href)
                    setImageModal(true)
                }

            } else if (rowData?.activityType == "Deposition") {
                const response = await axios({
                    url: `/downloadDepositionEvidenceById/${res?.data?.depositionId}`,
                    method: "GET",
                    responseType: "blob",
                });
                const link = document.createElement("a");
                link.href = URL.createObjectURL(new Blob([response.data]));
                if (link.href) {
                    setImageDocument(link.href)
                    setImageModal(true)
                }
            }
        } catch (error) {
            console.log(error)
        }
    }


    // download evidence 
    const handleDownloadDoucument = async (rowdata) => {
        try {
            if (rowdata?.activityType == "Request" || rowdata?.activityType == "Case Close") {
                const res = await axios.get(`/documentRequestByRequestId/${rowdata?.activityId}`)
                await DownloadFile(`/download-request-file/${res?.data?.documentRequestId}`, res?.data?.name)
            } else if (rowdata?.activityType == "Dispute") {
                const res = await axios.get(`/getdocumentDisputeByDisputeOrRtpId/${rowdata?.activityId}`)
                await DownloadFile(`/download-Dispute-file/${res?.data?.disputeOrRtpId}`, res?.data?.name)
            } else if (rowdata?.activityType == "Payment") {

                const res = await axios.get(`/getDocumentByPaymentId/${rowdata?.activityId}`)
                await DownloadFile(`/download-payment-file/${res?.data?.paymentId}`, res?.data?.name)

            } else if (rowdata?.activityType == "Deposition") {
                const res = await axios.get(`/getDepositionEvidenceByDepositionId/${rowdata?.activityId}`)
                await DownloadFile(`/downloadDepositionEvidenceById/${res?.data?.depositionId}`, res?.data?.name)
            }
        } catch (error) {
        }
    }

    useEffect(() => {
        getUser()
    }, [])

    return (
        <Fragment>
            <DataTable
                value={props?.data}
                removableSort
                size={"small"}
                tableStyle={{ minWidth: "50rem" }}
                className={`d-flex flex-column flex-grow-1 ${styles?.requestTable}`}
            >
                <Column
                    header="Date Time"
                    body={rowData => {
                        let date = ''
                        if (rowData?.lastModifiedTime) {
                            date = new Date(rowData?.lastModifiedTime).toLocaleDateString()?.split('/')
                            date = date[1] + '/' + date[0] + '/' + date[2]
                        }

                        return (
                            <p>{rowData?.lastModifiedTime && date + ' ' + new Date(rowData?.lastModifiedTime).toLocaleTimeString('en-us', { hour: '2-digit', minute: '2-digit', hourCycle: 'h12' })}</p>
                        )
                    }}
                />
                <Column
                    header="Name"
                    body={rowData => {
                        return (
                            <p>{userNames[rowData?.requestRaisedUserId]}</p>
                        )
                    }}
                />
                <Column
                    header="Lan Id"
                    field="lan"
                    body={(rowData) => {
                        return (
                            (rowData?.status === "Approved (Field Pickup)" || rowData?.activityType === "Field Visit") ?
                                <p style={{ color: 'lightgrey', cursor: 'default' }}>{rowData.lan}</p> :
                                rowData.lan == "-" ? "--" : <Link
                                    to={`/case_profile/ALL/calling/${rowData.lan}`}
                                    className="caseId"
                                >
                                    {rowData.lan ? rowData.lan : ""}
                                </Link>)
                    }}
                />
                <Column
                    header="Request Id"
                    field="requestid"
                />

                <Column
                    header="Type"
                    field="activityType"
                    body={rowData => {
                        return (
                            <p>{rowData?.activityType} {rowData?.repoAndLegal ? `(${rowData?.repoAndLegal})` : rowData?.unAllocate && `(${rowData?.unAllocate})`}</p>
                        )
                    }} />

                <Column
                    header="Evidence"
                    field="evidence"
                    body={rowData => {
                        return (
                            rowData?.isDocument == "yes" ? (
                                <>
                                    <button style={{ border: "none", background: "transparent" }} onClick={() => handleShowDoucument(rowData)}>
                                        <i className="bi bi-card-image" style={{ color: "green" }}></i>
                                    </button>

                                    <button style={{ border: "none", background: "transparent" }} onClick={() => handleDownloadDoucument(rowData)}>
                                        <i class="bi bi-cloud-download" style={{ color: "green" }}></i>
                                    </button>
                                </>
                            ) : " --"
                        )
                    }} />
                <Column
                    header="Remarks"
                    field="remark"
                />
                <Column
                    header="Status"
                    field="status"
                />
                <Column
                    header="Action"
                    body={rowData => {
                        if (["E", "F"].includes(user?.masterRole["requestmanagement_requestmanagement"])) {
                            // , 
                            return (
                                ["Pending", "Pending"]?.includes(rowData?.status) ?
                                    <i
                                        className="bi bi-pencil-square text-danger"
                                        style={{ cursor: "pointer" }}
                                        onClick={() => handleEditForm(rowData)}
                                    /> : <i
                                        className="bi bi-eye-fill text-primary"
                                        style={{ cursor: "pointer" }}
                                        onClick={() => handleEditForm(rowData)}
                                    />
                            )
                        }
                    }}
                />
            </DataTable>
            <Pagination
                totalCount={props?.totalCount}
                currentPage={props?.currentPage}
                numberOfDataPerPage={props?.numberOfDataPerPage}
                setCurrentPage={props?.setCurrentPage}
                setNumberOfDataPerPage={props?.setNumberOfDataPerPage}
            />

            {form?.activityType === "Payment" && Boolean(Object?.keys(paymentData).length) &&
                <Dialog
                    visible={form?.activityType === "Payment" && Boolean(Object?.keys(paymentData).length)}
                    header="Payment Record"
                    className={styles?.formModal}
                    onHide={onCloseForm}
                >
                    <RequestPaymentForm
                        data={paymentData}
                        formData={form}
                        onSuccess={onPaymentSuccess}
                    />
                </Dialog>
            }

            {/* && Boolean(Object?.keys(dipostionData).length) */}
            {form?.activityType === "Deposition" && Boolean(Object?.keys(dipostionData).length) &&
                <Dialog
                    // 
                    visible={form?.activityType === "Deposition"}
                    header="Deposition"
                    className={styles?.formModal}
                    onHide={onCloseForm}
                >
                    <RequestDipositionForm
                        data={dipostionData}
                        formData={form}
                        onSuccess={onPaymentSuccess}
                    />
                </Dialog>
            }


            {form?.activityType === "PTP" && Boolean(Object?.keys(ptpData).length) &&
                <Dialog
                    visible={form?.activityType === "PTP" && Boolean(Object?.keys(ptpData).length)}
                    header="PTP Record"
                    className={styles?.formModal}
                    onHide={onCloseForm}
                >
                    <RequestPTPForm
                        data={ptpData}
                        formData={form}
                        onSuccess={onPaymentSuccess}
                        userName={userName}
                    />
                </Dialog>
            }
            {(form?.activityType === "Request" || form?.activityType == "Case Close" || form?.activityType === "Foreclouser") && Boolean(Object?.keys(requestData).length) &&
                <Dialog
                    visible={(form?.activityType === "Request" || form?.activityType == "Case Close" || form?.activityType === "Foreclouser") && Boolean(Object?.keys(requestData).length)}
                    header={form?.activityType == "Request" ? "Request Record" : form?.activityType == "Case Close" ? "Case Close Request" : "Request Record"}
                    className={styles?.formModal}
                    onHide={onCloseForm}
                >
                    <RequestForm
                        data={requestData}
                        formData={form}
                        onSuccess={onPaymentSuccess}
                        userName={userName}
                    />
                </Dialog>
            }
            {form?.activityType === "Dispute" && Boolean(Object?.keys(disputeData)?.length) && Boolean(Object?.keys(disputeReason)?.length) &&
                <Dialog
                    visible={form?.activityType === "Dispute" && Boolean(Object?.keys(disputeData)?.length) && Boolean(Object?.keys(disputeReason)?.length)}
                    header="Dispute Record"
                    className={styles?.formModal}
                    onHide={onCloseForm}
                >

                    <RequestDisputeForm
                        data={disputeData && disputeData}
                        formData={form}
                        onSuccess={onPaymentSuccess}
                        disputeReason={disputeReason && disputeReason}
                    />
                </Dialog>
            }

            {form?.activityType === "Field Visit" && fieldVisitForm &&
                <Dialog
                    visible={form?.activityType === "Field Visit" && fieldVisitForm}
                    header="Field Visit Record"
                    className={styles?.formModal}
                    onHide={onCloseForm}
                >
                    <RequestFieldVisitForm
                        formData={form}
                        onSuccess={onPaymentSuccess}
                        fieldRes={fieldRes}
                    />
                </Dialog>
            }


            {/*  image show dialog box  */}
            {/* {form?.activityType === "Field Visit" && fieldVisitForm && */}
            <Dialog
                visible={imageModal == true}
                header="Evidence Document"
                className={styles?.formModal}
                onHide={onCloseForm}
            >
                <img src={imageDocument} alt="error" style={{ marginRight: "10px", height: "100%", width: "100%" }} />
            </Dialog>
            {/* } */}
        </Fragment>
    )
}

export default memo(RequestTable)