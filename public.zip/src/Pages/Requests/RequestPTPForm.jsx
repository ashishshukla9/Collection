import { Formik } from "formik";
import { memo, useEffect, useState } from "react";
import { Button, Form, Input } from "reactstrap";
import Field from "../../components/Field";
import styles from "./Request.module.scss";
import Select from "react-select";
import * as yup from "yup";
import Swal from "sweetalert2";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { getUserTypeData } from "../Master/LookupMaster/lookupSlice";
import { setLoader } from "../../reducer/globalReducer";

const RequestPTPForm = (props) => {
  // console.log(props?.formData, 'vyuvuyy')
  const [btnName, setBtnName] = useState("");
  const [agent, setAgent] = useState([]);
  const user = useSelector((state) => state.user.data);
  // console.log(props?.data?.user?.userId, "vhjvhj");
  const userTypeData = useSelector((state) => state?.lookup?.userTypeData);

  const dispatch = useDispatch();
  const initialValues = {
    ptpAmount: props?.data?.ptpAmount,
    ptpDate: props?.data?.ptpDate,
    ptpTime: props?.data?.ptpTime,
    agent: props?.userName || "",
    adminRemarks: props?.formData?.remark,
  };

  const validationSchema = yup.object({
    agent: yup
      .object()
      .test("required", "This field is required", function (value) {
        return btnName !== "Approve" ? true : value?.value;
      }),
  });

  const handleSubmit = async (values) => {
    try {
      let reportingManagerOfUser = props?.data?.reportingManagerOfUser;
      let requestRaisedUserId = props?.formData?.requestRaisedUserId;
      // if(btnName === "Escalate To TruBoard"){
      //     const userIdRes=await axios.get(`/getAllocationFromInternalToExternal/${props?.data?.loanAccountNumber}/${user?.userId}`)
      //     if(userIdRes?.data?.msgKey === "Success"){
      //         reportingManagerOfUser = userIdRes?.data?.data
      //         requestRaisedUserId = user?.userId
      //     }
      // }

      if (btnName === "Approve" && user?.userType === "U101") {
        if (props?.formData?.status === "Pending (Escalate To TruBoard)") {
          dispatch(setLoader(true));
          const escRes = await axios.post(
            `/updateAfterAgencyAdminFieldPickUp/${props?.formData?.escalateTBid}/${props?.data?.loanAccountNumber}`
          );
          dispatch(setLoader(false));
        } else {
          dispatch(setLoader(true));
          const misRes = await axios.put(
            `/updateStatusAfterFieldPickUp/${props?.data?.loanAccountNumber}`
          );
          dispatch(setLoader(false));
        }
      }

      if (btnName === "Approve" && user?.userType === "U103") {
        dispatch(setLoader(true));
        const faAllocationPayload = [props?.data?.loanAccountNumber];
        const res = await axios.post(
          `/DRAAllocation/${user?.userId}/${values?.agent?.value}/${values?.agent?.roleId}/Y/notAll`,
          faAllocationPayload
        );
        const updateres = await axios.post(
          `/updateAfterAgencyAdminFieldPickUpToAgent/${user?.userId}/${props?.data?.loanAccountNumber}`
        );
        dispatch(setLoader(false));
      }
      const userRole = user?.role?.map((a) => a?.roleCode?.toLowerCase());
      const userType = {};
      userTypeData?.map((a) =>
        Object.assign(userType, { [a?.code]: `${a?.description}_Agent` })
      );
      const subString = "AA";
      const addPayload = {
        ...props?.formData,

        agencyAdminField:
          userRole?.includes(subString.toLowerCase()) && props?.currentModule
            ? "Y"
            : "N",
        remark: values?.adminRemarks,
        status:
          btnName === "Approve"
            ? "Approved"
            : btnName === "Reject"
            ? "Rejected"
            : "Pending (Escalate To TruBoard)",
        selectedFieldAgentId:
          btnName !== "Escalate To TruBoard" ? values?.agent?.value : "",
        userType: userRole?.includes("ca")
          ? "CA"
          : userRole?.includes("dra")
          ? "DRA"
          : userRole.includes("atl")
          ? "ATL"
          : userRole?.includes("aa")
          ? "AA"
          : userType[user?.userType],
        // reportingManagerOfUser: reportingManagerOfUser,
        requestRaisedUserId:
          btnName === "Escalate To TruBoard"
            ? user?.userId
            : requestRaisedUserId,
        escalateTBid: requestRaisedUserId,
      };

      const updatePayload = {
        ...props?.formData,
        remark: values?.adminRemarks,
        status:
          user?.userType === "U101" && btnName === "Approve"
            ? "Approved (Field Pickup)"
            : btnName === "Approve"
            ? "Approved"
            : btnName === "Reject"
            ? "Rejected"
            : "Escalate To TruBoard",
        selectedFieldAgentId:
          btnName !== "Escalate To TruBoard" ? values?.agent?.value : "",
      };
      delete addPayload?.createdTime;
      delete addPayload?.lastModifiedTime;
      delete addPayload?.reportingManagerOfUser;
      delete addPayload?.requestManagementId;

      delete updatePayload?.createdTime;
      delete updatePayload?.lastModifiedTime;
      // delete updatePayload?.reportingManagerOfUser

      dispatch(setLoader(true));
      const res = await axios.put(
        `/updateRequestManagement/${props?.formData?.requestManagementId}`,
        updatePayload
      );
      dispatch(setLoader(false));

      if (btnName === "Escalate To TruBoard") {
        dispatch(setLoader(true));
        setTimeout(async () => {
          const requestRes = await axios.post(
            "/addRequestManagement",
            addPayload
          );
        }, 1000);
        dispatch(setLoader(false));
        // const updateRes = await axios.post(`/updateAfterAgencyAdminFieldPickUp/${user?.userId}/${props?.data?.loanAccountNumber}` )
      }

      if (res?.data?.msgKey === "success") {
        const ptpPayload = {
          ...props?.data,
          status:
            res?.data?.data?.status === "Approved"
              ? values?.agent?.value
                ? "Pending"
                : "Success"
              : res?.data?.data?.status === "Escalate To TruBoard"
              ? "Pending"
              : res?.data?.data?.status,
          user: {
            userId: props?.data?.user?.userId,
          },
        };
        // console.log(ptpPayload, 'check proper')

        delete ptpPayload?.createdTime;
        delete ptpPayload?.lastModifiedTime;
        delete ptpPayload?.ptpId;

        dispatch(setLoader(true));
        const updatePTPRes = await axios.put(
          `/updatePtpDetails/${props?.data?.ptpId}`,
          ptpPayload
        );
        dispatch(setLoader(false));
        props?.onSuccess();

        Swal.fire({
          position: "top-end",
          icon: "success",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const getFieldUser = async () => {
    try {
      const agencyId = user?.agency[0]?.agencyId;
      dispatch(setLoader(true));
      const res = await axios.get(`/getFieldAgentByAgency/${agencyId}`);
      dispatch(setLoader(false));
      const options = [];
      res?.data?.data?.map((a) => {
        if (a?.userId !== props?.formData?.requestRaisedUserId)
          options.push({
            label: `${a?.firstName} ${a?.lastName}`,
            value: a?.userId,
            roleId: a?.role[0]?.roleId,
          });
      });

      setAgent(options);
    } catch (error) {
      dispatch(setLoader(false));
    }
  };

  // const getLowerUsers=async()=>{
  //     try {
  //         const res=await axios.get(`/getLowerHierarchyByUserId/${user?.userId}`)
  //         const data=[]
  //         res?.data?.data?.filter(a=>{
  //             const caRole = Boolean(a?.role?.filter(b=>b?.roleCode === "CA").length)

  //             if(caRole){
  //                 data?.push({
  //                     label: `${a?.firstName} ${a?.lastName}`,
  //                     value: a?.userId
  //                 })
  //             }
  //         })

  //         setAgent(data)
  //     } catch (error) {

  //     }
  // }
  const getUserByRoleId = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getUserByRoleCode/MIS`);
      dispatch(setLoader(false));

      const data = [];
      res?.data?.data?.map((a) => {
        data.push({
          label: `${a?.firstName} ${a?.lastName}`,
          value: a?.userId,
        });
      });

      setAgent(data);
    } catch (error) {
      dispatch(setLoader(false));
    }
  };

  useEffect(() => {
    if (user?.userType === "U101") {
      getUserByRoleId();
    } else {
      getFieldUser();
    }
  }, []);

  useEffect(() => {
    dispatch(getUserTypeData());
  }, []);

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={handleSubmit}
      validationSchema={validationSchema}
    >
      {({
        values,
        errors,
        touched,
        handleChange,
        handleBlur,
        setFieldValue,
        handleSubmit,
        handleReset,
        resetForm,
      }) => {
        // console.log(values,'values');
        return (
          <Form onSubmit={handleSubmit}>
            <Field label="PTP Amount">
              <Input
                bsSize="sm"
                name="ptpAmount"
                value={values?.ptpAmount}
                disabled
              />
            </Field>
            <Field label="PTP Date">
              <Input
                bsSize="sm"
                name="ptpDate"
                value={values?.ptpDate}
                disabled
              />
            </Field>
            <Field label="PTP Time">
              <Input
                bsSize="sm"
                name="ptpTime"
                value={values?.ptpTime}
                disabled
              />
            </Field>
            <Field
              label="Select Agent"
              errorMessage={touched?.agent && errors?.agent}
            >
              <Select
                bsSize="sm"
                name="agent"
                options={agent}
                onChange={(e) => setFieldValue("agent", e)}
                value={values?.agent}
                classNamePrefix="react-select"
                // isDisabled = {props?.formData?.status !== "Pending"}
                isDisabled={
                  !["Pending (Escalate To TruBoard)", "Pending"]?.includes(
                    props?.formData?.status
                  )
                }
              />
            </Field>
            <Field label="Admin Remarks">
              <Input
                bsSize="sm"
                type="textarea"
                name="adminRemarks"
                onChange={handleChange}
                value={values?.adminRemarks}
                disabled={
                  !["Pending (Escalate To TruBoard)", "Pending"]?.includes(
                    props?.formData?.status
                  )
                }
              />
            </Field>
            {["Pending (Escalate To TruBoard)", "Pending"]?.includes(
              props?.formData?.status
            ) && (
              <div className={styles?.buttonGroup}>
                {user?.userType === "U103" && (
                  <Button
                    type="submit"
                    size="sm"
                    color="primary"
                    onMouseOver={() => setBtnName("Escalate To TruBoard")}
                  >
                    Assign to TruBoard
                  </Button>
                )}
                <Button
                  type="submit"
                  size="sm"
                  color="primary"
                  onMouseOver={() => setBtnName("Approve")}
                >
                  Approve
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  color="primary"
                  onMouseOver={() => setBtnName("Reject")}
                >
                  Reject
                </Button>
              </div>
            )}
          </Form>
        );
      }}
    </Formik>
  );
};

export default memo(RequestPTPForm);
