import { Formik } from "formik"
import { memo, useEffect, useState } from "react"
import { Button, Form, Input } from "reactstrap"
import Field from "../../components/Field"
import styles from './Request.module.scss'
import axios from "axios"
import Swal from "sweetalert2"
import { useDispatch, useSelector } from "react-redux"
import { setLoader } from "../../reducer/globalReducer"

const RequestPaymentForm = (props) => {
    const [btnName, setBtnName] = useState('')

    const dispatch=useDispatch()
    const user = useSelector((state) => state.user.data);
    // console.log(props?.data?.user?.userId,'vhjvjhvjh')

    // console.log(props?.data, "props?.dataprops?.data")
    const initialValues = {
        paymentType: props?.data?.paymentType,
        amount: props?.data?.amount,
        collectionMode: props?.data?.paymentMode,
        dateOfPayment: props?.data?.paymentDate,
        timeOfPayment: props?.data?.timeOfPayment,
        remarks: props?.data?.remark,
        adminRemarks: props?.formData?.remark,
        chequeNumber:props?.data?.chequeNumber,
        referenceNumber:props?.data?.referenceNumber

    }

    const handleSubmit = async (values) => {
        const data= {...props?.formData}
        try {
            const payload = {
                ...props?.formData,
                remark: values?.adminRemarks,
                status: btnName === "Approve" ? "Approved" : btnName === "Reject" ? "Rejected" : ""
            }

            // console.log(payload, "paymentpayload")
            delete payload?.createdTime
            delete payload?.lastModifiedTime

            dispatch(setLoader(true))
            const res = await axios.put(`/updateRequestManagement/${props?.formData?.requestManagementId}`, payload)
            dispatch(setLoader(false))

            if(res?.data?.msgKey === "success"){
                dispatch(setLoader(true))
                const ptpres=await axios.get(`/getPtpDetailsByPaymentId/${props?.data?.paymentId}`)
                dispatch(setLoader(false))
                if(ptpres?.data?.data?.ptpId){
                    dispatch(setLoader(true))
                    const updatePTPres=await axios.put(`/updatePtpDetailsStatus/${ptpres?.data?.data?.ptpId}/Paid`)
                    dispatch(setLoader(false))
                }
                const paymentPayload={
                    ...props?.data,
                    paymentStatus: res?.data?.data?.status === "Approved" ? 'Success' : res?.data?.data?.status,
                    user:{
                        userId: props?.data?.user?.userId
                    }
                }
                delete paymentPayload?.paymentId
                delete paymentPayload?.createdTime
                delete paymentPayload?.lastModifiedTime

                dispatch(setLoader(true))
                const payloadUpdateRes = await axios.put(`/updatePayment/${props?.data?.paymentId}`,paymentPayload)
                dispatch(setLoader(false))
                props?.onSuccess()

                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                }); 
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    return (
        <Formik
            initialValues={initialValues}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                setFieldValue,
                handleSubmit,
                handleReset,
                resetForm,
            }) => {
                return (
                    <Form onSubmit={handleSubmit}>
                        <Field
                            label="Payment Type"
                        >
                            <Input
                                bsSize="sm"
                                name="paymentType"
                                value={values?.paymentType}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Amount"
                        >
                            <Input
                                bsSize="sm"
                                name="amount"
                                value={values?.amount}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Cheque No"
                        >
                            <Input
                                bsSize="sm"
                                name="chequeNumber"
                                value={values?.chequeNumber ? values?.chequeNumber : "-"}
                                disabled
                            />
                        </Field>
                        <Field
                            label="ReferenceNo"
                        >
                            <Input
                                bsSize="sm"
                                name="referenceNumber"
                                value={values?.referenceNumber? values?.referenceNumber :"-"}
                                disabled
                            />
                        </Field>
                        
                        <Field
                            label="Collection Mode"
                        >
                            <Input
                                bsSize="sm"
                                name="collectionMode"
                                value={values?.collectionMode}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Date of Payment"
                        >
                            <Input
                                bsSize="sm"
                                name="dateOfPayment"
                                value={values?.dateOfPayment}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Time of Payment"
                        >
                            <Input
                                bsSize="sm"
                                name="timeOfPayment"
                                value={values?.timeOfPayment}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Remarks"
                        >
                            <Input
                                bsSize="sm"
                                name="remarks"
                                value={values?.remarks}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Approver`s Remarks"
                        >
                            {/* {console.log(values, "values?.adminRemarks")} */}
                            <Input
                                bsSize="sm"
                                type="textarea"
                                name="adminRemarks"
                                onChange={handleChange}
                                value={values?.adminRemarks}
                                disabled={props?.formData?.status !== "Pending"}
                            />
                        </Field>
                        {props?.formData?.status === "Pending" &&
                            <div className={styles?.buttonGroup}>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Approve')}
                                >
                                    Approve
                                </Button>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Reject')}
                                >
                                    Reject
                                </Button>
                            </div>
                        }
                    </Form>
                )
            }}
        </Formik>
    )
} 



export default memo(RequestPaymentForm)