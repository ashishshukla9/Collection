import { CCard, CCardBody } from "@coreui/react";
import { Formik } from "formik";
import { useEffect, useMemo, useState } from "react";
import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  FormGroup,
  Input,
  Row,
} from "reactstrap";
import {
  NUMBER_ONLY,
  ONE_SPACE,
  SPACE_NOT_ALLOW,
} from "../../utils/regex";
import "./user.css"
import axios from "axios";
import Swal from "sweetalert2";
import Select, { components } from "react-select";
import cx from "classnames";
import { useGetAgencyQuery } from "../Master/store/agencySlice";
import { useGetZoneQuery } from "../Master/store/zoneSlice";
import { useGetRegionByZoneQuery } from "../Master/store/regionSlice";
import { useGetStateByRegionQuery } from "../Master/store/stateSlice";
import { useGetPortfolioQuery } from "../Master/store/portfolioSlice";
import Branches from "../../components/User/Branches";
import ProductDropdown from "../../components/User/ProductDropdown";
import {
  removeMultiSelectOptionValue,
  scrollToErrorMessage,
} from "../../utils/commonFun";
import Field from "../../components/Field";
import * as yup from "yup";
import FileTable from "../../components/FileTable";
import FileUpload from "../../components/FileUpload";
import MultiSelectComma from "../../components/Selection/MultiSelectComma";
import { useDispatch } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";
import { MultiSelect } from "react-multi-select-component";
import MultiSelectionFormik from "../../components/Selection/MultiSelectionFormik";

const AddUser = ({
  data,
  isUpdate,
  isView,

  edit,
  manager,
  onFileUploadSuccess,
  onSuccess
}) => {
  const [activeUserDesignation, setActiveUserDesignation] = useState([]);
  const [activeProfile, setActiveProfile] = useState([]);
  const [selectedProfiles, setSelectedProfiles] = useState([]);
  const [activeRole, setActiveRole] = useState([]);
  const [roles, setRoles] = useState([]);
  const [activeUserType, setActiveUserType] = useState([]);
  const [activeAgency, setActiveAgency] = useState([]);
  const [activeProductList, setActiveProductList] = useState([]);
  const [orgName, setOrgName] = useState([]);
  const [activeZone, setActiveZone] = useState([]);
  const [activeRegion, setActiveRegion] = useState([]);
  const [ZoneIds, setZoneIds] = useState([]);
  const [RegionIds, setRegionIds] = useState([]);
  const [StateIds, setStateIds] = useState([]);
  const [CityIds, setCityIds] = useState([]);
  const [activeState, setActiveState] = useState([]);
  const [activeCity, setActiveCity] = useState([]);
  const [activePincode, setActivePincode] = useState([]);
  const [activePortfolio, setActivePortfolio] = useState([]);
  const [activeLender, setActiveLender] = useState([]);
  const [formik, setFormik] = useState({});
  const [passwordValidation, setPasswordValidation] = useState();
  const [portfolioId, setPortFolioId] = useState()
  const [addAgg, setAddAgg] = useState(false);
  const [editDocument, setEditDocument] = useState({
    visible: false,
    name: "",
  });
  const [aggDocument, setAggDocument] = useState([]);
  const [aggDocEdit, setAggDocEdit] = useState([]);
  const [aggDoc, setAggDoc] = useState([]);
  const [searchCity, setSearchCity] = useState('')
  const [isSearchCity, setIsSearchCity] = useState(false)
  const [searchPincode, setSearchPincode] = useState('')
  const [isSearchPincode, setIsSearchPincode] = useState(false)
  const [menuIsOpenCity, setMenuIsOpenCity] = useState(false)
  const [menuIsOpenPincode, setMenuIsOpenPincode] = useState(false)
  const [reportingManagers, setReportingManagers] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [currentPage, setCurrentPage] = useState(1)
  const [reportingManagerSearch, setReportingManagerSearch] = useState('')
  const [reportingManagersURL, setReportingManagersURL] = useState('')
  const [activityParams, setActivityparams] = useState("")
  const [userTypeParams, setUserTypeParams] = useState("")


  const { data: agencyLists } = useGetAgencyQuery();
  const { data: zoneLists } = useGetZoneQuery();
  const { data: regionLists, error: regionError } = useGetRegionByZoneQuery({
    ids: ZoneIds,
  });
  const { data: stateLists, error: stateError } = useGetStateByRegionQuery({
    ids: RegionIds,
  });
  // const { data: cityLists, error: cityError } = useGetCityByStateQuery({
  //   ids: StateIds,
  // });
  // const { data: pincodeLists, error: pincodeError } = useGetPincodeByCityQuery({
  //   ids: CityIds,
  // });
  const { data: portfolioLists } = useGetPortfolioQuery();

  const activityTypeOptions = useMemo(() => [
    { label: "Calling", value: "Calling" },
    { label: "Field", value: "Field" },
    { label: "Both", value: "Both" },
  ]);
  const organisationNameOptions = useMemo(
    () => [{ label: "Truboard", value: "Truboard" }],
    []
  );

  const content = manager?.content
  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(setLoader(true))
    axios.get(`/getPasswordValidations`).then((res) => {
      dispatch(setLoader(false))
      setPasswordValidation(res?.data?.data);
    }).catch(() => {
      dispatch(setLoader(false))
    })
  }, []);

  const passwordValidations = {
    minUppercase: new RegExp(`[A-Z]{${passwordValidation?.minUppercase},}`),
    requiredSpecialCharacter: new RegExp(
      `[!@#$%^&*]{${passwordValidation?.requiredSpecialCharacter},}`
    ),
    requiredDigit: new RegExp(`\\d{${passwordValidation?.requiredDigit},}`),
    maxLowercase: new RegExp(`[a-z]{${passwordValidation?.maxLowercase},}`),
  };

  const validationSchema = yup.object().shape({
    firstName: yup.string().max(50, "Too Long!").required("Required"),
    lastName: yup.string().max(50, "Too Long!").required("Required"),
    email: yup
      .string("Enter your email")
      .email("Enter a valid email")
      .required("Email is required"),

    password: yup.string().when(["isUpdate", "isView"], {
      is: () => !isUpdate && !isView,
      then: () =>
        yup
          .string()
          .required("Password is required")
          .test(
            "Pasword needs to be strong",
            `Password must contain at least ${passwordValidation?.minUppercase} uppercase letter, ${passwordValidation?.maxLowercase} lowercase letter and ${passwordValidation?.requiredSpecialCharacter} special character and ${passwordValidation?.requiredDigit} digits`,
            (value) => {
              const uppercaseRegex = passwordValidations?.minUppercase;
              const specialCharRegex =
                passwordValidations?.requiredSpecialCharacter;
              const digitRegex = passwordValidations?.requiredDigit;
              const lowercaseRegex = passwordValidations?.maxLowercase;
              const maxLength = passwordValidation?.maxPassLength;
              const MinLength = passwordValidation?.minPassLength;
              const isUppercaseValid = uppercaseRegex.test(value);
              const isSpecialCharValid = specialCharRegex.test(value);
              const isDigitValid = digitRegex.test(value);
              const isLowercaseValid = lowercaseRegex.test(value);
              return (
                isUppercaseValid &&
                isSpecialCharValid &&
                isDigitValid &&
                isLowercaseValid &&
                maxLength &&
                MinLength
              );
            }
          ),
    }),

    mobileNo: yup
      .string()
      .matches(/^[0-9]{10}$/, "Invalid mobile number")
      .required("Mobile number is required"),

    ufile: yup.mixed().when("isCertificate", {
      is: (isCertificate) => isCertificate === "Y",
      then: () => yup.mixed().required("Required"),
    }),
    designation: yup.string().required("Required"),
    zone: yup.array().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.array().min(1, "Required"),
    }),
    state: yup.array().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.array().min(1, "Required"),
    }),
    region: yup.array().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.array().min(1, "Required"),
    }),
    city: yup.array().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.array().min(1, "Required"),
    }),
    pincode: yup.array().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.array().min(1, "Required"),
    }),
    portfolio: yup.array().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.array().min(1, "Required"),
    }),
    product: yup.array().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.array().min(1, "Required"),
    }),
    agency: yup.mixed().when("userType", {
      is: (userType) => userType === "Agency",
      then: () => yup.mixed().required("Required"),
    }),
    lender: yup.object().when("userType", {
      is: (userType) => userType === "Lender",
      then: () => yup.object().required("Required"),
    }),
    // ticketSize: "",
    // bucket: [0, 10],
    // deal: "",
    organisationName: yup.object().when("userType", {
      is: (userType) => userType === "U101",
      then: () => yup.object().required("Required"),
    }),
    userType: yup.string().required("Required"),
    reportingManager: yup.string().required("Required"),
    agencyBranch: yup.mixed().when(["userType", "agency"], {
      is: (userType, agency) =>
        (userType === "U101" && agency?.length) || userType !== "Internal",
      then: () => yup.mixed().required("Required"),
    }),
    profile: yup.array().test("customProfileTest", "Required", (value) => {
      return value?.length > 0;
    }),
    role: yup.array().test("customRoleTest", "Required", (value) => {
      return value?.length > 0;
    }),
    // userName: yup.string().required("Required"),
    confirmPassword: yup
      .string()
      .oneOf([yup.ref("password"), null], "Passwords must match")
      .required("Confirm Password cannot be empty"),

    activityType: yup.object().required("Required"),
    minTicketSize: yup.string().when("userType", {
      is: (userType) => userType === "U101",
      then: () =>
        yup
          .string()
          .required("Required")
          .test(
            "minTicket",
            "Min Ticket Size value is less than or equal to Max Ticket Size value",
            (value, context) => {
              return (
                parseInt(value) <= parseInt(context?.parent?.maxTicketSize)
              );
            }
          ),
    }),
    maxTicketSize: yup.string().when("userType", {
      is: (userType) => userType === "U101", // userType === "U101",
      then: () => {
        yup
          .string()
          .required("Required")
          .test(
            "maxTicket",
            "Max Ticket Size value is greater than or equal to Min Ticket Size value",
            (value, context) => {
              return (
                parseInt(value) >= parseInt(context?.parent?.minTicketSize)
              );
            }
          );
      },
    }),
    minBucket: yup.string().when("userType", {
      is: (userType) => userType === "U101",
      then: () =>
        yup
          .string()
          .required("Required")
          .test(
            "minBucket",
            "Min Bucket Size value is less than or equal to Max Bucket Size value",
            (value, context) => {
              return parseInt(value) <= parseInt(context?.parent?.maxBucket);
            }
          ),
    }),
    maxBucket: yup.string().when("userType", {
      is: (userType) => userType === "U101",
      then: () =>
        yup
          .string()
          .required("Required")
          .test(
            "maxBucket",
            "Max Bucket Size value is greater than or equal to Min Bucket Size value",
            (value, context) => {
              return parseInt(value) >= parseInt(context?.parent?.minBucket);
            }
          ),
    }),
    loginType: yup.mixed().required("Required"),
    username: yup.string().required("required")
  });

  const LoginTypeOptions = [
    { label: "Web", value: "W" },
    { label: "Mobile", value: "M" },
    { label: "Both", value: "WM" },
  ];

  const initialValues = {
    firstName: isUpdate || isView ? data?.firstName : "",
    lastName: isUpdate || isView ? data?.lastName : "",
    email: isUpdate || isView ? data?.email : "",
    mobileNo: isUpdate || isView ? data?.mobileNo : "",
    role:
      isUpdate || isView
        ? data?.role?.map((role) => ({
          label: role?.roleName,
          profileCode: undefined,
          roleId: role?.roleId,
          value: role?.roleCode,
        }))
        : [],
    profile:
      isUpdate || isView
        ? data?.profile?.map((pro) => ({
          label: pro?.profileName,
          profileId: pro?.profileId,
          userTypeCode: pro?.userType,
          value: pro?.fieldCode,
        }))
        : [],
    userType: isUpdate || isView ? data?.userType : "",
    organisationName:
      isUpdate || isView
        ? {
          label: data?.organisationName,
          value: data?.organisationName,
        }
        : { label: "Truboard", value: "Truboard" },
    designation: isUpdate || isView ? data?.designation : "",
    reportingManager: isUpdate || isView ? data?.reportingManager : "",
    agencyBranch:
      isUpdate || isView
        ? data?.agencyBranch?.map((branch) => ({
          ...branch,
          label: branch?.branchName,
          value: branch?.branchCode,
        }))
        : [],
    zone:
      isUpdate || isView
        ? data?.zone?.map((zone) => ({
          label: zone.zoneName,
          value: zone.zoneId,
        }))
        : [],
    state:
      isUpdate || isView
        ? data?.state?.map((state) => ({
          label: state.stateName,
          value: state.stateId,
        }))
        : [],
    region:
      isUpdate || isView
        ? data?.region?.map((region) => ({
          label: region.regionName,
          value: region.regionId,
        }))
        : [],
    city:
      isUpdate || isView
        ? data?.city?.map((city) => ({
          label: city.cityName,
          value: city.cityId,
        }))
        : [],
    pincode:
      isUpdate || isView
        ? data?.pincode?.map((pincode) => ({
          label: pincode.pincode.toString(),
          value: pincode.pincodeId.toString(),
        }))
        : [],
    portfolio:
      isUpdate || isView
        ? data?.portfolio?.map((portfolio) => ({
          label: portfolio.portfolioDescription,
          value: portfolio.portfolioId,
        }))
        : [],
    product:
      isUpdate || isView
        ? data?.product?.map((product) => ({
          label: product.productDescription,
          value: product.productId,
        }))
        : [],
    maxTicketSize: isUpdate || isView ? data?.maxTicketSize || "" : "",
    minTicketSize: isUpdate || isView ? data?.minTicketSize || 0 : "",
    maxBucket: isUpdate || isView ? data?.maxBucket || "" : "",
    minBucket: isUpdate || isView ? data?.minBucket || 0 : "",
    deal: "1",
    isCertificate: "N",
    ufile: isUpdate || isView ? data?.firstName : "",
    status: isUpdate || isView ? data?.status : "Y",
    password: isUpdate || isView ? data?.password : "",
    confirmPassword: isUpdate || isView ? data?.password : "",
    sendWelcome: isUpdate || isView ? data?.sendWelcome : "Y",
    agency:
      isUpdate || isView
        ? data?.userType === "U101"
          ? data.agency?.map((a) => ({
            ...a,
            label: a?.agencyName,
            value: a?.agencyId,
          }))
          : data?.userType === "U103"
            ? {
              ...data.agency[0],
              label: data.agency[0]?.agencyName,
              value: data.agency[0]?.agencyId,
            }
            : ""
        : "",
    activityType:
      isUpdate || isView
        ? {
          label: data?.activityType,
          value: data?.activityType,
        }
        : "",
    lender:
      isUpdate || isView
        ? {
          ...data?.lender,
          label: data?.lender?.lenderName,
          value: data?.lender?.lenderId,
        }
        : "",
    loginType:
      isUpdate || isView
        ? {
          label:
            data?.loginType === "W"
              ? "Web"
              : data?.loginType === "M"
                ? "Mobile"
                : data?.loginType === "WM" && "Both",
          value: data?.loginType,
        }
        : "",
    allPincode: (isUpdate || isView) ? data?.allPincode : "",
    allCity: (isUpdate || isView) ? data?.allCity : "",
    username: (isUpdate || isView) ? data?.userName : ""
  };
  const Option = (props) => {
    return (
      <div>
        <components.Option {...props}>
          <input
            type="checkbox"
            checked={props.isSelected}
            onChange={() => null}
          />{" "}
          <label>{props.label}</label>
        </components.Option>
      </div>
    );
  };

  const fileUpload = (value, content) => {
    const formData = new FormData();
    for (let i = 0; i < value.length; i++) {
      formData.append(content, value[i]);
    }

    return formData;
  };


  const customStyles = {
    control: (base, state) => ({
      ...base,
      width: '200px', // Set your custom width here
    }),
  };


  const handleSubmit = (values) => {
    const payload = {
      ...values,
      profileIds: values?.profile?.map((profile) => profile?.profileId),
      state: values?.state?.map((state) => state?.value),
      roleIds: values?.role?.map((role) => role?.roleId),
      zone: values?.zone?.map((zone) => zone?.value),
      region: values?.region?.map((region) => region?.value),
      city: values?.allCity ? [] : values?.city?.map((city) => city?.value),
      product: values?.product?.map((product) => product?.value),
      portfolio: values?.portfolio?.map((portfolio) => portfolio?.value),
      pincode: values?.allPincode ? [] : values?.pincode?.map((pincode) => pincode?.value),
      agency:
        values?.userType === "U102"
          ? []
          : Array.isArray(values?.agency)
            ? values?.agency
            : values?.agency
              ? [values?.agency]
              : [],
      agencies: values?.userType === "U102" ? [] : (values?.userType === "U101" && values.agency.length) ? values?.agency?.map(a => ({ label: a?.label, value: a?.value })) : values?.userType === "U103" ? [{ label: values?.agency?.label, value: values?.agency?.value }] : [],
      lender: values?.userType === "U102" ? values?.lender : null,
      activityType: values?.activityType?.value,
      isActive: true,
      organisationName:
        values?.userType === "U101"
          ? values?.organisationName?.value || ""
          : "",
      password: isUpdate ? "abc" : values?.password,
      loginType: values?.loginType?.value,
      allCity: values?.allCity ? 'allCity' : 'notSelected',
      allPincode: values?.allPincode ? 'allPincode' : 'notSelected',
      userName: values?.username
    };

    delete payload.profile;
    delete payload.role;
    delete payload.confirmPassword;
    delete payload.ufile;
    dispatch(setLoader(true))
    if (isUpdate) {
      axios
        .put(`/updateUser/${data?.userId}`, payload)
        .then(async (res) => {
          dispatch(setLoader(false))
          if (res?.data?.msgKey === "Success") {
            let aggFormData = fileUpload(aggDoc, "content");
            if (aggFormData?.getAll("content")?.length) {
              try {
                dispatch(setLoader(true))
                const aggRes = await axios.post(
                  `/upload-document-user/${data?.userId}/ok`,
                  aggFormData
                );
                dispatch(setLoader(false))
                if (aggRes?.data?.msgKey === "Failure") {
                  Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${aggRes?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                  });
                } else {
                  Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `${aggRes?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                  });
                }
              } catch (error) {
                dispatch(setLoader(false))
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${error.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            }
            if (aggDocEdit?.length > 0) {
              aggDocEdit?.map(async (kycDoc) => {
                const aggDocFormData = new FormData();
                aggDocFormData.append("content", kycDoc?.data);
                try {
                  dispatch(setLoader(true))
                  const kycDocRes = await axios.put(
                    `/update-document-user/${data?.userId}/${kycDoc?.id}/ok`,
                    aggDocFormData
                  );
                  dispatch(setLoader(false))
                } catch (error) {
                  dispatch(setLoader(false))
                  Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                  });
                }
              });
            }
            // const formData = new FormData();
            // if (isEdit.flag) {
            //   formData.append("content", file);
            //   if (formData?.getAll('content').length) {
            //     axios
            //       .put(`update-document-user/${data?.userId}/${isEdit.docId}/ok`, formData, {
            //         headers: {
            //           "Content-Type": "multipart/form-data", // Set the Content-Type header
            //         },
            //       })
            //       .then(() => {
            //         // window.location.reload();
            //         onFileUploadSuccess()
            //       })
            //       .catch((error) => {
            //         Swal.fire({
            //           position: "top-end",
            //           icon: "error",
            //           title: `${error.message}`,
            //           showConfirmButton: false,
            //           toast: true,
            //           timer: 3000,
            //         });
            //       });
            //   } else {
            //     for (var i = 0; i < file?.length; i++) {
            //       formData.append("content", file[i]);
            //     }
            //     if (formData?.getAll('content').length) {
            //       axios
            //         .post(`/upload-document-user/${data?.userId}/ok`, formData, {
            //           headers: {
            //             "Content-Type": "multipart/form-data", // Set the Content-Type header
            //           },
            //         })
            //         .then(() => {
            //           // window.location.reload();
            //           onFileUploadSuccess()
            //         })
            //         .catch((error) => {
            //           Swal.fire({
            //             position: "top-end",
            //             icon: "error",
            //             title: `${error.message}`,
            //             showConfirmButton: false,
            //             toast: true,
            //             timer: 3000,
            //           });
            //         });
            //     }
            //   }
            // } else {
            //   for (var i = 0; i < file?.length; i++) {
            //     formData.append("content", file[i]);
            //   }
            //   if (formData?.getAll('content').length) {
            //     axios
            //       .post(`/upload-document-user/${data?.userId}/ok`, formData, {
            //         headers: {
            //           "Content-Type": "multipart/form-data", // Set the Content-Type header
            //         },
            //       })
            //       .then(() => {
            //         // window.location.reload();
            //         onFileUploadSuccess()
            //       })
            //       .catch((error) => {
            //         Swal.fire({
            //           position: "top-end",
            //           icon: "error",
            //           title: `${error.message}`,
            //           showConfirmButton: false,
            //           toast: true,
            //           timer: 3000,
            //         });
            //       });
            //   }
            // }
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: `${res?.data?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
            onSuccess();
          } else if (res?.data?.message === "failure") {
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${res?.data?.msgKey}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        })
        .catch((error) => {
          dispatch(setLoader(false))
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    } else {
      const formData = new FormData();
      for (let i = 0; i < values?.ufile?.length; i++) {
        formData.append("content", values?.ufile[i]);
      }
      dispatch(setLoader(true))
      axios
        .post("/createUser", payload)
        .then(({ data }) => {
          dispatch(setLoader(false))
          if (data?.message === "failure") {
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${data.msgKey}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          } else {
            if (values.ufile && values?.isCertificate === "Y") {
              let userID = data.data?.userId;
              dispatch(setLoader(true))
              axios
                .post(`/upload-document-user/${userID}/ok`, formData, {
                  headers: {
                    "Content-Type": "multipart/form-data", // Set the Content-Type header
                  },
                })
                .then(() => {
                  dispatch(setLoader(false))
                  // window.location.reload();
                  Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `${data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                  });
                  onSuccess();
                })
                .catch((error) => {
                  dispatch(setLoader(false))
                  Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                  });
                });
            } else {
              if (data?.msgKey === "Success") {
                Swal.fire({
                  position: "top-end",
                  icon: "success",
                  title: `${data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
                onSuccess();
              }
            }
          }
        })
        .catch((error) => {
          dispatch(setLoader(false))
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    }
  };

  const onBtnClickAgg = () => {
    setAddAgg(!addAgg);
  };
  const onEditClickAgg = (id, index) => {
    setEditDocument({
      visible: true,
      name: "AGGREMENT",
      index,
      docId: id,
    });
  };

  const onEditDocSave = (data) => {
    if (editDocument?.name === "AGGREMENT") {
      let duplicateDocKyc = aggDocument;
      duplicateDocKyc[editDocument?.index].name = data?.name;
      setAggDocEdit([...aggDocEdit, { data, id: editDocument?.docId }]);
    }

    setEditDocument({
      visible: false,
      name: "",
    });
  };

  const onAggSave = (data) => {
    setAggDocument([
      ...aggDocument,
      {
        name: data?.name,
        lastModifiedTime: new Date().toISOString(),
        createdTime: new Date().toISOString(),
      },
    ]);
    setAggDoc([...aggDoc, data]);
    setAddAgg(false);
  };

  const onInputChangeCity = (val) => {
    setSearchCity(val)
    setIsSearchCity(true)
  }
  const onInputChangePincode = (val) => {
    setSearchPincode(val?.toString())
    setIsSearchPincode(true)
  }


  const getReportingManagers = async (userType, activityType) => {
    try {
        if ((userType && activityType) || reportingManagersURL) {
            // Dynamically determine page size based on your criteria
            const calculatePageSize = () => {
                return 100;
            };

            const pageSize = calculatePageSize();
            const params = {
                page: currentPage,
                size: pageSize
            };
            // console.log(params, "res?.data?.data?.totalPages");

            const url = (userType && activityType) ? `/ReportingManagerList/${userType}/${activityType}` : `${reportingManagersURL}/${reportingManagerSearch}`;
            const res = await axios.get(url, { params });
            // console.log(res,'Resportingsss')

            if (res?.data?.msgKey === "Success") {
                setReportingManagersURL(url);
                setTotalPages(res?.data?.data?.totalPages);
                // console.log(res?.data?.data?.totalPages, "res?.data?.data?.totalPages");
                const data = res?.data?.data?.content;

                if (currentPage === 1) {
                    setReportingManagers(data);
                } else {
                    setReportingManagers([...reportingManagers, ...data]);
                }

                if (currentPage < res?.data?.data?.totalPages) {
                    currentPage++;
                    await getReportingManagers(userType, activityType); 
                }
            } else {
                setReportingManagersURL('');
                setTotalPages(1);
                setReportingManagers([]);
            }
        }
    } catch (error) {
        console.error("Error fetching reporting managers:", error);
    }
  }




  useEffect(() => {
    axios
      .get("/getAllRole")
      .then(({ data }) => {
        let tempRole = [];
        data?.data?.forEach((role) => {
          if (role.isActive === "Y") {
            tempRole.push({
              label: role.roleName,
              value: role.roleCode,
              profileCode: role.profileName,
              roleId: role.roleId,
            });
          }
          setRoles([...tempRole]);
        });
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });

    axios
      .get("/getAllActiveUserDesignation")
      .then(({ data }) => {
        let temp = [];
        data?.data?.forEach((e) => {
          temp.push({ label: e.description, value: e.code });
        });
        setActiveUserDesignation([...temp]);
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });

    axios
      .get("/getAllActiveProfile")
      .then(({ data }) => {
        let temp = [];
        data?.data?.forEach((profile) => {
          temp.push({
            label: profile.profileName,
            value: profile.fieldCode,
            profileId: profile.profileId,
            userTypeCode: profile.userType,
          });
        });
        setActiveProfile([...temp]);
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    axios
      .get("/getAllActiveUserType")
      .then(({ data }) => {
        let temp = [];
        data?.data?.forEach((user) => {
          temp.push({
            label: user.description,
            value: user.code,
          });
        });
        setActiveUserType([...temp]);
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });

    axios
      .get("/getAllActiveLender")
      .then(({ data }) => {
        let temp = [];
        data?.data?.forEach((e) => {
          temp.push({
            ...e,
            label: e.lenderName,
            value: e.lenderId,
          });
        });

        setActiveLender(temp);
      })
      .catch((error) => {
        console.log(error);
      });

    if (isView || isUpdate) {
      axios
        .get(`/documentUserId/${data?.userId}`)
        .then((res) => {
          if (res?.data === "") {
            setAggDocument([]);
          } else {
            setAggDocument([...res?.data]);
          }
        })
        .catch((error) => {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    }
  }, []);

  useEffect(() => {
    let tempProfile = [];
    data?.profile?.forEach((profile) => {
      let p = activeProfile?.filter((e) => e.profileId === profile.profileId);
      tempProfile = [...tempProfile, ...p];
    });

    setSelectedProfiles([...tempProfile]);
  }, [data?.profile, activeProfile]);

  useEffect(() => {
    if (selectedProfiles?.length > 0) {
      let ids = selectedProfiles?.map((e) => e.profileId);
      axios
        .get(`/getRoleByProfileId/${ids.toString()}`)
        .then(({ data }) => {
          let temp = [];
          data?.data?.forEach((role) => {
            temp.push({
              label: role.roleName,
              value: role.roleCode,
              profileCode: role.profileName,
              roleId: role.roleId,
            });
          });
          const unqTemp = [
            ...new Map(temp?.map((v) => [v.roleId, v])).values(),
          ];
          const finalValue = removeMultiSelectOptionValue(
            formik?.values?.role,
            unqTemp,
            "label",
            "label"
          );
          const isEmptyObj = !Boolean(Object.keys(formik)?.length);
          if (!isEmptyObj) {
            formik?.setFieldValue("role", finalValue);
          }
          setActiveRole([...unqTemp]);
        })
        .catch((error) => {
          //console.log(error);
        });
    } else {
      const isEmptyObj = !Boolean(Object.keys(formik)?.length);
      setActiveRole([]);
      if (!isEmptyObj) {
        formik?.setFieldValue("role", []);
      }
    }
  }, [selectedProfiles]);

  useEffect(() => {
    let agencytemp = [];
    if ((isUpdate || isView) && data?.userType === "U103" && data?.role?.some(a => a?.roleCode !== "AA")) {
      agencytemp = [{
        ...data.agency[0],
        label: data.agency[0]?.agencyName,
        value: data.agency[0]?.agencyId,
      }]
    } else {
      agencyLists?.data?.forEach((agency) => {
        // if (agency.active === "Y")
        agencytemp.push({
          ...agency,
          label: agency.agencyName,
          value: agency.agencyId,
        });
      });
    }
    setActiveAgency([...agencytemp]);
  }, [agencyLists]);

  useEffect(() => {
    let zonetemp = [];
    zoneLists?.data?.forEach((zone) => {
      if (zone.active === "Y")
        zonetemp.push({
          label: zone.zoneName,
          value: zone.zoneId,
        });
    });
    setActiveZone([...zonetemp]);
  }, [zoneLists]);

  useEffect(() => {
    let regiontemp = [];

    const isEmptyObj = !Boolean(Object.keys(formik)?.length);
    if (regionError || regionLists?.data?.length === 0) {
      if (!isEmptyObj) {
        formik?.setFieldValue("region", []);
        setRegionIds("");
      }
      setActiveRegion([]);
    } else {
      regionLists?.data?.forEach((region) => {
        if (region.active === "Y")
          regiontemp.push({
            label: region.regionName,
            value: region.regionId,
          });
      });
      const finalValue = removeMultiSelectOptionValue(
        formik?.values?.region,
        regiontemp,
        "label",
        "label"
      );

      if (!isEmptyObj) {
        formik?.setFieldValue("region", finalValue);
        setRegionIds(finalValue?.map((a) => a?.value));
      }
      setActiveRegion([...regiontemp]);
    }
  }, [regionLists, regionError]);

  useEffect(() => {
    let statetemp = [];
    const isEmptyObj = !Boolean(Object.keys(formik)?.length);

    if (stateError || stateLists?.data?.length === 0) {
      if (!isEmptyObj) {
        formik?.setFieldValue("state", []);
        setStateIds("");
      }
      setActiveState([]);
    } else {
      stateLists?.data?.forEach((state) => {
        if (state.active === "Y")
          statetemp.push({
            label: state.stateName,
            value: state.stateId,
          });
      });
      const finalValue = removeMultiSelectOptionValue(
        formik?.values?.state,
        statetemp,
        "label",
        "label"
      );

      if (!isEmptyObj) {
        formik?.setFieldValue("state", finalValue);
        setStateIds(finalValue?.map((a) => a?.value));
      }
      setActiveState([...statetemp]);
    }
  }, [stateLists, stateError]);



  // useEffect(() => {
  //   let citytemp = [];
  //   const isEmptyObj = !Boolean(Object.keys(formik)?.length);

  //   if (cityError || cityLists?.response?.length === 0) {
  //     if (!isEmptyObj) {
  //       formik?.setFieldValue("city", []);
  //       setCityIds("");
  //     }
  //     setActiveCity([]);
  //   } else if(!isSearchCity){
  //     cityLists?.response?.forEach((city) => {
  //       if (city.active === "Y")
  //         citytemp.push({
  //           label: city.cityName,
  //           value: city.cityId,
  //         });
  //     });
  //     const finalValue = removeMultiSelectOptionValue(
  //       formik?.values?.city,
  //       citytemp,
  //       "label",
  //       "label"
  //     );

  //     if (!isEmptyObj) {
  //       formik?.setFieldValue("city", finalValue);
  //       setCityIds(finalValue?.map((a) => a?.value));
  //     }
  //     setActiveCity([...citytemp]);
  //   }
  // }, [cityLists, cityError, isSearchCity]);

  // useEffect(() => {
  //   let pincodetemp = [];
  //   const isEmptyObj = !Boolean(Object.keys(formik)?.length);

  //   if (pincodeError || pincodeLists?.response?.length === 0) {
  //     if (!isEmptyObj) {
  //       formik?.setFieldValue("pincode", []);
  //     }
  //     setActivePincode([]);
  //   } else {
  //     pincodeLists?.response?.forEach((pincode) => {
  //       if (pincode.active === "Y")
  //         pincodetemp.push({
  //           label: pincode.pincode?.toString(),
  //           value: pincode.pincodeId?.toString(),
  //         });
  //     });
  //     const finalValue = removeMultiSelectOptionValue(
  //       formik?.values?.pincode,
  //       pincodetemp,
  //       "label",
  //       "label"
  //     );

  //     if (!isEmptyObj) {
  //       formik?.setFieldValue("pincode", finalValue);
  //     }
  //     setActivePincode([...pincodetemp]);
  //   }
  // }, [pincodeLists, pincodeError]);

  useEffect(() => {
    let temp = [];
    portfolioLists?.data?.forEach((portfolio) => {
      if (portfolio.active === "Y")
        temp.push({
          label: portfolio.portfolioDescription,
          value: portfolio.portfolioId,
        });
    });
    // const ids = temp?.map(item=> item?.value)?.join()
    // setPortFolioId(ids)
    setActivePortfolio([...temp]);
  }, [portfolioLists]);

  useEffect(() => {
    if (isView || isUpdate) {
      // const zoneIds = data?.zone?.map((zone) => zone?.zoneId);
      const zoneIds = zoneLists?.data?.map((zone) => zone?.zoneId);
      setZoneIds(zoneIds);
      // setZoneIds(zoneLists ?.)

      const regionIds = data?.region?.map((region) => region?.regionId);
      setRegionIds(regionIds);

      const stateIds = data?.state?.map((state) => state?.stateId);
      setStateIds(stateIds);

      const cityIds = data?.city?.map((city) => city?.cityId);
      setCityIds(cityIds);

      if (data?.userType === "U102") {
        setOrgName(data?.lender?.branches);
      } else if (data?.userType === "U103") {
        setOrgName(data?.agency[0]?.agencyBranches);
      } else if (data?.userType === "U101") {
        let op = data?.agency?.map((agency) => agency?.agencyBranches);
        op = Array.prototype.concat.apply([], op);
        setOrgName(op);
      }
    }
  }, [data]);

  useEffect(() => {
    const search = setTimeout(() => {
      if (searchCity?.length > 2) {
        const getSearchAPI = async () => {
          try {
            setMenuIsOpenCity(false)
            const payload = formik?.values?.state?.map(a => a?.value)
            const res = await axios.post(`/getCityByCityNameSelectedState/${searchCity}/0/0`, payload)
            if (res?.data?.msgKey === "Success") {
              const op = []
              res?.data?.data?.map(a => {
                if (a?.active === "Y") {
                  op?.push({
                    label: a?.cityName,
                    value: a?.cityId,
                  });
                }
              })
              setActiveCity(op)
              setTimeout(() => {
                setMenuIsOpenCity(true)
              }, 1000)
            }
          } catch (error) {

          }
        }

        getSearchAPI()
      }
    }, 1000)

    return () => {
      clearTimeout(search)
    }
  }, [searchCity])


  useEffect(() => {
    const search = setTimeout(() => {
      if (searchPincode?.length > 2) {
        const getSearchAPI = async () => {
          try {
            setMenuIsOpenCity(false)
            const payload = {
              selectedCity: formik?.values?.allCity ? [0] : formik?.values?.city?.map(a => a?.value),
              selectedStates: formik?.values?.state?.map(a => a?.value)
            }
            const res = await axios.post(`/getByPincodeForCityForSelectedState/${searchPincode}/${formik?.values?.allCity ? "Y" : "N"}`, payload)
            if (res?.data?.msgKey === "Success") {
              const op = []
              res?.data?.data?.map(a => {
                if (a?.active === "Y") {
                  op?.push({
                    label: a?.pincode + ' - ' + a.areaName,
                    value: a?.pincodeId,
                  });
                }
              })
              setActivePincode(op)
              setTimeout(() => {
                setMenuIsOpenPincode(true)
              }, 1000)
            }
          } catch (error) {

          }
        }

        getSearchAPI()
      }
    }, 1000)

    return () => {
      clearTimeout(search)
    }
  }, [searchPincode])

  useEffect(() => {
    const search = setTimeout(() => {
      if (reportingManagerSearch?.length > 2 && reportingManagersURL) {
        getReportingManagers()
      }
    }, 1000)
    return (() => {
      clearTimeout(search)
    })
  }, [reportingManagerSearch])

  useEffect(() => {
    getReportingManagers(userTypeParams, activityParams)
  }, [activityParams, userTypeParams])

  useEffect(() => {
    if (portfolioId) {
      // activePortfolio
      const portfolioid = portfolioId?.map((portfolio) => portfolio?.value)?.join()
      const activePortfolioid = activePortfolio?.map((portfolio) => portfolio?.value)?.join()
      dispatch(setLoader(true))
      axios.get(`/getProductByPortfolio/${portfolioid || activePortfolioid}`).then(({ data }) => {
        dispatch(setLoader(false))
        let tempProduct = [];
        data.data.forEach((product) => {
          tempProduct.push({
            label: product.productDescription,
            value: product.productId,
          });
        });
        setActiveProductList([...tempProduct]);
      });
      dispatch(setLoader(false))

    }
  }, [portfolioId])

  useEffect(() => {
    if (data) {
      let tempProduct = [];
      data.product.forEach((product) => {
        tempProduct.push({
          label: product.productDescription,
          value: product.productId,
        });
      });
      setActiveProductList([...tempProduct]);
    }
  }, [data])

  useEffect(() => {
    if (StateIds?.length == 0) {
      setActiveCity([])
      setActivePincode([])

    }
    if (CityIds?.length == 0) {
      setActivePincode([])
    }
  }, [StateIds, CityIds])
  return (
    <>
      <CCard>
        <CCardBody>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({
              values,
              errors,
              touched,
              handleSubmit,
              onSubmit,
              setFieldValue,
              handleBlur,
              handleChange,
              isSubmitting,
            }) => {
              // console.log(values, 'vhjvjh')
              const err = Object.keys(errors)[0];
              scrollToErrorMessage(isSubmitting, err);
              // if (edit) {
              //   edit(false)
              // getReportingManagers(values.userType, values.activityType.value)
              // }
              setActivityparams(values.activityType.value)
              setUserTypeParams(values.userType)
              return (
                <Form onSubmit={handleSubmit} autoComplete="off">
                  <Row>
                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="First Name"
                        errorMessage={touched.firstName && errors.firstName}
                      >
                        {/* {console.log(values.firstName, 'vhjhvjh')} */}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="firstName"
                          placeholder="Enter Text"
                          value={values.firstName}
                          // onChange={handleChange}
                          onChange={(e) => {
                            const value = e?.target?.value
                            if (ONE_SPACE.test(value) || value === "" || (value.length === (value.indexOf(' ') + 1) && value.length > 1)) {
                              setFieldValue("firstName", value);
                            }
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.firstName && Boolean(errors.firstName)
                          }
                          disabled={isView}
                          maxLength={50}
                        />
                      </Field>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Last Name"
                        errorMessage={touched.lastName && errors.lastName}
                      >
                        <Input
                          bsSize="sm"
                          type="text"
                          id="lastName"
                          placeholder="Enter Text"
                          value={values.lastName}
                          // onChange={handleChange}
                          onChange={(e) => {
                            if (SPACE_NOT_ALLOW.test(e.target.value)) {
                              setFieldValue("lastName", e.target.value);
                            }
                          }}
                          onBlur={handleBlur}
                          invalid={touched.lastName && Boolean(errors.lastName)}
                          disabled={isView}
                          maxLength={50}
                        />
                      </Field>
                    </Col>
                    {isUpdate || isView || (
                      <>
                        <Col lg={6} md={6} sm={12}>
                          <Field
                            isRequired
                            label="Password"
                            errorMessage={touched.password && errors.password}
                          >
                            <Input
                              bsSize="sm"
                              type="password"
                              id="password"
                              placeholder="Enter initial password"
                              value={values.password}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.password && Boolean(errors.password)
                              }
                              minLength={8}
                              maxLength={20}
                            />
                          </Field>
                        </Col>
                        <Col lg={6} md={6} sm={12}>
                          <Field
                            isRequired
                            label="Confirm Password"
                            errorMessage={
                              touched.confirmPassword && errors.confirmPassword
                            }
                          >
                            <Input
                              bsSize="sm"
                              type="password"
                              id="confirmPassword"
                              placeholder="Confirm Password"
                              value={values.confirmPassword}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              invalid={
                                touched.confirmPassword &&
                                Boolean(errors.confirmPassword)
                              }
                              maxLength={20}
                            />
                          </Field>
                        </Col>
                      </>
                    )}
                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Email ID"
                        errorMessage={touched.email && errors.email}
                      >
                        <Input
                          bsSize="sm"
                          type="email"
                          id="email"
                          placeholder="Enter Email ID"
                          value={values.email}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.email && Boolean(errors.email)}
                          disabled={isView}
                          maxLength={100}
                        />
                      </Field>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Mobile Number"
                        errorMessage={touched.mobileNo && errors.mobileNo}
                      >
                        <Input
                          bsSize="sm"
                          id="mobileNo"
                          placeholder="Enter Mobile Number"
                          value={values.mobileNo}
                          // onChange={(e) => {
                          //   if (e.target.value.length <= 10)
                          //     setFieldValue("mobileNo", e.target.value);
                          // }}
                          onChange={(e) => {
                            if (NUMBER_ONLY.test(e.target.value)) {
                              setFieldValue("mobileNo", e.target.value);
                            } else if (!e.target.value) {
                              setFieldValue("mobileNo", e.target.value);
                            }
                          }}
                          invalid={touched.mobileNo && Boolean(errors.mobileNo)}
                          onBlur={handleBlur}
                          disabled={isView}
                          maxLength={10}
                        />
                      </Field>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Designation"
                        errorMessage={touched.designation && errors.designation}
                      >
                        <Select
                          id="designation"
                          inputId="designation"
                          placeholder="Select an Option"
                          options={activeUserDesignation}
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}
                          onChange={(e) =>
                            setFieldValue("designation", e?.value)
                          }
                          value={activeUserDesignation?.filter(
                            (e) => e.value === values.designation
                          )}
                          className={cx({
                            abc:
                              touched.designation &&
                              Boolean(errors.designation),
                          })}
                          onBlur={handleBlur}
                          isDisabled={isView}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </Field>
                    </Col>

                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Activity Type"
                        errorMessage={
                          touched.activityType && errors.activityType
                        }
                      >
                        <Select
                          id="activityType"
                          inputId="activityType"
                          placeholder="Select an Option"
                          options={activityTypeOptions}
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}
                          onChange={(e) => {
                            setFieldValue("activityType", e);
                            if (values?.userType && e?.value) {
                              getReportingManagers(values?.userType, e?.value)
                              // setFieldValue('reportingManager', "")
                            }
                          }}
                          value={values?.activityType}
                          className={cx({
                            abc:
                              touched.activityType &&
                              Boolean(errors.activityType),
                          })}
                          onBlur={handleBlur}
                          isDisabled={isView}
                          autoComplete="off"
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </Field>
                    </Col>

                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="User Type"
                        errorMessage={touched.userType && errors.userType}
                      >
                        <Select
                          id="userType"
                          inputId="userType"
                          placeholder="Select an Option"
                          options={activeUserType}
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}
                          onChange={(e) => {
                            setFieldValue("userType", e?.value);
                            setFieldValue("organisationName", {
                              label: "Truboard",
                              value: "Truboard",
                            });
                            setFieldValue("agency", "");
                            setFieldValue("lender", "");
                            setFieldValue("branch", "");
                            setOrgName([]);
                            if (e?.value && values?.activityType?.value) {
                              getReportingManagers(e?.value, values?.activityType?.value)
                              setFieldValue('reportingManager', "")
                            }
                          }}
                          value={activeUserType?.filter(
                            (e) => e.value === values.userType
                          )}
                          className={cx({
                            abc: touched.userType && Boolean(errors.userType),
                          })}
                          onBlur={handleBlur}
                          isDisabled={isView}
                          autoComplete="off"
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </Field>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Profile"
                        errorMessage={touched.profile && errors.profile}
                      >
                        <Select
                          id="profile"
                          inputId="profile"
                          name="profile"
                          isMulti
                          isClearable={true}
                          options={activeProfile}
                          closeMenuOnSelect={false}
                          hideSelectedOptions={false}
                          onChange={(e) => {
                            setFormik({ values, setFieldValue });
                            setSelectedProfiles([...e]);
                            setFieldValue("profile", e);
                          }}
                          value={selectedProfiles}
                          components={{
                            Option,
                          }}
                          className={cx({
                            abc: touched.profile && Boolean(errors.profile),
                          })}
                          onBlur={handleBlur}
                          isDisabled={isView}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </Field>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Role"
                        errorMessage={touched.role && errors.role}
                      >
                        <Select
                          id="role"
                          inputId="role"
                          name="role"
                          isMulti
                          isClearable={true}
                          options={activeRole}
                          closeMenuOnSelect={false}
                          hideSelectedOptions={false}
                          onChange={(e) => {
                            setFieldValue("role", e)
                            if (e?.some(a => a?.value === "AA")) {
                              setFieldValue("reportingManager", "0")
                            }
                          }}
                          value={values.role}
                          components={{
                            Option,
                          }}
                          className={cx({
                            abc: touched.role && Boolean(errors.role),
                          })}
                          onBlur={handleBlur}
                          isDisabled={isView}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </Field>
                    </Col>

                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="Reporting Manager"
                        errorMessage={
                          touched.reportingManager && errors.reportingManager
                        }
                      >
                         {console.log(
                            (values?.role?.some(a => a?.value === "AA") && (!isUpdate && !isView)) ? 
                              [{ value: '0', label: `Self` }] :
                              (values?.role?.some(a => a?.value === "AA") && (isUpdate || isView)) ? 
                                (values?.reportingManager == 0) ? [{ value: '0', label: `Self` }] : 
                                  [{ value: values?.reportingManager, label: `${values?.firstName} ${values?.lastName}` }] : 
                                  reportingManagers?.filter(a => a?.value?.toString() === values?.reportingManager?.toString())
                          )}
                        {/* {console.log(values?.reportingManager, reportingManagers, "chchchc")} */}
                        <Select
                          id="reportingManager"
                          inputId="reportingManager"
                          placeholder="Select an Option"
                          options={
                            (values?.role?.some(a => a?.value === "AA") && (!isUpdate && !isView)) ? [{ value: '0', label: `Self` }] :
                              (values?.role?.some(a => a?.value === "AA") && (isUpdate || isView)) ? [{ value: values?.reportingManager, label: `${values?.firstName} ${values?.lastName}` }] :
                                reportingManagers
                          }
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}

                          onChange={(e) => {
                            if (values?.userType === "U103" && values?.role?.some(a => a?.value !== "AA")) {
                              setActiveAgency(e?.agency?.map(a => ({ ...a, label: a.label, value: a.value })))
                            }
                            setFieldValue("reportingManager", e?.value)
                            setFieldValue("agency", "")
                          }}
                          onInputChange={(e) => {
                            setReportingManagerSearch(e)
                            setCurrentPage(1)
                          }}
                          onMenuScrollToBottom={() => {
                            if (currentPage <= totalPages) {
                              setCurrentPage(prev => prev + 1)
                            }
                          }}
                         
                          
                          value={
                            (values?.role?.some(a => a?.value === "AA") && (!isUpdate && !isView)) ? [{ value: '0', label: `Self` }] :
                              (values?.role?.some(a => a?.value === "AA") && (isUpdate || isView)) ? (values?.reportingManager == 0) ? [{ value: '0', label: `Self` }] : [{ value: values?.reportingManager, label: `${values?.firstName} ${values?.lastName}` }] : reportingManagers?.filter(a => a?.value?.toString() === values?.reportingManager?.toString())
                          }
                          className={cx({
                            abc:
                              touched.reportingManager &&
                              Boolean(errors.reportingManager),
                          })}
                          onBlur={handleBlur}
                          isDisabled={isView}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </Field>
                    </Col>

                    {values?.userType === "U101" && (
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Organisation Name"
                          errorMessage={
                            touched.organisationName && errors.organisationName
                          }
                        >
                          <Select
                            id="organisationName"
                            inputId="OrganisationName"
                            placeholder="Select an Option"
                            options={organisationNameOptions}
                            closeMenuOnSelect={true}
                            hideSelectedOptions={false}
                            onChange={(e) => {
                              setFieldValue("organisationName", e);
                            }}
                            value={values?.organisationName}
                            className={cx({
                              abc:
                                touched.organisationName &&
                                Boolean(errors.organisationName),
                            })}
                            onBlur={handleBlur}
                            isDisabled={isView}
                            autoComplete="off"
                            menuPosition="fixed"
                            classNamePrefix="react-select"
                          />
                        </Field>
                      </Col>
                    )}

                    {values?.userType === "U102" && (
                      <>
                        <Col lg={6} md={6} sm={12}>
                          <Field
                            isRequired
                            label="Lender Name"
                            errorMessage={touched.lender && errors.lender}
                          >
                            <Select
                              id="lender"
                              inputId="lender"
                              placeholder="Select an Option"
                              options={activeLender}
                              closeMenuOnSelect={true}
                              hideSelectedOptions={false}
                              onChange={(e) => {
                                setFieldValue("branch", "");
                                setOrgName(e?.branches);
                                setFieldValue("lender", e);
                              }}
                              value={values?.lender}
                              className={cx({
                                abc: touched.lender && Boolean(errors.lender),
                              })}
                              onBlur={handleBlur}
                              isDisabled={isView}
                              autoComplete="off"
                              menuPosition="fixed"
                              classNamePrefix="react-select"
                            />
                          </Field>
                        </Col>
                      </>
                    )}

                    {(values?.userType === "U101" ||
                      values?.userType === "U103") && (
                        <>
                          <Col lg={6} md={6} sm={12}>
                            <Field
                              isRequired={values?.userType === "U103"}
                              label={`Agency ${values?.userType === "U103"
                                ? "Name"
                                : values?.userType === "U101" && "Mapping"
                                }`}
                              errorMessage={touched.agency && errors.agency}
                            >
                              <Select
                                id="agency"
                                isMulti={values?.userType === "U101"}
                                inputId="agency"
                                placeholder="Select an Option"
                                options={activeAgency}
                                // options={(values?.userType === "U103" && values?.reportingManager !== "0") ?  activeAgency}
                                closeMenuOnSelect={values?.userType !== "U101"}
                                hideSelectedOptions={false}
                                onChange={(e) => {
                                  const checkArray = Array.isArray(e);
                                  let branches = checkArray ? e?.map((branch) => branch?.agencyBranches) : e?.branch;
                                  branches = Array.prototype.concat.apply([], branches);
                                  setFieldValue("branch", "");
                                  setOrgName(branches);
                                  setFieldValue("agency", e);
                                  if (branches?.length) {
                                    const finalValue =
                                      removeMultiSelectOptionValue(
                                        values?.agencyBranch,
                                        branches,
                                        "branchCode",
                                        "branchCode"
                                      );
                                    setFieldValue("agencyBranch", finalValue);
                                  } else {
                                    setFieldValue("agencyBranch", []);
                                  }
                                  // const finalValue = values?.agencyBranch?.filter
                                  // setFormik({values,setFieldValue})
                                }}
                                components={
                                  values?.userType === "U101" && {
                                    Option,
                                  }
                                }
                                value={values?.agency}
                                className={cx({
                                  abc: touched.agency && Boolean(errors.agency),
                                })}
                                onBlur={handleBlur}
                                isDisabled={isView}
                                autoComplete="off"
                                menuPosition="fixed"
                                classNamePrefix="react-select"
                              />
                            </Field>
                          </Col>
                        </>
                      )}

                    <Col lg={6} md={6} sm={12}>
                      <Branches
                        isView={isView}
                        orgName={orgName}
                        Option={Option}
                      />
                    </Col>
                    {/* {console.log(values, "valuesvalues")} */}
                    {(values?.userType === "U101" || values?.userType === "U102") && (

                      <>
                        <h4>Allocation Logic</h4>
                        <Card className="mb-3">
                          <CardBody>
                            <Row>
                              {values?.userType !== "U102" &&
                                <>
                                  <Col lg={6} md={6} sm={12}>
                                    <Field
                                      isRequired
                                      label="Zone"
                                      errorMessage={touched.zone && errors.zone}
                                    >
                                      <Select
                                        id="zone"
                                        inputId="zone"
                                        name="zone"
                                        isMulti
                                        isClearable={true}
                                        options={activeZone}
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        onChange={(e) => {
                                          setZoneIds(e?.map((zone) => zone?.value));
                                          setFieldValue("zone", e);
                                          setFormik({ values, setFieldValue });
                                        }}
                                        value={values?.zone}
                                        components={{
                                          Option,
                                        }}
                                        className={cx({
                                          abc: touched.zone && Boolean(errors.zone),
                                        })}
                                        onBlur={handleBlur}
                                        isDisabled={isView}
                                        menuPosition="fixed"
                                        classNamePrefix="react-select"
                                      />
                                    </Field>
                                  </Col>
                                  <Col lg={6} md={6} sm={12}>
                                    <Field
                                      isRequired
                                      label="Region"
                                      errorMessage={touched.region && errors.region}
                                    >
                                      <Select
                                        id="region"
                                        inputId="region"
                                        name="region"
                                        isMulti
                                        isClearable={true}
                                        options={activeRegion}
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        onChange={(e) => {
                                          setRegionIds(
                                            e?.map((region) => region?.value)
                                          );
                                          setFieldValue("region", e);
                                          setFormik({ values, setFieldValue });
                                        }}
                                        value={values?.region}
                                        components={{
                                          Option,
                                        }}
                                        className={cx({
                                          abc:
                                            touched.region &&
                                            Boolean(errors.region),
                                        })}
                                        onBlur={handleBlur}
                                        isDisabled={isView}
                                        menuPosition="fixed"
                                        classNamePrefix="react-select"
                                      />
                                    </Field>
                                  </Col>
                                  <Col lg={6} md={6} sm={12}>
                                    <Field
                                      isRequired
                                      label="State"
                                      errorMessage={touched.state && errors.state}
                                    >
                                      <MultiSelect
                                        options={activeState}
                                        value={values?.state}
                                        onChange={(e) => {
                                          setStateIds(
                                            e?.map((state) => state?.value)
                                          );
                                          setFieldValue("state", e);
                                          setFormik({ values, setFieldValue });
                                        }}
                                        overrideStrings={{
                                          selectSomeItems: "Select...",
                                          allItemsAreSelected: "Select All",
                                          selectAll: "Select All",
                                        }}
                                        labelledBy={"Select"}
                                        isCreatable={true}
                                      />
                                      {/* <Select
                                        id="state"
                                        inputId="state"
                                        name="state"
                                        isMulti
                                        isClearable={true}
                                        options={activeState}
                                        closeMenuOnSelect={false}
                                        hideSelectedOptions={false}
                                        onChange={(e) => {
                                          setStateIds(
                                            e?.map((state) => state?.value)
                                          );
                                          setFieldValue("state", e);
                                          setFormik({ values, setFieldValue });
                                        }}
                                        value={values?.state}
                                        components={{
                                          Option,
                                        }}
                                        className={cx({
                                          abc:
                                            touched.state && Boolean(errors.state),
                                        })}
                                        onBlur={handleBlur}
                                        isDisabled={isView}
                                        menuPosition="fixed"
                                        classNamePrefix="react-select"
                                      /> */}
                                    </Field>
                                  </Col>
                                  <Col lg={6} md={6} sm={12}>
                                    <Field
                                      isRequired
                                      label="City"
                                      errorMessage={touched.city && errors.city}
                                    >
                                      <MultiSelectComma
                                        options={activeCity}
                                        onChange={(e, action, isSelectAll) => {
                                          setCityIds(
                                            e?.map((state) => state?.value)
                                          );
                                          if (!e?.length || isSelectAll) {
                                            setIsSearchCity(false)
                                            setSearchCity('')
                                            setActiveCity([])
                                          }
                                          setCityIds(e?.map(a => a?.value))
                                          setFieldValue('city', e)
                                          setFieldValue('allCity', isSelectAll)
                                          setFormik({ values, setFieldValue })
                                        }}
                                        closeMenu={false}
                                        value={values?.allCity === "All Cities" ? [{ value: "<SELECT_ALL>", label: "Select All", }] : values?.city}
                                        isClearable
                                        isDisabled={isView}
                                        onInputChange={(value) => {
                                          setFormik({ values, setFieldValue })
                                          onInputChangeCity(value)
                                        }}
                                        searchValue={searchCity}
                                        isSearch={isSearchCity}
                                        setIsSearch={setIsSearchCity}
                                        menuIsOpen={menuIsOpenCity}
                                        isMulti={true}
                                      />
                                    </Field>
                                  </Col>
                                  <Col lg={6} md={6} sm={12}>
                                    <Field
                                      isRequired
                                      label="Pincode"
                                      errorMessage={touched.pincode && errors.pincode}
                                    >
                                
                                      <MultiSelectComma
                                        options={activePincode}
                                        onChange={(e, action, isSelectAll) => {
                                          if (!e?.length || isSelectAll) {
                                            setIsSearchPincode(false)
                                            setSearchPincode('')
                                            setActivePincode([])
                                          }
                                          setFieldValue('pincode', e)
                                          setFieldValue('allPincode', isSelectAll)
                                          setFormik({ values, setFieldValue })
                                        }}
                                        closeMenu={false}
                                        value={values?.allPincode === "All Pincodes" ? [{ value: "<SELECT_ALL>", label: "Select All" }] : values?.pincode}
                                        isClearable
                                        isDisabled={isView}
                                        onInputChange={(value) => {
                                          setFormik({ values, setFieldValue })
                                          onInputChangePincode(value)
                                        }}
                                        searchValue={searchPincode}
                                        isSearch={isSearchPincode}
                                        setIsSearch={setIsSearchPincode}
                                        menuIsOpen={menuIsOpenPincode}
                                        isMulti={true}
                                      />
                                    </Field>
                                  </Col>
                                  <Col lg={6} md={6} sm={12}></Col> </>
                              }
                              <Col lg={6} md={6} sm={12}>
                                <Field
                                  isRequired
                                  label="Portfolio"
                                  errorMessage={
                                    touched.portfolio && errors.portfolio
                                  }
                                >
                                  <Select
                                    id="portfolio"
                                    inputId="portfolio"
                                    name="portfolio"
                                    isMulti
                                    isClearable={true}
                                    options={activePortfolio}
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    onChange={(e) => {
                                      setFieldValue("portfolio", e);
                                      setPortFolioId(e)
                                    }}
                                    value={values?.portfolio}
                                    components={{
                                      Option,
                                    }}
                                    className={cx({
                                      abc:
                                        touched.portfolio &&
                                        Boolean(errors.portfolio),
                                    })}
                                    onBlur={handleBlur}
                                    isDisabled={isView}
                                    menuPosition="fixed"
                                    classNamePrefix="react-select"
                                  />
                                </Field>
                              </Col>
                              <Col lg={6} md={6} sm={12}>
                                {/* <ProductDropdown
                                  isView={isView}
                                  portfolioListSelected={values.portfolio}
                                  ids={`product`}
                                  value={values.product}
                                /> */}
                                <Field
                                  isRequired
                                  label="Product"
                                  errorMessage={
                                    touched.product && errors.product
                                  }
                                >
                                  {/* {console.log(activeProductList, "activevevvv")} */}
                                  <MultiSelect
                                    options={activeProductList}
                                    value={values?.product}
                                    onChange={(e) => {
                                      // setStateIds(
                                      //   e?.map((state) => state?.value)
                                      // );
                                      setFieldValue("product", e);
                                      setFormik({ values, setFieldValue });
                                    }}
                                    overrideStrings={{
                                      selectSomeItems: "Select...",
                                      allItemsAreSelected: "Select All",
                                      selectAll: "Select All",
                                    }}
                                    labelledBy={"Select"}
                                    isCreatable={true}
                                    styles={{ width: "200px" }}
                                  />
                                </Field>
                              </Col>

                              {values?.userType !== "U102" &&
                                <>
                                  <Col lg={6} md={6} sm={12}>
                                    <Field
                                      isRequired
                                      label="Ticket Size"
                                      childrenClassName="minMaxField"
                                    >
                                      <div>
                                        <p>Min</p>
                                        <Input
                                          bsSize="sm"
                                          id="minTicketSize"
                                          placeholder="min ticket size"
                                          value={values.minTicketSize}
                                          onChange={(e) => {
                                            if (
                                              NUMBER_ONLY.test(e?.target?.value) ||
                                              !e?.target?.value
                                            ) {
                                              setFieldValue(
                                                "minTicketSize",
                                                e?.target?.value
                                              );
                                            }
                                          }}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.minTicketSize &&
                                            Boolean(errors.minTicketSize)
                                          }
                                          maxLength={10}
                                          disabled={isView}
                                        />
                                        {touched?.minTicketSize &&
                                          errors?.minTicketSize && (
                                            <p className="errorMsg">
                                              {errors?.minTicketSize}
                                            </p>
                                          )}
                                      </div>
                                      <div>
                                        <p>Max</p>
                                        <Input
                                          bsSize="sm"
                                          id="maxTicketSize"
                                          placeholder="max ticket size"
                                          value={values.maxTicketSize}
                                          onChange={(e) => {
                                            if (
                                              NUMBER_ONLY.test(e?.target?.value) ||
                                              !e?.target?.value
                                            ) {
                                              setFieldValue(
                                                "maxTicketSize",
                                                e?.target?.value
                                              );
                                            }
                                          }}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.maxTicketSize &&
                                            Boolean(errors.maxTicketSize)
                                          }
                                          maxLength={10}
                                          disabled={isView}
                                        />
                                        {touched?.maxTicketSize &&
                                          errors?.maxTicketSize && (
                                            <p className="errorMsg">
                                              {errors?.maxTicketSize}
                                            </p>
                                          )}
                                      </div>
                                    </Field>
                                  </Col>
                                  <Col lg={6} md={6} sm={12}>
                                    <Field
                                      isRequired
                                      label="Bucket"
                                      childrenClassName="minMaxField"
                                    >
                                      <div>
                                        <p>Min</p>
                                        <Input
                                          bsSize="sm"
                                          id="minBucket"
                                          placeholder="min bucket size"
                                          value={values.minBucket}
                                          onChange={(e) => {
                                            if (
                                              NUMBER_ONLY.test(e?.target?.value) ||
                                              !e?.target?.value
                                            ) {
                                              setFieldValue(
                                                "minBucket",
                                                e?.target?.value
                                              );
                                            }
                                          }}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.minBucket &&
                                            Boolean(errors.minBucket)
                                          }
                                          maxLength={4}
                                          disabled={isView}
                                        />
                                        {touched?.minBucket &&
                                          errors?.minBucket && (
                                            <p className="errorMsg">
                                              {errors?.minBucket}
                                            </p>
                                          )}
                                      </div>

                                      <div>
                                        <p>Max</p>
                                        <Input
                                          bsSize="sm"
                                          id="maxBucket"
                                          placeholder="max bucket size"
                                          value={values.maxBucket}
                                          onChange={(e) => {
                                            if (
                                              NUMBER_ONLY.test(e?.target?.value) ||
                                              !e?.target?.value
                                            ) {
                                              setFieldValue(
                                                "maxBucket",
                                                e?.target?.value
                                              );
                                            }
                                          }}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.maxBucket &&
                                            Boolean(errors.maxBucket)
                                          }
                                          maxLength={4}
                                          disabled={isView}
                                        />
                                        {touched?.maxBucket &&
                                          errors?.maxBucket && (
                                            <p className="errorMsg">
                                              {errors?.maxBucket}
                                            </p>
                                          )}
                                      </div>
                                    </Field>
                                  </Col>
                                </>
                              }


                            </Row>
                          </CardBody>
                        </Card>
                      </>
                    )}
                    <Col lg={6} md={6} sm={12}>
                      <Field label="Send welcome info">
                        <FormGroup switch className="ms-2">
                          <Input
                            type="switch"
                            checked={values.sendWelcome === "Y"}
                            onChange={(e) =>
                              setFieldValue(
                                "sendWelcome",
                                e.target.checked ? "Y" : "N"
                              )
                            }
                            id="sendWelcome"
                            readOnly
                            disabled={isView}
                          />
                        </FormGroup>
                      </Field>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                      <Field label="Status">
                        <FormGroup switch className="ms-2">
                          <Input
                            type="switch"
                            checked={values.status === "Y"}
                            onChange={(e) =>
                              setFieldValue(
                                "status",
                                e.target.checked ? "Y" : "N"
                              )
                            }
                            id="status"
                            readOnly
                            disabled={isView}
                          />
                        </FormGroup>
                      </Field>
                    </Col>

                    <Col>
                      <Field
                        isRequired
                        label="Login Type"
                        errorMessage={touched.loginType && errors.loginType}
                      >
                        <Select
                          id="loginType"
                          inputId="loginType"
                          name="loginType"
                          isClearable={true}
                          options={LoginTypeOptions}
                          closeMenuOnSelect={true}
                          hideSelectedOptions={false}
                          onChange={(e) => setFieldValue("loginType", e)}
                          value={values.loginType}
                          className={cx({
                            abc: touched.loginType && Boolean(errors.loginType),
                          })}
                          onBlur={handleBlur}
                          isDisabled={isView}
                          menuPosition="fixed"
                          classNamePrefix="react-select"
                        />
                      </Field>
                    </Col>

                    <Col lg={6} md={6} sm={12}>
                      <Field
                        isRequired
                        label="User Name"
                        errorMessage={touched.username && errors.username}
                      >
                        <Input
                          bsSize="sm"
                          type="text"
                          id="username"
                          placeholder="Enter Username"
                          value={values.username}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.username && Boolean(errors.username)}
                          disabled={isView || isUpdate}
                          maxLength={100}
                        />
                        {/* {console.log(values.username,"values.username")} */}
                      </Field>
                    </Col>

                    {isView || isUpdate || (
                      <>
                        <Col lg={12} md={12} sm={12}>
                          <Field label="Certificate Upload">
                            <FormGroup switch className="ms-2">
                              <Input
                                type="switch"
                                id="isCertificate"
                                checked={values.isCertificate === "Y"}
                                onChange={(e) =>
                                  setFieldValue(
                                    "isCertificate",
                                    e.target.checked ? "Y" : "N"
                                  )
                                }
                              />
                              <div className="col-lg-10 col-md-10 col-sm-12">
                                <Input
                                  bsSize="sm"
                                  type="file"
                                  id="ufile"
                                  className="form-control"
                                  style={{ width: "fit-content" }}
                                  disabled={!(values.isCertificate === "Y")}
                                  onChange={(event) => {
                                    setFieldValue(
                                      "ufile",
                                      event?.currentTarget?.files
                                    );
                                  }}
                                  invalid={
                                    values.isCertificate === "Y" &&
                                    touched.ufile &&
                                    Boolean(errors.ufile)
                                  }
                                  multiple
                                ></Input>
                                {touched.ufile && errors.ufile && (
                                  <div
                                    style={{ display: "block" }}
                                    className="invalid-feedback"
                                  >
                                    {errors.ufile}
                                  </div>
                                )}
                              </div>
                            </FormGroup>
                          </Field>
                        </Col>
                      </>
                    )}
                  </Row>

                  {!(isView || isUpdate) || (
                    // <Container className="p-2">
                    //   {certificateDocument?.length ? certificateDocument?.map(a => (
                    //     <Table className="text-center">
                    //       <thead>
                    //         <tr>
                    //           <th>Document Name</th>
                    //           <th>Action</th>
                    //         </tr>
                    //       </thead>
                    //       <tbody>
                    //         <tr>
                    //           <td>{a?.name}</td>
                    //           <td>
                    //             {
                    //               <ButtonGroup
                    //                 style={{
                    //                   width: "-webkit-fill-available",
                    //                 }}
                    //               >
                    //                 <Button
                    //                   size="sm"
                    //                   color="success"
                    //                   outline
                    //                   onClick={() =>
                    //                     DownloadFile(
                    //                       `/download-user-document/${a?.docUserId}`,
                    //                       a?.name
                    //                     )
                    //                   }
                    //                 >
                    //                   <i className="bi bi-download me-3"></i>
                    //                   Download - {a?.name}
                    //                 </Button>
                    //                 {isView || (
                    //                   <Button
                    //                     size="sm"
                    //                     color="primary"
                    //                     outline
                    //                     onClick={() => {
                    //                       setIsEdit({
                    //                         ...isEdit,
                    //                         flag: true,
                    //                         docId:
                    //                           a?.docUserId,
                    //                       });
                    //                       setDocumentModal(!documentModal);
                    //                     }}
                    //                   >
                    //                     <i className="bi bi-pencil-square"></i>
                    //                     Edit
                    //                   </Button>
                    //                 )}
                    //               </ButtonGroup>
                    //             }
                    //           </td>
                    //         </tr>
                    //       </tbody>
                    //     </Table>
                    //   )) : (
                    //     <>
                    //       <h3>No Document Found</h3>
                    //       <Button
                    //         size="sm"
                    //         color="success"
                    //         outline
                    //         onClick={() => {
                    //           setDocumentModal(!documentModal)
                    //           setIsEdit({
                    //             ...isEdit,
                    //             flag: false
                    //           })
                    //         }}
                    //       >
                    //         {file?.length ? `${file?.length} Files Selected` : 'Add Certificate'}
                    //       </Button>
                    //     </>
                    //   )}
                    // </Container>

                    <FileTable
                      onBtnClick={onBtnClickAgg}
                      isView={isView}
                      btnName="Add Aggrement Document"
                      docData={aggDocument}
                      id="docUserId"
                      downloadURL="/download-user-document"
                      onEditClick={onEditClickAgg}
                    />
                  )}

                  {isView || (
                    <div className="d-flex justify-content-end">
                      <Button color="primary" type="submit" size="sm">
                        Submit
                      </Button>
                    </div>
                  )}
                </Form>
              );
            }}
          </Formik>
        </CCardBody>
      </CCard>

      {addAgg && (
        <FileUpload
          header="Add Aggrement"
          visible={addAgg}
          setVisible={setAddAgg}
          onSave={onAggSave}
        />
      )}

      {editDocument?.visible && (
        <FileUpload
          header={`Edit ${editDocument?.name} Document`}
          visible={editDocument?.visible}
          setVisible={() => {
            setEditDocument({
              visible: false,
              name: "",
            });
          }}
          onSave={onEditDocSave}
        />
      )}
      {/* <Dialog
        header={isEdit ? "Edit Certificate" : "Add Certificate"}
        visible={documentModal}
        style={{
          width: "60vw",
        }}
        onHide={() => {
          setDocumentModal(!documentModal);
          setIsEdit({ ...isEdit, flag: false, docId: "" });
        }}
      >
        <label className="btn btn-sm upload-button btn-outline-primary">
          <i className="bi bi-upload uploadIcon"></i>
          {file ? file.name : "Select Certificate"}
          <input
            type="file"
            style={{ display: "none" }}
            onChange={(e) => {
              const val = certificateDocument?.length ? e.target?.files[0] : e.target?.files
              setFile(val);
            }}
            multiple={!certificateDocument?.length}
          />
        </label>
        <Button
          size="sm"
          color="success"
          className="m-2 ms-auto d-flex text-white"
          onClick={() => handleFileUpload(data?.userId)}
          disabled={!file}
        >
          Save
        </Button>
      </Dialog> */}
    </>
  );
};

export default AddUser;
