import { createAsyncThunk,createSlice } from '@reduxjs/toolkit';
import axios from 'axios';
import { baseUrl } from '../../../App.config';
import { setLoader } from '../../../reducer/globalReducer';

export const getAllUser = createAsyncThunk(
  'user/getAllUser', 
  async (params,{dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + "/getAllUserList");   
      // const response = await axios.get(baseUrl() + "/getUserForAllocation");   

      // console.log(response, "userlist response")
      dispatch(setLoader(false)) 
      return {
        list:response?.data?.data?.content,
      }
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch user data.');
    }
  }
);

export const addUser = createAsyncThunk(
  'user/addUser', 
  async (params, {dispatch}) => {
    try {
      dispatch(setLoader(true))
      await axios.post(baseUrl() + "/createUser",params);  
      dispatch(setLoader(false)) 
      dispatch(getAllUser()) 
      return true
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch user data.');
    }
  }
);
export const editUser = createAsyncThunk(
  'user/editUser', 
  async (params, {dispatch}) => {
    try {
      dispatch(setLoader(true))
      await axios.post(baseUrl() + `/updateUser/${params?.userId}`,params);   
      dispatch(setLoader(false))
      dispatch(getAllUser()) 
      return true
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch user data.');
    }
  }
);

export const deleteUser = createAsyncThunk(
    'user/deleteUser', 
    async (params, {dispatch}) => {
      try {
        dispatch(setLoader(true))
        await axios.put(baseUrl() + `/deleteUser/${params?.id}`);   
        dispatch(setLoader(false))
        dispatch(getAllUser()) 
        return true
      } catch (error) {
        dispatch(setLoader(false))
        throw new Error('Failed to fetch user data.');
      }
    }
  );
export const searchUser = createAsyncThunk(
  'user/searchBankMaster', 
  async (search,{dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + `/getUserByUID/${search}`);    
      dispatch(setLoader(false))
      return {
        list:response?.data?.data,
      }
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch State data.');
    }
  }
);

export const user = createSlice({
  name: 'user',
  initialState: { 
    list: [], 
    loader: false, 
    error: '',
    selected:null
  },
  reducers: {
    setSelected:(state,action)=>{
      action.payload === null ? state.selected = null : state.selected = action.payload 
    },
    setLoder:(state,action)=>{
      state.loader = action.payload 
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllUser.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.list;
      })
      builder
      .addCase(searchUser.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.list;
      })
  },
});  

export const { setSelected,setLoder } = user.actions;

export default user.reducer;
