import React, { useEffect, useState } from "react";
import AddUser from "./AddUser";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import {
  Card,
  CardBody,
  ButtonGroup,
  Container
} from "reactstrap";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import BulkUploadUserForm from "./BulkUploadUserForm";
import SearchBarHeader from "../../components/Header/SearchBarHeader";
import { setLoader } from "../../reducer/globalReducer";
import Pagination from "../../components/Pagination";
import moment from "moment";

export default function User({ access }) {
  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);
  const [view, setView] = useState(false);
  const [edit, setEdit] = useState(false);
  const [searchActive, setSearchActive] = useState(false)
  const [swich, setswitch] = useState(true)
  const [userData, setUserData] = useState([]);
  const [data, setData] = useState({});
  const [manager, setManager] = useState([]);
  const [bulkUploadUser, setBulkUploadUser] = useState(false)
  const [numberOfDataPerPage, setNumberOfDataPerPage] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalCount, setTotalCount] = useState(0)

  const [isViewCheck, setViewCheck] = useState(0);

  const dispatch = useDispatch()
  const getAllUser = async () => {
    try {
      dispatch(setLoader(true))
      // const res = await axios.get(`/getAllUsers/${currentPage}/${numberOfDataPerPage}`)
      const res = await axios.get(`/getUsers/${currentPage}/${numberOfDataPerPage}`)

      dispatch(setLoader(false))

      if (res?.data?.msgKey === "Success") {
        setUserData(res?.data?.data?.content)
        setTotalCount(res?.data?.data?.totalElements)

        // const managerData = res?.data?.data?.map(data => ({
        //   value: data?.userId?.toString(),
        //   label: `${data?.firstName} ${data?.lastName}`
        // }))

        setManager(res?.data?.data)
      } else {
        setUserData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }


  const getDataForUpdate = async (id) => {
    try {
      const res = await axios.get(`/getUserByUserId/${id}`)
      // console.log(res?.data.data, 'vhjjhv')
      setData(res?.data.data);
      if (res?.data.msgKey == "Success") {
        setEdit(!edit);
        setswitch(!swich)
      }

    } catch (error) {

    }
  }

  const getDataForView = async (id) => {
    try {
      const res = await axios.get(`/getUserByUserId/${id}`)
      // console.log(res?.data.data, 'vcghvchgvchg')
      setData(res?.data.data);
      if (res?.data.msgKey == "Success") {
        setView(!view);
      }
    } catch (error) {

    }
  }

  const searchUser = async (val) => {

    try {
      // setSearchActive(true)
      dispatch(setLoader(true))
      const res = await axios.get(`/getUserByUID/${val}`)

      dispatch(setLoader(false))
      if (res?.data?.msgKey === 'Success') {
        setUserData(res?.data?.data)
      } else {
        setUserData([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }



  const onSuccess = () => {
    if (open) {
      setOpen(false)
    } else if (edit) {
      setEdit(!edit)
    } else if (view) {
      setView(!view)
    }
    getAllUser()
  }


  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => searchUser(data)}
        getAllAPI={() => getAllUser()}
        onClick={() => {
          setOpen(!open)
        }}
        permission={user?.masterRole?.[access]}
        currentPage={currentPage}
        numberOfDataPerPage={numberOfDataPerPage}
      />

      <Card className="flex-grow-1 mb-1">
        {/* <CardHeader className="p-2 d-flex justify-content-between align-items-center">
          <p className="m-0">Users</p>
          {user?.masterRole[access] === "V" || (
            <Button size={"sm"} color="primary" onClick={onClickUploadBulkUser}>
              Upload Data
            </Button>
          )}
        </CardHeader> */}
        <CardBody className="tableCardBody p-1 d-flex flex-column" style={{ minHeight: 400, padding: '5px' }}>
          <DataTable
            value={userData}
            className="commonTable casesTable"
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            size={"small"}
            removableSort
          >
            <Column
              field="userId"
              header="Fullname"
              body={(rowData) => {
                return rowData.firstName + " " + rowData.lastName;
              }}
              sortable
            ></Column>
            <Column field="email" header="Email ID" sortable></Column>
            <Column field="mobileNo" header="Mobile Number" sortable></Column>
            <Column field="userName" header="Username" sortable></Column>
            <Column
              header="Create Date"
              body={(rowData) => {
                return moment(rowData.createdTime).format(
                  "DD-MM-YYYY HH:mm:ss"
                );
              }}
              sortable
            />
            <Column
              header="Update Date"
              sortable
              body={(rowData) => {
                return moment(rowData.lastModifiedTime).format(
                  "DD-MM-YYYY HH:mm:ss"
                );
              }}
            />
            <Column
              field="status"
              header="Status"
              body={(rowData) =>
                rowData.status === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                (
                  <ButtonGroup>
                    {["V", "F"].includes(user?.masterRole[access]) && (
                      <i
                        className="bi bi-eye-fill text-primary"
                        style={{ cursor: "pointer" }}
                        onClick={() => {
                          getDataForView(rowData?.userId)
                        }}
                      />
                    )}
                    {user?.masterRole[access] === "F" && (
                      <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                    )}
                    {/* {["E", "F"].includes(user?.masterRole[access]) && ( */}
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {

                        getDataForUpdate(rowData?.userId)
                        // setData({ ...rowData });
                      }}
                    />
                  </ButtonGroup>
                )
              )}
            ></Column>
          </DataTable>
          <Pagination
            totalCount={totalCount}
            currentPage={currentPage}
            numberOfDataPerPage={numberOfDataPerPage}
            setCurrentPage={setCurrentPage}
            setNumberOfDataPerPage={setNumberOfDataPerPage}
          />
        </CardBody>
      </Card>
      <Dialog
        header="User"
        visible={open}
        onHide={() => setOpen(!open)}
        style={{ maxWidth: "95vw", minWidth: "95vw" }}
      >
        <AddUser isUpdate={false} isView={false} manager={manager} onSuccess={onSuccess} onFileUploadSuccess={onSuccess} />
      </Dialog>

      <Dialog
        header="User"
        visible={edit && Object.keys(data)?.length}
        style={{
          width: "95vw",
        }}
        onHide={() => setEdit(!edit)}
      >
        <AddUser isUpdate={true} isView={false} edit={setswitch} data={data} manager={manager} onSuccess={onSuccess} onFileUploadSuccess={onSuccess} />
      </Dialog>

      <Dialog
        header="User"
        visible={view}
        style={{
          width: "95vw",
        }}
        onHide={() => setView(!view)}
      >
        <AddUser isUpdate={false} isView={true} data={data} manager={manager} onSuccess={onSuccess} onFileUploadSuccess={onSuccess} />
      </Dialog>

      {bulkUploadUser &&
        <BulkUploadUserForm
          visible={bulkUploadUser}
          setVisible={setBulkUploadUser}
        />
      }
    </Container>
  );
}
