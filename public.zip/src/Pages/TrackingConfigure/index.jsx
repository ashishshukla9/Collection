import { Formik } from "formik";
import { useFormik } from 'formik';
import React, { useEffect, useState } from "react";
import Select from 'react-select';
import { Card, CardBody, Form, Input, Label, Row, FormFeedback, FormGroup, Button, } from "reactstrap";
import { SelectButton } from "primereact/selectbutton";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import axios from "axios";
import { Checkbox } from "primereact/checkbox";
import Swal from "sweetalert2";
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import "./index.css";
const Index = () => {
  const [endTime, setEndTime] = useState('10:00');
  const [agencyTrackingId, setAgencyTrackingId] = useState('')
  const [selectError, setSelectError] = useState(false);
  const [startTimeError, setStartTimeError] = useState(false);
  const [endTimeError, setEndTimeError] = useState(false);
  const [frequencyError, setFrequencyError] = useState(false);
  const [selectionError, setSelectionError] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [testphase, settestphase] = useState([])
  const [selectedYears, setSelectedYears] = useState('');
  const [internalOption, setInternalOption] = useState([]);
  const [repatEvery, setRepatEvery] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [showWeekly, setShowWeekly] = useState(false);
  const [showMonthly, setShowMonthly] = useState(false);
  const [showYearly, setShowYearly] = useState(false);
  const [frequency, setFrequency] = useState('');
  const [selectedDaysOfMonth, setSelectedDaysOfMonth] = useState([]);
  const [checked, setChecked] = useState([]);
  const [selectedDaysOfWeek, setSelectedDaysOfWeek] = useState([]);
  const [allChecked, setAllChecked] = useState(false);
  const [startTime, setStartTime] = useState('10:00');
  const [update, setUpdate] = useState('');
  const [year, setYear] = useState(selectedYears || '');
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [repeatInterval, setRepeatInterval] = useState(1);
  const [selection, setSelection] = useState('');
  const [selectedMonths, setSelectedMonths] = useState([]);
  const [selectedDays, setSelectedDays] = useState([]);
  const [formActive, setFormActive] = useState({
    Weekly: false,
    Monthly: false,
    Yearly: false
  });
  useEffect(() => {
    setYear(selectedYears || '');
  }, [selectedYears]);
  const handleSelectChange = (event) => {
    const newSelection = event.target.value;
    setSelection(newSelection);
    if (newSelection === 'year') {
      setStartDate('');
      setEndDate('');
      setSelectedMonths([]);
      setSelectedDays([]);
    } else if (newSelection === 'month') {
      setYear('');
      setStartDate('');
      setEndDate('');
      setSelectedDays([]);
    } else if (newSelection === 'week') {
      setYear('');
      setStartDate('');
      setEndDate('');
      setSelectedMonths([]);
    } else if (newSelection === 'day') {
      setYear('');
      setSelectedMonths([]);
      setSelectedDays([]);
    }
  };
  const handleMonthChange = (event) => {
    const { value, checked } = event.target;
    setSelectedMonths(prevSelectedMonths =>
      checked
        ? [...prevSelectedMonths, value]
        : prevSelectedMonths.filter(month => month !== value)
    );
  };
  const handleDayChange = (event) => {
    const { value, checked } = event.target;
    setSelectedDays(prevSelectedDays =>
      checked
        ? [...prevSelectedDays, value]
        : prevSelectedDays.filter(day => day !== value)
    );
  };
  const [selectedCities, setSelectedCities] = useState([]);
  const [selectedRepeat, setSelectedRepeat] = useState('days');
  const options = [
    { label: 'On', value: true },
    { label: 'Off', value: false }
  ];
  const [value, setValue] = useState(true);
  const initialValues = {
    startDate: new Date(),
    endDate: new Date(),
    selectedDaysOfWeek: selectedDays,
    active: true,
    frequency: 'realtime',
    startTime: new Date(),
    endTime: new Date(),
    selectedCities: [], // Ensure this is initialized properly
  };
  const formatOptions = () => {
    return roles.map(role => ({
      value: role.roleId,       // Use roleId as value
      label: `${role.roleName} (${role.roleCode})` // Combine roleName and roleCode
    }));
  };
  const [roles, setRoles] = useState([
    { roleCode: "CH", roleId: 41, roleName: "COLLECTION HEAD", label: "COLLECTION HEAD", value: "CH" },
    { roleCode: "NRM", roleId: 40, roleName: "NATIONAL RECOVERY MANAGER", label: "NATIONAL RECOVERY MANAGER", value: "NRM" },
    { roleCode: "ZRM", roleId: 38, roleName: "ZONAL RECOVERY MANAGER", label: "ZONAL RECOVERY MANAGER", value: "ZRM" },
    { roleCode: "RRM", roleId: 37, roleName: "REGIONAL RECOVERY MANAGER", label: "REGIONAL RECOVERY MANAGER", value: "RRM" },
    { roleCode: "PRM", roleId: 36, roleName: "PORTFOLIO RECOVERY MANAGER", label: "PORTFOLIO RECOVERY MANAGER", value: "PRM" },
    { roleCode: "ARM", roleId: 35, roleName: "AREA RECOVERY MANAGER", label: "AREA RECOVERY MANAGER", value: "ARM" },
    { roleCode: "FFA1", roleId: 51, roleName: "FIELD AGENT", label: "FIELD AGENT", value: "FFA1" },
    { roleCode: "DRA", roleId: 46, roleName: "DEBT RECOVERY AGENT", label: "DEBT RECOVERY AGENT", value: "DRA" }
  ]);
  const weekData = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const monthData = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",];
  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };
  const validateSelection = () => {
    let isValid = true;
    if (!frequency) {
      setFrequencyError(true);
      isValid = false;
    } else {
      setFrequencyError(false);
    }
    if (!selection) {
      setSelectionError(true);
      isValid = false;
    } else {
      setSelectionError(false);
    }
    if (selection === 'year' && !year) {
      setSelectionError(true);
      isValid = false;
    } else if (selection === 'month' && selectedMonths.length === 0) {
      setSelectionError(true);
      isValid = false;
    } else if (selection === 'week' && selectedDays.length === 0) {
      setSelectionError(true);
      isValid = false;
    } else if (selection === 'day' && !(startDate || endDate)) {
      setSelectionError(true);
      isValid = false;
    }
    return isValid;
  };
  const validateTimes = () => {
    let isValid = true;
    if (!startTime) {
      setStartTimeError(true);
      isValid = false;
    } else {
      setStartTimeError(false);
    }
    if (!endTime) {
      setEndTimeError(true);
      isValid = false;
    } else {
      setEndTimeError(false);
    }
    if (startTime && endTime) {
      if (endTime <= startTime) {
        setEndTimeError(true);
        isValid = false;
      } else {
        setEndTimeError(false);
      }
    }
    return isValid;
  };
  useEffect(() => {
    if (['Weekly', 'Monthly', 'Yearly'].includes(selectedRepeat)) {
      setStartDate('');
      setEndDate('');
    }
  }, [selectedRepeat]);
  const handleEndDateChange = (e) => {
    setEndDate(e.target.value);
  };
  const handleYearChange = (event) => {
    setYear(event.target.value);
  };
  const fetchTrackingConfig = async () => {
    try {
      const response = await axios.get('getTrackingConfig'); // Replace with your API endpoint
      const data = response.data;
      if (data.response && data.response.length > 0) {
        const config = data.response[0];
        const trackingConfigs = config.agencyTrackingConfigs;
        let combinedConfigWithAgencyId = [];
        trackingConfigs.forEach(trackingConfig => {
          const roleStatusArray = JSON.parse(trackingConfig.agencyTrackingRoleStatus);
          roleStatusArray.forEach(roleStatus => {
            combinedConfigWithAgencyId.push({
              ...roleStatus,
              agencyId: trackingConfig.agencyId,
              agencyName: trackingConfig.agencyName, // Retain agency name if needed
            });
          });
        });
        settestphase(combinedConfigWithAgencyId);
        setSelectedCities(config.roles || []);
        setStartTime(config.frequencyStartTime || '');
        setUpdate(config.scheduleTrackingConfigId || '');
        setAgencyTrackingId(config.agencyTrackingConfigId || '');
        setEndTime(config.frequencyEndTime || '');
        setStartDate(config.startDate || '');
        setEndDate(config.endDate || '');
        const selectedCitiesWithRoleCode = config.roles.map(role => ({
          roleId: role.roleId,
          roleCode: role.roleCode,
          roleName: role.roleName
        }));
        setFrequency(config.frequencyType || '');
        const repeatType = config.selectedDays || '';
        const daysOfWeek = config.selectedWeeks ? config.selectedWeeks.split(',').map(day => day.trim()) : [];
        const daysOfMonth = config.selectedMonths ? config.selectedMonths.split(',').map(month => month.trim()) : [];
        const years = config.selectedYears ? [config.selectedYears] : '';
        const repeatevery = config.repeatEvery ? [config.repeatEvery] : [];
        setSelection(config.repeatEvery.toLowerCase() || '');
        setYear(config.selectedYears || '');
        setSelectedMonths(config.selectedMonths ? config.selectedMonths.split(',').map(month => month.trim()) : []);
        setSelectedDays(config.selectedWeeks ? config.selectedWeeks.split(',').map(day => day.trim()) : []);
        setStartDate(config.startDate || '');
        setEndDate(config.endDate || '');
        setShowWeekly(daysOfWeek.length > 0);
        setShowMonthly(daysOfMonth.length > 0);
        setShowYearly(years.length > 0);
        setSelectedRepeat(repeatType);
        setSelectedDaysOfWeek(daysOfWeek);
        setSelectedDaysOfMonth(daysOfMonth);
        setSelectedYears(years);
        setRepatEvery(repeatevery);
        setFormActive({
          Weekly: daysOfWeek.length > 1,
          Monthly: daysOfMonth.length > 1,
          Yearly: years.length > 1
        });
        setSelectedCities(selectedCitiesWithRoleCode);
        setRoles(prevRoles =>
          prevRoles.map(role => ({
            ...role,
            checked: selectedCitiesWithRoleCode.some(selectedRole => selectedRole.roleId === role.roleId)
          }))
        );
        setValue(config.active || false);
        setShowWeekly(repeatType === 'Weekly');
        setShowMonthly(repeatType === 'Monthly');
        setShowYearly(repeatType === 'Yearly');
      } else {
        console.error('No tracking config found in the response');
      }
    } catch (error) {
      console.error('Error fetching tracking config:', error);
    }
  };
  useEffect(() => {
    fetchTrackingConfig();
  }, []);
  const resetInternalOptions = () => {
    setInternalOption(prevOptions => prevOptions.map(option => ({
      ...option,
      adminChecked: false,
      agentChecked: false,
      tlChecked: false,
    })));
  };
  const handleClear = () => {
    if (formik) {
      formik.resetForm(); // Reset Formik fields to their initial values
    }
    setSelectedCities([]); // Reset selected cities
    setSelectedDaysOfWeek([]); // Reset days of the week
    setValue(null); // Reset active/inactive state
    setStartDate(''); // Reset start date
    setEndDate(''); // Reset end date
    setFrequency(''); // Reset frequency
    setSelection(''); // Reset repeat interval
    setRepeatInterval(''); // Reset repeat interval input
    setStartTime(''); // Reset start time
    setEndTime(''); // Reset end time
    setYear(''); // Reset year
    setSelectedMonths([]); // Reset selected months
    setSelectedDays([]); // Reset selected days
    resetInternalOptions(); // Reset internal options
    setChecked([]); // Reset checked items
    setAllChecked(false); // Reset all checked state
  };
  const getAllAgency = async () => {
    try {
      const res = await axios.get("getAllAgency");
      const internalopt = [];
      if (res?.data?.msgKey === "Success") {
        res?.data?.data?.forEach((item) => {
          if (item.status === "Y") {
            internalopt.push({
              id: item.agencyId,
              agencyName: item.agencyName,
              agencyAdminStatus: item.agencyAdmin,
              agencyAgentStatus: item.agent,
              agencyTLStatus: item.agencyTL,
              adminChecked: false,
              agentChecked: false,
              tlChecked: false,
            });
          }
        });
      }
      setInternalOption(prevInternalOption => {
        const existingAgenciesMap = new Map(prevInternalOption.map(item => [item.id, item]));
        internalopt.forEach(item => {
          existingAgenciesMap.set(item.id, item); // This will replace any existing item with the same ID
        });
        return Array.from(existingAgenciesMap.values());
      });
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getAllAgency();
  }, []);
  const handleAllCheck = (e) => {
    const isChecked = e.target.checked;
    setAllChecked(isChecked);
    const updatedTestphase = testphase.map(role => ({
      ...role,
      status: isChecked ? 'Y' : 'N'
    }));
    settestphase(updatedTestphase);
  };
  useEffect(() => {
    const allChecked = testphase.every(role => role.status === 'Y');
    setAllChecked(allChecked);
  }, [testphase]);
  const handleFrequencyChange = (e) => {
    setFrequency(e.target.value);
  };
  const validateSelect = () => {
    if (selectedCities.length === 0) {
      setSelectError(true);
      return false;
    }
    setSelectError(false);
    return true;
  };
  const handleSubmit = async () => {
    const isSelectionValid = validateSelection();
    const areTimesValid = validateTimes(); // Ensure validateTimes is defined
    const isSelectValid = validateSelect(); // Validate Select component
    if (isSelectionValid && areTimesValid && isSelectValid) {
      setHasError(false); // Clear any previous errors
      const selectedCitiesArray = Array.isArray(selectedCities) ? selectedCities : [];
      const selectedRoles = selectedCitiesArray.map(city => ({
        roleId: city.roleId,
        roleCode: city.roleCode,
      }));
      const arrayToCommaSeparatedString = (array) => array ? array.join(', ') : '';
      const payload = {
        scheduleTrackingConfigId: update || null,
        startDate: startDate ? new Date(startDate).toISOString().split('T')[0] : null,
        endDate: endDate ? new Date(endDate).toISOString().split('T')[0] : null,
        active: value,
        roles: selectedCities,
        frequencyType: frequency || 'null',
        frequencyStartTime: startTime,
        frequencyEndTime: endTime,
        repeatEvery: selection,
        selectedDays: selection === 'day' ? arrayToCommaSeparatedString(selectedDays) : '',
        selectedWeeks: selection === 'week' ? arrayToCommaSeparatedString(selectedDays) : null,
        selectedMonths: selection === 'month' ? arrayToCommaSeparatedString(selectedMonths) : null,
        selectedYears: selection === 'year' ? String(year) : null,
        agencyTrackingConfigs: internalOption.map(option => {
          const adminChecked = testphase.some(role =>
            role.roleCode === 'AA' && role.agencyId === option.id && role.status === 'Y'
          );
          const agentChecked = testphase.some(role =>
            role.roleCode === 'FA' && role.agencyId === option.id && role.status === 'Y'
          );
          const tlChecked = testphase.some(role =>
            role.roleCode === 'ATL' && role.agencyId === option.id && role.status === 'Y'
          );
          return {
            agencyId: option.id,
            agencyTrackingRoleStatus: JSON.stringify([
              { roleCode: 'AA', status: adminChecked ? 'Y' : 'N' },
              { roleCode: 'ATL', status: tlChecked ? 'Y' : 'N' },
              { roleCode: 'FA', status: agentChecked ? 'Y' : 'N' }
            ]),
          };
        }),
      };
      try {
        let response;
        if (!update) {
          response = await axios.post('/addTrackingConfig', payload);
        } else {
          response = await axios.put(`/updateTrackingConfigById/${update}`, payload);
        }
        Swal.fire({
          position: 'top-end',
          icon: 'success',
          title: response.data.response || 'Data submitted successfully',
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } catch (error) {
        console.error('Error:', error);
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: error.response?.data?.response || error.message || 'An error occurred',
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } else {
      setHasError(true);
      Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: 'Please complete the required fields correctly.',
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const formik = useFormik({
    initialValues: {
    },
    onSubmit: (values) => {
    },
    resetForm: () => {
      formik.resetForm();
    },
  });
  return (
    <>
      <Row>
        <Formik
          initialValues={initialValues}
          onSubmit={handleSubmit}
        >
          {({
            values,
            handleSubmit,
            resetForm
          }) => (
            <Form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
              <h5 className="bg-white px-2 py-2 border-bottom">
                Internal Role
              </h5>
              <Card className="px-2 py-2 rounded-0 border-0">
                <CardBody>
                  <div className="card flex justify-content-center">
                    <Select
                      isMulti
                      value={selectedCities.map(city => ({
                        value: city.roleId,
                        label: city.roleCode // Display roleCode for selected items
                      }))}
                      onChange={(selectedOptions) => {
                        const selectedIds = selectedOptions.map(option => option.value);
                        const selected = roles.filter(role => selectedIds.includes(role.roleId));
                        setSelectedCities(selected);
                      }}
                      options={formatOptions()} // Default display as roleName
                      placeholder="Select Role"
                      className={`w-full border-0 md:w-20rem ${selectError ? 'error-border' : ''}`}
                      styles={{
                        control: (provided, state) => ({
                          ...provided,
                          borderColor: selectError ? 'red' : provided.borderColor,
                          boxShadow: state.isFocused ? `0 0 0 1px ${selectError ? 'red' : provided.boxShadow}` : provided.boxShadow,
                          '&:hover': {
                            borderColor: selectError ? 'red' : provided.borderColor,
                          },
                        }),
                      }}
                    />
                  </div>
                  {selectError && (
                    <div className="invalid-feedback">
                      Please select at least one role.
                    </div>
                  )}
                </CardBody>
              </Card>
              <br />
              <h5 className="bg-white px-2 py-2 border-bottom">
                Agencies Roles
              </h5>
              <Card className="px-2 py-2 rounded-0 border-0 agency-table">
                <DataTable
                  value={internalOption}
                  className="commonTable casesTable"
                  tableStyle={{ minWidth: "50rem" }}
                  sortMode="multiple"
                  stripedRows
                  size={"small"}
                  removableSort
                >
                  <Column
                    header={<Checkbox onChange={handleAllCheck} checked={allChecked} />}
                    body={(rowData) => {
                      const isChecked = testphase.some(
                        role => role.agencyId === rowData.id && role.status === 'Y'
                      );
                      const handleCheckboxChange = () => {
                        const updatedTestphase = testphase.map(role =>
                          role.agencyId === rowData.id ? { ...role, status: isChecked ? 'N' : 'Y' } : role
                        );
                        if (!testphase.some(role => role.agencyId === rowData.id && role.roleCode === 'AA')) {
                          updatedTestphase.push({
                            roleCode: 'AA',
                            status: isChecked ? 'N' : 'Y',
                            agencyId: rowData.id,
                          });
                        }
                        if (!testphase.some(role => role.agencyId === rowData.id && role.roleCode === 'FA')) {
                          updatedTestphase.push({
                            roleCode: 'FA',
                            status: isChecked ? 'N' : 'Y',
                            agencyId: rowData.id,
                          });
                        }
                        if (!testphase.some(role => role.agencyId === rowData.id && role.roleCode === 'ATL')) {
                          updatedTestphase.push({
                            roleCode: 'ATL',
                            status: isChecked ? 'N' : 'Y',
                            agencyId: rowData.id,
                          });
                        }
                        settestphase(updatedTestphase);
                      };
                      return (
                        <Checkbox
                          onChange={handleCheckboxChange}
                          checked={isChecked}
                        />
                      );
                    }}
                    style={{ width: "50px" }}
                  />
                  <Column field="agencyName" header="Agency Name" sortable />
                  <Column
                    field="agencyAdminStatus"
                    header="Agency Admin"
                    sortable
                    body={(rowData) => {
                      const adminRole = testphase.find(role =>
                        role.roleCode === 'AA' && role.agencyId === rowData.id
                      );
                      const handleCheckboxChange = () => {
                        const updatedTestphase = testphase.map(role =>
                          role.agencyId === rowData.id && role.roleCode === 'AA'
                            ? { ...role, status: adminRole?.status === 'Y' ? 'N' : 'Y' }
                            : role
                        );
                        if (!updatedTestphase.some(role => role.agencyId === rowData.id && role.roleCode === 'AA')) {
                          updatedTestphase.push({
                            roleCode: 'AA',
                            status: adminRole?.status === 'Y' ? 'N' : 'Y',
                            agencyId: rowData.id,
                          });
                        }
                        settestphase(updatedTestphase);
                      };
                      return (
                        <Checkbox
                          onChange={handleCheckboxChange}
                          checked={adminRole?.status === 'Y'}
                          style={{ borderColor: adminRole?.status === 'Y' ? 'blue' : undefined }}
                        />
                      );
                    }}
                  />
                  <Column
                    field="agencyAgentStatus"
                    header="Agent"
                    sortable
                    body={(rowData) => {
                      const agent = testphase.find(role =>
                        role.roleCode === 'FA' && role.agencyId === rowData.id
                      );
                      const handleAgentCheckboxChange = () => {
                        const updatedTestphase = testphase.map(role =>
                          role.agencyId === rowData.id && role.roleCode === 'FA'
                            ? { ...role, status: agent?.status === 'Y' ? 'N' : 'Y' }
                            : role
                        );
                        if (!updatedTestphase.some(role => role.agencyId === rowData.id && role.roleCode === 'FA')) {
                          updatedTestphase.push({
                            roleCode: 'FA',
                            status: agent?.status === 'Y' ? 'N' : 'Y',
                            agencyId: rowData.id,
                          });
                        }
                        settestphase(updatedTestphase);
                      };
                      return (
                        <Checkbox
                          onChange={handleAgentCheckboxChange}
                          checked={agent?.status === 'Y'}
                          style={{ borderColor: agent?.status === 'Y' ? 'blue' : undefined }}
                        />
                      );
                    }}
                  />
                  <Column
                    field="agencyTLStatus"
                    header="Agency TL"
                    sortable
                    body={(rowData) => {
                      const agentTL = testphase.find(role =>
                        role.roleCode === 'ATL' && role.agencyId === rowData.id
                      );
                      const handleAgentTLCheckboxChange = () => {
                        const updatedTestphase = testphase.map(role =>
                          role.agencyId === rowData.id && role.roleCode === 'ATL'
                            ? { ...role, status: agentTL?.status === 'Y' ? 'N' : 'Y' }
                            : role
                        );
                        if (!updatedTestphase.some(role => role.agencyId === rowData.id && role.roleCode === 'ATL')) {
                          updatedTestphase.push({
                            roleCode: 'ATL',
                            status: agentTL?.status === 'Y' ? 'N' : 'Y',
                            agencyId: rowData.id,
                          });
                        }
                        settestphase(updatedTestphase);
                      };
                      return (
                        <Checkbox
                          onChange={handleAgentTLCheckboxChange}
                          checked={agentTL?.status === 'Y'}
                          style={{ borderColor: agentTL?.status === 'Y' ? 'blue' : undefined }}
                        />
                      );
                    }}
                  />
                </DataTable>
              </Card>
              <div className="row equal-height-row">
                <div className="padd pt-3">
                  <div className="gap-4 d-flex justify-content-start bg-white px-2 py-2 border-bottom">
                    <div className="scheduler-header">
                      <h5 className="">Scheduler</h5>
                    </div>
                  </div>
                  <Card className="schedule-card px-2 mt-0 py-2 rounded-0 border-0">
                    <CardBody>
                      <div className="row">
                        <div className="col-lg-2 mb-2">
                          <FormGroup>
                            <Label for="repeatInterval" className="form-label">Repeat every</Label>
                            <div className="repeat-group">
                              <select
                                className={`align_select ${selectionError ? 'error-border' : ''}`}
                                id="date-select"
                                onChange={handleSelectChange}
                                value={selection}
                              >
                                <option value="">Select</option>
                                <option value="year">Year</option>
                                <option value="month">Month</option>
                                <option value="week">Week</option>
                                <option value="day">Day</option>
                              </select>
                            </div>
                          </FormGroup>
                          {selectionError && (
                            <div className="invalid-feedback">
                              Please make a valid selection.
                            </div>
                          )}
                        </div>
                        {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
                        <div className="col-lg-7 mb-2">
                          {selection === 'year' && (
                            <div>
                              <label className="form-label form-label">Enter Year</label>
                              <input
                                type="number"
                                className="form-control"
                                id="year"
                                min="2024"
                                max="9999"
                                value={year}
                                onChange={handleYearChange}
                                placeholder="Enter year"
                              />
                            </div>
                          )}
                          {selection === 'month' && (
                            <div>
                              <label className="form-label form-label">Days of the Month</label>
                              <div className="days-of-month">
                                {monthData.map((month, index) => (
                                  <label className="align_sub" key={index}>
                                    <input
                                      className="data_change"
                                      type="checkbox"
                                      value={month}
                                      checked={selectedMonths.includes(month)}
                                      onChange={handleMonthChange}
                                    />
                                    {month}
                                  </label>
                                ))}
                              </div>
                            </div>
                          )}
                          {selection === 'week' && (
                            <div>
                              <label className="form-label form-label">Days of the Week</label>
                              <div className="days-of-week">
                                {weekData.map((day, index) => (
                                  <label className="align_sub" key={index}>
                                    <input
                                      className="data_change"
                                      type="checkbox"
                                      value={day}
                                      checked={selectedDays.includes(day)}
                                      onChange={handleDayChange}
                                    />
                                    {day}
                                  </label>
                                ))}
                              </div>
                            </div>
                          )}
                          {selection === 'day' && (
                            <div className="row">
                              <div className="col-lg-6 mb-2">
                                <label className="form-label" htmlFor="endDate">Start Date</label>
                                <input
                                  type="date"
                                  className="startEndDate dateclass"
                                  id="startDate"
                                  value={startDate}
                                  onChange={handleStartDateChange}
                                />
                              </div>
                              <div className="col-lg-6 mb-2">
                                <label className="form-label" htmlFor="endDate">End Date</label>
                                <input
                                  type="date"
                                  className="startEndDate dateclass"
                                  id="endDate"
                                  value={endDate}
                                  onChange={handleEndDateChange}
                                />
                              </div>
                            </div>
                          )}
                        </div>
                        <div className="col-lg-3 mb-2">
                          <FormGroup>
                            <Label for="activeInactive" className="form-label">Active / Inactive</Label>
                            <SelectButton
                              value={value}
                              color="primary"
                              className="EndDate"
                              onChange={(e) => setValue(e.value)}
                              options={options}
                            />
                          </FormGroup>
                        </div>
                        <div className="col-lg-2 mb-2">
                          <FormGroup>
                            <Label for="startTime" className="form-label">
                              Start Time
                            </Label>
                            <TimePicker
                              id="startTime"
                              openClockOnFocus={false}
                              value={startTime}
                              onChange={setStartTime}
                              format="hh:mm a" // AM/PM format
                              clearIcon={null}
                              clockIcon={null}
                              className={startTimeError ? 'error-border' : ''}
                            />
                            {startTimeError && (
                              <div className="invalid-feedback">
                                Please select a start time.
                              </div>
                            )}
                          </FormGroup>
                        </div>
                        <div className="col-lg-2 mb-2">
                          <FormGroup>
                            <Label for="endTime" className="form-label">
                              End Time
                            </Label>
                            <TimePicker
                              id="endTime"
                              openClockOnFocus={false}
                              value={endTime}
                              onChange={setEndTime}
                              format="hh:mm a" // AM/PM format
                              clearIcon={null}
                              clockIcon={null}
                              className={endTimeError ? 'error-border' : ''}
                            />
                            {endTimeError && (
                              <div className="invalid-feedback">
                                {startTime && endTime <= startTime ? 'End time must be after start time.' : 'Please select an end time.'}
                              </div>
                            )}
                          </FormGroup>
                        </div>
                        <div className="col-lg-6 mb-2">
                          <FormGroup>
                            <Label for="frequency" className="form-label align-baseline">
                              Frequency
                            </Label>
                            <Input
                              type="select"
                              id="frequency"
                              name="frequency"
                              value={frequency}
                              onChange={handleFrequencyChange}
                              invalid={hasError && !frequency}
                            >
                              <option value="">-Select-</option>
                              <option value="realtime">Realtime tracking</option>
                              <option value="hourly">Hourly tracking</option>
                            </Input>
                            {hasError && !frequency && (
                              <FormFeedback>
                                Please select a frequency.
                              </FormFeedback>
                            )}
                          </FormGroup>
                        </div>
                      </div>
                      <div className="actions">
                        <Button
                          color="danger"
                          onClick={handleClear}
                        >
                          Clear
                        </Button>
                        <Button type="submit" className="me-1 btn-primary text-white" size="sm">
                          Submit
                        </Button>
                      </div>
                    </CardBody>
                  </Card>
                </div>
              </div>
            </Form>
          )}
        </Formik>
      </Row>
    </>
  );
};
export default Index; 