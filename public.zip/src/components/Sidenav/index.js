import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { set, foldable } from "../../features/sideBar/sidebarSlice";
import LOGO from "../../assets/images/logo/logo.png";
import {
  CSidebar,
  CSidebarBrand,
  CSidebarNav,
  CSidebarToggler,
} from "@coreui/react";
import { AppSidebarNav } from "./AppSidebarNav";
import SimpleBar from "simplebar-react";
import "simplebar-core/dist/simplebar.css";
import navigation from "./_nav";
const AppSidebar = () => {
  const dispatch = useDispatch();
  const unfoldable = useSelector((state) => state.sideNav.sidebarUnfoldable);
  const sidebarShow = useSelector((state) => state.sideNav.sidebarShow);
  return (
    <CSidebar
      position="fixed"
      unfoldable={unfoldable}
      visible={sidebarShow}
      onVisibleChange={(visible) => {
        dispatch(set(visible));
      }}
    >
      <CSidebarBrand
        style={{ backgroundColor: "white" }}
        className="d-none d-md-flex"
        to="/"
      >
        <img
          src={LOGO}
          className="img img-fluid sidebar-brand-full"
          alt=""
          style={{ maxWidth: "70%" }}
        />
        <img
          src={LOGO}
          className="img img-fluid sidebar-brand-narrow"
          alt=""
        />
      </CSidebarBrand>
      <CSidebarNav>
        <SimpleBar>
          <AppSidebarNav items={navigation} />
        </SimpleBar>
      </CSidebarNav>
        <div style={{height:"50px", width:"100%", display:"flex", justifyContent:"space-between", alignContent:"center"}}>
          <div style={{display: "flex", justifyContent: "center", alignItems: "center"}}>
          <p style={{fontSize:"0.7em", paddingLeft:"5px"}}>&copy; TruBoard Servicing Private Limited</p>
          </div>
          <div>
          <CSidebarToggler
          className="d-none d-lg-flex"
          onClick={() =>
            dispatch(foldable(!unfoldable))
          }
        >
        </CSidebarToggler>
          </div>
        </div>
    </CSidebar>
  );
};
export default React.memo(AppSidebar);