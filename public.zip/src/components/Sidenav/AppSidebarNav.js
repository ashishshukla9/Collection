import React, { useMemo } from "react";
import { NavLink, useLocation } from "react-router-dom";
import PropTypes from "prop-types";
import { useSelector } from "react-redux";
import { CBadge } from "@coreui/react";

export const AppSidebarNav = ({ items }) => {
  const user = useSelector((state) => state.user.data);
  const location = useLocation();
  const navLink = (name, icon, badge) => {
    return (
      <>
        {icon && icon}
        {name && name}
        {badge && (
          <CBadge color={badge.color} className="ms-auto">
            {badge.text}
          </CBadge>
        )}
      </>
    );
  };

  // console.log(user?.masterRole, "masterrole")
  const roleKeyValue = useMemo(()=>{
    if(user?.masterRole){
      return Object.entries(user?.masterRole) 
    }
  },[user?.masterRole])

  const navItem = (item, index) => {
    const { component, name, badge, icon, roleType, ...rest } = item;

    const Component = component;
    let key = name.replaceAll(" ", "").toLowerCase();
    key = key.replaceAll('&','').toLowerCase()
    // key = ["configuration","calculation"]?.includes(key) ? "incentivespayouts" : key
    let checkIsEveryNull=false
    if(name === "Cases"){
      let getCurrentRoleValues = roleKeyValue?.filter(a=>(a[0].includes("caseactivity") || a[0].includes("customerprofile")) && a)
      getCurrentRoleValues = getCurrentRoleValues?.reduce((a,b)=>({...a,[b[0]]:b[1]}),{}) || {}
      getCurrentRoleValues = Object.values(getCurrentRoleValues)
      checkIsEveryNull = getCurrentRoleValues?.every(a=>a === null)
    }

    // let checkIsReportsNull=false
    // if(name==="Reports"){
    //   let getCurrentRoleValues = roleKeyValue?.filter(a=>a[0].includes("reports") && a)
    //   console.log(getCurrentRoleValues,'getCurrentRoleValues');
    // }
    if (((name !== "Cases" ? user?.masterRole[`${roleType}_${key}`] !== null : true) && !checkIsEveryNull)) {
      return (
        <Component
          {...(rest.to &&
            !rest.items && {
              component: NavLink,
            })}
          key={index}
          {...rest}
        >
          {navLink(name, icon, badge)}
        </Component>
      );
    }
  };
  const navGroup = (item, index) => {
    const { component, name, icon, to, roleType, ...rest } = item;
    const Component = component;
    let key = name.replaceAll(" ", "").toLowerCase();
    key = key.replaceAll('&','').toLowerCase()
    const checkItemVisible = item?.group ? roleKeyValue?.filter(a=> item?.group?.includes(a[0]))?.map(a=>a[1])?.filter(Boolean)?.length : true
    if (user?.masterRole[`${roleType}_${key}`] !== null && checkItemVisible) {
      return (
        <Component
          idx={String(index)}
          key={index}
          toggler={navLink(name, icon)}
          visible={location.pathname.startsWith(to)}
          {...rest}
        >
          {item.items?.map((item, index) =>
            item.items ? navGroup(item, index) : navItem(item, index)
          )}
        </Component>
      );
    }
  };

  return (
    <React.Fragment>
      {items &&
        items.map((item, index) =>
          item.items ? navGroup(item, index) : navItem(item, index)
        )}
    </React.Fragment>
  );
};

AppSidebarNav.propTypes = {
  items: PropTypes.arrayOf(PropTypes.any).isRequired,
};
