import React, { useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { set } from "../../features/sideBar/sidebarSlice";
import { useSelector, useDispatch, ReactReduxContext } from "react-redux";

import {
  CContainer,
  CHeader,
  CHeaderBrand,
  CHeaderDivider,
  CHeaderNav,
  CHeaderToggler,
  CNavLink,
  CNavItem,
  CBadge,
} from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { cilBell, cilEnvelopeOpen, cilList, cisBellRing, cilMenu } from "@coreui/icons";
import BellIcon from 'react-bell-icon';
import AppBreadcrumb from "./AppBreadcrumb";
import AppHeaderDropdown from "./AppHeaderDropdown";
import { logo } from "../../assets/brand/logo";
import axios from "axios";
import "./Header.module.css"
import { Cookies } from "react-cookie";

const AppHeader = () => {
  const [count, setcount] = useState(null)
  const dispatch = useDispatch();
  const sidebarShow = useSelector((state) => state.sideNav.sidebarShow);
  const user = useSelector((state) => state.user.data)
  const navigate = useNavigate()
  // console.log(user, "userResponse")
  const cookie = new Cookies()


  const handleClick = async () => {
    if (count > 0) {
      const res = await axios.post("/updateMapperCount")
      // console.log(res, "updatemapperres")
      const updatedCount = res?.data?.data == null ? 0 : res?.data?.data
      navigate("/cases");
      setcount(updatedCount)
    }

  }


  useEffect(() => {
    const token = cookie.get("token")
    // alert(token)
    if ((user && user?.userName == "EMP116")&& token) {
      const getNotificationCount = async () => {
        try {
          const res = await axios.get("/mapperNewCount")
          setcount(res?.data?.data)
        } catch (error) {
     
        }
      }
      getNotificationCount()
    }
  }, [user])
  return (
    <CHeader position="sticky" className="mb-1">
      <CContainer fluid>
        <CHeaderToggler
          className="ps-1"
          onClick={() => {
            // dispatch({ type: "set", sidebarShow: !sidebarShow });
            dispatch(set(!sidebarShow));
          }}
        >
          <CIcon icon={cilMenu} size="lg" />
        </CHeaderToggler>
        <CHeaderBrand className="mx-auto d-md-none custom-header-brand" to="/">
          <img
            src="/img/truboard_header.svg"
            className="img sidebar-brand-full"
            alt=""
            // style={{maxWidth:"40%"}}
            height={30}
          />
        </CHeaderBrand>
        <CHeaderNav className="d-none d-md-flex me-auto">
          <CNavItem className="display-6"></CNavItem>
        </CHeaderNav>
        {/* <CHeaderNav className="d-none d-md-flex me-auto">
          <CNavItem>
            <CNavLink to="/dashboard" component={NavLink}>
              Dashboard
            </CNavLink>
          </CNavItem>
          <CNavItem>
            <CNavLink href="#">Users</CNavLink>
          </CNavItem>
          <CNavItem>
            <CNavLink href="#">Settings</CNavLink>
          </CNavItem>
        </CHeaderNav> */}

        <CHeaderNav >
          {
            user?.role[0]?.roleCode == "MIS" ? (
              <CNavItem>
                <CNavLink style={{ cursor: "pointer", display: "flex", alignItems: "center" }} onClick={handleClick}>
                  {
                    count > 0 ? (<BellIcon width='30' active={true} animate={true} color={"rgb(251, 125, 41)"} style={{ marginTop: "10px" }} />) : (<BellIcon width='25' active={false} animate={false} color={"rgb(251, 125, 41)"} style={{ marginTop: "10px" }} />)
                  }
                  {count > 0 ? <span style={{ marginLeft: "-10px", fontWeight: "bold", borderRadius: "50%", minWidth: "20px", minHeight: "20px", textAlign: "center", background: "green", color: "white", fontSize: "12px" }}>{count}</span> : ""}
                </CNavLink>
              </CNavItem>
            ) : ""
            // requestmanagement_all

          }
          {/* </CNavItem> */}

          {/* <CNavItem>
            <CNavLink href="#">
              <CIcon icon={cilList} size="lg" />
            </CNavLink>
          </CNavItem>
          <CNavItem>
            <CNavLink href="#">
              <CIcon icon={cilEnvelopeOpen} size="lg" />
            </CNavLink>
          </CNavItem> */}
        </CHeaderNav>
        <CHeaderNav className="ms-3">
          <AppHeaderDropdown />
        </CHeaderNav>
      </CContainer>
      <CHeaderDivider />
      <CContainer fluid>
        <AppBreadcrumb />
      </CContainer>
    </CHeader>
  );
};

export default AppHeader;
