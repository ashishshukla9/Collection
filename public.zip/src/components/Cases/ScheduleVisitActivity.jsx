import moment from "moment";
import React from "react";
import { Card, CardBody, Table } from "reactstrap";

const ScheduleVisitActivity = ({ data, obj, isHistory = false }) => {
  function createDateFromArray(dateArray) {
    if (!dateArray || dateArray.length !== 3) {
      return null;
    }
    var year = dateArray[0];
    var month = dateArray[1] - 1;
    var day = dateArray[2];
    var date = new Date(year, month, day);
    return moment(date).format("YYYY-MM-DD");
  }

  return (
    <Card className="m-1">
      <CardBody>
        <div>
          <Table striped className="text-center activityHistory mb-0 b-0">
            <tbody>
              <tr>
                <td className="fw-bold"> Name</td>
                <td>{`${data?.user?.firstName} ${data?.user?.lastName}`}</td>
                <td className="fw-bold leftBorder">Created Time</td>
                <td>
                  <td>{`${createDateFromArray(obj?.date)} ${obj?.time}`}</td>
                </td>
              </tr>
              {isHistory && (
                <tr>
                  <td className="fw-bold">Customer Name</td>
                  <td>{`${obj?.name}`}</td>
                  <td className="fw-bold leftBorder">Visit Date</td>
                  <td>{createDateFromArray(obj?.date)}</td>
                </tr>
              )}
              <tr>
                <td className="fw-bold">Visit Address</td>
                <td>{obj?.address}</td>
                <td className="fw-bold leftBorder" >Visit Time</td>
                <td>{obj?.time}</td>

              </tr>
              <tr>
                <td className="fw-bold">Status</td>
                <td>{obj?.status}</td>
                <td className="fw-bold leftBorder">Visit Outcome</td>
                <td>{obj?.outcome ? obj?.outcome : "--"}</td>
              </tr>
              <tr>
                <td className="fw-bold">Remark</td>
                <td>{obj?.remark}</td>
                <td className="fw-bold leftBorder"></td>
                <td>{ }</td>
              </tr>

              {obj?.offlineCreationDate ? (
                <tr>
                  <td className="fw-bold">Offline Created-Date</td>
                  <td style={{borderRight:"1px solid lightgray"}}>{obj.offlineCreationDate}</td>
                </tr>
              ) : null}


            </tbody>
          </Table>
        </div>
      </CardBody>
    </Card>
  )
}

export default ScheduleVisitActivity
