import { memo, useState } from "react"
import { Card, CardBody, Table } from "reactstrap";
import moment from "moment";
import axios from "axios";
import { DownloadFile } from "../../utils/DownloadFile";
import { Dialog } from "primereact/dialog";
import { object } from "yup";
const RequestActivity = ({ obj, isHistory = false }) => {
    const [EvidenceImage, setEvedenceImage] = useState(false)
    const [evidencedata, setEvidenceData] = useState("")
    // const [RequestType, SetRequestType]=useState()

    const handleShowRequestEvidence = async (obj) => {
        try {
            const res = await axios.get(`/documentRequestByRequestId/${obj?.requestId}`)
            const response = await axios({
                url: `/download-request-file/${res?.data?.documentRequestId}`,
                method: "GET",
                responseType: "blob",
            });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(new Blob([response.data]));
            // console.log(link.href, "request link")
            setEvidenceData(link.href)
            setEvedenceImage(!EvidenceImage)
        } catch (error) {
            console.log(error)
        }
    }

    const handleDownloadRequestEvidence = async (obj) => {
        const res = await axios.get(`/documentRequestByRequestId/${obj?.requestId}`)
        await DownloadFile(`/download-request-file/${res?.data?.documentRequestId}`, res?.data?.name)
    }

    return (
        <Card className="m-1">
            <CardBody>
                <>
                    <Table striped className="text-center activityHistory mb-0 b-0">
                        <tbody>
                            {isHistory && (
                                <tr>
                                    <td className="fw-bold">Name</td>
                                    <td>{`${obj?.user?.firstName} ${obj?.user?.lastName}`}</td>
                                    <td className="fw-bold leftBorder">Update Time</td>
                                    <td>
                                        {moment(obj?.createdTime).format("YYYY-MM-DD HH:mm:ss")}
                                    </td>
                                </tr>
                            )}
                            <tr>
                                <td className="fw-bold leftBorder">Request</td>
                                <td>{obj?.requestType}</td>
                                <td className="fw-bold leftBorder">Remarks</td>
                                <td>{obj?.remark}</td>
                            </tr>
                            {

                                (obj?.requestType == "Name Change" || obj?.requestType == "Contact Change" || obj?.requestType == "Address Change") ? (<tr>
                                    <td className="fw-bold leftBorder">Old Value</td>
                                    <td>{obj?.oldValue}</td>
                                    <td className="fw-bold leftBorder">New Value</td>
                                    <td>{obj?.newValue}</td>
                                </tr>) : ""
                            }
                            <tr>
                                <td className="fw-bold leftBorder">Status</td>
                                <td>{obj?.status}</td>
                                <td className="fw-bold leftBorder">Evidence</td>
                                <td>
                                    {
                                        obj?.isDocument == "yes" ? (
                                            <>
                                                <button onClick={() => handleShowRequestEvidence(obj)} style={{ border: "none", background: "transparent", color: "green" }}><i class="bi bi-card-image" ></i></button>
                                                <button onClick={() => handleDownloadRequestEvidence(obj)} style={{ border: "none", background: "transparent", color: "green" }}><i class="bi bi-cloud-download" ></i></button>
                                            </>
                                        ) : "No upload"
                                    }
                                </td>
                            </tr>
                            {obj?.offlineCreationDate ? (
                                <tr>
                                    <td className="fw-bold">Offline Created-Date</td>
                  <td style={{borderRight:"1px solid lightgray"}}>{obj.offlineCreationDate}</td>
                                </tr>
                            ) : null}



                        </tbody>
                    </Table>
                    <Dialog
                        visible={EvidenceImage && evidencedata}
                        header="Request Evidence"

                        onHide={() => setEvedenceImage(!EvidenceImage)}
                    >
                        <img src={evidencedata} style={{ width: "100%", height: "100%" }}></img>
                    </Dialog>
                </>
            </CardBody>
        </Card>
    )
}

export default memo(RequestActivity)