import React, { useState } from "react";
import { Card, CardBody, Table } from "reactstrap";
import moment from "moment";
import axios from "axios";
import { DownloadFile } from "../../utils/DownloadFile";
import { Dialog } from "primereact/dialog";

export default function ExceptionActivity({ obj, raiseException, isHistory = false }) {
  const [EvidenceImage, setEvedenceImage] = useState(false)
  const [evidencedata, setEvidenceData] = useState("")
  const handleShowExceptionEvidence = async (obj) => {
    try {
      const res = await axios.get(`/getdocumentRaiseExceptionByRaiseExceptionId/${obj?.raiseExceptionId}`)
      const response = await axios({
        url: `/downloadDocumentRaiseExceptionByRaiseExceptionId/${res?.data?.documentRaiseExceptionId}`,
        method: "GET",
        responseType: "blob",
      });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(new Blob([response.data]));
      setEvidenceData(link.href)
      setEvedenceImage(!EvidenceImage)
    } catch (error) {
      console.log(error)
    }


  }

  const handleDownloadExceptionEvidence = async (obj) => {
    try {
      const res = await axios.get(`/getdocumentRaiseExceptionByRaiseExceptionId/${obj?.raiseExceptionId}`)
      await DownloadFile(`/downloadDocumentRaiseExceptionByRaiseExceptionId/${res?.data?.documentRaiseExceptionId}`, res?.data?.name)
    } catch (error) {
    }
  }
  return (
    <Card className="m-1">
      <CardBody>
        <>
          <Table striped className="text-center activityHistory mb-0 b-0">
            <tbody>
              {isHistory && (
                <tr>
                  <td className="fw-bold">Name</td>
                  <td>{`${obj?.user?.firstName} ${obj?.user?.lastName}`}</td>
                  <td className="fw-bold leftBorder">Update Time</td>
                  <td>
                    {moment(obj?.createdTime).format("YYYY-MM-DD HH:mm:ss")}
                  </td>
                </tr>
              )}
              <tr>
                <td className="fw-bold">Exception Request</td>
                <td>{raiseException?.[obj?.request]}</td>
                <td className="fw-bold leftBorder">Remarks</td>
                <td>{obj?.remark}</td>
              </tr>
              <tr>
                {/* {obj?.ptpType ?? "-"}*/}
                <td className="fw-bold">Evidence</td>
                <td>
                  <button onClick={() => handleShowExceptionEvidence(obj)} style={{ border: "none", background: "transparent", color: "green" }}><i class="bi bi-card-image" ></i></button>
                  <button onClick={() => handleDownloadExceptionEvidence(obj)} style={{ border: "none", background: "transparent", color: "green" }}><i class="bi bi-cloud-download" ></i></button>

                </td>
                <td className="fw-bold leftBorder"></td>
                <td></td>
              </tr>

            

              {obj?.offlineCreationDate ? (
                <tr>
                  <td className="fw-bold">Offline Created-Date</td>
                  <td style={{borderRight:"1px solid lightgray"}}>{obj.offlineCreationDate}</td>
                </tr>
              ) : null}


            </tbody>
          </Table>
          <Dialog
            visible={EvidenceImage && evidencedata}
            header="Exception Evidence"
            onHide={() => setEvedenceImage(!EvidenceImage)}
          >
            <img src={evidencedata} style={{ width: "100%", height: "100%" }}></img>
          </Dialog>
        </>
      </CardBody>
    </Card>
  );
}
