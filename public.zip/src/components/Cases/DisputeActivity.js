import React, { useState } from "react";
import { Card, CardBody, Table } from "reactstrap";
import moment from "moment";
import axios from "axios";
import { DownloadFile } from "../../utils/DownloadFile";
import { Dialog } from "primereact/dialog";

export default function DisputeActivity({ obj, disputeReason, isHistory = false }) {

    const [EvidenceImage, setEvedenceImage] = useState(false)
    const [evidencedata, setEvidenceData] = useState("")
    const handleDownloadEvidence = async (obj) => {
        try {
            const res = await axios.get(`/getdocumentDisputeByDisputeOrRtpId/${obj?.disputeOrRtpId}`)
            await DownloadFile(`/download-Dispute-file/${res?.data?.disputeOrRtpId}`, res?.data?.name)
        } catch (error) {

        }
    }

    const handleShowDisputeEvidance = async (obj) => {
        try {
            const res = await axios.get(`/getdocumentDisputeByDisputeOrRtpId/${obj?.disputeOrRtpId}`)
            const response = await axios({
                url: `/download-Dispute-file/${res?.data?.disputeOrRtpId}`,
                method: "GET",
                responseType: "blob",
            });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(new Blob([response.data]));
            // console.log(link.href, "my image docs")
            setEvidenceData(link.href)
            setEvedenceImage(!EvidenceImage)
        } catch (error) {

        }
    }




    return (
        <Card className="m-1">
            <CardBody>
                <>
                    <Table striped className="text-center activityHistory mb-0 b-0">
                        <tbody>
                            {isHistory && (
                                <tr>
                                    <td className="fw-bold">Name</td>
                                    <td>{`${obj.user?.firstName} ${obj?.user?.lastName}`}</td>
                                    <td className="fw-bold leftBorder">Update Time</td>
                                    <td>
                                        {moment(obj.createdTime).format("YYYY-MM-DD HH:mm:ss")}
                                    </td>
                                </tr>
                            )}
                            <tr>
                                <td className="fw-bold">amount</td>
                                <td>{obj?.amount}</td>
                                <td className="fw-bold leftBorder">Remarks</td>
                                <td>{obj?.remark}</td>
                            </tr>
                            <tr>
                                <td className="fw-bold">Dispute Type</td>
                                <td>{obj?.disputeType}</td>
                                <td className="fw-bold leftBorder">Dispute Reason</td>
                                <td>{disputeReason[obj?.disputeReason]}</td>
                            </tr>
                            <tr>
                                {/* {obj?.ptpType ?? "-"} */}
                                <td className="fw-bold">Evidence</td>
                                <td>
                                    {
                                        obj?.isDocument == "yes" ? (
                                            <>
                                                <button onClick={() => handleShowDisputeEvidance(obj)} style={{ border: "none", background: "transparent", color: "green", marginRight: "10px" }}><i class="bi bi-card-image" ></i></button>
                                                <button onClick={() => handleDownloadEvidence(obj)} style={{ border: "none", background: "transparent", color: "green" }}><i class="bi bi-cloud-download" ></i></button>
                                            </>
                                        ) : "Not upload"
                                    }

                                </td>
                                <td className="fw-bold leftBorder"></td>
                                <td></td>
                            </tr>

                            {obj?.offlineCreationDate ? (
                                <tr>
                                    <td className="fw-bold">Offline Created-Date</td>
                                    <td style={{borderRight:"1px solid lightgray"}}>{obj.offlineCreationDate}</td>
                                </tr>
                            ) : null}


                        </tbody>
                    </Table>

                    <Dialog
                        visible={EvidenceImage && evidencedata}
                        header="Dispute Evidence"

                        onHide={() => setEvedenceImage(!EvidenceImage)}
                    >
                        <img src={evidencedata} style={{ width: "100%", height: "100%" }}></img>
                    </Dialog>
                </>
            </CardBody>
        </Card>
    );
}
