import React, { useEffect, useState } from "react";
import MultiSelectionFormik from "../Selection/MultiSelectionFormik";
import { useFormikContext } from "formik";
import axios from "axios";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";

export default function ProductDropdown({
  isView,
  ids,
  touch,
  error,
  value,
  portfolioListSelected,
}) {
  const [activeProductList, setActiveProductList] = useState([]);
  const { setFieldValue } = useFormikContext();
  const dispatch = useDispatch()
  useEffect(() => {
    let portfolioIds =
      portfolioListSelected &&
      portfolioListSelected?.map((portfolio) => portfolio.value)?.join();
    if (portfolioIds){
      dispatch(setLoader(true))
      axios.get(`/getProductByPortfolio/${portfolioIds}`).then(({ data }) => {
        dispatch(setLoader(false))
        let tempProduct = [];
        data.data.forEach((product) => {
          tempProduct.push({
            label: product.productDescription,
            value: product.productId,
          });
        });
        setActiveProductList([...tempProduct]);
      });
      dispatch(setLoader(false))
    }
  }, [portfolioListSelected]);

  return (
    <MultiSelectionFormik
      label={"Product:"}
      options={activeProductList}
      handleChangeEvent={(e) => {
        setFieldValue(ids, e);
      }}
      ids={ids}
      isView={isView}
      value={value}
      touch={touch}
      error={error}
      isRequired
    />
  );
}
