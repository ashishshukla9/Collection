import React, { useEffect, useState } from "react";
import { useFormikContext } from "formik";
import { FormGroup, Label, Col } from "reactstrap";
import Select from "react-select";
import cx from "classnames";
import Field from "../Field";
// import axios from "axios";

export default function Branches({ isView, orgName, Option }) {
  const { values, errors, touched, setFieldValue, handleBlur } =
    useFormikContext();
  const [branches, setBranches] = useState([]);

  useEffect(() => {
    if (orgName) {
      let branch = [];
      orgName?.forEach((e) => {
        branch.push({ ...e, label: (e?.branchName || e?.label), value: (e?.branchCode || e?.value) });
      });
      setBranches([...branch]);
    }
  }, [orgName]);

  return (
    <Field
      // isRequired={(values?.userType !== "U101") || (values?.userType === 'U101' && Boolean(values?.agency?.length))}
      label={`Branch`}
      // errorMessage={touched.agency && errors.agency}
    >
      <Select
        inputId="agencyBranch"
        placeholder="Select an Option"
        options={branches}
        closeMenuOnSelect={false}
        hideSelectedOptions={false}
        onChange={(e) => {
          setFieldValue("agencyBranch", e)
        }}
        value={values.agencyBranch}
        // className={cx({
        //   abc: touched.agencyBranch && Boolean(errors.agencyBranch),
        // })}
        classNamePrefix="react-select"
        onBlur={handleBlur}
        isDisabled={isView}
        menuPosition="fixed"
        isMulti
        components={{
          Option,
        }}
      />
    </Field>
  );
}
