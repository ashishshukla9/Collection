import React, { useEffect, useState } from "react";
import MultiSelectionFormik from "../Selection/MultiSelectionFormik";
import axios from "axios";
import { useFormikContext } from "formik";
import { useDispatch } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";

export default function StateDropdown({
  isView,
  ids,
  error,
  touch,
  zoneLists,
  value,
}) {
  const [activeState, setActiveState] = useState([]);
  const { setFieldValue } = useFormikContext();
  const dispatch=useDispatch()

  useEffect(() => {
    if (zoneLists.length > 0) {
      let zones = zoneLists?.map((portfolio) => portfolio.value)?.join();
      if (zones)
        // axios.get(`/getStateByZone/${zones}`).then(({ data }) => {
    dispatch(setLoader(true))
        axios.get(`/getRegionByZone/${zones}`).then(({ data }) => {
          dispatch(setLoader(false))
          let tempState = [];
          data.data.forEach((state) => {
            tempState.push({
              label: state.stateName,
              value: state.stateId,
            });
          });
          setActiveState([...tempState]);
        });
        dispatch(setLoader(false))
    } else {
      setFieldValue(ids, []);
      setActiveState([]);
    }
  }, [zoneLists]);

  return (
    <MultiSelectionFormik
      label={"State:"}
      options={activeState}
      handleChangeEvent={(e) => {
        setFieldValue(ids, e);
      }}
      value={value}
      ids={ids}
      isView={isView}
      error={error}
      touch={touch}
      isRequired
    />
  );
}
