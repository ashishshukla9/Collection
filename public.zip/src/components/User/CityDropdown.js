import { useFormikContext } from "formik";
import React, { useState, useEffect } from "react";
import MultiSelectionFormik from "../Selection/MultiSelectionFormik";
import axios from "axios";

export default function CityDropdown({
  isView,
  ids,
  error,
  touch,
  value,
  cityLists,
}) {
  const { setFieldValue } = useFormikContext();
  const [activeCities, setActiveCities] = useState([]);
  useEffect(() => {
    // if (regionLists.length > 0) {
    //   let region = regionLists?.map((region) => region.value)?.join();
    //   if (region)
    if (cityLists.length > 0) {
      let region = cityLists?.map((region) => region.value)?.join();
      if (region)
        // axios.get(`/getCityByRegion/${region}`).then(({ data }) => {
        // axios.get(`/getStateByRegion/${region}`).then(({ data }) => {
        axios.get(`/getCityByState/${region}/1/10`).then(({ data }) => {
          // axios.get(`/getRegionByZone/${region}`).then(({ data }) => {
          let tempCity = [];
          data.response.forEach((region) => {
            tempCity.push({
              label: region.cityName,
              value: region.cityId,
            });
          });
          setActiveCities([...tempCity]);
        });
    } else {
      setFieldValue(ids, []);
      setActiveCities([]);
    }
    // }, [regionLists]);
  }, [cityLists]);

  return (
    <MultiSelectionFormik
      label={"City:"}
      options={activeCities}
      handleChangeEvent={(e) => {
        setFieldValue(ids, e);
      }}
      value={value}
      ids={ids}
      isView={isView}
      error={error}
      touch={touch}
      isRequired
    />
  );
}
