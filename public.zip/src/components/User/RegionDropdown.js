import { useFormikContext } from "formik";
import React, { useState, useEffect } from "react";
import MultiSelectionFormik from "../Selection/MultiSelectionFormik";
import axios from "axios";
import { useDispatch } from "react-redux";

export default function RegionDropdown({
  isView,
  ids,
  touch,
  error,
  stateLists,
  value,
}) {
  const { setFieldValue } = useFormikContext();
  const [activeRegion, setActiveRegion] = useState([]);
  const dispatch=useDispatch()

  useEffect(() => {
    if (stateLists.length > 0) {
      let state = stateLists?.map((portfolio) => portfolio.value)?.join();
      if (state)
      dispatch(setLoader(true))
        axios.get(`/getRegionByState/${state}`).then(({ data }) => {
          dispatch(setLoader(false))
          let tempRegion = [];
          data.data.forEach((region) => {
            tempRegion.push({
              label: region.regionName,
              value: region.regionId,
            });
          });
          setActiveRegion([...tempRegion]);
        });
        dispatch(setLoader(false))
    } else {
      setActiveRegion([]);
      setFieldValue(ids, []);
    }
  }, [stateLists]);

  return (
    <MultiSelectionFormik
      label={"Region:"}
      options={activeRegion}
      handleChangeEvent={(e) => {
        setFieldValue(ids, e);
      }}
      value={value}
      ids={ids}
      isView={isView}
      touch={touch}
      error={error}
      isRequired
    />
  );
}
