
import { memo } from 'react'
import styles from './Field.module.scss'
import classNames from 'classnames'

const Label = (props) => {
    return (
        <label className={classNames(styles?.label, props?.labelClassName)}>
            {props?.label}
            {props?.isRequired && <span className={styles?.requiredSign}>*</span>}
        </label>
    )
}

export default memo(Label)