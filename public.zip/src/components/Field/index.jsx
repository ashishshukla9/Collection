import { memo } from "react"
import styles from './Field.module.scss'
import Label from "./Label";
import classNames from "classnames";

const Index = (props) => {
    return (
        <div className={classNames(styles?.container,props?.containerClassName)}   >
            {props?.label &&
                <Label 
                    labelClassName={props?.labelClassName}
                    label={props?.label}
                    isRequired={props?.isRequired}
                />
                
            }
            <div className={styles?.children} >
                <div className={props?.childrenClassName}  >
                    {props?.children}
                </div>
                {props?.errorMessage && <p className={styles?.error}>{props?.errorMessage}</p>}
            </div>
        </div>
    )
}

export default memo(Index);