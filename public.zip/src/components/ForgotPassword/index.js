import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  Input,
  FormGroup,
  Label,
  Row,
  FormFeedback,
  Container,
} from "reactstrap";
import { Formik, ErrorMessage } from "formik";
import { scrollToErrorMessage } from "../../utils/commonFun";
import * as yup from "yup";
import Swal from "sweetalert2";
import cx from "classnames";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";

const ForgotPassword = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [confirmpasswordShow, setConfirmpasswordshow] = useState(false);
  const [tokenValid, setTokenValid] = useState(false);
  const [passwordValidation, setPasswordValidation] = useState();
  const initialValues = {
    password: "",
    confirmpassword: "",
  };


  useEffect(() => {
    axios.get(`/getPasswordValidations`).then((res) => {
      setPasswordValidation(res?.data?.data);
    });
  }, []);

  const passwordValidations = {
    minUppercase: new RegExp(`[A-Z]{${passwordValidation?.minUppercase},}`),
    requiredSpecialCharacter: new RegExp(
      `[!@#$%^&*]{${passwordValidation?.requiredSpecialCharacter},}`
    ),

    requiredDigit: new RegExp(`\\d{${passwordValidation?.requiredDigit},}`),
    maxLowercase: new RegExp(`[a-z]{${passwordValidation?.maxLowercase},}`),
  };

   const Navigate = useNavigate() 
  const validation = yup.object().shape({
    password: yup
      .string()
      .required("Password is required")
      .min(
        passwordValidation?.minPassLength,
        `Password minimum lenth should be ${passwordValidation?.minPassLength}.`
      )
      .max(
        passwordValidation?.maxPassLength,
        `Password maximum lenth should be ${passwordValidation?.maxPassLength}.`
      )
      .test(
        "Pasword needs to be strong",
        `Password must contain at least ${passwordValidation?.minUppercase} uppercase letter, ${passwordValidation?.maxLowercase} lowercase letter and ${passwordValidation?.requiredSpecialCharacter} special character and ${passwordValidation?.requiredDigit} digits`,
        (value) => {
          const uppercaseRegex = passwordValidations?.minUppercase;
          const specialCharRegex = passwordValidations?.requiredSpecialCharacter;
           const digitRegex = passwordValidations?.requiredDigit;
          const lowercaseRegex = passwordValidations?.maxLowercase;

          const isUppercaseValid = uppercaseRegex.test(value);
          const isSpecialCharValid = specialCharRegex.test(value);
          const isDigitValid = digitRegex.test(value);
          const isLowercaseValid = lowercaseRegex.test(value);

          return (
            isUppercaseValid &&
            isSpecialCharValid &&
            isDigitValid &&
            isLowercaseValid
          );
        }
      ),
    confirmpassword: yup
      .string()
      .required("Confirm Password is required")
      .oneOf([yup.ref("password"), null], "Passwords must match"),
  });

  const location = useLocation();

  useEffect(() => {
    const params = {
      token: location.search.replace("?", ""),
    };

    axios.get(`/urlExpiry`, { params }).then((tokenresponse) => {
      if (tokenresponse.data.msgKey === "Success") {
        setTokenValid(true);
      }
    });
  }, []);

  const forgotPassword = (values) => {
    const payload = {
      password: values.password,
    };
    const params = {
      token: location.search.replace("?", ""),
    };
    try {
      axios.put(`/forgetPassword`, payload, { params }).then((res) => {
        if (res?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          Navigate("/")
        }

        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {}
  };

  return (
    <>
      <div className="App">
        <Container>
          {tokenValid ? (
            <Formik
              enableReinitialize={true}
              initialValues={initialValues}
              validationSchema={validation}
              onSubmit={forgotPassword}
            >
              {({
                values,
                errors,
                handleChange,
                handleBlur,
                touched,
                handleSubmit,
                setFieldValue,
                setFieldError,
                isSubmitting,
              }) => {
                const err = Object.keys(errors)[0];
                scrollToErrorMessage(isSubmitting, err);
                return (
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      minHeight: "80vh",
                    }}
                  >
                    <Form onSubmit={handleSubmit}>
                      <Card
                        style={{
                          width: "500px",
                          height: "450px",
                          padding: "30px",
                        }}
                      >
                        <CardBody>
                          {/* <Row className="mt-3 mb-3">
                            <Col lg={12} md={12} sm={12}>
                              <FormGroup className="rmb-0" floating>
                                <Input
                                  type="text"
                                  id="uid"
                                  value={values.uid}
                                  placeholder="User Name"
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  invalid={touched.uid && Boolean(errors.uid)}
                                />
                                <Label for="password">User Name</Label>
                                <FormFeedback>{errors?.uid}</FormFeedback>
                              </FormGroup>
                            </Col>
                          </Row> */}
                          <Row className="mb-3  mt-5">
                            <Col lg={12} md={12} sm={12}>
                              <FormGroup className="rmb-0" floating>
                                <Input
                                  id="password"
                                  placeholder="password"
                                  type={showPassword ? "text" : "password"}
                                  className="password"
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  invalid={errors?.password && true}
                                  value={values.password}
                                />
                                <Label for="password">Password</Label>
                                <FormFeedback>{errors?.password}</FormFeedback>
                                <i
                                  className={cx({
                                    bi: true,
                                    "bi-eye-fill": showPassword,
                                    "bi-eye-slash-fill": !showPassword,
                                  })}
                                  onClick={() => setShowPassword(!showPassword)}
                                ></i>
                              </FormGroup>
                            </Col>
                          </Row>
                          <Row>
                            <Col lg={12} md={12} sm={12}>
                              <FormGroup className="rmb-0" floating>
                                <Input
                                  id="confirmpassword"
                                  name="confirmpassword"
                                  placeholder="Confirm Password"
                                  type={
                                    confirmpasswordShow ? "text" : "password"
                                  }
                                  className="password"
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  invalid={errors?.confirmpassword && true}
                                  value={values.confirmpassword}
                                />
                                <Label for="confirmpassword">
                                  Confirm Password
                                </Label>

                                <FormFeedback>
                                  {errors?.confirmpassword}
                                </FormFeedback>
                                <i
                                  className={cx({
                                    bi: true,
                                    "bi-eye-fill": confirmpasswordShow,
                                    "bi-eye-slash-fill": !confirmpasswordShow,
                                  })}
                                  onClick={() =>
                                    setConfirmpasswordshow(!confirmpasswordShow)
                                  }
                                ></i>
                              </FormGroup>
                            </Col>
                          </Row>

                          <Row className="mb-3 mt-3">
                            <FormGroup className="rmb-0" floating>
                              <div className="d-flex justify-content-center">
                                <Button
                                  size="md"
                                  type="submit"
                                  color="primary"
                                  style={{ color: "white" }}
                                >
                                  Save
                                </Button>
                              </div>
                            </FormGroup>
                          </Row>
                        </CardBody>
                      </Card>
                    </Form>
                  </div>
                );
              }}
            </Formik>
          ) : (
            <div className="d-flex justify-content-center ">
              <Card
             
                style={{
                  width: "500px",
                  padding: "30px",
                  marginTop:"25%"
                }}
              >
                <CardBody>
                  <h4>URL has expired. Please request a new one. </h4>
                  <a href="/">Back To Login Screen</a>
                </CardBody>
              </Card>
            </div>
          )}
        </Container>
      </div>
    </>
  );
};

export default ForgotPassword;
