import React from 'react';
import { useField } from 'formik';
import Select from 'react-select'; // You can change this import if you're using a different multi-select library
import cx from 'classnames';

const MultiSelectionFormik2 = ({
  label,
  options,
  handleChangeEvent,
  value,
  closeMenu = false,
  ids,
  classNamePrefix = 'react-select',
  overrideStrings,
  isCreatable = false,
  isMulti = true,
  error,
  touch,
  filterOption,
  onKeyDown,
  onInputChange,
  isRequired,
  onMenuScrollToBottom,
  ...props
}) => {
  // Using Formik's `useField` hook to connect the component to Formik's state
  const [field, meta, helpers] = useField(ids);

  // Handle change in selected options
  const handleChange = (selectedOptions) => {
    if (handleChangeEvent) {
      handleChangeEvent(selectedOptions); // Custom handler passed as prop
    } else {
      helpers.setValue(selectedOptions); // Use Formik helpers to set the value
    }
  };

  return (
    <div className={cx('multi-select-form-group', { 'has-error': meta.touched && meta.error })}>
      {/* Label and error handling */}
      {label && <label htmlFor={ids}>{label}</label>}
      {meta.touched && meta.error && (
        <div className="error">{meta.error || error}</div> // Display error if any
      )}

      {/* react-select component */}
      <Select
        {...props} // Spread additional props for customization
        inputId={ids}
        value={value || []} // Pass selected values
        onChange={handleChange} // Handle change of selected items
        options={options} // Options for the select dropdown
        isMulti={isMulti} // Multiple selection
        closeMenuOnSelect={closeMenu} // Whether to close the dropdown on selection
        classNamePrefix={classNamePrefix} // Prefix for custom styles
        isCreatable={isCreatable} // Whether to allow creating new options
        placeholder={overrideStrings?.selectSomeItems || 'Select an option'} // Custom placeholder
        getOptionLabel={(e) => e.label || e.productDescription} // Customize option label
        getOptionValue={(e) => e.value || e.productCode} // Customize value extraction
        filterOption={filterOption} // Option filtering
        onKeyDown={onKeyDown} // Key down event handler
        onInputChange={onInputChange} // Input change handler
        onMenuScrollToBottom={onMenuScrollToBottom} // Handler for scroll to bottom of the menu
        styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }} // Custom styles (e.g., for z-index)
      />
    </div>
  );
};

export default MultiSelectionFormik2;
