import React, { useState } from "react";
import {
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  Col,
  Button,
  FormFeedback,
} from "reactstrap";
import { User, validationSchema } from "../../common/schema/User";
import { useFormik } from "formik";

export default function Master() {
  const formik = useFormik({
    initialValues: User,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      alert(JSON.stringify(values, null, 2));
    },
  });
  const [user, setUser] = useState(User);
  return (
    <main id="main">
      <section>
        <h3>Master</h3>
        <Form onSubmit={formik.handleSubmit}>
          <Row>
            <Col lg={6} md={6} sm={12}>
              <FormGroup row className="align-items-center">
                <Label sm={4} for="firstName">
                  Field Code
                  <span className="required" style={{ color: "red" }}>
                    *
                  </span>
                </Label>
                <Col sm={8}>
                  <Input
                    bsSize="sm"
                    type="text"
                    id="firstName"
                    placeholder="Field Code"
                    value={formik.values.firstName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={
                      formik.touched.firstName &&
                      Boolean(formik.errors.firstName)
                    }
                  ></Input>
                  <FormFeedback>
                    {formik.touched.firstName && formik.errors.firstName}
                  </FormFeedback>
                </Col>
              </FormGroup>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <FormGroup row className="align-items-center">
                <Label sm={4} for="lastName">
                  Profile Name
                  <span className="required" style={{ color: "red" }}>
                    *
                  </span>
                </Label>
                <Col sm={8}>
                  <Input
                    bsSize="sm"
                    type="text"
                    id="lastName"
                    placeholder="Profile Name"
                    value={formik.values.lastName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={
                      formik.touched.lastName && Boolean(formik.errors.lastName)
                    }
                  ></Input>
                  <FormFeedback>
                    {formik.touched.lastName && formik.errors.lastName}
                  </FormFeedback>
                </Col>
              </FormGroup>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <FormGroup row className="align-items-center">
                <Label sm={4} for="state">
                  User Type
                  <span className="required" style={{ color: "red" }}>
                    *
                  </span>
                </Label>
                <Col sm={8}>
                  <Input
                    bsSize="sm"
                    type="select"
                    id="state"
                    value={user.state}
                    onChange={(e) =>
                      setUser({ ...user, state: e.target.target })
                    }
                  >
                    <option disabled>Select an Option</option>
                    <option>Option 1</option>
                    <option>Option 2</option>
                  </Input>
                </Col>
              </FormGroup>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <FormGroup row>
                <Label sm={4} for="status">
                  Active
                </Label>
                <Col sm={8}>
                  <FormGroup switch className="ms-2">
                    <Input
                      type="switch"
                      checked={formik.values.status}
                      onChange={formik.handleChange}
                      id="status"
                      readOnly
                    />
                  </FormGroup>
                </Col>
              </FormGroup>
            </Col>
          </Row>
          <div className="text-left">
            <Button color="primary" type="submit" size="sm">
              Submit
            </Button>{" "}
            <Button color="danger" type="cancel" className="ml-2" size="sm">
              Cancel
            </Button>
          </div>
        </Form>
      </section>
    </main>
  );
}
