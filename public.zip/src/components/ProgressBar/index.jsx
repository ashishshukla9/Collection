import { Fragment, memo } from "react"
import { Spinner } from "reactstrap"
import styles from './ProgressBar.module.scss'

const Index=(props)=>{
    return(
        <div className={styles?.spinnerContainer}>
            <Spinner 
                color="primary"
                className={styles?.loader}
            />
            {(props?.progressData?.percentage >=0 && ['uploading','validating']?.includes(props?.progressData?.stage)) ?
                <Fragment>
                    <p>{props?.progressData?.percentage} %</p>
                    <p>{props?.progressData?.stage === "uploading" ? 'Uploaded Data' : props?.progressData?.stage === "validating" && 'Validated Data'} - {props?.progressData?.uploadedData}</p>
                    <p>Total Data - {props?.progressData?.totalData}</p>  
                    {/* {props?.progressData?.stage === "validating" && <p>Data is validating...</p>} */}
                </Fragment> : 
                <p>Waiting for upload...</p>
            }
        </div>
    )
}

export default memo(Index)