import moment from "moment";
import React, { useState } from "react";
import {
  Accordion,
  AccordionBody,
  AccordionHeader,
  AccordionItem,
} from "reactstrap";
import { camelCaseToNormalString } from "../../utils/commonFun";

export const AccordionEle = ({ index, heading, bodyComp, customClassName }) => {
  const [createtime, setCreateTime]= useState("")
  function formatDateTime(milliseconds) {
    if (!milliseconds) return null;
    var dateTime = new Date(milliseconds);
    var year = dateTime.getFullYear();
    var month = String(dateTime.getMonth() + 1).padStart(2, '0'); 
    var day = String(dateTime.getDate()).padStart(2, '0'); 
    var hours = String(dateTime.getHours()).padStart(2, '0');
    var minutes = String(dateTime.getMinutes()).padStart(2, '0'); 
    var seconds = String(dateTime.getSeconds()).padStart(2, '0'); 
    var formattedDateTime = day + '-' + month + '-' + year + ' ' + hours + ':' + minutes + ':' + seconds;
    return formattedDateTime;
}

  return (
    bodyComp && (
      <AccordionItem className="my-1">
        <AccordionHeader targetId={index}>
          <div className="accordWidth d-flex justify-content-between">
            <div>{camelCaseToNormalString(heading?.activityType)}</div>
            <div>
              {heading?.actionPerformed} Date:{" "}
              {formatDateTime(heading?.createdTime)}
              
            </div>
          </div>
        </AccordionHeader>
        <AccordionBody accordionId={index} className={`${customClassName}`}>
          {/* {bodyComp?.requestType.include(["Name Change", "Contact Change", "Address Change"])? bodyComp :""} */}
          {bodyComp}

        </AccordionBody>
      </AccordionItem>
    )
  );
};
