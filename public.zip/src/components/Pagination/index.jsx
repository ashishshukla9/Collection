import { memo, useMemo, useState } from "react"
import styles from './Pagination.module.scss'
import { MdChevronLeft, MdChevronRight } from "react-icons/md";
import classNames from "classnames";

const Pagination=(props)=>{
    console.log(props?.totalCount , "jjkfhdjkhkjgkfkj")
    const noOfDataPerPageOption=useMemo(()=>[10,25,50,100],[])
    const currentPage=useMemo(()=> (parseInt(props?.currentPage) || 1),[props?.currentPage])
    const numberOfDataPerPage=useMemo(()=> (parseInt(props?.numberOfDataPerPage) || 10),[props?.numberOfDataPerPage])

    const totalPages = useMemo(()=>{
        if(props?.totalCount){
            const count = Array.from({length: Math.ceil(props?.totalCount / numberOfDataPerPage)}, (_, i) => i + 1)
            if(currentPage >=3 && count.length > 5){
                return count.splice((count?.length - 3) < currentPage ? (count?.length - 5) : currentPage - 3,5)
            }else{
                return count.splice(0,5)
            }
        }
        return []
    },[props?.totalCount,numberOfDataPerPage,currentPage])

    const onNextClick=()=>{
        if(currentPage !== totalPages?.findLast(a=>a) && totalPages?.length){
            props?.setCurrentPage(prev=>prev + 1)
        }
    }
    const onPrevClick=()=>{
        if(currentPage !== 1 && totalPages?.length){
            props?.setCurrentPage(prev=>prev - 1)
        }
    }

    const onSelectData=(e)=>{
        props?.setNumberOfDataPerPage(e?.target?.value)
        props?.setCurrentPage(1)
    }
    
    return(
        <div className={styles?.container}>
            <div 
                className={classNames((currentPage === 1 || !totalPages?.length) && styles?.disabledArrow,styles?.arrow)}
                onClick={onPrevClick}
            >
                <MdChevronLeft />
            </div>
            {totalPages?.map(a=>(
                <div 
                    key={a} 
                    className={classNames(currentPage === a && styles?.activePage, styles?.page)}
                    onClick={()=>props?.setCurrentPage(a)}
                >
                    {a}
                </div>
            ))}
            <div 
                className={classNames((currentPage === totalPages?.findLast(a=>a) || !totalPages?.length) && styles?.disabledArrow,styles?.arrow)}
                onClick={onNextClick}
            >
                <MdChevronRight />
            </div>
            <div>
                <select
                    onChange={onSelectData}
                    value={numberOfDataPerPage}
                    className={styles?.perPageDataSelect}
                >
                    {noOfDataPerPageOption?.map(a=>(
                        <option key={a} value={a}>{a}</option>
                    ))}
                </select>
            </div>
        </div>
    )
}

export default memo(Pagination)