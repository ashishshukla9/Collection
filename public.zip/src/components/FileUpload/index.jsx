import { Dialog } from "primereact/dialog";
import { memo, useState } from "react"
import { Button } from "reactstrap";
import Select from "react-select";

const Index = (props) => {
    const [file, setFile] = useState({})
    const [docType, setDocType] = useState("")

    return (
        <Dialog
            header={props?.header}
            visible={props?.visible}
            style={{
                width: "60vw",
            }}
            onHide={() => props?.setVisible(false)}
        >
            <div style={{display: 'flex', gap: '10px'}}>
                {props?.header === "Add KYC" &&
                    <>
                        <label style={{whiteSpace: "nowrap"}}>Select Document</label>
                        <Select
                            bsSize="sm"
                            type="text"
                            isClearable={true}
                            isSearchable
                            options={props?.documentOptions}
                            value={props?.documentOptions.filter((e) => e.value === docType)}
                            closeMenuOnSelect={true}
                            onChange={(e) => setDocType(e?.value)}
                            classNamePrefix="react-select"
                            menuPosition={"fixed"}
                        />
                    </>
                }
                <label className="btn btn-sm upload-button btn-outline-primary">
                    <i className="bi bi-upload uploadIcon"></i>
                    Select {file?.name}
                    <input
                        type="file"
                        style={{ display: "none" }}
                        onChange={(event) => {
                            setFile(event.target?.files[0]);
                        }}
                    />
                </label>

            </div>
            <Button
                color="success"
                className="m-2 ms-auto d-flex text-white"
                onClick={() => {
                    setFile({})
                    props?.onSave(file,docType)
                }}
                disabled={!file}
                size="sm"
            >
                Save
            </Button>
        </Dialog>
    )
}

export default memo(Index)