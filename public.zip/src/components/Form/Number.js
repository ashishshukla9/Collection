import React from "react";
import { Input } from "reactstrap";

export default function Number({ className, ids, changeHandler, value }) {
  return (
    <Input
      value={value}
      className={className}
      id={ids}
      onChange={changeHandler}
    />
  );
}
