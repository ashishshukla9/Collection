import React, { useState } from 'react';
import { GoogleMap, DirectionsRenderer, LoadScript } from '@react-google-maps/api';

const MapData = ({ origin, destination }) => {
  const [directions, setDirections] = useState(null);

  const onLoad = (directionsService) => {
    directionsService.route(
      {
        origin: origin,
        destination: destination,
        travelMode: 'DRIVING' // Adjust travel mode as needed (DRIVING, BICYCLING, TRANSIT, WALKING)
      },
      (result, status) => {
        if (status === 'OK') {
          setDirections(result);
        } else {
          console.error(`Error fetching directions ${result}`);
        }
      }
    );
  };

  return (
    <LoadScript googleMapsApiKey="YOUR_API_KEY"> {/* Replace with your Google Maps API key */}
      <GoogleMap
        center={origin}
        zoom={10}
        mapContainerStyle={{ width: '100%', height: '400px' }}
      >
        {directions && <DirectionsRenderer directions={directions} />}
      </GoogleMap>
    </LoadScript>
  );
};

export default MapData;
