import axios from "axios";

export const DownloadFile = async (api, fileName) => {
  try {
    const response = await axios({
      url: api, // Replace with your file URL
      method: "GET",
      responseType: "blob", // Important: Set the response type as 'blob'
    });

    // Create a temporary link element
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([response.data]));
    // console.log(link.href, "link hred")
    // // console.log(link)

    // // // Set the file name
    link.setAttribute("download", fileName); // Replace 'filename.ext' with the desired file name and extension

    // // // Append the link to the document body and trigger the download
    document.body.appendChild(link);
    link.click();

    // // // Clean up the temporary link
    document.body.removeChild(link);
  } catch (error) {
    console.error("Error downloading file:", error);
  }
};
