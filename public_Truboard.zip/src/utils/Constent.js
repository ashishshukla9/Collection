export const ZoneOption = [
  {
    value: "NORTH",
    label: "North",
  },
  {
    value: "EAST",
    label: "East",
  },
  {
    value: "SOUTH",
    label: "South",
  },
  {
    value: "WEST",
    label: "West",
  },
];

export const API_STATUS = {
  SUCCESS: 'Success',
  FAILED: 'Failed'
}