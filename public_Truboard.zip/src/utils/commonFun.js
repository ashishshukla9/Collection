import axios from "axios";
import { Cookies } from "react-cookie";
const cookies = new Cookies()
export const camelCaseToNormalString = (str) => {
  return str === "Dispute/Rtp" ? 'Dispute/RTP' : str.replace(/([A-Z])/g, " $1").trim();
}
export const scrollToErrorMessage = (isSubmitting, name) => {
  if (isSubmitting && name) {
    const getElement = document.getElementById(name)
    getElement?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }
}
export const removeMultiSelectOptionValue = (valueArr, optionArr, valueCompareKey, optionCompareKey) => {
  return valueArr?.filter(a => optionArr?.some(b => b[optionCompareKey] === a[valueCompareKey]))
}
export const extendToken = (loginSessionTimeout) => {
  const getToken = cookies.get('token')
  cookies.remove('token')
  const cookiesExpireTime = 60 * (loginSessionTimeout || 3)
  let showLogoutMessageTiming = new Date()
  showLogoutMessageTiming = showLogoutMessageTiming.setSeconds(showLogoutMessageTiming.getSeconds() + (cookiesExpireTime - 30))
  cookies.set('token', getToken, { maxAge: cookiesExpireTime })
  cookies.remove('logout')
  cookies.set('logout', showLogoutMessageTiming, { maxAge: cookiesExpireTime })
}
export const addAudit = async (payload) => {
  try {
    const res = await axios.post('/addAuditTrail', payload)
  } catch (error) {
  }
}