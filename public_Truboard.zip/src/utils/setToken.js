import axios from "axios";

// axios.defaults.baseURL = "http://192.168.1.36:8081/loan-collections-1-0/v1/collections";

axios.defaults.baseURL = process.env.REACT_APP_BASE_URL;

// axios.interceptors.request.use((request) => {
//   // console.log(request, "axios");
//   return request;
// });

// axios.interceptors.response.use((response) => {
//   // console.log(response, "axios");
//   return response;
// });

export const setToken = (token) => {
  if (token) {
    axios.defaults.headers.common["Authorization"] = `Bearer ` + token;
  } else {
    delete axios.defaults.headers.common["Authorization"];
  }
};
