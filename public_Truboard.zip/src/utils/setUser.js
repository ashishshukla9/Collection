import axios from "axios";
import store from "../store";
import { login } from "../features/user/userSlice";
import { useDispatch } from "react-redux";
// import { setLoder } from "../Pages/User/store";
// import { setLoader } from "../reducer/globalReducer";

export default function setUser(UID) {
// const dispatch=useDispatch()
// /getUserByUID -- mai api change kiya hu only 
// console.log(UID, "userid")
  axios
    .get(`/getUserByUserNameForDashboard/${UID}`)
    .then(({ data }) => {
      // dispatch(setLoader(true))
      const user = data.data;
      // console.log(data, "finallizedata")

      let masterRole;
      if (user.role.length > 1) {
        masterRole = JSON.parse(user.role[0].access);
        for (var i = 1; i < user.role.length; i++) {
          let access = JSON.parse(user.role[i].access);
          for (let key in masterRole) {
            if (masterRole[key] && access[key]) {
              if (masterRole[key] !== access[key]) {
                masterRole[key] = "F"
              }
            } else if (!masterRole[key]) {
              masterRole[key] = access[key]
            }
          }
        }
      }else{
        masterRole = JSON.parse(user.role[0].access);
        for (const key in masterRole) {
          masterRole = {
            ...masterRole,
            [key]: masterRole[key]
          }
        }
      }
      user["masterRole"] = masterRole;
      store.dispatch(login({ ...user }));
      // dispatch(login({ ...user }));
    })
    .catch((error) => {
      console.log(error);
    });
}
