import { useFormik } from "formik";
import { useEffect, useState, useMemo } from "react";
import { Row, Form, Col, Button } from "reactstrap";
import * as Yup from "yup";
import Swal from "sweetalert2";
import Field from "../../components/Field";
import axios from "axios";
import Select from "react-select";
import cx from "classnames";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";
const LenderConfigurationForm = (props) => {
  const [lenderList, setLenderList] = useState([]);
  const [configData, setConfigData] = useState([]);
  const dispatch = useDispatch();
  const isView = useMemo(() => props?.formType === "View", []);
  const isEdit = useMemo(() => props?.formType === "Edit", []);
  const handleSubmit = async (values) => {
    try {
      const payload = {
        lenderIds: values?.lender?.map((lender) => lender.value),
        configurationIds: values?.schemeCode?.map((config) => config.value),
      };
      dispatch(setLoader(true));
      const lenderConfigId = props?.selectedData?.lenderConfigId;
      if (lenderConfigId) {
        const updateRes = await axios.put(
          `/updateLenderConfiguration/${lenderConfigId}`,
          payload
        );
        if (updateRes?.data?.messageKey) {
          props?.onSuccess();
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Lender configuration updated successfully.",
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        } else {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: updateRes?.data?.message,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      } else {
        const res = await axios.post("/maplenderToConfiguration", payload);
        if (res?.data?.messageKey) {
          props?.onSuccess();
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: res?.data?.message,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        } else {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: res?.data?.message,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      }
      dispatch(setLoader(false));
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: error.message,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const initialValues = {
    lender:
      isView || isEdit
        ? Array.isArray(props?.selectedData?.lenderName)
          ? props?.selectedData?.lenderName
          : props?.selectedData?.lenderName
          ? [
              {
                label: props.selectedData.lenderName,
                value: props.selectedData.lenderId,
              },
            ]
          : []
        : [],
    schemeCode:
      isView || isEdit
        ? Array.isArray(props?.selectedData?.schemeCode)
          ? props?.selectedData?.schemeCode
          : props?.selectedData?.schemeCode
          ? [
              {
                label: props.selectedData.schemeCode,
                value: props.selectedData.incPayInConfigId,
              },
            ]
          : []
        : [],
  };
  const validationSchema = Yup.object({
    lender: Yup.array()
      .min(1, "Please select at least one lender")
      .required("Lender Name is required"),
    schemeCode: Yup.array()
      .min(1, "Please select at least one configuration")
      .required("Configuration Detailed is required"),
  });
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: handleSubmit,
  });
  useEffect(() => {}, [formik.values]);
  const getLenderList = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getActiveLenderList");
      dispatch(setLoader(false));
      const lenders =
        res.data.data?.map((data) => ({
          label: data.lenderName,
          value: data.lenderId,
        })) || [];
      setLenderList(lenders);
    } catch (error) {
      dispatch(setLoader(false));
      console.error(error);
    }
  };
  useEffect(() => {
    getLenderList();
  }, []);
  const configureSlabData = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllPayInIncentiveConfiguration");
      dispatch(setLoader(false));
      const configurations =
        res.data.response?.map((data) => ({
          schemeCode: data.schemeCode,
          incPayInConfigId: data.incPayInConfigId,
        })) || [];
      setConfigData(configurations);
    } catch (error) {
      dispatch(setLoader(false));
      console.error(error);
    }
  };
  useEffect(() => {
    configureSlabData();
  }, []);
  return (
    <Form
      onSubmit={formik.handleSubmit}
      autoComplete="off"
      className="p-3 bg-white rounded"
      style={{ border: "1px solid rgba(0, 0, 21, 0.175)" }}
    >
      <Row>
        <Col lg={6}>
          <Field
            isRequired
            label="Lender Name"
            errorMessage={formik?.touched?.lender && formik?.errors?.lender}
          >
            <Select
              id="lenderIds"
              name="lenderIds"
              inputId="lenderIds"
              className={
                formik?.touched?.lender && formik?.errors?.lender
                  ? "select-error"
                  : ""
              }
              placeholder="Lender Name"
              closeMenuOnSelect={true}
              hideSelectedOptions={false}
              isMulti={true}
              menuPosition="fixed"
              isDisabled={isView}
              classNamePrefix="react-select"
              options={lenderList}
              value={formik.values.lender}
              onChange={(selectedOption) =>
                formik.setFieldValue("lender", selectedOption)
              }
              getOptionLabel={(e) => e.label}
              getOptionValue={(e) => e.value}
            />
          </Field>
        </Col>
        <Col lg={6}>
          <Field
            isRequired
            label="Configuration Detailed"
            errorMessage={
              formik?.touched?.schemeCode && formik?.errors?.schemeCode
            }
          >
            <Select
              id="schemeCode"
              inputId="schemeCode"
              placeholder="Scheme Code"
              closeMenuOnSelect={false}
              hideSelectedOptions={false}
              value={formik?.values.schemeCode}
              isMulti
              onChange={(selectedOptions) =>
                formik.setFieldValue("schemeCode", selectedOptions)
              }
              options={configData.map((item) => ({
                label: item.schemeCode,
                value: item.incPayInConfigId,
              }))}
              className={cx({
                abc:
                  formik?.touched.schemeCode &&
                  Boolean(formik?.errors.schemeCode),
              })}
              onBlur={formik?.handleBlur}
              menuPosition="fixed"
              classNamePrefix="react-select"
              isDisabled={isView}
            />
          </Field>
        </Col>
      </Row>
      {!isView && (
        <div className="d-flex justify-content-end mx-4">
          <Button type="submit" size="sm" color="primary">
            Submit
          </Button>
        </div>
      )}
    </Form>
  );
};
export default LenderConfigurationForm;