import { Formik } from "formik";
import { memo, useEffect, useMemo, useState } from "react";
import * as yup from "yup";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import { Button, Col, Form, FormGroup, Input, Row } from "reactstrap";
import Select from "react-select";
import Field from "../../../components/Field";
import { AMOUNT } from "../../../utils/regex";
import axios from "axios";
import styles from "./Configuration.module.scss";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";
const ConfigurationForm = (props, values) => {
  const ruleBodyRow = useMemo(() => ({
    id: 1,
    gridType: "",
    conditionType: "",
    dpdConditionType1: "",
    dpdConditionType2: "",
    dpdConditionType3: "",
    condition1: "",
    condition2: "",
    dpdCondition11: "",
    dpdCondition12: "",
    dpdCondition21: "",
    dpdCondition22: "",
    dpdCondition31: "",
    dpdCondition32: "",
    value1: "",
    value2: "",
    dpdValue11: "",
    dpdValue12: "",
    dpdValue21: "",
    dpdValue22: "",
    dpdValue31: "",
    dpdValue32: "",
    payInPercent: "",
    extraIncentiveAmount: "",
    dpdInc1: "",
    dpdInc2: "",
    dpdInc3: "",
    securedValue: "",
    unSecuredValue: "",
    slabCategory: "",
    dpdValue1: "",
    dpdValue2: "",
    dpdValue3: "",
  }));
  const user = useSelector((state) => state?.user?.data);
  const [payoutGridOptions, setPayoutGridOptions] = useState([]);
  const [selectedPortfolioTypesArray, setSelectedPortfolioTypesArray] =
    useState([]);
  const dispatch = useDispatch();
  const isView = useMemo(() => props?.formType === "View", []);
  const [portfolio, setPortfolio] = useState();
  const [gridTypeData, setGridTypeData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [productList, setProductList] = useState([]);
  const isEdit = useMemo(() => props?.formType === "Edit", []);
  const incentiveTypeOptions = useMemo(
    () => [{ label: "Pay In", value: "Pay In" }],
    []
  );
  const paddedColumnStyle = {
    padding: "0.2rem 1rem", 
  };
  useEffect(() => {
    const fetchAllGridData = async () => {
      try {
        const res = await axios.get("/getAllGrid");
        setGridTypeData(res?.data?.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchAllGridData();
  }, []);
  useEffect(() => {
    if (gridTypeData && gridTypeData.length > 0) {
      const options = gridTypeData.map((item) => ({
        value1: item.incPayInGridId,
        value: item.gridType, // Use incPayInGridId as the value
        label: item.gridType || item.gridType, // Use gridDescription or gridType as the label
      }));
      setPayoutGridOptions(options);
    }
  }, [dispatch, gridTypeData]);
  const conditionOptions = useMemo(
    () => [
      { label: ">=", value: ">=" },
      { label: ">", value: ">" },
      { label: "<=", value: "<=" },
      { label: "<", value: "<" },
      { label: "=", value: "=" },
      { label: "&&", value: "&&" },
    ],
    []
  );
  useEffect(() => {}, [values?.gridDtoData]); // Trigger effect when gridDtoData changes
  const condition1Options = useMemo(
    () => [
      { label: ">=", value: ">=" },
      { label: ">", value: ">" },
    ],
    []
  );
  const headerStyle = {
    position: "sticky",
    top: 0,
    zIndex: 0, // Ensure header stays above the table content
    backgroundColor: "#fff", // Optional: Adds background color
  };
  const condition2Options = useMemo(
    () => [
      { label: "<=", value: "<=" },
      { label: "<", value: "<" },
    ],
    []
  );
  const typeOfAmountOptions = [
    { value: "ROR", label: "ROR" },
    {
      value: "POS",
      label: "POS",
    },
    { value: "Charges Only", label: "Charges Only" },
  ];
  const ageNpaTypeOptions = [
    { value: "Active", label: "Active" },
    { value: "Deactive", label: "Deactive" },
  ];
  const accountTypeOptions = [
    { value: "PerAccount", label: "Per Account" },
    { value: "TotalAccount", label: "Total Account" },
    { value: "Both", label: "Both" },
  ];
  const getPortfolio = async () => {
    try {
      dispatch(setLoader(true));
      await axios.get("/getActivePortfolios").then((res) => {
        dispatch(setLoader(false));
        let Portpholio = [];
        res.data.data?.map((data) => {
          Portpholio.push({
            label: data.portfolioDescription,
            value: data.portfolioCode,
            id: data.portfolioId,
          });
        });
        setPortfolio(Portpholio);
      });
    } catch (error) {
      dispatch(setLoader(false));
    }
  };
  useEffect(() => {
    getPortfolio();
  }, []);
  const getProductByPortfolioId = async (selectedPortfolioValues) => {
    try {
      dispatch(setLoader(true)); // Start the loader
      const mappedPortfolioValues = selectedPortfolioValues.map((portfolio) => {
        if (portfolio === "Secured") return "SC";
        if (portfolio === "Unsecured") return "USC";
        return portfolio; // If 'Both' is selected, keep as is
      });
      const response = await axios.post(
        "/getProductByPortfolioList",
        mappedPortfolioValues
      );
      dispatch(setLoader(false)); // Stop the loader once the request is complete
      const products = response.data.data?.map((data) => ({
        label: data.productDescription,
        value: data.productCode,
        id: data.productId,
      }));
      setProductList(products);
    } catch (error) {
      dispatch(setLoader(false)); // Ensure the loader stops even in case of error
      console.error("Error fetching products:", error);
    }
  };
  useEffect(() => {
    if (isEdit) {
      const portfolioTypes = selectedPortfolioTypesArray.length
        ? selectedPortfolioTypesArray
        : values?.portFolioType
        ? values.portFolioType.split(", ")
        : [];
      let defaultPayload = [];
      defaultPayload = ["SC", "USC"]; // Always set this when "Both" is in the types
      if (!portfolioTypes.includes("Both")) {
        if (portfolioTypes.includes("Secured")) {
          defaultPayload = ["SC"]; // Only Secured
        }
        if (portfolioTypes.includes("Unsecured")) {
          defaultPayload = ["USC"]; // Only Unsecured
        }
      }
      if (defaultPayload.length === 0) {
        defaultPayload = [];
      }
      getProductByPortfolioId(defaultPayload);
    }
  }, [isEdit, selectedPortfolioTypesArray, values?.portFolioType]);
  const initialValues = {
    incentiveType: isView || isEdit ? props?.selectedData?.incentiveType : null,
    description: isView || isEdit ? props?.selectedData?.description : null,
    accountCalculationType:
      isView || isEdit ? props?.selectedData?.accountCalculationType : null, // Add this line
    productResponseDtoData:
      isView || isEdit
        ? (props?.selectedData?.productResponseDtoData ?? []).map((refefs) => ({
            productId: refefs.productId,
            productDescription: refefs.productDescription, // Assuming this structure from your payload
            productCode: refefs.productCode,
          }))
        : [],
    portFolioType: isView || isEdit ? props?.selectedData?.portFolioType : null,
    gridDtoData:
      isView || isEdit
        ? (props?.selectedData?.gridDtoData ?? []).map((grid) => ({
            gridType: grid.gridType,
            gridId: grid.gridId, // Assuming this structure from your payload
          }))
        : [],
    maximumCapSC: isView || isEdit ? props?.selectedData?.maximumCapSC : null,
    branch: isView || isEdit ? props?.selectedData?.branch : null,
    maximumCapUSC: isView || isEdit ? props?.selectedData?.maximumCapUSC : null,
    recoveryType: isView || isEdit ? props?.selectedData?.recoveryType : null,
    slabCategory: isView || isEdit ? props?.selectedData?.slabCategory : null,
    ageOfNPA: isView || isEdit ? props?.selectedData?.ageOfNPA : null,
    maximumCapSC: isView || isEdit ? props?.selectedData?.maximumCapSC : null,
    maximumCapUSC: isView || isEdit ? props?.selectedData?.maximumCapUSC : null,
    npaType: isView || isEdit ? props?.selectedData?.npaType || null : null, // Add npaType to initial values
    accountStatus: isView || isEdit ? props?.selectedData?.accountStatus : null,
    holdBack: isView || isEdit ? props?.selectedData?.holdBack : null,
    schemeCode: isView || isEdit ? props?.selectedData?.schemeCode : null,
    active: isView || isEdit ? props?.selectedData?.active : true,
    incentivePayInSlabsDto:
      isView || isEdit
        ? props?.selectedData?.incentivePayInSlabsDto?.length
          ? props?.selectedData?.incentivePayInSlabsDto
          : [ruleBodyRow]
        : [ruleBodyRow],
  };
  const validationSchema = yup.object().shape({
    incentiveType: yup.string().required("Required"),
    accountCalculationType: yup.string().required("Required"),
    schemeCode: yup.string().required("Required"),
    description: yup.string().required("Required"),
    ageOfNPA: yup.string().required("Required"),
    maximumCapSC: yup.string().required("Required"),
    branch: yup.string().required("Required"),
    maximumCapUSC: yup.string().required("Required"),
    recoveryType: yup.string().required("Required"),
  });
  const configureId = props.selectedData.incPayInConfigId;
  const handleSubmit = async (values) => {
    try {
      const incentivePayInSlabsDto = values?.incentivePayInSlabsDto?.map(
        (a) => {
          if (a?.conditionType === "&&") {
            return a;
          } else {
            return {
              ...a,
              condition1: a?.conditionType,
              condition2: null,
              value2: null,
              value5: null,
            };
          }
        }
      );
      const payload = {
        ...values,
        uid: user?.userId,
        incentivePayInSlabsDto,
      };
      dispatch(setLoader(true));
      let res;
      if (props?.selectedData?.incPayInConfigId) {
        const configureId = props.selectedData.incPayInConfigId;
        res = await axios.put(
          `/updatePayInIncentiveConfiguration/${configureId}`,
          payload
        );
      } else {
        res = await axios.post("/addIncentivePayInConfiguration", payload);
      }
      dispatch(setLoader(false));
      if (res?.data?.messageKey) {
        props?.onSuccess();
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      } else {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({
        values,
        errors,
        touched,
        handleSubmit,
        setFieldValue,
        handleBlur,
        handleChange,
        isSubmitting,
      }) => {
        const err = Object.keys(errors)[0];
        scrollToErrorMessage(isSubmitting, err);
        return (
          <Form onSubmit={handleSubmit} autoComplete="off">
            <Row>
              <Col lg={4} md={4} sm={12}>
                <Field
                  isRequired
                  label="Payin Type"
                  errorMessage={touched?.incentiveType && errors?.incentiveType}
                >
                  <Select
                    name="incentiveType"
                    classNamePrefix="react-select"
                    menuPosition="fixed"
                    className={
                      touched?.incentiveType && errors?.incentiveType
                        ? "select-error"
                        : ""
                    }
                    isDisabled={isView}
                    value={incentiveTypeOptions?.filter(
                      (a) => a?.value === values?.incentiveType
                    )}
                    placeholder="Select an Option"
                    options={incentiveTypeOptions}
                    onChange={(e) => {
                      setFieldValue("incentiveType", e?.value);
                    }}
                    onBlur={handleBlur}
                  />
                </Field>
              </Col>
              <Col lg={4}>
                <Field
                  isRequired
                  label="Account Type"
                  errorMessage={
                    touched.accountCalculationType &&
                    errors.accountCalculationType
                  }
                >
                  <div className="input-container d-block">
                    <Select
                      id="accountCalculationType"
                      name="accountCalculationType"
                      inputId="accountCalculationType"
                      className={
                        touched.accountCalculationType &&
                        errors.accountCalculationType
                          ? "select-error"
                          : ""
                      }
                      isDisabled={isView}
                      placeholder="Select an Option"
                      closeMenuOnSelect={false}
                      hideSelectedOptions={false}
                      isMulti={false}
                      value={accountTypeOptions?.find(
                        (a) => a.value === values?.accountCalculationType
                      )}
                      menuPosition="fixed"
                      classNamePrefix="react-select"
                      options={[
                        { value: null, label: "Select None" },
                        ...accountTypeOptions,
                      ]}
                      onChange={(selectedOption) => {
                        const selectedValue = selectedOption
                          ? selectedOption.value
                          : null;
                        setFieldValue("accountCalculationType", selectedValue);
                      }}
                      onBlur={handleBlur}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4}>
                <Field
                  label="Portfolio"
                  errorMessage={touched?.portfolio && errors?.portfolio}
                >
                  <div className="input-container d-block">
                    <Select
                      id="portfolio"
                      inputId="portfolio"
                      placeholder="Select an Option"
                      options={
                        Array.isArray(portfolio)
                          ? portfolio.filter((option) => {
                              const selectedPortfolioTypes =
                                values?.portFolioType?.split(", ") || [];
                              if (values?.portFolioType === "Both") {
                                return !["Secured", "Unsecured"].includes(
                                  option.label
                                );
                              }
                              if (!selectedPortfolioTypesArray.length) {
                                if (
                                  selectedPortfolioTypes &&
                                  selectedPortfolioTypes.length > 0
                                ) {
                                  setSelectedPortfolioTypesArray(
                                    selectedPortfolioTypes
                                  );
                                }
                              }
                              if (
                                selectedPortfolioTypes.includes("Secured") &&
                                option.label === "Secured"
                              ) {
                                return false;
                              }
                              if (
                                selectedPortfolioTypes.includes("Unsecured") &&
                                option.label === "Unsecured"
                              ) {
                                return false;
                              }
                              return true;
                            })
                          : []
                      }
                      onChange={(selectedOptions) => {
                        if (Array.isArray(selectedOptions)) {
                          const selectedLabels = selectedOptions.map(
                            (option) => option.label
                          );
                          if (
                            selectedLabels.includes("Secured") &&
                            selectedLabels.includes("Unsecured")
                          ) {
                            setFieldValue("portFolioType", "Both");
                          } else {
                            const selectedPortfolioString =
                              selectedLabels.join(", ");
                            setFieldValue(
                              "portFolioType",
                              selectedPortfolioString
                            );
                          }
                          const selectedPortfolioValues = selectedOptions.map(
                            (option) => option.value
                          );
                          if (selectedPortfolioValues.length === 1) {
                            getProductByPortfolioId([
                              selectedPortfolioValues[0],
                            ]);
                          } else if (selectedPortfolioValues.length > 1) {
                            getProductByPortfolioId(["Secured", "Unsecured"]);
                          } else {
                            getProductByPortfolioId([]);
                          }
                        }
                      }}
                      classNamePrefix="react-select"
                      closeMenuOnSelect={false}
                      isDisabled={isView}
                      hideSelectedOptions={false}
                      value={
                        values?.portFolioType
                          ? values.portFolioType
                              .split(", ")
                              .map((label) => ({ label, value: label }))
                          : []
                      }
                      isClearable={true}
                      isMulti
                      onBlur={handleBlur}
                      menuPosition="fixed"
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4}>
                <Field label="Product">
                  <Select
                    options={[
                      { label: "Select All", value: "selectAll" }, // Add "Select All" option at the top
                      ...(Array.isArray(productList)
                        ? productList
                            .filter(
                              (product) =>
                                !values?.productResponseDtoData?.some(
                                  (selected) =>
                                    selected.productDescription ===
                                    product.label
                                )
                            )
                            .map((product) => ({
                              ...product, // Pass the remaining product attributes
                            }))
                        : []),
                    ]}
                    value={
                      values?.productResponseDtoData?.map((product) => ({
                        label: product.productDescription,
                        id: product.productId,
                        value: product.productCode,
                      })) || [] // Default empty array if no selected items
                    }
                    onChange={(selectedItems) => {
                      const items = Array.isArray(selectedItems)
                        ? selectedItems
                        : [selectedItems];
                      if (items.some((item) => item.value === "selectAll")) {
                        setFieldValue(
                          "productCode",
                          productList.map((product) => product.id) || []
                        );
                        setFieldValue(
                          "productResponseDtoData",
                          productList.map((product) => ({
                            productId: product.id,
                            productDescription: product.label,
                            productCode: product.value,
                          }))
                        );
                      } else {
                        setFieldValue(
                          "productCode",
                          items.map((item) => item.id) || []
                        );
                        const selectedProducts = items.map((product) => ({
                          productId: product.id,
                          productDescription: product.label,
                          productCode: product.value,
                        }));
                        setFieldValue(
                          "productResponseDtoData",
                          selectedProducts
                        );
                      }
                      setFieldValue("lan", []); // Reset 'lan' field
                    }}
                    classNamePrefix="react-select"
                    overrideStrings={{
                      selectSomeItems: "Select an Option",
                      allItemsAreSelected: "All Items Are Selected",
                      selectAll: "Select All",
                    }}
                    isDisabled={isView}
                    labelledBy={"Select"}
                    isCreatable={true}
                    isMulti
                  />
                </Field>
              </Col>
              <Col lg={4}>
                <Field
                  isRequired
                  label="Recovery Type"
                  errorMessage={touched.recoveryType && errors.recoveryType}
                >
                  <div className="input-container d-block">
                    <Select
                      id="recoveryType"
                      name="recoveryType"
                      inputId="recoveryType"
                      className={
                        touched.recoveryType && errors.recoveryType
                          ? "select-error"
                          : ""
                      }
                      placeholder="Select an Option"
                      closeMenuOnSelect={false}
                      hideSelectedOptions={false}
                      isMulti={false}
                      isDisabled={isView}
                      menuPosition="fixed"
                      classNamePrefix="react-select"
                      value={typeOfAmountOptions?.filter(
                        (a) => a?.value === values?.recoveryType
                      )}
                      options={[
                        { value: null, label: "Select None" },
                        ...typeOfAmountOptions,
                      ]}
                      onChange={(selectedOption) => {
                        const selectedValue = selectedOption
                          ? selectedOption.value
                          : "";
                        setFieldValue("recoveryType", selectedValue);
                      }}
                      onBlur={handleBlur}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4} md={4} sm={12}>
                <Field
                  isRequired
                  label="Scheme Code"
                  errorMessage={touched?.schemeCode && errors?.schemeCode}
                >
                  <div className="input-container">
                    <Input
                      bsSize="sm"
                      name="schemeCode"
                      value={values?.schemeCode}
                      className={
                        touched?.schemeCode && errors?.schemeCode
                          ? "select-error"
                          : ""
                      }
                      onChange={handleChange}
                      onBlur={handleBlur}
                      disabled={isView}
                      placeholder="Scheme Code"
                      style={{
                        paddingRight: "40px",
                      }}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4} md={4} sm={12}>
                <Field
                  isRequired
                  label="Scheme Description"
                  errorMessage={touched?.description && errors?.description}
                >
                  <div className="input-container">
                    <Input
                      bsSize="sm"
                      name="description"
                      value={values?.description}
                      className={
                        touched?.description && errors?.description
                          ? "select-error"
                          : ""
                      }
                      onChange={handleChange}
                      onBlur={handleBlur}
                      disabled={isView}
                      placeholder="Scheme Description"
                      style={{
                        paddingRight: "40px",
                      }}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4}>
                <Field
                  isRequired
                  label="Age Of NPA"
                  errorMessage={touched.ageOfNPA && errors.ageOfNPA}
                >
                  <div className="input-container d-block">
                    <Select
                      id="ageOfNPA"
                      name="ageOfNPA"
                      inputId="ageOfNPA"
                      className={
                        touched.ageOfNPA && errors.ageOfNPA
                          ? "select-error"
                          : ""
                      }
                      isDisabled={isView}
                      placeholder="Select an Option"
                      closeMenuOnSelect={false}
                      hideSelectedOptions={false}
                      isMulti={false}
                      menuPosition="fixed"
                      classNamePrefix="react-select"
                      options={[
                        { value: null, label: "Select None" },
                        ...ageNpaTypeOptions,
                      ]}
                      value={
                        ageNpaTypeOptions.find(
                          (option) => option.value === values.ageOfNPA
                        ) || null
                      }
                      onChange={(selectedOption) => {
                        const selectedValue = selectedOption
                          ? selectedOption.value
                          : "";
                        setFieldValue("ageOfNPA", selectedValue);
                      }}
                      onBlur={handleBlur}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4}>
                <Field
                  isRequired
                  label="Max Cap Secure"
                  errorMessage={touched.maximumCapSC && errors.maximumCapSC}
                >
                  <div className="input-container d-block">
                    <Select
                      id="maximumCapSC"
                      name="maximumCapSC"
                      inputId="maximumCapSC"
                      className={
                        touched.maximumCapSC && errors.maximumCapSC
                          ? "select-error"
                          : ""
                      }
                      isDisabled={isView}
                      placeholder="Select an Option"
                      closeMenuOnSelect={false}
                      hideSelectedOptions={false}
                      isMulti={false}
                      menuPosition="fixed"
                      classNamePrefix="react-select"
                      options={[
                        { value: null, label: "Select None" },
                        ...ageNpaTypeOptions,
                      ]}
                      value={
                        ageNpaTypeOptions.find(
                          (option) => option.value === values.maximumCapSC
                        ) || null
                      }
                      onChange={(selectedOption) => {
                        const selectedValue = selectedOption
                          ? selectedOption.value
                          : "";
                        setFieldValue("maximumCapSC", selectedValue);
                      }}
                      onBlur={handleBlur}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4}>
                <Field
                  isRequired
                  label="Max Cap Unsecure"
                  errorMessage={touched.maximumCapUSC && errors.maximumCapUSC}
                  style={{ maxWidth: "200px" }}
                >
                  <div className="input-container d-block">
                    <Select
                      id="maximumCapUSC"
                      name="maximumCapUSC"
                      inputId="maximumCapUSC"
                      className={
                        touched.maximumCapUSC && errors.maximumCapUSC
                          ? "select-error"
                          : ""
                      }
                      isDisabled={isView}
                      placeholder="Select an Option"
                      closeMenuOnSelect={false}
                      hideSelectedOptions={false}
                      isMulti={false}
                      menuPosition="fixed"
                      classNamePrefix="react-select"
                      options={[
                        { value: null, label: "Select None" },
                        ...ageNpaTypeOptions,
                      ]}
                      value={
                        ageNpaTypeOptions.find(
                          (option) => option.value === values.maximumCapUSC
                        ) || null
                      }
                      onChange={(selectedOption) => {
                        const selectedValue = selectedOption
                          ? selectedOption.value
                          : "";
                        setFieldValue("maximumCapUSC", selectedValue);
                      }}
                      onBlur={handleBlur}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4}>
                <Field
                  isRequired
                  label="Branch"
                  errorMessage={touched.branch && errors.branch}
                  style={{ maxWidth: "200px" }}
                >
                  <div className="input-container d-block">
                    <Select
                      id="branch"
                      name="branch"
                      inputId="branch"
                      className={
                        touched.branch && errors.branch ? "select-error" : ""
                      }
                      isDisabled={isView}
                      placeholder="Select an Option"
                      closeMenuOnSelect={false}
                      hideSelectedOptions={false}
                      isMulti={false}
                      menuPosition="fixed"
                      classNamePrefix="react-select"
                      options={[
                        { value: null, label: "Select None" },
                        ...ageNpaTypeOptions,
                      ]}
                      value={
                        ageNpaTypeOptions.find(
                          (option) => option.value === values.branch
                        ) || null
                      }
                      onChange={(selectedOption) => {
                        const selectedValue = selectedOption
                          ? selectedOption.value
                          : "";
                        setFieldValue("branch", selectedValue);
                      }}
                      onBlur={handleBlur}
                    />
                  </div>
                </Field>
              </Col>
              <Col lg={4} md={4} sm={12}>
                <Field
                  isRequired
                  label="Payin Grid"
                  errorMessage={touched?.gridDtoData && errors?.gridDtoData}
                >
                  <div className="input-container d-block">
                    <Select
                      isDisabled={isView}
                      name="gridDtoData"
                      placeholder="Select an Option"
                      options={[
                        { value: null, label: "Select None" },
                        ...payoutGridOptions,
                      ]}
                      className={
                        touched?.gridDtoData && errors?.gridDtoData
                          ? "select-error"
                          : ""
                      }
                      classNamePrefix="react-select"
                      menuPosition="fixed"
                      isMulti
                      value={
                        values?.gridDtoData?.map((item) => ({
                          value: item.gridType,
                          label: item.gridType,
                          value1: item.gridId || item.value1,
                        })) || []
                      }
                      onChange={(selectedOptions) => {
                        if (Array.isArray(selectedOptions)) {
                          const selectedGridTypes = selectedOptions.map(
                            (option) => ({
                              gridType: option.value,
                              gridId: option.value1 || option.gridId,
                            })
                          );
                          if (
                            selectedOptions.some(
                              (option) => option.value === null
                            )
                          ) {
                            setFieldValue("gridDtoData", []);
                          } else {
                            setFieldValue("gridDtoData", selectedGridTypes);
                          }
                        } else {
                          console.error(
                            "Selected options are not in the expected format",
                            selectedOptions
                          );
                        }
                      }}
                      onBlur={handleBlur}
                    />
                  </div>
                </Field>
              </Col>
              <Col>
                <Field label="Active">
                  <FormGroup switch className="ms-2">
                    <Input
                      type="switch"
                      name="active"
                      checked={values?.active}
                      onChange={(e) => {
                        setFieldValue("active", e?.target?.checked);
                      }}
                    />
                  </FormGroup>
                </Field>
              </Col>
            </Row>
            <Row></Row>
            <>
              <br />
              <Row>
                <p>Rule Condition</p>
                <DataTable
                  value={values?.incentivePayInSlabsDto}
                  className="commonTable"
                  style={headerStyle}
                >
                  <Column
                    header="Grid"
                    style={{ paddingTop: "15px" }}
                    headerClassName={styles?.mediumHeader}
                    body={(rowData, i) => {
                      const selectedGridTypes =
                        values?.gridDtoData?.map((item) => item.gridType) || [];
                      const filteredOptions = payoutGridOptions.filter(
                        (option) => selectedGridTypes.includes(option.value)
                      );
                      return (
                        <Select
                          name={`incentivePayInSlabsDto.${i?.rowIndex}.gridType`}
                          classNamePrefix="react-select selectField"
                          menuPosition="fixed"
                          isDisabled={isView}
                          value={
                            filteredOptions.find(
                              (option) =>
                                option.value ===
                                values?.incentivePayInSlabsDto[i?.rowIndex]
                                  ?.gridType
                            ) || null
                          }
                          options={filteredOptions} // Use the filtered options
                          onChange={(e) =>
                            setFieldValue(
                              `incentivePayInSlabsDto.${i?.rowIndex}.gridType`,
                              e?.value
                            )
                          }
                          onBlur={handleBlur}
                        />
                      );
                    }}
                    className="dynamic-column-2"
                  />
                  <Column
                    header="Condition"
                    headerClassName={styles?.mediumHeader}
                    body={(rowData, i) => (
                      <Select
                        name={`incentivePayInSlabsDto.${i?.rowIndex}.conditionType`}
                        classNamePrefix="react-select selectField"
                        menuPosition="fixed"
                        isDisabled={isView}
                        value={conditionOptions?.filter(
                          (a) =>
                            a?.value ===
                            values?.incentivePayInSlabsDto[i?.rowIndex]
                              ?.conditionType
                        )}
                        options={[
                          { label: "Select None", value: null },
                          ...conditionOptions,
                        ]}
                        onChange={(e) => {
                          const value = e?.value;
                          if (value === null) {
                            setFieldValue(
                              `incentivePayInSlabsDto.${i?.rowIndex}.conditionType`,
                              null
                            );
                          } else {
                            setFieldValue(
                              `incentivePayInSlabsDto.${i?.rowIndex}.conditionType`,
                              value
                            );
                          }
                        }}
                        onBlur={handleBlur}
                        className="dynamic-column-2"
                      />
                    )}
                  />
                  <Column
                    header="Value (% / Days)"
                    body={(rowData, i) => (
                      <div className={styles?.ruleValuesCol}>
                        {rowData?.conditionType === "&&" && (
                          <Select
                            name={`incentivePayInSlabsDto.${i?.rowIndex}.condition1`}
                            classNamePrefix="react-select selectField"
                            menuPosition="fixed"
                            isDisabled={isView}
                            value={condition1Options?.filter(
                              (a) =>
                                a?.value ===
                                values?.incentivePayInSlabsDto[i?.rowIndex]
                                  .condition1
                            )}
                            options={condition1Options}
                            onChange={(e) =>
                              setFieldValue(
                                `incentivePayInSlabsDto.${i?.rowIndex}.condition1`,
                                e?.value
                              )
                            }
                            onBlur={handleBlur}
                            className="dynamic-column"
                          />
                        )}
                        <div className="inputField">
                          <Input
                            className="form-align dynamic-column form-control"
                            name={`incentivePayInSlabsDto.${i?.rowIndex}.value1`}
                            value={
                              values?.incentivePayInSlabsDto[i?.rowIndex]
                                ?.value1
                            }
                            onChange={(e) => {
                              const isDecimal = e?.target?.value?.includes(".");
                              const afterDecimalCount = isDecimal
                                ? e.target.value.split(".")[1]?.length > 4
                                : false;
                              if (
                                (AMOUNT.test(e?.target?.value) ||
                                  !e?.target?.value) &&
                                !afterDecimalCount
                              ) {
                                setFieldValue(
                                  `incentivePayInSlabsDto.${i?.rowIndex}.value1`,
                                  e?.target?.value
                                );
                              }
                            }}
                            size="sm"
                            disabled={isView}
                          />
                        </div>
                        {rowData?.conditionType === "&&" && (
                          <>
                            <Select
                              name={`incentivePayInSlabsDto.${i?.rowIndex}.condition2`}
                              classNamePrefix="react-select selectField"
                              menuPosition="fixed"
                              isDisabled={isView}
                              value={condition2Options?.filter(
                                (a) =>
                                  a?.value ===
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    .condition2
                              )}
                              options={condition2Options}
                              onChange={(e) =>
                                setFieldValue(
                                  `incentivePayInSlabsDto.${i?.rowIndex}.condition2`,
                                  e?.value
                                )
                              }
                              onBlur={handleBlur}
                              className="dynamic-column"
                            />
                            <div className="inputField">
                              <Input
                                className="form-align dynamic-column form-control"
                                name={`incentivePayInSlabsDto.${i?.rowIndex}.value2`}
                                value={
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.value2
                                }
                                onChange={(e) => {
                                  const isDecimal =
                                    e?.target?.value?.includes(".");
                                  const afterDecimalCount = isDecimal
                                    ? e.target.value.split(".")[1]?.length > 4
                                    : false;
                                  if (
                                    (AMOUNT.test(e?.target?.value) ||
                                      !e?.target?.value) &&
                                    !afterDecimalCount
                                  ) {
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.value2`,
                                      e?.target?.value
                                    );
                                  }
                                }}
                                size="sm"
                                disabled={isView}
                              />
                            </div>
                          </>
                        )}
                      </div>
                    )}
                    className="dynamic-column"
                  />
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="DPD Condition - 1"
                      headerClassName={styles?.mediumHeader}
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <Select
                              name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType1`}
                              classNamePrefix="react-select selectField"
                              menuPosition="fixed"
                              isDisabled={isView}
                              value={conditionOptions?.find(
                                (a) =>
                                  a?.value ===
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.dpdConditionType1
                              )}
                              options={[
                                { label: "Select None", value: null },
                                ...conditionOptions,
                              ]}
                              onChange={(e) => {
                                const value = e?.value;
                                if (value === null) {
                                  setFieldValue(
                                    `incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType1`,
                                    null
                                  );
                                } else {
                                  setFieldValue(
                                    `incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType1`,
                                    value
                                  );
                                }
                              }}
                              onBlur={handleBlur}
                            />
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="Value (Days)"
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <div className={styles?.ruleValuesCol}>
                              {rowData?.dpdConditionType1 === "&&" && (
                                <Select
                                  name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition11`}
                                  classNamePrefix="react-select selectField"
                                  menuPosition="fixed"
                                  isDisabled={isView}
                                  value={condition1Options?.find(
                                    (a) =>
                                      a?.value ===
                                      values?.incentivePayInSlabsDto[
                                        i?.rowIndex
                                      ]?.dpdCondition11
                                  )}
                                  options={condition1Options}
                                  onChange={(e) =>
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition11`,
                                      e?.value
                                    )
                                  }
                                  onBlur={handleBlur}
                                  className="dynamic-column"
                                />
                              )}
                              <div className="inputField">
                                <Input
                                  className="form-align form-control dynamic-column"
                                  name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdValue11`}
                                  value={
                                    values?.incentivePayInSlabsDto[i?.rowIndex]
                                      ?.dpdValue11
                                  }
                                  onChange={(e) => {
                                    const isDecimal =
                                      e?.target?.value?.includes(".");
                                    const afterDecimalCount = isDecimal
                                      ? e.target.value.split(".")[1]?.length > 4
                                      : false;
                                    if (
                                      (AMOUNT.test(e?.target?.value) ||
                                        !e?.target?.value) &&
                                      !afterDecimalCount
                                    ) {
                                      setFieldValue(
                                        `incentivePayInSlabsDto.${i?.rowIndex}.dpdValue11`,
                                        e?.target?.value
                                      );
                                    }
                                  }}
                                  size="sm"
                                  disabled={isView}
                                />
                              </div>
                              {rowData?.dpdConditionType1 === "&&" && (
                                <>
                                  <Select
                                    name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition12`}
                                    classNamePrefix="react-select selectField"
                                    menuPosition="fixed"
                                    isDisabled={isView}
                                    value={condition2Options?.find(
                                      (a) =>
                                        a?.value ===
                                        values?.incentivePayInSlabsDto[
                                          i?.rowIndex
                                        ]?.dpdCondition12
                                    )}
                                    options={condition2Options}
                                    onChange={(e) =>
                                      setFieldValue(
                                        `incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition12`,
                                        e?.value
                                      )
                                    }
                                    onBlur={handleBlur}
                                    className="dynamic-column"
                                  />
                                  <div className="inputField">
                                    <Input
                                      className="form-align form-control dynamic-column"
                                      name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdValue12`}
                                      value={
                                        values?.incentivePayInSlabsDto[
                                          i?.rowIndex
                                        ]?.dpdValue12
                                      }
                                      onChange={(e) => {
                                        const isDecimal =
                                          e?.target?.value?.includes(".");
                                        const afterDecimalCount = isDecimal
                                          ? e.target.value.split(".")[1]
                                              ?.length > 4
                                          : false;
                                        if (
                                          (AMOUNT.test(e?.target?.value) ||
                                            !e?.target?.value) &&
                                          !afterDecimalCount
                                        ) {
                                          setFieldValue(
                                            `incentivePayInSlabsDto.${i?.rowIndex}.dpdValue12`,
                                            e?.target?.value
                                          );
                                        }
                                      }}
                                      size="sm"
                                      disabled={isView}
                                    />
                                  </div>
                                </>
                              )}
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="DPD Incentive %"
                      headerClassName={styles?.smallHeader}
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <div className="inputField">
                              <Input
                                className="form-align form-control"
                                value={
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.dpdInc1
                                }
                                onChange={(e) => {
                                  const isDecimal =
                                    e?.target?.value?.includes(".");
                                  const afterDecimalCount = isDecimal
                                    ? e.target.value.split(".")[1]?.length > 4
                                    : false;
                                  if (
                                    (AMOUNT.test(e?.target?.value) ||
                                      !e?.target?.value) &&
                                    !afterDecimalCount
                                  ) {
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.dpdInc1`,
                                      e?.target?.value
                                    );
                                  }
                                }}
                                size="sm"
                                disabled={isView}
                              />
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="DPD Condition - 2"
                      headerClassName={styles?.mediumHeader}
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <Select
                              name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType2`}
                              classNamePrefix="react-select selectField"
                              menuPosition="fixed"
                              isDisabled={isView}
                              value={conditionOptions?.find(
                                (a) =>
                                  a?.value ===
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.dpdConditionType2
                              )}
                              options={[
                                { label: "Select None", value: null },
                                ...conditionOptions,
                              ]}
                              onChange={(e) => {
                                const value = e?.value;
                                if (value === null) {
                                  setFieldValue(
                                    `incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType2`,
                                    null
                                  );
                                } else {
                                  setFieldValue(
                                    `incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType2`,
                                    value
                                  );
                                }
                              }}
                              onBlur={handleBlur}
                            />
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="Value (Days)"
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <div className={styles?.ruleValuesCol}>
                              {rowData?.dpdConditionType2 === "&&" && (
                                <Select
                                  name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition21`}
                                  classNamePrefix="react-select selectField"
                                  menuPosition="fixed"
                                  isDisabled={isView}
                                  value={condition1Options?.find(
                                    (a) =>
                                      a?.value ===
                                      values?.incentivePayInSlabsDto[
                                        i?.rowIndex
                                      ]?.dpdCondition21
                                  )}
                                  options={condition1Options}
                                  onChange={(e) =>
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition21`,
                                      e?.value
                                    )
                                  }
                                  onBlur={handleBlur}
                                  className="dynamic-column"
                                />
                              )}
                              <div className="inputField">
                                <Input
                                  className="form-align form-control dynamic-column"
                                  name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdValue21`}
                                  value={
                                    values?.incentivePayInSlabsDto[i?.rowIndex]
                                      ?.dpdValue21
                                  }
                                  onChange={(e) => {
                                    const isDecimal =
                                      e?.target?.value?.includes(".");
                                    const afterDecimalCount = isDecimal
                                      ? e.target.value.split(".")[1]?.length > 4
                                      : false;
                                    if (
                                      (AMOUNT.test(e?.target?.value) ||
                                        !e?.target?.value) &&
                                      !afterDecimalCount
                                    ) {
                                      setFieldValue(
                                        `incentivePayInSlabsDto.${i?.rowIndex}.dpdValue21`,
                                        e?.target?.value
                                      );
                                    }
                                  }}
                                  size="sm"
                                  disabled={isView}
                                />
                              </div>
                              {rowData?.dpdConditionType2 === "&&" && (
                                <>
                                  <Select
                                    name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition22`}
                                    classNamePrefix="react-select selectField"
                                    menuPosition="fixed"
                                    isDisabled={isView}
                                    value={condition2Options?.find(
                                      (a) =>
                                        a?.value ===
                                        values?.incentivePayInSlabsDto[
                                          i?.rowIndex
                                        ]?.dpdCondition22
                                    )}
                                    options={condition2Options}
                                    onChange={(e) =>
                                      setFieldValue(
                                        `incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition22`,
                                        e?.value
                                      )
                                    }
                                    onBlur={handleBlur}
                                    className="dynamic-column"
                                  />
                                  <div className="inputField">
                                    <Input
                                      className="form-align form-control dynamic-column"
                                      name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdValue22`}
                                      value={
                                        values?.incentivePayInSlabsDto[
                                          i?.rowIndex
                                        ]?.dpdValue22
                                      }
                                      onChange={(e) => {
                                        const isDecimal =
                                          e?.target?.value?.includes(".");
                                        const afterDecimalCount = isDecimal
                                          ? e.target.value.split(".")[1]
                                              ?.length > 4
                                          : false;
                                        if (
                                          (AMOUNT.test(e?.target?.value) ||
                                            !e?.target?.value) &&
                                          !afterDecimalCount
                                        ) {
                                          setFieldValue(
                                            `incentivePayInSlabsDto.${i?.rowIndex}.dpdValue22`,
                                            e?.target?.value
                                          );
                                        }
                                      }}
                                      size="sm"
                                      disabled={isView}
                                    />
                                  </div>
                                </>
                              )}
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="DPD - 2 Incentive %"
                      headerClassName={styles?.smallHeader}
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <div className="inputField">
                              <Input
                                className="form-align form-control"
                                value={
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.dpdInc2
                                }
                                onChange={(e) => {
                                  const isDecimal =
                                    e?.target?.value?.includes(".");
                                  const afterDecimalCount = isDecimal
                                    ? e.target.value.split(".")[1]?.length > 4
                                    : false;
                                  if (
                                    (AMOUNT.test(e?.target?.value) ||
                                      !e?.target?.value) &&
                                    !afterDecimalCount
                                  ) {
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.dpdInc2`,
                                      e?.target?.value
                                    );
                                  }
                                }}
                                size="sm"
                                disabled={isView}
                              />
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="DPD Condition - 3"
                      headerClassName={styles?.mediumHeader}
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <Select
                              name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType3`}
                              classNamePrefix="react-select selectField"
                              menuPosition="fixed"
                              isDisabled={isView}
                              value={conditionOptions?.find(
                                (a) =>
                                  a?.value ===
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.dpdConditionType3
                              )}
                              options={[
                                { label: "Select None", value: null },
                                ...conditionOptions,
                              ]}
                              onChange={(e) => {
                                const value = e?.value;
                                if (value === null) {
                                  setFieldValue(
                                    `incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType3`,
                                    null
                                  );
                                } else {
                                  setFieldValue(
                                    `incentivePayInSlabsDto.${i?.rowIndex}.dpdConditionType3`,
                                    value
                                  );
                                }
                              }}
                              onBlur={handleBlur}
                            />
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="Value (Days)"
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <div className={styles?.ruleValuesCol}>
                              {rowData?.dpdConditionType3 === "&&" && (
                                <Select
                                  name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition31`}
                                  classNamePrefix="react-select selectField"
                                  menuPosition="fixed"
                                  isDisabled={isView}
                                  value={condition1Options?.find(
                                    (a) =>
                                      a?.value ===
                                      values?.incentivePayInSlabsDto[
                                        i?.rowIndex
                                      ]?.dpdCondition31
                                  )}
                                  options={condition1Options}
                                  onChange={(e) =>
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition31`,
                                      e?.value
                                    )
                                  }
                                  onBlur={handleBlur}
                                  className="dynamic-column"
                                />
                              )}
                              <div className="inputField">
                                <Input
                                  className="form-align form-control dynamic-column"
                                  name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdValue31`}
                                  value={
                                    values?.incentivePayInSlabsDto[i?.rowIndex]
                                      ?.dpdValue31
                                  }
                                  onChange={(e) => {
                                    const isDecimal =
                                      e?.target?.value?.includes(".");
                                    const afterDecimalCount = isDecimal
                                      ? e.target.value.split(".")[1]?.length > 4
                                      : false;
                                    if (
                                      (AMOUNT.test(e?.target?.value) ||
                                        !e?.target?.value) &&
                                      !afterDecimalCount
                                    ) {
                                      setFieldValue(
                                        `incentivePayInSlabsDto.${i?.rowIndex}.dpdValue31`,
                                        e?.target?.value
                                      );
                                    }
                                  }}
                                  size="sm"
                                  disabled={isView}
                                />
                              </div>
                              {rowData?.dpdConditionType3 === "&&" && (
                                <>
                                  <Select
                                    name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition32`}
                                    classNamePrefix="react-select selectField"
                                    menuPosition="fixed"
                                    isDisabled={isView}
                                    value={condition2Options?.find(
                                      (a) =>
                                        a?.value ===
                                        values?.incentivePayInSlabsDto[
                                          i?.rowIndex
                                        ]?.dpdCondition32
                                    )}
                                    options={condition2Options}
                                    onChange={(e) =>
                                      setFieldValue(
                                        `incentivePayInSlabsDto.${i?.rowIndex}.dpdCondition32`,
                                        e?.value
                                      )
                                    }
                                    onBlur={handleBlur}
                                    className="dynamic-column"
                                  />
                                  <div className="inputField">
                                    <Input
                                      className="form-align form-control dynamic-column"
                                      name={`incentivePayInSlabsDto.${i?.rowIndex}.dpdValue32`}
                                      value={
                                        values?.incentivePayInSlabsDto[
                                          i?.rowIndex
                                        ]?.dpdValue32
                                      }
                                      onChange={(e) => {
                                        const isDecimal =
                                          e?.target?.value?.includes(".");
                                        const afterDecimalCount = isDecimal
                                          ? e.target.value.split(".")[1]
                                              ?.length > 4
                                          : false;
                                        if (
                                          (AMOUNT.test(e?.target?.value) ||
                                            !e?.target?.value) &&
                                          !afterDecimalCount
                                        ) {
                                          setFieldValue(
                                            `incentivePayInSlabsDto.${i?.rowIndex}.dpdValue32`,
                                            e?.target?.value
                                          );
                                        }
                                      }}
                                      size="sm"
                                      disabled={isView}
                                    />
                                  </div>
                                </>
                              )}
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header=" DPD - 3 Incentive %"
                      headerClassName={styles?.smallHeader}
                      body={(rowData, i) => {
                        if (rowData?.gridType === "DPD/ROR") {
                          return (
                            <div className="inputField">
                              <Input
                                className="form-align form-control"
                                value={
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.dpdInc3
                                }
                                onChange={(e) => {
                                  const isDecimal =
                                    e?.target?.value?.includes(".");
                                  const afterDecimalCount = isDecimal
                                    ? e.target.value.split(".")[1]?.length > 4
                                    : false;
                                  if (
                                    (AMOUNT.test(e?.target?.value) ||
                                      !e?.target?.value) &&
                                    !afterDecimalCount
                                  ) {
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.dpdInc3`,
                                      e?.target?.value
                                    );
                                  }
                                }}
                                size="sm"
                                disabled={isView}
                              />
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) =>
                      rowData?.gridType === "DPD" ||
                      rowData?.gridType === "ROR" ||
                      rowData?.gridType === "MutuallyAgreed" ||
                      rowData?.gridType === "PenalInterest" ||
                      rowData?.gridType === "pos_SC_Settlment/Closure" ||
                      rowData?.gridType === "POS" ||
                      rowData?.gridType === "pos_USC" ||
                      rowData?.gridType === "EMI" ||
                      rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="Slab Categories"
                      headerClassName={styles?.mediumHeader}
                      style={paddedColumnStyle}
                      body={(rowData, i) => {
                        if (
                          rowData?.gridType === "DPD" ||
                          rowData?.gridType === "ROR" ||
                          rowData?.gridType === "MutuallyAgreed" ||
                          rowData?.gridType === "PenalInterest" ||
                          rowData?.gridType === "pos_SC_Settlment/Closure" ||
                          rowData?.gridType === "POS" ||
                          rowData?.gridType === "pos_USC" ||
                          rowData?.gridType === "EMI" ||
                          rowData?.gridType === "DPD/ROR"
                        ) {
                          return (
                            <>
                              <select
                                name={`incentivePayInSlabsDto.${i?.rowIndex}.slabCategory`}
                                value={
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.slabCategory
                                }
                                className="form-align form-control"
                                onChange={(e) => {
                                  handleChange(e);
                                  setFieldValue(
                                    `incentivePayInSlabsDto.${i?.rowIndex}.slabCategory`,
                                    e.target.value
                                  );
                                }}
                                onBlur={handleBlur}
                                disabled={isView}
                              >
                                <option value="">Select Category</option>
                                <option value="Field">Field</option>
                                <option value="Calling">Calling</option>
                                <option value="USC">Unsecured</option>
                                <option value="SC">Secured</option>
                                <option value="Settlement/Foreclosure">
                                  Settlement/Foreclosure
                                </option>
                                <option value="EMI">EMI</option>
                                <option value="Partial">Partial</option>
                                <option value="Microfinance">
                                  Microfinance
                                </option>
                                <option value="SMT-PL">SMT-PL</option>
                                <option value="PL-Salaried">PL-Salaried</option>
                                <option value="PL">PL</option>
                                <option value="CV">CV</option>
                                <option value="VL">VL</option>
                                <option value="HL">HL</option>
                                <option value="BL">BL</option>
                                <option value="MortgageLoans">
                                  MortgageLoans
                                </option>
                                <option value="Retail/SME">Retail/SME</option>
                              </select>
                            </>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) =>
                      rowData?.gridType === "DPD" ||
                      rowData?.gridType === "ROR" ||
                      rowData?.gridType === "MutuallyAgreed" ||
                      rowData?.gridType === "PenalInterest" ||
                      rowData?.gridType === "pos_SC_Settlment/Closure" ||
                      rowData?.gridType === "POS" ||
                      rowData?.gridType === "pos_USC" ||
                      rowData?.gridType === "EMI"
                  ) && (
                    <Column
                      header="Secured Value"
                      headerClassName={styles?.mediumHeader}
                      style={{ padding: "0.2rem 1rem" }}
                      body={(rowData, i) => {
                        if (
                          rowData?.gridType === "DPD" ||
                          rowData?.gridType === "ROR" ||
                          rowData?.gridType === "MutuallyAgreed" ||
                          rowData?.gridType === "PenalInterest" ||
                          rowData?.gridType === "pos_SC_Settlment/Closure" ||
                          rowData?.gridType === "POS" ||
                          rowData?.gridType === "pos_USC" ||
                          rowData?.gridType === "EMI"
                        ) {
                          return (
                            <Input
                              bsSize="sm"
                              name={`incentivePayInSlabsDto.${i?.rowIndex}.securedValue`}
                              value={
                                values?.incentivePayInSlabsDto[i?.rowIndex]
                                  ?.securedValue
                              }
                              className="form-align form-control"
                              onChange={(e) => {
                                handleChange(e);
                                setFieldValue(
                                  `incentivePayInSlabsDto.${i?.rowIndex}.securedValue`,
                                  e.target.value
                                );
                              }}
                              onBlur={handleBlur}
                              disabled={isView}
                              placeholder="Secured Value"
                            />
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) =>
                      rowData?.gridType === "DPD" ||
                      rowData?.gridType === "ROR" ||
                      rowData?.gridType === "PenalInterest" ||
                      rowData?.gridType === "MutuallyAgreed" ||
                      rowData?.gridType === "pos_SC_Settlment/Closure" ||
                      rowData?.gridType === "POS" ||
                      rowData?.gridType === "pos_USC" ||
                      rowData?.gridType === "EMI"
                  ) && (
                    <Column
                      header="Unsecured Value"
                      headerClassName={styles?.mediumHeader}
                      style={{ padding: "0.2rem 1rem" }}
                      body={(rowData, i) => {
                        if (
                          rowData?.gridType === "DPD" ||
                          rowData?.gridType === "ROR" ||
                          rowData?.gridType === "PenalInterest" ||
                          rowData?.gridType === "MutuallyAgreed" ||
                          rowData?.gridType === "pos_SC_Settlment/Closure" ||
                          rowData?.gridType === "POS" ||
                          rowData?.gridType === "pos_USC" ||
                          rowData?.gridType === "EMI"
                        ) {
                          return (
                            <Input
                              bsSize="sm"
                              name={`incentivePayInSlabsDto.${i?.rowIndex}.unSecuredValue`}
                              value={
                                values?.incentivePayInSlabsDto[i?.rowIndex]
                                  ?.unSecuredValue
                              }
                              className="form-align form-control"
                              onChange={(e) => {
                                handleChange(e);
                                setFieldValue(
                                  `incentivePayInSlabsDto.${i?.rowIndex}.unSecuredValue`,
                                  e.target.value
                                );
                              }}
                              onBlur={handleBlur}
                              disabled={isView}
                              placeholder="Unsecured Value"
                            />
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) =>
                      rowData?.gridType === "ROR" ||
                      rowData?.gridType === "POS" ||
                      rowData?.gridType === "DPD/ROR"
                  ) && (
                    <Column
                      header="Incentive %"
                      headerClassName={styles?.smallHeader}
                      body={(rowData, i) => {
                        if (
                          rowData?.gridType === "ROR" ||
                          rowData?.gridType === "POS" ||
                          rowData?.gridType === "DPD/ROR"
                        ) {
                          return (
                            <div className="inputField">
                              <Input
                                className="form-align form-control"
                                value={
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.payInPercent
                                }
                                onChange={(e) => {
                                  const isDecimal =
                                    e?.target?.value?.includes(".");
                                  const afterDecimalCount = isDecimal
                                    ? e.target.value.split(".")[1]?.length > 4
                                    : false;
                                  if (
                                    (AMOUNT.test(e?.target?.value) ||
                                      !e?.target?.value) &&
                                    !afterDecimalCount
                                  ) {
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.payInPercent`,
                                      e?.target?.value
                                    );
                                  }
                                }}
                                size="sm"
                                disabled={isView}
                              />
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {values?.incentivePayInSlabsDto.some(
                    (rowData) => rowData?.gridType === "POS"
                  ) && (
                    <Column
                      header="Extra Incentive Amount"
                      headerClassName={styles?.smallHeader}
                      body={(rowData, i) => {
                        if (rowData?.gridType === "POS") {
                          return (
                            <div className="inputField">
                              <Input
                                className="form-align form-control"
                                name={`incentivePayInSlabsDto.${i?.rowIndex}.extraIncentiveAmount`}
                                value={
                                  values?.incentivePayInSlabsDto[i?.rowIndex]
                                    ?.extraIncentiveAmount
                                }
                                onChange={(e) => {
                                  const isDecimal =
                                    e?.target?.value?.includes(".");
                                  const afterDecimalCount = isDecimal
                                    ? e.target.value.split(".")[1]?.length > 4
                                    : false;
                                  if (
                                    (AMOUNT.test(e?.target?.value) ||
                                      !e?.target?.value) &&
                                    !afterDecimalCount
                                  ) {
                                    setFieldValue(
                                      `incentivePayInSlabsDto.${i?.rowIndex}.extraIncentiveAmount`,
                                      e?.target?.value
                                    );
                                  }
                                }}
                                size="sm"
                                disabled={isView}
                              />
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  )}
                  {!isView && (
                    <Column
                      header="Action"
                      headerClassName={styles?.smallHeader}
                      body={(rowData, i) => (
                        <div className={styles?.ruleActionButtonContainer}>
                          <Button
                            size="sm"
                            type="button"
                            color="danger"
                            style={{ marginLeft: "10px" }}
                            className={styles?.ruleActionButton}
                            onClick={() => {
                              if (values?.incentivePayInSlabsDto?.length > 1) {
                                let duplicateValues =
                                  values?.incentivePayInSlabsDto;
                                duplicateValues.splice(i?.rowIndex, 1);
                                setFieldValue(
                                  "incentivePayInSlabsDto",
                                  duplicateValues
                                );
                              }
                            }}
                          >
                            -
                          </Button>
                          <Button
                            size="sm"
                            type="button"
                            className={styles?.ruleActionButton}
                            color="success"
                            onClick={() => {
                              setFieldValue("incentivePayInSlabsDto", [
                                ...values?.incentivePayInSlabsDto,
                                ruleBodyRow,
                              ]);
                            }}
                            style={{ color: "#fff" }}
                          >
                            +
                          </Button>
                        </div>
                      )}
                    />
                  )}
                </DataTable>
              </Row>
              {!isView && (
                <div
                  className={styles?.formButtonGrp}
                  style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: "10px",
                  }}
                >
                  <Button
                    size="sm"
                    type="button"
                    onClick={props?.onClose}
                    style={{
                      padding: "8px 16px",
                      fontSize: "14px",
                      borderRadius: "5px",
                      backgroundColor: "#f0f0f0",
                      color: "#333",
                      border: "1px solid #ddd",
                      transition: "background-color 0.3s ease",
                    }}
                    onMouseEnter={(e) =>
                      (e.target.style.backgroundColor = "#e0e0e0")
                    }
                    onMouseLeave={(e) =>
                      (e.target.style.backgroundColor = "#f0f0f0")
                    }
                  >
                    Close
                  </Button>
                  <Button
                    size="sm"
                    type="submit"
                    color="primary"
                    style={{
                      padding: "8px 16px",
                      fontSize: "14px",
                      borderRadius: "5px",
                      backgroundColor: "#007bff",
                      color: "white",
                      border: "none",
                      transition: "background-color 0.3s ease",
                    }}
                    onMouseEnter={(e) =>
                      (e.target.style.backgroundColor = "#0056b3")
                    }
                    onMouseLeave={(e) =>
                      (e.target.style.backgroundColor = "#007bff")
                    }
                  >
                    Save
                  </Button>
                </div>
              )}
            </>
          </Form>
        );
      }}
    </Formik>
  );
};
export default memo(ConfigurationForm);