import { useEffect, useState } from "react";
import { CardBody, Card, ButtonGroup, CardHeader } from "reactstrap";
import { Dialog } from "primereact/dialog";
import Swal from "sweetalert2";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import axios from "axios";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";
import SearchBarHeader from "../../components/Header/SearchBarHeader";
import LenderConfigurationForm from "./LenderConfigurationForm";
const UpdateLender = () => {
  const [configData, setConfigData] = useState([]);
  const [visible, setVisible] = useState(false);
  const [formType, setFormType] = useState("");
  const [datas, setDatas] = useState([]);
  const [selectedData, setSelectedData] = useState({});
  const getAllIncentiveConfigration = async (val) => {
    try {
      const url = val
        ? `/getAllLenderConfigurationData/${val}`
        : "/getAllLenderConfigurationData";
      dispatch(setLoader(true));
      const res = await axios.get(url);
      dispatch(setLoader(false));
      setDatas(res.data.response);
    } catch (error) {
      dispatch(setLoader(false));
    }
  };
  useEffect(() => {
    getAllIncentiveConfigration();
  }, []);
  useEffect(() => {}, [datas]);
  const onHandleAction = async (btnType, rowData) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `/getLenderConfigurationById/${rowData?.lenderConfigId}`
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey) {
        setVisible(true);
        setFormType(btnType);
        setSelectedData(res?.data?.response);
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onCreateClick = () => {
    setVisible(true);
    setFormType("Create");
    setSelectedData({});
  };
  const onCloseForm = () => {
    setVisible(false);
    setFormType("");
    setSelectedData({});
  };
  const onSuccess = () => {
    getAllIncentiveConfigration();
    onCloseForm();
  };
  const dispatch = useDispatch();
  const configureSlabData = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllPayInIncentiveConfiguration");
      dispatch(setLoader(false));
      const lenders =
        res.data.response?.map((data) => ({
          schemeCode: data.schemeCode,
          incPayInConfigId: data.incPayInConfigId,
        })) || [];
      setConfigData(lenders);
    } catch (error) {
      dispatch(setLoader(false));
      console.error(error);
    }
  };
  useEffect(() => {
    configureSlabData();
  }, []);
  useEffect(() => {
    configureSlabData();
  }, []);
  return (
    <>
      <SearchBarHeader
        permission={true}
        onClick={onCreateClick}
        getAllAPI={getAllIncentiveConfigration}
        serachAPI={getAllIncentiveConfigration}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2"> Configuration Detailed </CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={datas}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="lenderConfigId" header="Configure Id" />
            <Column field="lenderName" header="Lender Name" />
            <Column field="schemeCode" header="Scheme Code" />
            <Column field="shortName" header="Short Name" />
            <Column
              body={(rowData) => (
                <ButtonGroup>
                  <i
                    className="bi bi-eye-fill text-primary"
                    style={{ cursor: "pointer" }}
                    onClick={() => onHandleAction("View", rowData)}
                  ></i>
                  <i
                    className="bi bi-pencil-square text-danger"
                    style={{ cursor: "pointer" }}
                    onClick={() => onHandleAction("Edit", rowData)}
                  ></i>
                </ButtonGroup>
              )}
              header="Actions"
            />
          </DataTable>
        </CardBody>
      </Card>
      {visible && (
        <Dialog
          header={`${formType} Incentive Configuration`}
          visible={visible}
          onHide={onCloseForm}
          style={{
            width: "80vw",
          }}
        >
          <LenderConfigurationForm
            onClose={onCloseForm}
            formType={formType}
            selectedData={selectedData}
            onSuccess={onSuccess}
            // roleOptions={roleOptions}
            // agencyOptions={agencyOptions}
          />
        </Dialog>
      )}
    </>
  );
};
export default UpdateLender;
