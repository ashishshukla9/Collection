import { memo, useEffect, useMemo, useState } from "react";
import styles from "./Calculation.module.scss";
import CalculationGraph from "./CalculationGraph";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import axios from "axios";
import Swal from "sweetalert2";
import { Input } from "reactstrap";
import { useDispatch } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";
const CalculationDetails = (props) => {
  const { data } = props;
  const [first, setFirst] = useState(0); // To manage the starting index of the current page
  const rowsPerPage = 10;
  const [decendentUsers, setDecendentUsers] = useState(data?.decendentUsers);
  const [search, setSearch] = useState("");
  const overallTotalPercentage = useMemo(
    () =>
      (data?.total?.totalCollectedAmount / data?.total?.totalAllocatedPos) *
      100,
    [data]
  );
  const ownTotalPercentage = useMemo(
    () =>
      (data?.ownTotal?.totalCollectedAmount /
        data?.ownTotal?.totalAllocatedPos) *
      100,
    [data]
  );
  const teamTotalPercentage = useMemo(
    () =>
      (data?.allocatedTotal?.totalCollectedAmount /
        data?.allocatedTotal?.totalAllocatedPos) *
      100,
    [data]
  );
  const dispatch = useDispatch();
  const onClickUser = async (singleData) => {
    dispatch(setLoader(true));
    try {
      const params = props?.params;
      const res = await axios.get(
        `/getIncentivePayInCalculationByUserId/${singleData?.userId}`,
        { params }
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey) {
        props?.onSuccess(res?.data?.response, singleData);
      } else {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onSearchUser = (e) => {
    setSearch(e?.target?.value);
  };
  useEffect(() => {
    const searchAPI = setTimeout(() => {
      const api = async () => {
        if (search.length) {
          try {
            const params = props?.params;
            dispatch(setLoader(true));
            const res = await axios.get(
              `/getDecenderListBySearch/${data?.id}/${search}`,
              { params }
            );
            dispatch(setLoader(false));
            if (res?.data?.messageKey && Array.isArray(res?.data?.response)) {
              setDecendentUsers(res.data.response);
            } else {
              console.error("Invalid response format:", res.data);
            }
          } catch (error) {
            dispatch(setLoader(false));
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } else {
          if (Array.isArray(data?.decendentUsers)) {
            setDecendentUsers([...data.decendentUsers]);
          } else {
            console.error(
              "data?.decendentUsers is not an array:",
              data?.decendentUsers
            );
          }
        }
      };
      api();
    }, 1000);
    return () => {
      clearTimeout(searchAPI);
    };
  }, [search]);
  useEffect(() => {
    setDecendentUsers(data?.decendentUsers);
  }, [data?.decendentUsers]);
  return (
    <div className={styles?.box} key={data?.id}>
      <div className={styles?.graphContainer}>
        {decendentUsers?.length > 0 && overallTotalPercentage ? (
          <CalculationGraph
            graphType="Doughnut"
            header="Overall Total"
            percentage={data.ownLenderIncentives[0].ror}
            amountDetails={data?.total}
            data={{
              labels: ["Collected Amount", "Not Collected Amount"],
              datasets: [
                {
                  data: [overallTotalPercentage, 100 - overallTotalPercentage],
                  backgroundColor: ["rgb(54, 162, 235)", "#d3d3d3"],
                  hoverOffset: 4,
                },
              ],
            }}
          />
        ) : (
          ""
        )}
        {Object.keys(data?.ownTotal)?.length > 0 && ownTotalPercentage ? (
          <CalculationGraph
            className="bg-white p-3 mt-5 rounded"
            graphType="Doughnut"
            header={data?.ownLenderIncentives[0].lenderName}
            percentage={data.ownLenderIncentives[0].ror}
            amountDetails={data?.ownTotal}
            data={{
              labels: ["Collected Amount", "Not Collected Amount"],
              datasets: [
                {
                  data: [
                    data.ownLenderIncentives[0].ror,
                    100 - data.ownLenderIncentives[0].ror,
                  ],
                  backgroundColor: ["rgb(54, 162, 235)", "#d3d3d3"],
                  hoverOffset: 4,
                },
              ],
            }}
          />
        ) : (
          ""
        )}
        {decendentUsers?.length > 0 && teamTotalPercentage ? (
          <CalculationGraph
            graphType="Doughnut"
            header="Team Total"
            percentage={teamTotalPercentage}
            amountDetails={data?.allocatedTotal}
            data={{
              labels: ["Collected Amount", "Not Collected Amount"],
              datasets: [
                {
                  data: [teamTotalPercentage, 100 - teamTotalPercentage],
                  backgroundColor: ["rgb(54, 162, 235)", "#d3d3d3"],
                  hoverOffset: 4,
                },
              ],
            }}
          />
        ) : (
          ""
        )}
      </div>
      {data?.ownLenderIncentives?.length > 0 && (
        <DataTable
          value={data?.ownLenderIncentives}
          header="Lender Incentives"
          size={"small"}
          removableSort
          className="d-flex flex-column flex-grow-1 casesTable"
          paginator // Enables pagination
          rows={rowsPerPage} // Number of rows per page
          first={first} // The starting index for the current page
          onPage={(e) => setFirst(e.first)} // Event handler to update the current page index
          totalRecords={data?.ownLenderIncentives.length} // Total number of records for pagination
        >
          <Column
            header="Loan Account No"
            body={(rowData) => {
              const lan = rowData?.lan;
              return (
                <span>
                  {lan === "null" || lan === null || lan === "" ? "-" : lan}
                </span>
              );
            }}
            field="lan"
          />
          <Column
            header="Allocated POS"
            body={(rowData) => {
              const allocatedPos = rowData?.allocatedPos;
              const formattedAmount = Number(allocatedPos).toLocaleString();
              return <span>₹ {formattedAmount}</span>;
            }}
            field="allocatedPos"
          />
          <Column
            header="Collected Amount"
            body={(rowData) => {
              const collectedAmount = rowData?.collectedAmount;
              const formattedAmount = Number(collectedAmount).toLocaleString();
              return <span>₹ {formattedAmount}</span>;
            }}
            field="collectedAmount"
          />
          <Column
            header="Incentive Amount"
            body={(rowData) => {
              const incentiveAmount = rowData?.incentiveAmount;
              const formattedAmount = Number(incentiveAmount).toLocaleString();
              return <span>₹ {formattedAmount}</span>;
            }}
            field="incentiveAmount"
          />
          <Column
            header="Incentive Slab"
            body={(rowData) => {
              return (
                <span>
                  {rowData?.incentiveSlab?.toString()?.includes(".")
                    ? rowData?.incentiveSlab?.toFixed(2)
                    : rowData?.incentiveSlab}
                  %
                </span>
              );
            }}
            field="incentiveSlab"
          />
          <Column
            header="Slab Category"
            body={(rowData) => {
              const slabCategory = rowData?.slabCategory;
              return (
                <span>
                  {slabCategory === "null" ||
                  slabCategory === null ||
                  slabCategory === ""
                    ? "-"
                    : slabCategory?.toString()?.includes(".")
                    ? slabCategory?.toFixed(2)
                    : slabCategory}
                </span>
              );
            }}
            field="slabCategory"
          />
          <Column
            header="Product"
            body={(rowData) => {
              const product = rowData?.product;
              return (
                <span>
                  {product === "null" || product === null || product === ""
                    ? "-"
                    : product?.toString()?.includes(".")
                    ? product?.toFixed(2)
                    : product}
                </span>
              );
            }}
            field="product"
          />
          {data?.ownLenderIncentives[0]?.ror !== 0 &&
            data?.ownLenderIncentives[0]?.ror !== null &&
            data?.ownLenderIncentives[0]?.ror !== undefined && (
              <Column
                header="ROR"
                body={(rowData) => {
                  const rorString = rowData?.ror?.toString();
                  return (
                    <span>
                      {rorString?.includes(".")
                        ? rowData?.ror?.toFixed(4)
                        : rowData?.ror}
                      %
                    </span>
                  );
                }}
                field="ror"
              />
            )}
          {data?.ownLenderIncentives[0]?.totalDaysForDPD !== 0 &&
            data?.ownLenderIncentives[0]?.totalDaysForDPD !== null &&
            data?.ownLenderIncentives[0]?.totalDaysForDPD !== undefined && (
              <Column
                header="DPD"
                body={(rowData) => {
                  const rorString = rowData?.totalDaysForDPD?.toString();
                  return (
                    <span>
                      {rorString?.includes(".")
                        ? rowData?.totalDaysForDPD?.toFixed(2)
                        : rowData?.totalDaysForDPD}{" "}
                      Days
                    </span>
                  );
                }}
                field="totalDaysForDPD"
              />
            )}
        </DataTable>
      )}
      {data?.allocatedLenderIncentives?.length > 0 && (
        <DataTable
          value={data?.ownLenderIncentives}
          header="Lender Incentives"
          size={"small"}
          removableSort
          className="d-flex flex-column flex-grow-1 casesTable"
          paginator // Enable pagination
          rows={10} // Number of rows per page
          rowsPerPageOptions={[5, 10, 25, 50]} // Options for number of rows per page
          currentPageReportTemplate="Showing {first} to {last} of {totalRecords}" // Pagination report
          pageLinkSize={5} // Number of page links to display
        >
          <Column
            header="Loan Account No"
            body={(rowData) => {
              const lan = rowData?.lan;
              return (
                <span>
                  {lan === "null" || lan === null || lan === "" ? "-" : lan}
                </span>
              );
            }}
            field="lan"
          />
          <Column
            header="Allocated POS"
            body={(rowData) => {
              const allocatedPos = rowData?.allocatedPos;
              const formattedAmount = Number(allocatedPos).toLocaleString();
              return <span>₹ {formattedAmount}</span>;
            }}
            field="allocatedPos"
          />
          <Column
            header="Collected Amount"
            body={(rowData) => {
              const collectedAmount = rowData?.collectedAmount;
              const formattedAmount = Number(collectedAmount).toLocaleString();
              return <span>₹ {formattedAmount}</span>;
            }}
            field="collectedAmount"
          />
          <Column
            header="Incentive Amount"
            body={(rowData) => {
              const incentiveAmount = rowData?.incentiveAmount;
              const formattedAmount = Number(incentiveAmount).toLocaleString();
              return <span>₹ {formattedAmount}</span>;
            }}
            field="incentiveAmount"
          />
          <Column
            header="Incentive Slab"
            body={(rowData) => {
              return (
                <span>
                  {rowData?.incentiveSlab?.toString()?.includes(".")
                    ? rowData?.incentiveSlab?.toFixed(2)
                    : rowData?.incentiveSlab}{" "}
                  %
                </span>
              );
            }}
            field="incentiveSlab"
          />
          <Column
            header="Slab Category"
            body={(rowData) => {
              const slabCategory = rowData?.slabCategory;
              return (
                <span>
                  {slabCategory === "null" ||
                  slabCategory === null ||
                  slabCategory === ""
                    ? "-"
                    : slabCategory?.toString()?.includes(".")
                    ? slabCategory?.toFixed(2)
                    : slabCategory}
                </span>
              );
            }}
            field="slabCategory"
          />
          <Column
            header="Product"
            body={(rowData) => {
              const product = rowData?.product;
              return (
                <span>
                  {product === "null" || product === null || product === ""
                    ? "-"
                    : product?.toString()?.includes(".")
                    ? product?.toFixed(2)
                    : product}
                </span>
              );
            }}
            field="product"
          />
          {data?.ownLenderIncentives[0]?.ror !== 0 &&
            data?.ownLenderIncentives[0]?.ror !== null &&
            data?.ownLenderIncentives[0]?.ror !== undefined && (
              <Column
                header="ROR"
                body={(rowData) => {
                  const rorString = rowData?.ror?.toString();
                  return (
                    <span>
                      {rorString?.includes(".")
                        ? rowData?.ror?.toFixed(4)
                        : rowData?.ror}{" "}
                      %
                    </span>
                  );
                }}
                field="ror"
              />
            )}
          {data?.ownLenderIncentives[0]?.totalDaysForDPD !== 0 &&
            data?.ownLenderIncentives[0]?.totalDaysForDPD !== null &&
            data?.ownLenderIncentives[0]?.totalDaysForDPD !== undefined && (
              <Column
                header="DPD"
                body={(rowData) => {
                  const rorString = rowData?.totalDaysForDPD?.toString();
                  return (
                    <span>
                      {rorString?.includes(".")
                        ? rowData?.totalDaysForDPD?.toFixed(2)
                        : rowData?.totalDaysForDPD}{" "}
                      Days
                    </span>
                  );
                }}
                field="totalDaysForDPD"
              />
            )}
        </DataTable>
      )}
      {decendentUsers?.length > 0 && (
        <div className={styles?.tableContainer}>
          <div className={styles?.headerContainer}>
            <p className={styles?.header}>Decendent Users</p>
            <Input
              type="text"
              size={"sm"}
              onChange={onSearchUser}
              placeholder="search"
              className={styles?.searchBox}
              value={search}
            />
          </div>
          <div className={styles?.tableData}>
            {decendentUsers?.map((a, i) => {
              return (
                <span>
                  {i + 1}.
                  <span
                    className={styles?.userName}
                    onClick={() => onClickUser(a)}
                  >
                    {a?.firstName} {a?.lastName}
                  </span>
                </span>
              );
            })}
          </div>
        </div>
      )}
      {!props?.lastIndex && <hr></hr>}
    </div>
  );
};
export default memo(CalculationDetails);