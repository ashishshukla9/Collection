import { memo, useMemo } from "react";
import { Doughnut, Pie } from "react-chartjs-2";
import styles from "./Calculation.module.scss";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  Colors,
  CategoryScale,
  registerables,
} from "chart.js";
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  Colors,
  CategoryScale,
  ...registerables
);
const CalculationGraph = (props) => {
  const options = useMemo(() => {
    return {
      responsive: true,
      plugins: {
        legend: {
          display: true,
          position: "bottom",
          align: "start",
        },
      },
    };
  }, []);
  const graph = (data, graphType) => {
    switch (graphType) {
      case "Doughnut":
        return (
          <Doughnut
            data={data}
            options={{ ...options, rotation: 270, circumference: 180 }}
            className={styles?.chart}
          />
        );
        break;
      default:
        break;
    }
  };
  const formatAmount = (amount) => {
    if (amount !== null && amount !== undefined) {
      return Number(amount).toLocaleString();
    }
    return "0";
  };
  return (
    <div className={styles?.graphBox}>
      <p className={styles?.header}>{props?.header}</p>
      {props?.amountDetails?.totalAllocatedPos !== null &&
        props?.amountDetails?.totalAllocatedPos !== undefined &&
        props?.amountDetails?.totalAllocatedPos !== "" && (
          <p className={styles?.amountDetails}>
            Total Allocated POS:{" "}
            <b>
              ₹{" "}
              {props?.amountDetails?.totalAllocatedPos
                ? formatAmount(props?.amountDetails?.totalAllocatedPos)
                : "0"}
            </b>
          </p>
        )}
      <p className={styles?.amountDetails}>
        Total Collected Amount:{" "}
        <b>
          ₹{" "}
          {props?.amountDetails?.totalCollectedAmount
            ? formatAmount(props?.amountDetails?.totalCollectedAmount)
            : "0"}
        </b>
      </p>
      <p className={styles?.amountDetails}>
        Slab For Total Account:{" "}
        <b>
          {props?.amountDetails?.slabForTotalAccount?.toString()?.includes(".")
            ? props?.amountDetails?.slabForTotalAccount?.toFixed(2)
            : props?.amountDetails?.slabForTotalAccount}
          %
        </b>
      </p>
      <p className="text-center">Total Incentive Amount</p>
      <p className={styles?.percentage}>
        <b>
          ₹{" "}
          {props?.amountDetails?.totalIncentiveAmount
            ? formatAmount(props?.amountDetails?.totalIncentiveAmount)
            : "0"}
        </b>
      </p>
      {graph(props?.data, props?.graphType)}
    </div>
  );
};
export default memo(CalculationGraph);