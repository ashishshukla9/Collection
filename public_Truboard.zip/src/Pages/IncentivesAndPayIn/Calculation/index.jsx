import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  Colors,
  CategoryScale,
  registerables,
} from "chart.js";
import styles from "./Calculation.module.scss";
import { Input } from "reactstrap";
import { Formik } from "formik";
import Field from "../../../components/Field";
import {
  AccordionBody,
  AccordionHeader,
  AccordionItem,
  Button,
  ButtonGroup,
  Form,
  UncontrolledAccordion,
} from "reactstrap";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import Select from "react-select";
import { useMemo, useEffect, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import * as yup from "yup";
import CalculationDetails from "./CalculationDetails";
import { setLoader } from "../../../reducer/globalReducer";
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  Colors,
  CategoryScale,
  ...registerables
);
const Index = () => {
  const [data, setData] = useState([]);
  const [selectedLender, setSelectedLender] = useState(null);
  const [isFormCleared, setIsFormCleared] = useState(false);
  const [selectedBranchCode, setSelectedBranchCode] = useState(null);
  const [branchCodeOptions, setBranchCodeOptions] = useState([]);
  const [splitBranchCode, setSplitBranchCode] = useState([]);
  const [productOptions, setProductOptions] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState([]);
  const [showMutuallyAgreedField, setShowMutuallyAgreedField] = useState(false);
  const [showNewSelect, setShowNewSelect] = useState(false);
  const [showInputBox, setShowInputBox] = useState(false);
  const [selectedSubCategory, setSelectedSubCategory] = useState(null);
  const [paramsObj, setParamsObj] = useState({});
  const [showLoanAccountField, setShowLoanAccountField] = useState(false);
  const [selectedLoanAccount, setSelectedLoanAccount] = useState(null);
  const [schemeOptions, setSchemeOptions] = useState([]); // To store scheme codes
  const [portFolioTypeOptions, setPortFolioTypeOptions] = useState([]);
  const [selectedPortfolioType, setSelectedPortfolioType] = useState(null);
  const [selectedScheme, setSelectedScheme] = useState(null);
  const [loanAccounts, setLoanAccounts] = useState([]);
  const [lenderOptions, setLenderOptions] = useState([]);
  const [branchIdOptions, setBranchIdOptions] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [selectedMutuallyAgreed, setSelectedMutuallyAgreed] = useState(null);
  const [maximumCapSC, setMaximumCapSC] = useState(null);
  const [maximumCapUSC, setMaximumCapUSC] = useState(null);
  const [branchStatus, setBranchStatus] = useState(false);
  const user = useSelector((state) => state.user.data);
  const dispatch = useDispatch();
  const selectAllOption = {
    label: "Select All",
    value: "selectAll",
  };
  const optionsWithSelectAll = [selectAllOption, ...productOptions];
  const reportTypeOptions = useMemo(() => [
    { value: "yearly", label: "Yearly" },
    { value: "quarterly", label: "Quarterly" },
    { value: "monthly", label: "Monthly" },
  ]);
  const handleMutuallyAgreedChange = (selectedOption) => {
    setSelectedMutuallyAgreed(selectedOption || null);
  };
  const dayOptions = useMemo(() => {
    const days = [];
    for (let i = 1; i <= 31; i++) {
      days.push({ value: i, label: i.toString() });
    }
    return days;
  }, []);
  const monthOptions = useMemo(
    () => [
      { value: 1, label: "January" },
      { value: 2, label: "February" },
      { value: 3, label: "March" },
      { value: 4, label: "April" },
      { value: 5, label: "May" },
      { value: 6, label: "June" },
      { value: 7, label: "July" },
      { value: 8, label: "August" },
      { value: 9, label: "September" },
      { value: 10, label: "October" },
      { value: 11, label: "November" },
      { value: 12, label: "December" },
    ],
    []
  );
  const quarterlyOptions = useMemo(() => [
    { value: 4, label: "Quarter 1" },
    { value: 7, label: "Quarter 2" },
    { value: 10, label: "Quarter 3" },
    { value: 1, label: "Quarter 4" },
  ]);
  const mutuallyOptions = useMemo(
    () => [
      { value: "Active", label: "Active" },
      { value: "Deactive", label: "Deactive" },
    ],
    []
  );
  const yearOptions = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const finalYear = [];
    for (let index = currentYear; 2000 <= index; index--) {
      finalYear.push({
        label: index,
        value: index,
      });
    }
    return finalYear;
  });
  const initialValues = {
    year: "",
    month: "",
    reportType: "",
  };
  const getLenderList = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getActiveLenderList");
      dispatch(setLoader(false));
      const lenders =
        res.data.data?.map((data) => ({
          label: data.lenderName,
          value: data.lenderId,
        })) || [];
      setLenderOptions(lenders);
    } catch (error) {
      dispatch(setLoader(false));
      console.error(error);
    }
  };
  useEffect(() => {
    getLenderList();
  }, []);
  const getLenderConfiguration = async (lenderId) => {
    if (!lenderId) return;
    try {
      dispatch(setLoader(true));
      const res = await axios.get(
        `/getLenderConfigurationBylenderId/${lenderId}`
      );
      dispatch(setLoader(false));
      const schemes =
        res.data.response?.map((config) => {
          return {
            label: config.schemeCode,
            value: config.schemeCode,
            accountCalculationType: config.accountCalculationType,
            maximumCapSC: config.maximumCapSC,
            branchStatus: config.branchStatus,
            maximumCapUSC: config.maximumCapUSC,
            configId: config.incPayInConfigId,
            portFolioType: config.portFolioType,
            productResponseDto: config.productResponseDto,
            slabGridType: config.slabGridType,
          };
        }) || [];
      setSchemeOptions(schemes);
      const branchCodes =
        res.data.response?.flatMap((config) => config.branchCode) || [];
      const uniqueBranchCodes = [...new Set(branchCodes)];
      setBranchIdOptions(
        uniqueBranchCodes.map((branch) => ({
          label: branch,
          value: branch,
        }))
      );
    } catch (error) {
      dispatch(setLoader(false));
      console.error("Error fetching lender configuration:", error);
    }
  };
  useEffect(() => {
    getLenderList();
  }, []);
  useEffect(() => {}, [loanAccounts]);
  const fetchLoanAccounts = async (lenderId, schemeCode) => {
    if (!lenderId || !schemeCode) return;
    try {
      dispatch(setLoader(true));
      const response = await axios.get(
        `/getListOfLanByLenderId/${lenderId}?schemeCode=${schemeCode}`
      );
      dispatch(setLoader(false));
      setLoanAccounts(response.data.response);
    } catch (error) {
      dispatch(setLoader(false));
      console.error("Error fetching loan accounts:", error);
    }
  };
  const handleLenderChange = (selectedOption) => {
    const lenderId = selectedOption ? selectedOption.value : null;
    setSelectedLender(lenderId);
    setSelectedBranchId(null);
    setSelectedScheme(null);
    getLenderConfiguration(lenderId);
  };
  const handleSchemeChange = (selectedOption) => {
    const schemeCode = selectedOption ? selectedOption.value : null;
    setSelectedScheme(schemeCode);
    const selectedSchemeConfig = schemeOptions.find(
      (scheme) => scheme.value === schemeCode
    );
    if (selectedSchemeConfig) {
      const {
        accountCalculationType,
        configId,
        portFolioType,
        branchStatus: brnch,
        maximumCapSC: capSC,
        maximumCapUSC: capUSC,
        productResponseDto,
        slabGridType,
      } = selectedSchemeConfig;
      setShowMutuallyAgreedField(slabGridType.includes("MutuallyAgreed"));
      setMaximumCapSC(capSC === "Active");
      setMaximumCapUSC(capUSC === "Active");

      setBranchStatus(brnch === "Active");
      if (
        accountCalculationType === "PerAccount" ||
        accountCalculationType === "Both"
      ) {
        setShowLoanAccountField(true);
        fetchLoanAccounts(selectedLender, schemeCode);
      } else {
        setShowLoanAccountField(false);
      }
      if (configId) {
        fetchBranchCodes(configId);
      }
      if (portFolioType) {
        setPortFolioTypeOptions([portFolioType]);
      } else {
        setPortFolioTypeOptions([]);
      }
      if (productResponseDto && productResponseDto.length > 0) {
        setProductOptions(
          productResponseDto.map((product) => ({
            label: product.productCode,
            value: product.productCode,
          }))
        );
      } else {
        setProductOptions([]);
      }
    } else {
      console.log("Selected scheme config not found.");
    }
  };
  const handleProductChange = (selectedOptions) => {
    if (
      selectedOptions &&
      selectedOptions.some((option) => option.value === "selectAll")
    ) {
      setSelectedProduct(productOptions.map((option) => option.value));
    } else {
      const selectedValues = selectedOptions
        ? selectedOptions.map((option) => option.value)
        : [];
      setSelectedProduct(selectedValues);
    }
  };
  const handlePortfolioTypeChange = (selectedOption) => {
    setSelectedPortfolioType(selectedOption);
  };
  const handleBranchIdChange = (selectedOption) => {
    const branchCode = selectedOption ? selectedOption.value : null;
    setSelectedBranchId(branchCode);
  };
  const fetchBranchCodes = async (configId) => {
    try {
      const response = await axios.get(
        `getListOfSlabCategoryByPayInConfigId/${configId}`
      );
      const branchCodeOptions = response?.data?.response
        ?.map((item, index) => {
          if (item) {
            return {
              label: item,
              value: item,
            };
          }
          return null;
        })
        .filter(Boolean);
      setBranchCodeOptions(branchCodeOptions);
    } catch (error) {
      console.error("Error fetching branch codes:", error);
    }
  };
  const handleBranchCodeChange = (selectedOption) => {
    const branchCode = selectedOption ? selectedOption.value : null;
    setSelectedBranchCode(branchCode);
    if (branchCode && branchCode.includes("/")) {
      const splitValues = branchCode.split("/");
      setSplitBranchCode(splitValues);
      setShowInputBox(false);
      setShowNewSelect(true);
    } else {
      setSplitBranchCode([]);
      setShowNewSelect(false);
      setShowInputBox(false);
    }
  };
  const handleSubCategoryChange = (selectedOption) => {
    const subCategory = selectedOption ? selectedOption.value : null;
    setSelectedSubCategory(subCategory);
  };
  const handleLoanAccountChange = (selectedOption) => {
    const loanAccountNumber = selectedOption ? selectedOption.value : null;
    setSelectedLoanAccount(loanAccountNumber);
  };
  const validationSchema = yup.object().shape({
    schemeCode: yup.string().required("Scheme Code is required"),
    portFolioType: yup.string().when("schemeCode", {
      is: "Unsecured",
      then: yup.string().required("Portfolio Type is required"),
    }),
    productCode: yup.string().when("portFolioType", {
      is: "Unsecured",
      then: yup.string().required("Product Code is required"),
    }),
    year: yup.mixed().required("This field is required."),
    month: yup.mixed().when("reportType", {
      is: (reportType) =>
        reportType?.value !== "yearly" && reportType?.value !== "quarterly",
      then: () => yup.mixed().required("This field is required"),
    }),
    reportType: yup.mixed().required("This field is required."),
  });
  const handleSubmit = async (values) => {
    dispatch(setLoader(true));
    try {
      const params = {
        month:
          values?.reportType?.value === "yearly"
            ? 0
            : values?.reportType?.value === "quarterly"
            ? values?.quarter?.value
            : values?.month?.value,
        year: values?.year?.value,
        reportType: values?.reportType?.value,
        mutuallyAgreed: selectedMutuallyAgreed?.value ?? null,
        schemeCode: selectedScheme || null,
        productCode: selectedProduct || null,
        maxCapForSC: values.maxCapForSC || 0.0,
        maxCapForUSC: values.maxCapForUSC || 0.0,
        slabCategory:
          showNewSelect && splitBranchCode.length > 0 && selectedSubCategory
            ? selectedSubCategory
            : selectedBranchCode || "null",
        branchCode: selectedBranchId || "null",
        dates: values?.day?.label || 0,
        lan: selectedLoanAccount || "null",
        portFolioType: selectedPortfolioType?.value || null,
      };
      setParamsObj(params);
      const queryString = new URLSearchParams();
      Object.keys(params).forEach((key) => {
        const value = params[key];
        if (value !== undefined) {
          queryString.append(key, value === null ? "null" : value);
        }
      });
      const url = `/getIncentivePayInCalculationByLenderId/${selectedLender}`;
      const res = await axios.get(url, { params: queryString });
      dispatch(setLoader(false));
      if (res?.data?.messageKey) {
        setData([{ ...res?.data?.response, id: user?.userId }]);
      } else {
        setData([]);
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onSuccess = (apiRes, selectedUser, i) => {
    const obj = {
      ...apiRes,
      id: selectedUser?.userId,
      name: `${selectedUser?.firstName} ${selectedUser?.lastName}`,
    };
    const duplicateData = data;
    duplicateData.splice(i + 1, duplicateData.length, obj);
    setData([...duplicateData]);
  };
  const handleClear = () => {
    setData([]);
    setParamsObj({});
  };
  return (
    <div
      style={{ backgroundColor: "#fff", borderRadius: "5px" }}
      className={styles?.pageContainer}
    >
      <Formik initialValues={initialValues} onSubmit={handleSubmit}>
        {({
          values,
          errors,
          handleBlur,
          touched,
          handleSubmit,
          setFieldValue,
          isSubmitting,
          resetForm,
        }) => {
          const err = Object.keys(errors)[0];
          scrollToErrorMessage(isSubmitting, err);
          return (
            <Form onSubmit={handleSubmit}>
              <div className="row">
                <div className="col-lg-3 col-md-4 col-sm-6">
                  <Field
                    name="lender"
                    isRequired
                    label="Lender"
                    containerClassName={styles?.fieldContainer}
                  >
                    <Select
                      name="lender"
                      placeholder="Select an Option"
                      bsSize="sm"
                      isClearable={true}
                      options={lenderOptions}
                      closeMenuOnSelect={true}
                      onBlur={handleBlur}
                      onChange={(selectedOption) =>
                        handleLenderChange(selectedOption)
                      }
                      value={
                        lenderOptions.find(
                          (option) => option.value === selectedLender
                        ) || null
                      }
                      required
                    />
                  </Field>
                </div>

                {selectedLender && schemeOptions.length > 0 && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field
                      isRequired
                      label="Scheme Code"
                      containerClassName={styles?.fieldContainer}
                    >
                      <Select
                        name="schemeCode"
                        bsSize="sm"
                        placeholder="Select an Option"
                        isClearable={true}
                        options={schemeOptions}
                        closeMenuOnSelect={true}
                        onChange={handleSchemeChange}
                        value={
                          schemeOptions.find(
                            (option) => option.value === selectedScheme
                          ) || null
                        }
                        required
                      />
                    </Field>
                  </div>
                )}
                {branchStatus && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field
                      isRequired
                      label="Branch Name"
                      containerClassName={styles?.fieldContainer}
                    >
                      <Select
                        name="branchCode"
                        placeholder="Select an Option"
                        bsSize="sm"
                        isClearable={true}
                        options={branchIdOptions}
                        closeMenuOnSelect={true}
                        onChange={handleBranchIdChange}
                        value={
                          branchIdOptions.find(
                            (option) => option.value === selectedBranchId
                          ) || null
                        }
                        required
                      />
                    </Field>
                  </div>
                )}
                {maximumCapSC && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field
                      isRequired
                      label="Max Cap Secure"
                      errorMessage={touched?.maxCapForSC && errors?.maxCapForSC}
                    >
                      <div className="input-container">
                        <Input
                          name="maxCapForSC"
                          value={values?.maxCapForSC || ""}
                          maxLength={19}
                          placeholder="Maximum Cap Secure"
                          onBlur={handleBlur}
                          onChange={(e) => {
                            const value = e.target.value.replace(/[^0-9]/g, "");
                            setFieldValue("maxCapForSC", value);
                          }}
                          className={`${
                            touched?.maxCapForSC && errors?.maxCapForSC
                              ? "select-error"
                              : ""
                          } input-field`}
                          required
                        />
                      </div>
                    </Field>
                  </div>
                )}
                {maximumCapUSC && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field
                      isRequired
                      label="Max Cap Unsecure"
                      errorMessage={
                        touched?.maxCapForUSC && errors?.maxCapForUSC
                      }
                    >
                      <div className="input-container">
                        <Input
                          name="maxCapForUSC"
                          value={values?.maxCapForUSC || ""}
                          maxLength={19}
                          placeholder="Maximum Cap Unsecure"
                          onBlur={handleBlur}
                          onChange={(e) => {
                            const value = e.target.value.replace(
                              /[^0-9.]/g,
                              ""
                            );
                            const dotCount = (value.match(/\./g) || []).length;
                            if (dotCount <= 1) {
                              setFieldValue("maxCapForUSC", value);
                            }
                          }}
                          className={`${
                            touched?.maxCapForUSC && errors?.maxCapForUSC
                              ? "select-error"
                              : ""
                          } input-field`}
                          required
                        />
                      </div>
                    </Field>
                  </div>
                )}
                {selectedScheme && portFolioTypeOptions.length > 0 && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field
                      isRequired
                      label="Portfolio Type"
                      containerClassName={styles?.fieldContainer}
                    >
                      <Select
                        name="portFolioType"
                        bsSize="sm"
                        placeholder="Select an Option"
                        isClearable={true}
                        options={portFolioTypeOptions.map((type) => ({
                          label: type,
                          value: type,
                        }))}
                        closeMenuOnSelect={true}
                        onChange={handlePortfolioTypeChange}
                        required
                      />
                    </Field>
                  </div>
                )}
                {selectedLender && branchCodeOptions.length > 0 && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field isRequired label="Slab Category">
                      <Select
                        name="branchCode"
                        bsSize="sm"
                        isClearable={true}
                        options={branchCodeOptions}
                        closeMenuOnSelect={true}
                        onChange={handleBranchCodeChange}
                        value={
                          branchCodeOptions.find(
                            (option) => option.value === selectedBranchCode
                          ) || null
                        }
                        required
                      />
                    </Field>
                  </div>
                )}
                {showNewSelect && splitBranchCode.length > 0 && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field label="Sub Category">
                      <Select
                        name="subCategory"
                        bsSize="sm"
                        placeholder="Select an Option"
                        options={splitBranchCode.map((item) => ({
                          label: item,
                          value: item,
                        }))}
                        onChange={handleSubCategoryChange}
                      />
                    </Field>
                  </div>
                )}
                {selectedLender && productOptions.length > 0 && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field
                      isRequired
                      label="Product Code"
                      containerClassName={styles?.fieldContainer}
                    >
                      <Select
                        name="productCode"
                        bsSize="sm"
                        placeholder="Select an Option"
                        isClearable={true}
                        options={optionsWithSelectAll}
                        closeMenuOnSelect={false} // false to allow multiple selections
                        onChange={handleProductChange}
                        value={
                          Array.isArray(selectedProduct) &&
                          selectedProduct.length > 0
                            ? productOptions.filter((option) =>
                                selectedProduct.includes(option.value)
                              )
                            : []
                        }
                        required
                        isMulti
                      />
                    </Field>
                  </div>
                )}
                {selectedLender && showInputBox && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field label="Slab Name">
                      <div className="input-container d-block">
                        <input
                          type="text"
                          id="slabName"
                          className="form-align form-control"
                          name="slabName"
                          value={values.slabCategory || ""}
                          onChange={(e) =>
                            setFieldValue("slabCategory", e.target.value)
                          }
                          onBlur={handleBlur}
                          placeholder="Enter Slab Name"
                        />
                      </div>
                    </Field>
                  </div>
                )}
                <div className="col-lg-3 col-md-4 col-sm-6">
                  <Field
                    isRequired
                    label="Report Types"
                    containerClassName={styles?.fieldContainer}
                    errorMessage={touched?.reportType && errors?.reportType}
                  >
                    <Select
                      name="reportType"
                      bsSize="sm"
                      placeholder="Select an Option"
                      isClearable={true}
                      options={reportTypeOptions}
                      closeMenuOnSelect={true}
                      onChange={(e) => setFieldValue("reportType", e || "")}
                      onBlur={handleBlur}
                      menuPosition={"fixed"}
                      classNamePrefix="react-select"
                      value={values?.reportType}
                      required
                    />
                  </Field>
                </div>
                {values?.reportType?.value !== "yearly" &&
                  values?.reportType?.value !== "quarterly" && (
                    <div
                      className="col-lg-3 col-md-4 col-sm-6"
                      style={{
                        display: values?.reportType?.value ? "block" : "none",
                      }}
                    >
                      <Field
                        isRequired
                        label="Month"
                        containerClassName={styles?.fieldContainer}
                        errorMessage={touched?.month && errors?.month}
                      >
                        <Select
                          name="month"
                          bsSize="sm"
                          isClearable={true}
                          placeholder="Select an Option"
                          options={monthOptions}
                          closeMenuOnSelect={true}
                          onChange={(e) => setFieldValue("month", e || "")}
                          onBlur={handleBlur}
                          menuPosition={"fixed"}
                          classNamePrefix="react-select"
                          value={values?.month}
                          required
                        />
                      </Field>
                    </div>
                  )}
                {values?.reportType?.value !== "yearly" &&
                  values?.reportType?.value !== "monthly" && (
                    <div
                      className="col-lg-3 col-md-4 col-sm-6"
                      style={{
                        display: values?.reportType?.value ? "block" : "none",
                      }}
                    >
                      <Field
                        isRequired
                        label="Quarter"
                        containerClassName={styles?.fieldContainer}
                        errorMessage={touched?.quarter && errors?.quarter}
                      >
                        <Select
                          name="quarter"
                          bsSize="sm"
                          placeholder="Select an Option"
                          isClearable={true}
                          options={quarterlyOptions}
                          closeMenuOnSelect={true}
                          onChange={(e) => setFieldValue("quarter", e || "")}
                          onBlur={handleBlur}
                          menuPosition={"fixed"}
                          classNamePrefix="react-select"
                          value={values?.quarter}
                          required
                        />
                      </Field>
                    </div>
                  )}
                {values?.reportType?.value === "monthly" && (
                  <div
                    className="col-lg-3 col-md-4 col-sm-6"
                    style={{
                      display: values?.reportType?.value ? "block" : "none",
                    }}
                  >
                    <Field
                      label="Day"
                      containerClassName={styles?.fieldContainer}
                      errorMessage={touched?.day && errors?.day}
                    >
                      <Select
                        name="day"
                        bsSize="sm"
                        placeholder="Select an Option"
                        isClearable={true}
                        options={dayOptions}
                        closeMenuOnSelect={true}
                        onChange={(e) => setFieldValue("day", e || "")}
                        onBlur={handleBlur}
                        menuPosition={"fixed"}
                        classNamePrefix="react-select"
                        value={values?.day}
                      />
                    </Field>
                  </div>
                )}
                <div
                  className="col-lg-3 col-md-4 col-sm-6"
                  style={{
                    display: values?.reportType?.value ? "block" : "none",
                  }}
                >
                  <Field
                    isRequired
                    label="Year"
                    containerClassName={styles?.fieldContainer}
                    errorMessage={touched?.year && errors?.year}
                  >
                    <Select
                      name="year"
                      bsSize="sm"
                      placeholder="Select an Option"
                      isClearable={true}
                      options={yearOptions}
                      closeMenuOnSelect={true}
                      onChange={(e) => setFieldValue("year", e)}
                      onBlur={handleBlur}
                      menuPosition={"fixed"}
                      classNamePrefix="react-select"
                      value={values?.year}
                      required
                    />
                  </Field>
                </div>
                {showMutuallyAgreedField && (
                  <div className="col-lg-3 col-md-4 col-sm-6">
                    <Field
                      label="Mutually Agreed"
                      containerClassName={styles?.fieldContainer}
                      errorMessage={touched?.quarter && errors?.quarter}
                    >
                      <Select
                        options={mutuallyOptions} // Populate mutuallyOptions with actual values
                        placeholder="Select an Option"
                        value={selectedMutuallyAgreed}
                        onChange={handleMutuallyAgreedChange}
                      />
                    </Field>
                  </div>
                )}
              </div>
              <div className="col-lg-3 col-md-3 col-sm-6 px-3 mt-2 align-self-end">
                <ButtonGroup
                  className={`${styles?.btnGrp}  d-flex justify-content-between align-items-center`}
                >
                  <Button
                    type="submit"
                    size="sm"
                    color="primary"
                    className={`${styles.filterBtn} ${
                      touched?.year && errors?.year && styles?.filterBtnError
                    }`}
                    style={{ marginRight: "10px" }}
                    disabled={isSubmitting}
                  >
                    Filter
                  </Button>
                  <Button
                    type="reset"
                    size="sm"
                    color="danger"
                    className={`${styles.filterBtn} ${
                      touched?.year && errors?.year && styles?.filterBtnError
                    }`}
                    onClick={() => {
                      resetForm();
                      setSelectedLender(null);
                      setSelectedMutuallyAgreed(null);
                      setSelectedProduct(null);
                      setSelectedBranchId(null);
                      setSelectedScheme(null);
                      setSelectedBranchCode(null);
                      setSelectedSubCategory(null);
                      setShowNewSelect(false);
                      setShowInputBox(false);
                      setMaximumCapSC(false);
                      setBranchStatus(false);
                      setMaximumCapUSC(false);
                      setShowLoanAccountField(false);
                      setShowMutuallyAgreedField(false);
                      setIsFormCleared(true);
                      setData([]);
                      setParamsObj({});
                    }}
                  >
                    Clear
                  </Button>
                </ButtonGroup>
              </div>
            </Form>
          );
        }}
      </Formik>
      <UncontrolledAccordion stayOpen>
        <div className={styles?.detailsContainer}>
          {data?.length > 0 ? (
            data.map((a, i) => {
              if (i === 0) {
                return (
                  <CalculationDetails
                    key={i}
                    data={a}
                    params={paramsObj}
                    onSuccess={(apiRes, selectedUser) =>
                      onSuccess(apiRes, selectedUser, i)
                    }
                    userIds={data?.map((a) => a?.id)}
                    lastIndex={data?.length === i + 1}
                  />
                );
              } else {
                return (
                  <AccordionItem key={i}>
                    <AccordionHeader targetId={i.toString()}>
                      <div className={styles?.accordionHeader}>
                        <p>{a?.name} Details</p>
                      </div>
                    </AccordionHeader>
                    <AccordionBody accordionId={i.toString()}>
                      <CalculationDetails
                        data={a}
                        params={paramsObj}
                        onSuccess={(apiRes, selectedUser) =>
                          onSuccess(apiRes, selectedUser, i)
                        }
                        userIds={data?.map((a) => a?.id)}
                        lastIndex={data?.length === i + 1}
                        selectedLender={selectedLender}
                      />
                    </AccordionBody>
                  </AccordionItem>
                );
              }
            })
          ) : (
            <p className="mt-2 px-3">No details available</p>
          )}
        </div>
      </UncontrolledAccordion>
    </div>
  );
};
export default Index;
