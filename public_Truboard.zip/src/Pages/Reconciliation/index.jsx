import { CardBody, Card } from "reactstrap";
import ReconciliationFilterForm from "./ReconciliationFilterForm";

const Reconciliation = () => {
  return (
    <>
      <Card>
        <CardBody>
          <ReconciliationFilterForm />
        </CardBody>
      </Card>
    </>
  );
};

export default Reconciliation;
