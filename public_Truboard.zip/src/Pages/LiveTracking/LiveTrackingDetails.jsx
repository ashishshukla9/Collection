import React, { useState, useEffect, useCallback } from "react";
import {
  GoogleMap,
  InfoWindow,
  useLoadScript,
  Marker,
  DirectionsRenderer,
} from "@react-google-maps/api";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import UserList from "./UserList";
import TrackingFilter from "./TrackingFilter";
import redDot from "../../assets/images/red-dot.png"; // Import your red dot image
import greenDot from "../../assets/images/green-dot.png"; // Import your green dot image
import orangeDot from "../../assets/images/orange-dot.png";
import blueDot from "../../assets/images/blue-dot.png";
import { getUserListDetails } from "./LiveTrackingSlice";
import { useParams } from "react-router-dom";
const libraries = ["places"];
const mapContainerStyle = {
  width: "100vw",
  height: "100%",
};
const center = {
  lat: 28.6139,
  lng: 77.209,
};
const Map = ({ scheduleVisits }) => {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: "AIzaSyBuUvhwxGimiUUicIv_O6IvE3xvzRjixhc",
    libraries,
  });
  const [tracker, setTracker] = useState([]);
  const [activeMarkerIndex, setActiveMarkerIndex] = useState(null);
  const [activeMarkerDetails, setActiveMarkerDetails] = useState(null);
  const [activeVisitId, setActiveVisitId] = useState(null);
  const [directions, setDirections] = useState(null);
  const { userName } = useParams();
  const userData = useSelector((state) => state.LiveTrackingSlice.userData);
  const user = useSelector((state) => state.user.data);
  const [afterFilterLiveTrackerCount, setAfterFilterLiveTrackerCount] =
    useState();
  const [liveTrackerCount, setLiveTrackerCount] = useState(null);
  const [activeTrackerId, setActiveTrackerId] = useState(null);
  const [userByFilterData, setUserByFilterData] = useState(null);
  const [sharedValueStartTime, setSharedValueStartTime] = useState("");
  const [sharedValueEndTime, setSharedValueEndTime] = useState("");
  const [sharedValueCurrent, setSharedValueCurrent] = useState("");
  const dispatch = useDispatch();
  useEffect(() => {
    const getDashBoardData = async () => {
      try {
        const res = await axios.post(
          `/getLiveTrackerDashboard/${user?.userId}`
        );
        setLiveTrackerCount(res?.data?.data);
      } catch (error) {
        console.log(error);
      }
    };
    getDashBoardData();
    dispatch(getUserListDetails(user?.userId));
  }, [user?.userId, dispatch]);
  useEffect(() => {
    if (afterFilterLiveTrackerCount) {
      setLiveTrackerCount(afterFilterLiveTrackerCount);
    }
  }, [afterFilterLiveTrackerCount]);
  const userDetail = userData.find((user) => user.userName === userName);
  const userId = userDetail?.userId;
  const [updatedTracker, setUpdatedTracker] = useState([]);
  const statusClasses = {
    Completed: "text-teal-700 font-bold text-lg",
    Successful: "text-teal-700 font-bold text-lg",
    Pending: "text-orange-400 font-bold text-lg",
  };
  const customizedContent = (item) => (
    <div className="border-gray-100 overflow-hidden">
      <div className="card border-0 flex bg-gray-100 justify-content-between">
        <div className="d-flex justify-content-between">
          <span className="text-bluegray-500 text-xs">{item.date}</span>
          <span className="text-bluegray-500 text-xs">{item.time}</span>
        </div>
        <div className="scroll-view">
          <span className="limited-lines text-bluegray-500 text-xs">
            {item.areaName}
          </span>
        </div>
      </div>
    </div>
  );
  const customizedOpposite = (item) => {
    const constructedURL = `${process.env.REACT_APP_BASE_URLS}/#/case_profile/All/calling/${item.lan}`;
    const containsPTP = item.activity.includes("PTP");
    const containsPayment = item.activity.includes("Payment");
    const containsScheduleVisit = item.activity.includes("ScheduleVisit");
    const containsDisputeRTP = item.activity.includes("Dispute/RTP"); 
    const containsRaiseException = item.activity.includes("Raise Exception"); 
    const containsRequest = item.activity.includes("Request"); 
    return (
      <div className="bg-gray-100 text-center w-8rem bg-blue-500 border-1 border-yellow-200 text-yellow-700 rounded p-1 mt-6">
        {/* {console.log(item, "vcghvchg")} */}
        {containsPTP || containsPayment || containsScheduleVisit || containsDisputeRTP || containsRaiseException || containsRequest ? (
          <a
            href={constructedURL} // Pass the dynamically constructed URL here
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-500 underline"
          >
            {item.activity}{" "}
          </a>
        ) : item.activity === "Login" ? (
          "Login"
        ) : item.activity === "Logout" ? (
          "Logout"
        ) : (
          item.activity
        )}
      </div>
    );
  };
  const markerIcons = {
    Completed: greenDot,
    ReScheduled: blueDot,
    Pending: orangeDot,
    Login: greenDot,
    Notlogin: redDot,
  };
  const formatDate = (inputDate) => {
    const date = new Date(inputDate);
    const day = date.getDate().toString().padStart(2, "0");
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const year = date.getFullYear().toString();
    return `${day}/${month}/${year}`;
  };
  const formatTime = (inputDate) => {
    const date = new Date(inputDate);
    const hours = date.getHours().toString().padStart(2, "0");
    const minutes = date.getMinutes().toString().padStart(2, "0");
    return `${hours}:${minutes}`;
  };
  const groupBy = (array, keys) => {
    return array.reduce((result, item) => {
      const groupKey = keys.map((key) => item[key]).join("|");
      if (!result[groupKey]) {
        result[groupKey] = [];
      }
      result[groupKey].push(item);
      return result;
    }, {});
  };
  const uniqueLocationDetails = (data) => {
    const groupedByDateAddressAndActivity = groupBy(data, [
      "date",
      "address",
      "activity",
    ]);
    return Object.values(groupedByDateAddressAndActivity).map((group) => {
      const representativeItem = group[0];
      const activity = group.every((item) => item.activity === "NIL")
        ? "No Activity"
        : representativeItem.activity || "NIL";
      // console.log(representativeItem.lan, "vhjvjhv");
      return {
        activity: activity,
        date: formatDate(representativeItem.createdTime),
        time: formatTime(representativeItem.createdTime),
        address: representativeItem.address || "No Address",
        icon: "pi pi-map-marker",
        color: "bg-gray-300",
        image: "game-controller.jpg",
        areaName: representativeItem.areaName || "No Area",
        trackerId: representativeItem.trackerId || "Unknown",
        lan: representativeItem.lan || "Unknown",
      };
    });
  };
  const locationDetail = uniqueLocationDetails(updatedTracker);
  useEffect(() => {
    const fetchTrackerData = async () => {
      const payload = {
        userIds: [userId],
        date: new Date(),
        fromTime: "03-00",
        toTime: "22-00",
      };
      try {
        const response = await axios.post(`/mapDataByUserId`, payload);
        const fetchedScheduleVisits =
          response?.data?.data?.shceduleVisits || [];
        const fetchedTracker = response?.data?.data?.tracker || [];
        const updatedScheduleVisits = fetchedScheduleVisits.map((item) => ({
          ...item,
          type: "scheduleVisit",
          position: item.geoCordinates
            ? {
                lat: parseFloat(item.geoCordinates.split(",")[0]),
                lng: parseFloat(item.geoCordinates.split(",")[1]),
              }
            : null,
        }));
        const updatedTracker = fetchedTracker.map((item) => ({
          ...item,
          type: "tracker",
          position: item.coordinates
            ? {
                lat: parseFloat(item.coordinates.split(",")[0]),
                lng: parseFloat(item.coordinates.split(",")[1]),
              }
            : null,
        }));
        setTracker([...updatedScheduleVisits, ...updatedTracker]);
        setUpdatedTracker(updatedTracker);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchTrackerData();
  }, [userId]);
  const handleActiveMarker = (id, type) => {
    if (type === "tracker") {
      setActiveTrackerId((prevId) => (prevId === id ? null : id));
    } else if (type === "scheduleVisit") {
      setActiveVisitId((prevId) => (prevId === id ? null : id));
    }
  };
  const handleMarkerClick = (index, type) => {
    const markerDetails = tracker[index];
    setActiveMarkerIndex(index);
    setActiveMarkerDetails({
      activity: markerDetails.activity,
      areaName: markerDetails.areaName,
      createdTime: markerDetails.createdTime,
      status: markerDetails.status,
    });
    if (type === "scheduleVisit") {
      setActiveVisitId(markerDetails.visitId); // Ensure visitId is part of markerDetails
    }
  };
  const handleMarkerDoubleClick = useCallback(
    (index) => {
      const { position } = tracker[index];
      const { lat, lng } = position;
      const matchingMarkers = tracker
        .map((marker, i) =>
          marker.position.lat === lat && marker.position.lng === lng ? i : null
        )
        .filter((i) => i !== null);

      if (matchingMarkers.length > 0) {
        let newIndex;
        if (
          activeMarkerIndex === null ||
          !matchingMarkers.includes(activeMarkerIndex)
        ) {
          newIndex = matchingMarkers[0];
        } else {
          const currentIndex = matchingMarkers.indexOf(activeMarkerIndex);
          newIndex =
            matchingMarkers[(currentIndex + 1) % matchingMarkers.length];
        }
        setActiveMarkerIndex(newIndex);
        const markerDetails = tracker[newIndex];
        setActiveMarkerDetails({
          activity: markerDetails.activity,
          areaName: markerDetails.areaName,
          createdTime: markerDetails.createdTime,
          status: markerDetails.status,
        });
      } else {
        setActiveMarkerIndex(null);
        setActiveMarkerDetails(null);
      }
    },
    [tracker, activeMarkerIndex]
  );
  const getMarkerIcon = (activity, status) => {
    if (activity === "ScheduleVisit") {
      return {
        url: markerIcons.Pending, // Use the orange dot icon for ScheduleVisit
        scaledSize: new window.google.maps.Size(32, 32),
      };
    }
    return {
      url: markerIcons[status] || markerIcons.Notlogin,
      scaledSize: new window.google.maps.Size(32, 32),
    };
  };
  const calculateDirections = () => {
    if (tracker.length < 2) {
      setDirections(null);
      return;
    }
    const waypoints = [];
    for (let i = 0; i < tracker.length - 1; i++) {
      const origin = tracker[i].position;
      const destination =
        tracker[i + 1].addressPosition || tracker[i + 1].position;
      if (origin && destination) {
        waypoints.push({ origin, destination });
      }
    }
    const directionsService = new window.google.maps.DirectionsService();
    const requests = waypoints.map(({ origin, destination }) => ({
      origin: origin,
      destination: destination,
      travelMode: window.google.maps.TravelMode.DRIVING,
    }));
    const directionPromises = requests.map(
      (request) =>
        new Promise((resolve, reject) => {
          directionsService.route(request, (result, status) => {
            if (status === window.google.maps.DirectionsStatus.OK) {
              resolve(result);
            } else {
              reject(`Directions request failed due to ${status}`);
            }
          });
        })
    );
    Promise.all(directionPromises)
      .then((results) => {
        setDirections(results);
      })
      .catch((error) => {
        console.error("Error calculating directions:", error);
        setDirections(null);
      });
  };
  useEffect(() => {
    calculateDirections();
  }, [tracker]);
  const calculateDistance = (latLng1, latLng2) => {
    if (!latLng1 || !latLng2) return 0;
    const from = new window.google.maps.LatLng(latLng1.lat, latLng1.lng);
    const to = new window.google.maps.LatLng(latLng2.lat, latLng2.lng);
    return window.google.maps.geometry.spherical.computeDistanceBetween(
      from,
      to
    );
  };
  if (loadError) return <div>Error loading maps</div>;
  if (!isLoaded) return <div>Loading Maps</div>;
  return (
    <>
      <TrackingFilter
        afterFilterLiveTrackerCount={afterFilterLiveTrackerCount}
        setAfterFilterLiveTrackerCount={setAfterFilterLiveTrackerCount}
        setUserByFilterData={setUserByFilterData}
        liveTrackerCount={liveTrackerCount}
        userData={userData}
        setSharedValueStartTime={setSharedValueStartTime}
        setSharedValueEndTime={setSharedValueEndTime}
        setSharedValueCurrent={setSharedValueCurrent}
      />
      <div className="d-flex justify-content-between Tracking_Container">
        {!isLoaded && !loadError && (
          <div className="loader"></div> // Show loader while map is loading
        )}
        {isLoaded && (
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            zoom={5}
            center={center}
          >
            {tracker.map((marker, index) => {
              const { position, trackerId, visitId, type, status, activity } =
                marker;
              const isActive = activeMarkerIndex === index;
              const icon =
                activity && activity.toLowerCase() === "schedulevisit"
                  ? status === "ReScheduled"
                    ? markerIcons.ReScheduled
                    : status === null
                    ? markerIcons.Pending
                    : markerIcons[status] || markerIcons.Notlogin
                  : activity && activity.toLowerCase() === "login"
                  ? markerIcons.Login
                  : markerIcons[status] || markerIcons.Notlogin;
              return (
                <Marker
                  key={trackerId || visitId}
                  position={position}
                  icon={icon}
                  onClick={() => handleMarkerClick(index, type)}
                  onDblClick={() => handleMarkerDoubleClick(index)}
                >
                  {type === "tracker" && isActive && activeMarkerDetails && (
                    <InfoWindow onCloseClick={() => setActiveMarkerIndex(null)}>
                      <Marker
                        key={trackerId || visitId}
                        position={position}
                        icon={icon}
                        onClick={() => handleMarkerClick(index, type)}
                        onDblClick={() => handleMarkerDoubleClick(index)}
                      >
                        <div>
                          <p>
                            <strong className="fw-bold">Activity:</strong>{" "}
                            {activeMarkerDetails.activity || "No Activity"}
                          </p>
                          <p>
                            <strong className="fw-bold">Area Name:</strong>{" "}
                            {activeMarkerDetails.areaName || "N/A"}
                          </p>
                          <p>
                            <strong className="fw-bold">Time:</strong>{" "}
                            {formatTime(activeMarkerDetails.createdTime)}
                          </p>
                          {activeMarkerDetails.activity === "ScheduleVisit" &&
                          activeMarkerDetails.status === null ? (
                            <p>
                              <strong className="fw-bold">Status:</strong>{" "}
                              Pending
                            </p>
                          ) : activeMarkerDetails.status !== null ? (
                            <p>
                              <strong className="fw-bold">Status:</strong>{" "}
                              {activeMarkerDetails.status}
                            </p>
                          ) : null}
                        </div>
                      </Marker>
                    </InfoWindow>
                  )}
                  {type === "scheduleVisit" && activeVisitId === visitId && (
                    <InfoWindow onCloseClick={() => setActiveVisitId(null)}>
                      <div>
                        <p>
                          <strong className="fw-bold">Name:</strong>{" "}
                          {marker.name || "N/A"}
                        </p>
                        <p>
                          <strong className="fw-bold">Address:</strong>{" "}
                          {marker.address || "N/A"}
                        </p>
                        <p>
                          <strong className="fw-bold">Date:</strong>{" "}
                          {formatDate(marker.date)}
                        </p>
                        <p>
                          <strong className="fw-bold">Time:</strong>{" "}
                          {marker.time || "N/A"}
                        </p>
                        <p>
                          <strong className="fw-bold">Remark:</strong>{" "}
                          {marker.remark || "N/A"}
                        </p>
                        <p>
                          <strong className="fw-bold">LAN:</strong>{" "}
                          {marker.lan || "N/A"}
                        </p>
                        <p>
                          <strong className="fw-bold">Status:</strong>{" "}
                          {marker.status || "N/A"}
                        </p>
                      </div>
                    </InfoWindow>
                  )}
                </Marker>
              );
            })}
            {directions &&
              directions.map((result, index) => (
                <DirectionsRenderer
                  key={`directions_${index}`}
                  directions={result}
                  options={{
                    suppressMarkers: true, // Ensure this is true if you are using custom markers
                    polylineOptions: {
                      strokeColor: "#4285F4",
                      strokeOpacity: 0.8,
                      strokeWeight: 4,
                    },
                  }}
                />
              ))}
          </GoogleMap>
        )}
        {/* {console.log(locationDetail, "vjhvj")} */}
        <div className="map-list">
          <UserList
            customizedOpposite={customizedOpposite}
            userDetail={userDetail}
            locationDetail={locationDetail}
            customizedContent={customizedContent}
            sharedValueStartTime={sharedValueStartTime}
            sharedValueEndTime={sharedValueEndTime}
            sharedValueCurrent={sharedValueCurrent}
          />
        </div>
      </div>
    </>
  );
};
export default Map;