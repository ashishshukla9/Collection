import React, { memo } from "react";
import { Input } from "reactstrap";
import { useFormikContext } from "formik";

const CheckBox = memo(({ ids, checked, type, isDisabled }) => {
  const { values, setFieldValue } = useFormikContext();
  let [_, field] = ids.split(".");

  const handleView = ({ target }) => {
    const moduleAll = ids.split('.')[1].split('_')[0] + '_all'
    
    switch (values.access[field]) {
      case "F":
        setFieldValue(ids, "E");
        setFieldValue(`access.${moduleAll}`, !target.checked && "E")
        break;
      case "E":
        setFieldValue(ids, target.checked ? "F" : null);
        break;
      default:
        setFieldValue(ids, target.checked ? "V" : null);
        setFieldValue(`access.${moduleAll}`, !target.checked && null)
    }
  };

  const handleEdit = ({ target }) => {
    const moduleAll = ids.split('.')[1].split('_')[0] + '_all'

    switch (values.access[field]) {
      case "F":
        setFieldValue(ids, "V");
        setFieldValue(`access.${moduleAll}`, !target.checked && "V")
        break;
      case "V":
        setFieldValue(ids, target.checked ? "F" : null);
        break;
      default:
        setFieldValue(ids, target.checked ? "E" : null);
        setFieldValue(`access.${moduleAll}`, !target.checked && null)
    }
  };

  const handleFull = ({ target }) => {
    setFieldValue(ids, target.checked ? "F" : null);
  };

  const fullAccess = ({ target }) => {
    let a = field.split("_")[0];
    for (let key in values.access) {
      if (key !== "roleaccessibilityid" && key.split("_")[0] === a)
        setFieldValue(`access.${key}`, target.checked ? "F" : null);
    }
  };

  const handleViewAll = ({ target }) => {
    let a = field.split("_")[0];
    for (let key in values.access) {
      if (key !== "roleaccessibilityid" && key.split("_")[0] === a) {
        if (target.checked) {
          if (values?.access[key] === "E" || values?.access[key] === "F") {
            setFieldValue(`access.${key}`, 'F')
          } else {
            setFieldValue(`access.${key}`, 'V')
          }
        } else {
          if (values?.access[key] === "F" || values?.access[key] === "E") {
            setFieldValue(`access.${key}`, 'E')
          } else {
            setFieldValue(`access.${key}`, null)
          }
        }
      }
    }
  };

  const hanldeEditAll = ({ target }) => {
    let a = field.split("_")[0];
    for (let key in values.access) {
      if (key !== "roleaccessibilityid" && key.split("_")[0] === a) {
        if (target.checked) {
          if (values?.access[key] === "V" || values?.access[key] === "F") {
            setFieldValue(`access.${key}`, 'F')
          } else {
            setFieldValue(`access.${key}`, 'E')
          }
        } else {
          if (values?.access[key] === "F" || values?.access[key] === "V") {
            setFieldValue(`access.${key}`, 'V')
          } else {
            setFieldValue(`access.${key}`, null)
          }
        }
      }
    }
  };

  return (
    <Input
      type="checkbox"
      id={ids}
      onChange={(e) => {
        switch (type) {
          case "view":
            handleView(e);
            break;
          case "edit":
            handleEdit(e);
            break;
          case "full":
            handleFull(e);
            break;
          case "viewAll":
            handleViewAll(e);
            break;
          case "editAll":
            hanldeEditAll(e);
            break;
          case "fullAccess":
            fullAccess(e);
            break;
          default:
            break;
        }
      }}
      checked={checked}
      disabled={isDisabled}
    />
  );
});

export default CheckBox;
