import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../App.config";
import { setLoader } from "../../../reducer/globalReducer";

export const getAllRole = createAsyncThunk(
  "role/getAllRole",
  async (params, {dispatch}) => {
    dispatch(setLoader(true))
    try {
      const response = await axios.get(baseUrl() + "/getAllRole");
      
      dispatch(setLoader(false)) 
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false)) 
      throw new Error("Failed to fetch role data.");
    }
  }
);

export const addRole = createAsyncThunk(
  "role/addRole",
  async (params, { dispatch }) => {
    dispatch(setLoader(true)) 
    try {
      await axios.post(baseUrl() + "/createRole", params);
      dispatch(getAllRole());
      dispatch(setLoader(false)) 
      return true;
    } catch (error) {
      dispatch(setLoader(false)) 
      throw new Error("Failed to fetch role data.");
    }
  }
);
export const editRole = createAsyncThunk(
  "role/editRole",
  async (params, { dispatch }) => {
    dispatch(setLoader(true)) 
    try {
      const response =   await axios.put(baseUrl() + `/updateRole/${params?.id}`, params);
      dispatch(getAllRole());
      dispatch(setLoader(false)) 
      return true;
    } catch (error) {
      dispatch(setLoader(false)) 
      throw new Error("Failed to fetch role data.");
    }
  }
);

export const searchRole = createAsyncThunk(
  "role/searchRole",
  async (search,{dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(
        baseUrl() + `/getRoleName/${search}`
      );
      dispatch(setLoader(false))
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error("Failed to fetch role data.");
    }
  }
);

export const role = createSlice({
  name: "role",
  initialState: {
    list: [],
    loader: false,
    error: "",
    selected: null,
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null
        ? (state.selected = null)
        : (state.selected = {
            ...action.payload,
            access: JSON.parse(action.payload.access),
          });
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllRole.fulfilled, (state, action) => {
      state.loader = false;
      state.list = action.payload.list;
    });
    builder.addCase(searchRole.fulfilled, (state, action) => {
      state.loader = false;
      state.list = action.payload.list;
    });
    
  },
});

export const { setSelected, setLoder } = role.actions;

export default role.reducer;
