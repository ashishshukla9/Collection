import React, { useState, useEffect, useRef } from "react";
import {
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  Col,
  Button,
  FormFeedback,
  Table,
} from "reactstrap";
import { validationSchema } from "../../Schema/RoleShema";
import { Formik } from "formik";
import Swal from "sweetalert2";
import axios from "axios";
import MultiSelectionFormik from "../../components/Selection/MultiSelectionFormik";
import CheckBox from "../../components/Role/CheckBox";
import Select, { components } from "react-select";
import cx from "classnames";
import { scrollToErrorMessage } from "../../utils/commonFun";
import Field from "../../components/Field";
import { NO_SPACE } from "../../utils/regex";
export default function CreateRoles({
  type,
  profileList,
  rowData,
  cancelModal,
  onSuccess,
}) {
  const [profileOption, setProfileOption] = useState([]);
  const [profileValue, setProfileValue] = useState([]);
  const formRef = useRef();
  const initialValues = {
    profile:
      rowData?.profile?.map((pro) => ({
        label: pro.profileName,
        value: pro.fieldCode,
        profileId: pro.profileId,
      })) || "",
    roleCode: rowData?.roleCode || "",
    roleName: rowData?.roleName || "",
    isActive: rowData?.isActive || "Y",
    access: {
      administrator_all: rowData?.access?.administrator_all || null,
      administrator_role: rowData?.access?.administrator_role || null,
      administrator_profile: rowData?.access?.administrator_profile || null,
      administrator_user: rowData?.access?.administrator_user || null,
      administrator_lender: rowData?.access?.administrator_lender || null,
      administrator_agency: rowData?.access?.administrator_agency || null,
      administrator_geographymaster:
        rowData?.access?.administrator_geographymaster || null,
      administrator_bankbranchmaster:
        rowData?.access?.administrator_bankbranchmaster || null,
      administrator_portfoliomaster:
        rowData?.access?.administrator_portfoliomaster || null,
      administrator_productmaster:
        rowData?.access?.administrator_productmaster || null,
      administrator_lookupmaster:
        rowData?.access?.administrator_lookupmaster || null,
      customerprofile_all: rowData?.access?.customerprofile_all || null,
      customerprofile_applicationdetails:
        rowData?.access?.customerprofile_applicationdetails || null,
      customerprofile_loanhistory:
        rowData?.access?.customerprofile_loanhistory || null,
      customerprofile_collateraldetails:
        rowData?.access?.customerprofile_collateraldetails || null,
      caseactivity_all: rowData?.access?.caseactivity_all || null,
      caseactivity_paymentinfo:
        rowData?.access?.caseactivity_paymentinfo || null,
      caseactivity_ptp: rowData?.access?.caseactivity_ptp || null,
      caseactivity_payment: rowData?.access?.caseactivity_payment || null,
      caseactivity_disputertp: rowData?.access?.caseactivity_disputertp || null,
      caseactivity_raiseexception:
        rowData?.access?.caseactivity_raiseexception || null,
      caseactivity_request: rowData?.access?.caseactivity_request || null,
      caseactivity_contactcentre:
        rowData?.access?.caseactivity_contactcentre || null,
      caseactivity_statcard: rowData?.access?.caseactivity_statcard || null,
      caseactivity_autoallocation:
        rowData?.access?.caseactivity_autoallocation || null,
      caseactivity_manualallocation:
        rowData?.access?.caseactivity_manualallocation || null,
      caseupload_all: rowData?.access?.caseupload_all || null,
      caseupload_caseupload: rowData?.access?.caseupload_caseupload || null,

      campaignmanagement_all: rowData?.access?.campaignmanagement_all || null,
      campaignmanagement_campaignmanagement:
        rowData?.access?.campaignmanagement_campaignmanagement || null,
      requestmanagement_all: rowData?.access?.requestmanagement_all || null,
      requestmanagement_requestmanagement:
        rowData?.access?.requestmanagement_requestmanagement || null,
      audit_all: rowData?.access?.audit_all || null,
      audit_audit: rowData?.access?.audit_audit || null,
      reports_all: rowData?.access?.reports_all || null,
      reports_reports: rowData?.access?.reports_reports || null,
      reports_callingagentreport:
        rowData?.access?.reports_callingagentreport || null,
      reports_fieldagentreport:
        rowData?.access?.reports_reports_fieldagentreport || null,
      reports_agencyreport: rowData?.access?.reports_agencyreport || null,
      reports_lenderreport: rowData?.access?.reports_lenderreport || null,
      reports_productreport: rowData?.access?.reports_productreport || null,
      reports_callattendancereport:
        rowData?.access?.reports_callattendancereport || null,
      reports_paymentreport: rowData?.access?.reports_paymentreport || null,
      reports_cashcollectreport:
        rowData?.access?.reports_cashcollectreport || null,
      reports_productlenderreport:
        rowData?.access?.reports_productlenderreport || null,
      reports_lenderdpdreport: rowData?.access?.reports_lenderdpdreport || null,
      reports_attendancereport:
        rowData?.access?.reports_attendancereport || null,
      reports_monthlydealcollectionamountreport:
        rowData?.access?.reports_monthlydealcollectionamountreport || null,
      reports_collectionthroughccandfosreport:
        rowData?.access?.reports_collectionthroughccandfosreport || null,
      reports_settlementandclosurereport:
        rowData?.access?.reports_settlementandclosurereport || null,
      reports_poolwiseptpandpaidsummaryreport:
        rowData?.access?.reports_poolwiseptpandpaidsummaryreport || null,
      reports_loginreport: rowData?.access?.reports_loginreport || null,
      reports_userportfolioreport:
        rowData?.access?.reports_userportfolioreport || null,
      reports_paymentreport2: rowData?.access?.reports_paymentreport2 || null,
      reports_allocationreport:
        rowData?.access?.reports_allocationreport || null,
      // Payout
      payoutconfiguration_all: rowData?.access?.payoutconfiguration_all || null,
      payoutconfiguration_payoutconfiguration:
        rowData?.access?.payoutconfiguration_payoutconfiguration || null,
      payoutcalculation_all: rowData?.access?.payoutcalculation_all || null,
      payoutcalculation_payoutcalculation: rowData?.access?.payoutcalculation_payoutcalculation || null,
      // Payin
      payinconfiguration_all: rowData?.access?.payinconfiguration_all || null,
      payinconfiguration_payinconfiguration:
        rowData?.access?.payinconfiguration_payinconfiguration || null,
      payincalculation_all: rowData?.access?.payincalculation_all || null,
      payincalculation_payincalculation:
        rowData?.access?.payincalculation_payincalculation || null,

        payoutreconciliation_all: rowData?.access?.payoutreconciliation_all || null,
        payoutreconciliation_payoutreconciliation:
        rowData?.access?.payoutreconciliation_payoutreconciliation || null,
      securitypolicies_all: rowData?.access?.securitypolicies_all || null,
      securitypolicies_securitypolicies:
        rowData?.access?.securitypolicies_securitypolicies || null,
      bulkdeallocation_bulkdeallocation:
        rowData?.access?.bulkdeallocation_bulkdeallocation || null,
      bulkdeallocation_all: rowData?.access?.bulkdeallocation_all || null,
      livetracking_all: rowData?.access?.livetracking_all || null,
      livetracking_livetracking:
        rowData?.access?.livetracking_livetracking || null,
      agencyfeedbackupload_agencyfeedbackupload:
        rowData?.access?.agencyfeedbackupload_agencyfeedbackupload || null,
      agencyfeedbackupload_all:
        rowData?.access?.agencyfeedbackupload_all || null,
    },
  };
  useEffect(() => {
    let userTypeTemp = [];
    profileList.forEach((type) => {
      userTypeTemp.push({
        label: type.profileName,
        value: type.fieldCode,
        profileId: type.profileId,
      });
    });
    setProfileOption([...userTypeTemp]);
    const modifiedProfile = rowData?.profile.map((e) => ({
      label: e.profileName,
      value: e.profileId,
    }));
    setProfileValue(modifiedProfile);
  }, [rowData, profileList]);
  const roleOptions = [
    {
      header: "Administrator",
      roles: [
        "Role",
        "Profile",
        "User",
        "Lender",
        "Agency",
        "Geography Master",
        "Bank Branch Master",
        "Portfolio Master",
        "Product Master",
        "Lookup Master",
      ],
    },
    {
      header: "Case Upload",
      roles: ["Case Upload"],
    },
    {
      header: "Bulk  Deallocation",
      roles: ["Bulk  Deallocation"],
    },
    {
      header: "Agency Feedback Upload",
      roles: ["Agency Feedback Upload"],
    },
    {
      header: "Customer Profile",
      roles: ["Application Details", "Loan History", "Collateral Details"],
    },
    {
      header: "Case Activity",
      roles: [
        "Payment Info",
        "PTP",
        "Payment",
        "Dispute/RTP",
        "Raise Exception",
        "Request",
        "Contact Centre",
        "Stat Card",
        "Auto Allocation",
        "Manual Allocation",
      ],
    },
    {
      header: "Campaign Management",
      roles: ["Campaign Management"],
    },

    {
      header: "Request Management",
      roles: ["Request Management"],
    },
    {
      header: "Audit",
      roles: ["Audit"],
    },
    {
      header: "Payout Configuration",
      roles: ["Payout Configuration"],
    },

    {
      header: "Payout Reconciliation",
      roles: ["Payout Reconciliation"],
    },
    {
      header: "Payout Calculation",
      roles: ["Payout Calculation"],
    },
    {
      header: "Payin Configuration",
      roles: ["Payin Configuration"],
    },
    {
      header: "Payin Calculation",
      roles: ["Payin Calculation"],
    },

    {
      header: "Reports",
      roles: [
        "Agency Report",
        "Lender Report",
        "Product Report",
        "Call Attendance Report",
        "Payment Report",
        "Cash Collect Report",
        "Product Lender Report",
        "Lender DPD Report",
        "Attendance Report",
        "Monthly Deal Collection Amount Report",
        "Collection Through Cc And Fos Report",
        "Settlement And Closure Report",
        "Pool Wise PTP And Paid Summary Report",
        "Login Report",
        "User Portfolio Report",
        "Payment Report 2",
      ],
    },
    {
      header: "Security Policies",
      roles: ["Security Policies"],
    },
    {
      header: "Live Tracking",
      roles: ["Live Tracking"],
    },
  ];
  const handleFormSubmit = (values) => {
    const payload = {
      ...values,
      access: JSON.stringify(values?.access),
    };
    // console.log(values, "values");
    if (type === "Create") {
      axios
        .post("/createRole", payload, {
          headers: { Accept: "application/json" },
        })
        .then((response) => {
          if (response?.data?.msgKey === "Success") {
            onSuccess();
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: "Records has been saved",
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          } else if (response?.data?.msgKey === "Failure") {
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: response?.data?.message,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        })
        .catch((error) => {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: error.code,
            text: error?.response?.data?.error,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    } else {
      axios
        .put(`/updateRole/${rowData.roleId}`, payload)
        .then((res) => {
          if (res?.data?.msgKey === "Success") {
            onSuccess();
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: "Records has been saved",
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          } else if (res?.data?.msgKey === "Failure") {
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: res?.data?.message,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        })
        .catch((error) => {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: error.code,
            text: error?.response?.data?.error,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    }
  };

  return (
    <Formik
      // initialValues={type !== "Create" ? rowData : RoleShema}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleFormSubmit}
    >
      {({
        values,
        errors,
        handleChange,
        handleSubmit,
        handleBlur,
        setFieldValue,
        touched,
        handleChangeEvent,
        onChange,
        isSubmitting,
      }) => {
        const err = Object.keys(errors)[0];
        scrollToErrorMessage(isSubmitting, err);
        return (
          <Form onSubmit={handleSubmit} ref={formRef}>
            <Row>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Role Code"
                  errorMessage={touched.roleCode && errors.roleCode}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="roleCode"
                    placeholder="Role Code"
                    value={values.roleCode}
                    onChange={(e) => {
                      if (
                        NO_SPACE.test(e?.target?.value) ||
                        e?.target?.value === ""
                      ) {
                        setFieldValue("roleCode", e?.target?.value);
                      }
                    }}
                    onBlur={handleBlur}
                    invalid={touched.roleCode && Boolean(errors.roleCode)}
                    maxLength={4}
                    disabled={type !== "Create"}
                  />
                </Field>
              </Col>

              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Role Name"
                  errorMessage={touched.roleName && errors.roleName}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="roleName"
                    placeholder="Role Name"
                    value={values.roleName}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    invalid={touched.roleName && Boolean(errors.roleName)}
                    disabled={type === "View"}
                  />
                </Field>
              </Col>

              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Profile Name"
                  errorMessage={touched.profile && errors.profile}
                >
                  <Select
                    id="profile"
                    inputId="profile"
                    name="profile"
                    label={"Profile Name"}
                    isClearable={true}
                    options={profileOption}
                    isMulti
                    closeMenuOnSelect={false} // Keep the dropdown open after selection
                    hideSelectedOptions={false}
                    onChange={(selectedOptions) => {
                      setFieldValue("profile", selectedOptions);
                    }}
                    value={values?.profile}
                    className={cx({
                      abc: touched.profile && Boolean(errors.profile),
                    })}
                    invalid={touched.profile && Boolean(errors.profile)}
                    onBlur={handleBlur}
                    menuPosition="fixed"
                    isDisabled={type === "View"}
                    classNamePrefix="react-select"
                  />
                </Field>
              </Col>

              <Col lg={6} md={6} sm={12}>
                <Field label="Active">
                  <FormGroup switch className="ms-2">
                    <Input
                      type="switch"
                      checked={values.isActive === "Y"}
                      onChange={(e) => {
                        setFieldValue("isActive", e.target.checked ? "Y" : "N");
                      }}
                      id="isActive"
                      readOnly
                      disabled={type === "View"}
                    />
                  </FormGroup>
                </Field>
              </Col>
            </Row>

            <Table striped className="border" responsive>
              <thead>
                <tr>
                  <th className="text-start">Menu / Function</th>
                  <th>View</th>
                  <th>Edit</th>
                  <th>Full</th>
                </tr>
              </thead>
              {roleOptions?.map((roles, index) => {
                return (
                  <tbody key={`Roles${index}`}>
                    <tr className="head text-light">
                      <td className="text-start">{roles.header}</td>
                      <td>
                        <CheckBox
                          ids={`access.${roles.header
                            .toLocaleLowerCase()
                            .replace(/[^A-Z0-9]/gi, "")}_all`}
                          type={"viewAll"}
                          checked={["V", "F"]?.includes(
                            values.access[
                              `${roles.header
                                .toLocaleLowerCase()
                                .replace(/[^A-Z0-9]/gi, "")}_all`
                            ]
                          )}
                          isDisabled={type === "View"}
                        />
                      </td>
                      <td>
                        <CheckBox
                          ids={`access.${roles.header
                            .toLocaleLowerCase()
                            .replace(/[^A-Z0-9]/gi, "")}_all`}
                          type={"editAll"}
                          checked={["E", "F"].includes(
                            values.access[
                              `${roles.header
                                .toLocaleLowerCase()
                                .replace(/[^A-Z0-9]/gi, "")}_all`
                            ]
                          )}
                          isDisabled={type === "View"}
                        />
                      </td>
                      <td>
                        <CheckBox
                          ids={`access.${roles.header
                            .toLocaleLowerCase()
                            .replace(/[^A-Z0-9]/gi, "")}_all`}
                          type={"fullAccess"}
                          checked={["F"].includes(
                            values.access[
                              `${roles.header
                                .toLocaleLowerCase()
                                .replace(/[^A-Z0-9]/gi, "")}_all`
                            ]
                          )}
                          isDisabled={type === "View"}
                        />
                      </td>
                    </tr>
                    {roles.roles.map((e, i) => (
                      <tr key={`individualRole${i}`}>
                        <td className="text-start">{e}</td>
                        <td>
                          <CheckBox
                            ids={`access.${roles.header
                              .toLocaleLowerCase()
                              .replace(/[^A-Z0-9]/gi, "")}_${e
                              ?.replace(/[^A-Z0-9]/gi, "")
                              .toLocaleLowerCase()}`}
                            type={"view"}
                            checked={["V", "F"].includes(
                              values.access[
                                `${roles.header
                                  .toLocaleLowerCase()
                                  .replace(/[^A-Z0-9]/gi, "")}_${e
                                  .replace(/[^A-Z0-9]/gi, "")
                                  .toLocaleLowerCase()}`
                              ]
                            )}
                            isDisabled={type === "View"}
                          />
                        </td>
                        <td>
                          <CheckBox
                            ids={`access.${roles.header
                              .toLocaleLowerCase()
                              .replace(/[^A-Z0-9]/gi, "")}_${e
                              ?.replace(/[^A-Z0-9]/gi, "")
                              .toLocaleLowerCase()}`}
                            type={"edit"}
                            checked={["E", "F"].includes(
                              values.access[
                                `${roles.header
                                  .toLocaleLowerCase()
                                  .replace(/[^A-Z0-9]/gi, "")}_${e
                                  .replace(/[^A-Z0-9]/gi, "")
                                  .toLocaleLowerCase()}`
                              ]
                            )}
                            isDisabled={type === "View"}
                          />
                        </td>
                        <td>
                          <CheckBox
                            ids={`access.${roles.header
                              .toLocaleLowerCase()
                              .replace(/[^A-Z0-9]/gi, "")}_${e
                              ?.replace(/[^A-Z0-9]/gi, "")
                              .toLocaleLowerCase()}`}
                            type={"full"}
                            checked={["F"].includes(
                              values.access[
                                `${roles.header
                                  .toLocaleLowerCase()
                                  .replace(/[^A-Z0-9]/gi, "")}_${e
                                  .replace(/[^A-Z0-9]/gi, "")
                                  .toLocaleLowerCase()}`
                              ]
                            )}
                            isDisabled={type === "View"}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                );
              })}
            </Table>

            {type !== "View" && (
              <div className="d-flex justify-content-end">
                <Button
                  color="primary"
                  type="submit"
                  className="me-1"
                  size="sm"
                >
                  Submit
                </Button>{" "}
                <Button
                  size="sm"
                  color="danger"
                  type="button"
                  style={{ color: "#fff" }}
                  onClick={() => cancelModal(false)}
                >
                  Cancel
                </Button>
              </div>
            )}
          </Form>
        );
      }}
    </Formik>
  );
}
