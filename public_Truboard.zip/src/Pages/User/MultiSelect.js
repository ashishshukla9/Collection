import React, { useEffect, useState } from "react";
import Select, { components } from "react-select";

const MultiSelect = ({ options, selectedOptions, onChange }) => {
  const [selectAll, setSelectAll] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [filterOption, setFilterOption] = useState([]);


  // const handleSelectChange = (selected) => {
  //   console.log("selected", selected);

  //   if (selected.some((option) => option.value === "selectAll")) {
  //     setSelectAll(true);
  //     onChange(filterOption);
  //   } else {
  //     setSelectAll(false);
  //     onChange(selectedOptions);
  //   }
  // };

  const selectAllOption = { value: "selectAll", label: "Select All" };

  const Option = (props) => {
    return (
      <div>
        <components.Option {...props}>
          <input type="checkbox" checked={selectAll} onChange={() => null} />{" "}
          <label>{props.label}</label>
        </components.Option>
      </div>
    );
  };

  // const handleChangeEvent = (event) => {
  //   let tempPin = [];
  //   event?.split(",").map((data) => {
  //     tempPin = [
  //       ...tempPin,
  //       ...options?.filter((pin) =>
  //         pin?.label.toString().includes(data.trim().toString())
  //       ),
  //     ];
  //   });
  //   // console.log("tempPin", tempPin);
  //   setFilterOption(tempPin);
  // };
  const handleSelectChange = (selected) => {
    if (selected.some((option) => option.value === "selectAll")) {
      setSelectAll(true);
      onChange(options);
    } else {
      setSelectAll(false);
      onChange(selected);
    }
  };
  

  useEffect(() => {
    setFilterOption(options);
  }, [options]);
  const option = [selectAllOption, ...filterOption];


  const Input = ({ innerRef, ...innerProps }) => (
    <components.Input
      {...innerProps}
      ref={innerRef}
      value={searchValue}
      onChange={(e) => setSearchValue(e.target.value)}
    />
  );
  
  

  return (
    <div>
      {/* <Select
        closeMenuOnSelect={true}
        hideSelectedOptions={false}
        components={{
          Option,
        }}
        options={option}
        onInputChange={(e) => handleChangeEvent(e)}
        isMulti
         value={selectAll ? [selectAllOption] : selectedOptions}
        onChange={handleSelectChange}
        autoComplete="off"
        menuPosition="fixed"
        classNamePrefix="react-select"
      /> */}

      <Select
        options={[
          selectAllOption,
          ...options.map((option) => ({
            value: option.value,
            label: (
              <Option
                label={option.label}
                isChecked={selectedOptions.some(
                  (selectedOption) => selectedOption.value === option.value
                )}
              />
            ),
          })),
        ]}
        isMulti
        value={selectAll ? [selectAllOption] : selectedOptions}
        onChange={handleSelectChange}
        // components={{ Input }} // Custom Input component
        filterOption={({ label }, rawInput) => {
          if (typeof label === "string") {
            return label.toLowerCase().includes(rawInput.toLowerCase());
          }
          return false; // If label is not a string, don't include it in the search
        }}
      
        isSearchable // Enable search
      />
    </div>
  );
};

export default MultiSelect;
