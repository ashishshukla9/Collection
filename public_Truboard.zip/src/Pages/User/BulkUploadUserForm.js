import { Formik } from "formik"
import { Dialog } from "primereact/dialog"
import { Button, Col, Form, FormFeedback, FormGroup, Input, Label, Row } from "reactstrap"

const BulkUploadUserForm = (props) => {
    return (
        <Dialog
            header="User Bulk Upload"
            visible={props?.visible}
            style={{
                width: "60vw",
            }}
            onHide={() => props?.setVisible(false)}
        >
            <Formik
                initialValues={{
                    file: ''
                }}
            >
                {({
                    values,
                    errors,
                    touched,
                    handleSubmit,
                    onSubmit,
                    setFieldValue,
                    handleBlur,
                    handleChange,
                }) => {
                    return (
                        <Form onSubmit={handleSubmit} autoComplete="off">
                            <Row>
                                <FormGroup row className="align-items-center">
                                    <Col sm={2}>
                                        <Label>
                                            Upload File:
                                            <span className="required">*</span>
                                        </Label>
                                    </Col>
                                    <Col>
                                        <Input
                                            type="file"
                                            bsSize="sm"
                                            className="form-control"
                                            style={{ width: "fit-content" }}
                                            accept=".csv, .xlsx"
                                        />
                                        <FormFeedback>
                                        </FormFeedback>
                                    </Col>
                                </FormGroup>
                            </Row>
                            <Row
                                className="justify-content-end"
                            >
                                <Col xs={'auto'}>
                                    <Button color="primary" type="submit" size="sm">
                                        Submit
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    )
                }}
            </Formik>
        </Dialog>
    )
}
export default BulkUploadUserForm