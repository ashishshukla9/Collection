import {
  Button,
  ButtonGroup,
  Card,
  CardBody,
  Col,
  Container,
  Form,
  FormFeedback,
  FormGroup,
  Input,
  Label,
  Row,
  Table,
} from "reactstrap";
import { Formik, ErrorMessage } from "formik";
import axios from "axios";
import Swal from "sweetalert2";
import * as yup from "yup";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import { useEffect, useState } from "react";
import { setLoader } from "../../../reducer/globalReducer";
import { useDispatch } from "react-redux";
const Password_Policy = () => {
  const [ID, setID] = useState();
  const [initialValues, setInitialValues] = useState({
    maxPassLength: "",
    minPassLength: "",
    disallowOldPassword: "",
    maxPassAge: "",
    minPassAge: "",
    warningBeforeExpiration: "",
    alphaCharacterLength: "",
    minUppercase: "",
    maxLowercase: "",
    requiredDigit: "",
    requiredSpecialCharacter: "",
  });

  const dispatch=useDispatch()

  const validation = yup.object({
    maxPassLength: yup.number().required("Required"),

    minPassLength: yup
      .number()
      .required("Required")
      .test(
        "minPassLength",
        "Minimum password length must be less than or not equal to the maximum length",
        function (minPassLength) {
          const maxPassLength = this.parent.maxPassLength; // Access maxPasswordLength from the form values
          return minPassLength < maxPassLength;
        }
      ),
    disallowOldPassword: yup.string().required("Required"),
    maxPassAge: yup.string().required("Required"),
    minPassAge: yup
      .string()
      .required("Required")
      .test(
        "maxPassAge",
        "Minimum password age length must be less than or not equal to the maximum age",
        function (minPassAge) {
          const maxPassAge = this.parent.maxPassAge; // Access maxPasswordLength from the form values
          return minPassAge <= maxPassAge;
        }
      ),
    warningBeforeExpiration: yup.string().required("Required"),
    alphaCharacterLength: yup
      .string()
      .required("Required")
      .test(
        "maxPassLength",
        "Character length must not be grater then maximum password length.",
        function (alphaCharacterLength) {
          const Charlength = this.parent.maxPassLength;
          return alphaCharacterLength < Charlength;
        }
      ),
    minUppercase: yup
      .string()
      .required("Required ")
      .test(
        "alphaCharacterLength",
        "Uppercase must not be grater or equal to given alphabet characters.",
        function (minUppercase) {
          const Charlength = this.parent.alphaCharacterLength;
          return minUppercase < Charlength;
        }
      ),
    maxLowercase: yup
      .string()
      .required("Required")
      .test(
        "minUppercase",
        "lowercase characters must not grater and equal  then Total number of alpha and uppercase characters ",
        function (value, a) {
          const uppercaseCount = this.parent.minUppercase;
          return (
            a?.parent?.maxLowercase !== uppercaseCount &&
            a?.parent?.maxLowercase <= a?.parent?.alphaCharacterLength
          );
        }
      ),

    requiredDigit: yup
      .number()
      .required("Required")
      .test(
        "maxDigitLength",
        "Digit should not be equal to or greater than the maximum digit length.",
        function (value, a) {
          const maxPassLength = this.parent.maxPassLength;
          const alphaCharacterLength = a.parent.alphaCharacterLength;

          const maxDigitLength = maxPassLength - alphaCharacterLength;

          return value < maxDigitLength;
        }
      ),

    requiredSpecialCharacter: yup
      .string()
      .required("Required")
      .test(
        "isOnlyOne",
        "Only one special character is allowed",
        function (value) {
          return value === "1";
        }
      ),
  });

  const getPassword = async () => {
    try {
      dispatch(setLoader(true))
      await axios.get("/getPasswordPolicy").then((res) => {
        dispatch(setLoader(false))
       
        setID(res?.data?.data?.id);
        setInitialValues({
          maxPassLength: res.data.data?.maxPassLength,
          minPassLength: res.data.data?.minPassLength,
          disallowOldPassword: res.data.data?.disallowOldPassword,
          maxPassAge: res.data.data?.maxPassAge,
          minPassAge: res.data.data?.minPassAge,
          warningBeforeExpiration: res.data.data?.warningBeforeExpiration,
          alphaCharacterLength: res.data.data?.alphaCharacterLength,
          minUppercase: res.data.data?.minUppercase,
          maxLowercase: res.data.data?.maxLowercase,
          requiredDigit: res.data.data?.requiredDigit,
          requiredSpecialCharacter: res.data.data?.requiredSpecialCharacter,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  const addPassword = async (values, { resetForm }) => {
    const payload = {
      maxPassLength: values.maxPassLength,
      minPassLength: values.minPassLength,
      disallowOldPassword: values.disallowOldPassword,
      maxPassAge: values.maxPassAge,
      minPassAge: values.minPassAge,
      warningBeforeExpiration: values.warningBeforeExpiration,
      alphaCharacterLength: values.alphaCharacterLength,
      minUppercase: values.minUppercase,
      maxLowercase: values.maxLowercase,
      requiredDigit: values.requiredDigit,
      requiredSpecialCharacter: values.requiredSpecialCharacter,
      id: ID || "",
    };

    try {
      dispatch(setLoader(true))
      await axios.post("/addPasswordPolicy", payload).then((res) => {
        dispatch(setLoader(false))
        if (res?.data?.msgKey === "Success") {
          resetForm({
            values: {
              maxPassLength: "",
              minPassLength: "",
              disallowOldPassword: "",
              maxPassAge: "",
              minPassAge: "",
              warningBeforeExpiration: "",
              alphaCharacterLength: "",
              minUppercase: "",
              maxLowercase: "",
              requiredDigit: "",
              requiredSpecialCharacter: "",
            },
          });

          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });

          setTimeout(()=>{
            getPassword()
          },[1000])

         
        }
        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  useEffect(() => {
    getPassword();
  }, []);

  return (
    <>
      <Row className="mb-3">
        <h5>
          <b>Password Policy</b>
        </h5>
        <br />
        <text>
          Complex passwords that are changed on a ragular basis reduce the
          likelihood of a success attack. Password policy settings control the
          complexity and lifetime of passwords.
        </text>
      </Row>

      <Row>
        <Formik
          enableReinitialize={true}
          initialValues={initialValues}
          validationSchema={validation}
          onSubmit={addPassword}
        >
          {({
            values,
            errors,
            handleChange,
            handleBlur,
            touched,
            handleSubmit,
            setFieldValue,
            setFieldError,
            isSubmitting,
          }) => {
            const err = Object.keys(errors)[0];
            scrollToErrorMessage(isSubmitting, err);
            return (
              <Form onSubmit={handleSubmit}>
                <Card className=" p-4">
                  <CardBody>
                    <Row className="mt-3 mb-3">
                      <Col lg={2}>
                        <Label>Maximum password Length</Label>
                      </Col>

                      <Col lg={4} md={6} sm={12}>
                        {" "}
                        <Input
                          bsSize="sm"
                          type="text"
                          id="maxPassLength"
                          placeholder="Maximum password Length"
                          value={values.maxPassLength}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={
                            touched.maxPassLength &&
                            Boolean(errors.maxPassLength)
                          }
                        />
                        <ErrorMessage
                          name="maxPassLength"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row>
                      <Col lg={2}>
                        <Label> Minimum password length</Label>
                      </Col>
                      <Col lg={4} md={6} sm={12}>
                        <Input
                          bsSize="sm"
                          type="text"
                          id="minPassLength"
                          placeholder=" Minimum password length"
                          value={values.minPassLength}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={
                            touched.minPassLength &&
                            Boolean(errors.minPassLength)
                          }
                        />
                        <ErrorMessage
                          name="minPassLength"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                  </CardBody>
                </Card>

                <h5>
                  <b>Password History</b>
                </h5>
                <Card className="p-4 mt-1">
                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Disallow X number of old password
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder="Disallow X number of old password"
                        bsSize="sm"
                        onChange={handleChange}
                        id="disallowOldPassword"
                        value={values.disallowOldPassword}
                        onBlur={handleBlur}
                        invalid={
                          touched.disallowOldPassword &&
                          Boolean(errors.disallowOldPassword)
                        }
                      />

                      <ErrorMessage
                        name="disallowOldPassword"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Maximum password age
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder=" Maximum password age"
                        bsSize="sm"
                        id="maxPassAge"
                        onChange={handleChange}
                        value={values.maxPassAge}
                        onBlur={handleBlur}
                        invalid={
                          touched.maxPassAge && Boolean(errors.maxPassAge)
                        }
                      />
                      <ErrorMessage
                        name="maxPassAge"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Minimum Password Age
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder="Minimum password age"
                        bsSize="sm"
                        onChange={handleChange}
                        value={values.minPassAge}
                        id="minPassAge"
                        onBlur={handleBlur}
                        invalid={
                          touched.minPassAge && Boolean(errors.minPassAge)
                        }
                      />
                      <ErrorMessage
                        name="minPassAge"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Warning at logon before expiration (days)
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder="Warning at logon before expiration (days)"
                        bsSize="sm"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        id="warningBeforeExpiration"
                        value={values.warningBeforeExpiration}
                        invalid={
                          touched.warningBeforeExpiration &&
                          Boolean(errors.warningBeforeExpiration)
                        }
                      />
                      <ErrorMessage
                        name="warningBeforeExpiration"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>
                </Card>

                <h5>
                  <b>Password Characters Group Requirement</b>
                </h5>
                <Card className="p-4 mt-1">
                  <Row>
                    <Col lg={2} md={6} sm={12}>
                      Require alpha characters
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder=" Require alpha characters"
                        bsSize="sm"
                        onBlur={handleBlur}
                        onChange={handleChange}
                        id="alphaCharacterLength"
                        value={values.alphaCharacterLength}
                        invalid={
                          touched.alphaCharacterLength &&
                          Boolean(errors.alphaCharacterLength)
                        }
                      />
                      <ErrorMessage
                        name="alphaCharacterLength"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>
                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Minimum number of uppercase characters
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        bsSize="sm"
                        id="minUppercase"
                        onBlur={handleBlur}
                        onChange={handleChange}
                        value={values.minUppercase}
                        placeholder="Minimum number of uppercase characters"
                        invalid={
                          touched.minUppercase && Boolean(errors.minUppercase)
                        }
                      />
                      <ErrorMessage
                        name="minUppercase"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Maximum number of lowercase characters
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        id="maxLowercase"
                        placeholder=" Maximum number of lowercase characters"
                        bsSize="sm"
                        onChange={handleChange}
                        value={values.maxLowercase}
                        onBlur={handleBlur}
                        invalid={
                          touched.maxLowercase && Boolean(errors.maxLowercase)
                        }
                      />
                      <ErrorMessage
                        name="maxLowercase"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Required digits
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder=" Required digits"
                        bsSize="sm"
                        onChange={handleChange}
                        id="requiredDigit"
                        value={values.requiredDigit}
                        onBlur={handleBlur}
                        invalid={
                          touched.requiredDigit && Boolean(errors.requiredDigit)
                        }
                      />
                      <ErrorMessage
                        name="requiredDigit"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                      Required special characters
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder="Warning at logon before expiration (days)"
                        bsSize="sm"
                        onChange={handleChange}
                        id="requiredSpecialCharacter"
                        value={values.requiredSpecialCharacter}
                        onBlur={handleBlur}
                        invalid={
                          touched.requiredSpecialCharacter &&
                          Boolean(errors.requiredSpecialCharacter)
                        }
                      />
                      <ErrorMessage
                        name="requiredSpecialCharacter"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row>
                    <Col
                      lg={6}
                      md={6}
                      sm={12}
                      className="d-flex justify-content-end p-3"
                    >
                      <Button
                        size="sm"
                        color="primary"
                        type="submit"
                        style={{ color: "white" }}
                      >
                        Save
                      </Button>
                    </Col>
                  </Row>
                </Card>

                {/* <h5>
                  <b>Password Content Restriction</b>
                </h5>
                <Card className="p-4 mt-1">
                  <Row>
                    <Col lg={2} md={6} sm={12}>
                      Disallow parts of user name
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input type="checkbox" />
                    </Col>
                  </Row>
                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                     Disallow digit as first character in password
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input
                        type="checkbox"
                       
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                     Disallow consecutive identical characters
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input
                        type="text"
                        placeholder="Disallow consecutive identical characters"
                        bsSize="sm"
                        onBlur={handleBlur}
                        invalid={
                          touched.templateName && Boolean(errors.templateName)
                        }
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                     Disallow incremental Passwords
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input
                        type="checkbox"
                     
                      />
                    </Col>
                  </Row>

                 
                </Card> */}

                {/* <h5>
                  <b>Password Reset Options</b>
                </h5>
                <Card className="p-4 mt-1">
                  <Row>
                    <Col lg={2} md={6} sm={12}>
                     Ignore this policy on password reset
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input type="checkbox" />
                    </Col>
                  </Row>
                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                     Require user to change password on next logon
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                    <Input type="checkbox" />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                    Unlocked locked accounts automatically on reset
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                    <Input type="checkbox" />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2} md={6} sm={12}>
                    Disable initial password that have not been used within X days of creation.
                    </Col>
                    <Col lg={10} md={6} sm={12}>
                      <Input
                        type="password"
                        placeholder="Minmum password age"
                        bsSize="sm"
                        onBlur={handleBlur}
                        invalid={
                          touched.templateName && Boolean(errors.templateName)
                        }
                      />
                    </Col>
                  </Row>

                 
                </Card> */}
              </Form>
            );
          }}
        </Formik>
      </Row>
    </>
  );
};

export default Password_Policy;
