import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  Input,
  FormGroup,
  Label,
  Row,
  FormFeedback,
} from "reactstrap";
import { Formik, ErrorMessage } from "formik";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import * as yup from "yup";
import Swal from "sweetalert2";
import cx from "classnames";

import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../../reducer/globalReducer";

const SmtpSettings = () => {
  const [submit, setSubmit] = useState(false);
  const [emailaddress, setEmailAddress] = useState();
  const [showPassword, setShowPassword] = useState(false);
  const [smtpId, setSmtpId] = useState()
  const [initialValues, setInitialValues] = useState({
    host: "",
    port: "",
    sslEnable: "",
    authRequired: "",
    userName: "",
    password: "",
    fromEmail: "",
    subjectPrefix: "",
  });

  const user = useSelector((state) => state.user.data);
  const dispatch=useDispatch()
 
  const getsemtp = async () => {
    try {
      dispatch(setLoader(true))
      await axios.get("/getSmtp").then((res) => {
        dispatch(setLoader(false))
        setSmtpId(res?.data?.data.smtpId)
        setInitialValues({
          host: res.data.data?.host,
          port: res.data.data?.port,
          sslEnable: res.data.data?.sslEnable,
          authRequired: res.data.data?.authRequired,
          userName: res.data.data?.userName,
          password: res.data.data?.password,
          fromEmail: res.data.data?.fromEmail,
          subjectPrefix: res.data.data?.subjectPrefix,
        });
        
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  const validation = yup.object({
    host: yup.string().required("Required"),
    port: yup.string().required("Required"),
    sslEnable: yup.string().required("Required"),
    authRequired: yup.string().required("Required"),
    userName: yup.string().required("Required"),
    password: yup.string().required("Required"),
    fromEmail: yup.string().required("Required"),
    subjectPrefix: yup.string().required("Required"),
  });

  const addSMTP = async (values, { resetForm }) => {
    const payload = {
      host: values.host,
      port: values.port,
      sslEnable: values.sslEnable,
      authRequired: values.authRequired,
      userName: values.userName,
      password: values.password,
      fromEmail: values.fromEmail,
      subjectPrefix: values.subjectPrefix,
      uid: user?.userId,
      active: true,
      submit: submit,
      smtpId: smtpId|| "",
    };
    try {
      dispatch(setLoader(true))
      await axios.post("/addSmtp", payload).then((res) => {
        dispatch(setLoader(false))
        if (res?.data?.msgKey === "Success") {
          resetForm({
            values: {
              host: "",
              port: "",
              sslEnable: "",
              authRequired: "",
              userName: "",
              password: "",
              fromEmail: "",
              subjectPrefix: "",
            },
          });
          setTimeout(()=>{
            getsemtp();
          },[1000])
         
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const handalInput = (e) => {
    setEmailAddress(e.target.value);
  };

  const testAddress = async () => {
    try {
      dispatch(setLoader(true))
      await axios.post(`/sendTestMail/${emailaddress}`).then((res) => {
        dispatch(setLoader(false))
        if (res?.data?.msgKey === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `{res.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          setEmailAddress("");
        }
        Swal.fire({
          position: "top-end",
          icon: res?.data?.msgKey === "Failure" ? "error" : "success",
          title: `${res.data.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    } catch (error) {
      dispatch(setLoader(false))
    }
  };

  useEffect(() => {
    getsemtp();
  }, []);

  return (
    <>
      <Row className="mb-3">
        <h5>
          <b>SMTP Settings</b>
        </h5>
        <br />
        <text>
          SMTP Server is the server that used for your out going mail.Please
          specify your SMTP server settings so application can send/receive
          emails.
        </text>
      </Row>

      <Row>
        <Formik
          enableReinitialize={true}
          initialValues={initialValues}
          validationSchema={validation}
          onSubmit={addSMTP}
        >
          {({
            values,
            errors,
            handleChange,
            handleBlur,
            touched,
            handleSubmit,
            setFieldValue,
            setFieldError,
            isSubmitting,
          }) => {
            const err = Object.keys(errors)[0];
            scrollToErrorMessage(isSubmitting, err);
            return (
              <Form onSubmit={handleSubmit}>
                <Card className="mb-3">
                  <Row className="mt-2">
                    <h6>
                      <b>Mail Server Settings</b>
                    </h6>
                  </Row>
                  <hr />
                  <CardBody className="p-3">
                    <Row>
                      <Col lg={2}>
                        <Label>Mail Server Address</Label>
                      </Col>
                      <Col lg={4} md={6} sm={12}>
                        <Input
                          type="text"
                          id="host"
                          value={values.host}
                          placeholder="Mail Server Address"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.host && Boolean(errors.host)}
                        ></Input>
                        <ErrorMessage
                          name="host"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3 mb-3">
                      <Col lg={2}>
                        <Label>Mail Server Port</Label>
                      </Col>
                      <Col lg={4} md={6} sm={12}>
                        <Input
                          type="text"
                          id="port"
                          value={values.port}
                          placeholder="Mail Server Port"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          invalid={touched.port && Boolean(errors.port)}
                        ></Input>
                        <ErrorMessage
                          name="port"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col lg={2} md={6} sm={12}>
                        <Label>Use Secure (SSL) Connection</Label>
                      </Col>

                      <Col lg={4} md={6} sm={12}>
                        {" "}
                        <Input
                          type="checkbox"
                          id="sslEnable"
                          checked={values.sslEnable === true}
                          onChange={(e) => {
                            setFieldValue(
                              "sslEnable",
                              e.target.checked ? true : false
                            );
                          }}
                          onBlur={handleBlur}
                          invalid={
                            touched.sslEnable && Boolean(errors.sslEnable)
                          }
                        />
                        <ErrorMessage
                          name="sslEnable"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                  </CardBody>
                </Card>

                <h5>
                  <b>Logon Details</b>
                </h5>
                <Card className="p-4 mt-1">
                  <Row>
                    <Col lg={2} md={6} sm={12}>
                      Server Require Authentication
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="checkbox"
                        id="authRequired"
                        checked={values.authRequired === true}
                        onChange={(e) => {
                          setFieldValue(
                            "authRequired",
                            e.target.checked ? true : false
                          );
                        }}
                        onBlur={handleBlur}
                        invalid={
                          touched.authRequired && Boolean(errors.authRequired)
                        }
                      />

                      <ErrorMessage
                        name="authRequired"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2}>
                      <Label> User Name</Label>
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <Input
                        type="text"
                        id="userName"
                        value={values.userName}
                        placeholder="User Name"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={touched.userName && Boolean(errors.userName)}
                      ></Input>
                      <ErrorMessage
                        name="userName"
                        render={(msg) => (
                          <div className="text-danger">{msg}</div>
                        )}
                      />
                    </Col>
                  </Row>

                  <Row className="mt-3" mb="3">
                    <Col lg={2}>
                      {" "}
                      <Label for="password">Password</Label>
                    </Col>
                    <Col lg={4} md={6} sm={12}>
                      <FormGroup className="rmb-0" floating>
                        <Input
                          id="password"
                          name="password"
                          placeholder="password"
                          type={showPassword ? "text" : "password"}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          className="password"
                          bsSize="sm"
                          invalid={errors?.password && true}
                          value={values.password}
                        />

                        <FormFeedback>{errors?.password}</FormFeedback>
                        <i
                          className={cx({
                            bi: true,
                            "bi-eye-fill": showPassword,
                            "bi-eye-slash-fill": !showPassword,
                          })}
                          onClick={() => setShowPassword(!showPassword)}
                        ></i>
                      </FormGroup>
                    </Col>
                  </Row>
                </Card>

                <h5>
                  <b>Email Settings</b>
                </h5>
                <Card className="mt-1">
                  <CardBody className="p-4">
                    <Row>
                      <Col lg={2}>
                        <Label>From Email Address</Label>
                      </Col>
                      <Col lg={4} md={6} sm={12}>
                        <Input
                          id="fromEmail"
                          type="text"
                          placeholder="From Mail  Address"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          value={values.fromEmail}
                          invalid={
                            touched.fromEmail && Boolean(errors.fromEmail)
                          }
                        ></Input>
                        <ErrorMessage
                          name="fromEmail"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                    <Row className=" mt-3 mb-3">
                      <Col lg={2}>
                        <Label>Subject Prefix</Label>
                      </Col>
                      <Col lg={4} md={6} sm={12}>
                        <Input
                          type="text"
                          placeholder="Subject Prefix"
                          bsSize="sm"
                          id="subjectPrefix"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          value={values.subjectPrefix}
                          invalid={
                            touched.subjectPrefix &&
                            Boolean(errors.subjectPrefix)
                          }
                        ></Input>
                        <ErrorMessage
                          name="subjectPrefix"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </Col>
                    </Row>
                  </CardBody>
                </Card>

                <h5>
                  <b>Test Email Configuration</b>
                </h5>
                <Card className="p-4 mt-1">
                  <Row>
                    You can enter a test reicipient email below and click test
                    whether this email setting is valid by sending a test mail
                    to the specified address(es).
                  </Row>
                  <Row className="mt-3">
                    <Col lg={2} md={6} sm={12}>
                      Test recipient address
                    </Col>
                    <Col lg={4} md={6} sm={12} className="d-flex gap-3">
                      <Input type="test " onChange={(e) => handalInput(e)} />
                      <Button
                        className="sx"
                        style={{ color: "white" }}
                        onClick={testAddress}
                        color="primary"
                      >
                        Test
                      </Button>
                    </Col>
                  </Row>
                </Card>

                <Row>
                  <div className="d-flex justify-content-end gap-3 p-3">
                    <Button
                      size="sm"
                      type="submit"
                      color="primary"
                      onMouseOver={() => setSubmit(false)}
                      style={{ color: "white" }}
                    >
                      Save
                    </Button>
                 
                  </div>
                </Row>
              </Form>
            );
          }}
        </Formik>
      </Row>
    </>
  );
};
export default SmtpSettings;
