import React from "react";

export default function Repossession() {
  return <div>Repossession</div>;
}
