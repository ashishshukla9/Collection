import {useFormik } from "formik";
import { memo, useEffect, useState } from "react";
import {
  Row,
  Form,
  Col,
  Label,
  Input,
  Button,
} from "reactstrap";
import Field from "../../components/Field";
import axios from "axios";
import Select from "react-select";
import * as yup from "yup";
import cx from "classnames";
import ReconciliationTable from "./ReconciliationTable";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";
import { MultiSelect } from "react-multi-select-component";
const ReconciliationFilterForm = () => {
  const [landerList, setLanderList] = useState([]);
  const [portfolio, setPortfolio] = useState();
  const [productList, setProductList] = useState([]);
  const [lanIdList, setLanIdList] = useState([]);
  const [date, setDate] = useState();
  const [list, setList] = useState([]);
  const [branchIDs, setBranchIDs] = useState([]);
  const [isUploadDisabled, setIsUploadDisabled] = useState(true);
  const initialValues = {
    lender: "",
    lenderBranch: "",
    portfolio: "",
    productCode: "",
    date: "",
    lan: [],
  };
  const validation = yup.object({
    lender: yup.object().required("Required"),
    portfolio: yup.array().required("Required"),
    lenderBranch: yup.array().required("Required"),
    productCode: yup.array().required("Required"),
    date: yup.string().required("Required"),
  });
  const dispatch = useDispatch();
  const getLanderList = async () => {
    try {
      dispatch(setLoader(true));
      await axios.get("/getActiveLenderList").then((res) => {
        dispatch(setLoader(false));
        let Landers = [];
        res.data.data?.map((data) => {
          Landers.push({ label: data.lenderName, value: data.lenderId });
        });
        setLanderList(Landers);
      });
    } catch (error) {
      dispatch(setLoader(false));
    }
  };
  const getPortfolio = async () => {
    try {
      dispatch(setLoader(true));
      await axios.get("/getActivePortfolios").then((res) => {
        dispatch(setLoader(false));
        let Portpholio = [];
        res.data.data?.map((data) => {
          Portpholio.push({
            label: data.portfolioDescription,
            value: data.portfolioCode,
            id: data.portfolioId,
          });
        });
        setPortfolio(Portpholio);
      });
    } catch (error) {
      dispatch(setLoader(false));
    }
  };
  const getProductByPortfolioId = async () => {
    try {
      dispatch(setLoader(true));
      await axios
        .post(
          "/getProductByPortfolioList",
          formik?.values?.portfolio?.map((a) => a.value)
        )
        .then((res) => {
          dispatch(setLoader(false));
          let products = [];
          res.data.data?.map((data) => {
            products.push({
              label: data.productDescription,
              value: data.productCode,
            });
          });
          setProductList(products);
        });
    } catch (error) {
      dispatch(setLoader(false));
    }
  };
  const handleSubmit = async (values) => {
    try {
      const payload = {
        lender: values?.lender?.label,
        lenderBranch: values?.lenderBranch?.map((a) => a?.value),
        portfolio: values?.portfolio?.map((a) => a?.value),
        productCode: values?.productCode?.map((a) => a?.value),
        date: values?.date,
        lan: values?.lan?.map((a) => a?.value)?.join(",") || null,
      };
      dispatch(setLoader(true));
      axios.post(`/getReconciliationPreviewList`, payload).then((res) => {
        dispatch(setLoader(false));
        setList(res?.data?.data);
        setIsUploadDisabled(false);
      });
    } catch (error) {
      setIsUploadDisabled(true);
      dispatch(setLoader(false));
    }
  };
  const formik = useFormik({
    initialValues,
    validationSchema: validation,
    onSubmit: handleSubmit,
  });
  const getBranchByLanderId = () => {
    if (formik?.values?.lender?.value) {
      try {
        dispatch(setLoader(true));
        axios
          .get(`/getBranchesByLenderId/${formik?.values?.lender?.value}`)
          .then((res) => {
            dispatch(setLoader(false));
            const branchIdValue = [];
            res?.data?.data?.map((data) => {
              branchIdValue.push({
                label: data.branchName,
                value: data.branchName,
              });
            });
            setBranchIDs(branchIdValue);
          });
      } catch (error) {
        dispatch(setLoader(false));
      }
    }
  };
  const getLanId = async () => {
    const payload = {
      lender: formik?.values?.lender?.label,
      lenderBranch: formik?.values?.lenderBranch?.map((a) => a?.value),
      portfolio: formik?.values?.portfolio?.map((a) => a?.value),
      productCode: formik?.values?.productCode?.map((a) => a?.value),
      date: formik?.values?.date,
    };
    try {
      dispatch(setLoader(true));
      await axios.post(`/getLanListForReconciliation`, payload).then((res) => {
        dispatch(setLoader(false));
        const data = res.data.data;
        const newOptions = data.map((item) => ({
          label: item,
          value: item,
        }));
        setLanIdList(newOptions);
      });
    } catch (error) {
      dispatch(setLoader(false));
    }
  };
  useEffect(() => {
    if (formik?.values?.portfolio) {
      getProductByPortfolioId();
    }
  }, [formik?.values?.portfolio]);

  useEffect(() => {
    getLanderList();
    getPortfolio();
  }, []);

  useEffect(() => {
    if (formik?.values?.lender) {
      getBranchByLanderId();
    }
  }, [formik?.values?.lender]);
  useEffect(() => {
    const values = Object.values(formik?.values)
      ?.filter(Boolean)
      ?.filter((a) => (Array.isArray(a) ? a.length : a));
    if (values?.length === 5) {
      getLanId();
    }
  }, [formik?.values]);

  return (
    <>
      <Form onSubmit={formik?.handleSubmit} autoComplete="off" className="p-3">
        <Row>
          <Col lg={6}>
            <Field
              isRequired
              label="Lender"
              errorMessage={formik?.touched?.lender && formik?.errors?.lender}
            >
              <Select
                id="lender"
                inputId="lender"
                placeholder="Select Lender"
                options={landerList}
                closeMenuOnSelect={false}
                hideSelectedOptions={false}
                value={formik?.values.lender}
                onChange={(e) => {
                  formik?.setFieldValue("lender", e);
                  formik?.setFieldValue("lenderBranch", []);
                  formik?.setFieldValue("lan", []);
                  getBranchByLanderId();
                }}
                className={cx({
                  abc: formik?.touched.lender && Boolean(formik?.errors.lender),
                })}
                onBlur={formik?.handleBlur}
                menuPosition="fixed"
                classNamePrefix="react-select"
              />
            </Field>
          </Col>
          <Col lg={6}>
            <Field
              isRequired
              label="Lender Branch"
              errorMessage={
                formik?.touched?.lenderBranch && formik?.errors?.lenderBranch
              }
            >
              <Select
                id="lenderBranch"
                inputId="lenderBranch"
                placeholder="Branch Id"
                options={branchIDs}
                closeMenuOnSelect={false}
                hideSelectedOptions={false}
                value={formik?.values.lenderBranch}
                isMulti
                onChange={(e) => {
                  formik?.setFieldValue("lenderBranch", e);
                  formik?.setFieldValue("lan", []);
                }}
                className={cx({
                  abc:
                    formik?.touched.lenderBranch &&
                    Boolean(formik?.errors.lenderBranch),
                })}
                onBlur={formik?.handleBlur}
                menuPosition="fixed"
                classNamePrefix="react-select"
              />
            </Field>
          </Col>
        </Row>
        <Row>
          <Col lg={6}>
            <Field
              isRequired
              label="Portfolio"
              errorMessage={
                formik?.touched?.portfolio && formik?.errors?.portfolio
              }
            >
              <Select
                id="portfolio"
                inputId="portfolio"
                placeholder="Select Portfolio"
                options={portfolio}
                onChange={(e) => {
                  formik?.setFieldValue("portfolio", e);
                  formik?.setFieldValue("productCode", []);
                  formik?.setFieldValue("lan", []);
                }}
                classNamePrefix="react-select"
                closeMenuOnSelect={false}
                hideSelectedOptions={false}
                value={formik?.values?.portfolio}
                isClearable={true}
                className={cx({
                  abc:
                    formik?.touched.portfolio &&
                    Boolean(formik?.errors.portfolio),
                })}
                isMulti
                onBlur={formik?.handleBlur}
                menuPosition="fixed"
              />
            </Field>
          </Col>
          <Col lg={6}>
            <Field
              isRequired
              label="Product"
              errorMessage={
                formik?.touched?.productCode && formik?.errors?.productCode
              }
            >
              <MultiSelect
                options={productList}
                value={formik?.values?.productCode}
                onChange={(e) => {
                  formik?.setFieldValue("productCode", e);
                  formik?.setFieldValue("lan", []);
                }}
                overrideStrings={{
                  selectSomeItems: "Select...",
                  allItemsAreSelected: "Select All",
                  selectAll: "Select All",
                }}
                labelledBy={"Select"}
                isCreatable={true}
              />
            </Field>
          </Col>
        </Row>
        <Row>
          <Col lg={6}>
            {" "}
            <Field
              isRequired
              label="Reconciliation Month"
              errorMessage={formik?.touched?.date && formik?.errors?.date}
            >
              <Input
                id="date"
                inputId="date"
                type="month"
                onChange={(e) => {
                  formik?.setFieldValue("date", e?.target.value);
                  formik?.setFieldValue("lan", []);
                  setDate(e?.target.value);
                }}
                onBlur={formik?.handleBlur}
                invalid={formik?.touched.date && Boolean(formik?.errors.date)}
              />
            </Field>
          </Col>
          <Col>
            <Field label="Search Case">
              <Col lg={12}>
                <Select
                  bsSize="sm"
                  placeholder="Search Case"
                  options={lanIdList}
                  name="lan"
                  value={formik?.values?.lan}
                  onChange={(e) => {
                    formik?.setFieldValue("lan", e);
                  }}
                  classNamePrefix="react-select"
                  isClearable={true}
                  closeMenuOnSelect={false}
                  hideSelectedOptions={false}
                  isMulti
                  id="lan"
                  inputId="lan"
                  menuPosition="fixed"
                />
              </Col>
            </Field>
          </Col>
        </Row>

        <div className="d-flex justify-content-end mx-4">
          <Button type="submit" size="sm" color="primary">
            Preview
          </Button>
        </div>
      </Form>
      <br />
      <ReconciliationTable
        list={list}
        isUploadDisabled={isUploadDisabled}
        searchLanID={lanIdList}
        date={date}
        selectedLAN={formik?.values?.lan}
      />
    </>
  );
};

export default memo(ReconciliationFilterForm);
