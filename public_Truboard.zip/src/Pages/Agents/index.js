import React from "react";

export default function Agent() {
  return <div>Agent</div>;
}
