import * as yup from "yup";
import { Column } from "primereact/column";
import Swal from "sweetalert2";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { DataTable } from "primereact/datatable";
import { Row } from "reactstrap";

const MyCapaignTable = ({
  setCampaginSchedule,
  setView,
  setEdit,
  setGetViewData,
  list,
}) => {
  const getDataForView = async (data) => {
    try {
      await axios
        .get(`/getCampScheduleByCampId/${data?.campaignId}`)
        .then((res) => {
          setGetViewData(res.data.data);
          setCampaginSchedule(true);
        });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      {/* //Table */}
      <Row>
        <h5>
          <b>My Campaigns</b>
        </h5>
      </Row>
      <br />
      <DataTable
        className="commonTable"
        rowsPerPageOptions={[10, 25, 50, 100]}
        rows={10}
        value={list}
        tableStyle={{ minWidth: "50rem" }}
        sortMode="multiple"
        removableSort
      >
        <Column field="campaignName" header="Campaign Name" sortable></Column>
        <Column field="startDate" header="Start Date" sortable></Column>
        <Column field="endDate" header="End Date" sortable></Column>
        <Column field="templateName" header="Template" sortable></Column>
        <Column
          header="Action"
          body={(rowData) => (
            <>
              <i
                className="bi bi-eye-fill text-primary"
                style={{ cursor: "pointer" }}
                onClick={() => {
                  getDataForView({ ...rowData });
                  setView(true);
                }}
              />
              <i
                className="bi bi-pencil-square text-danger"
                style={{ cursor: "pointer" }}
                onClick={() => {console.log(rowData, "editclick")
                  getDataForView({ ...rowData });
                  setEdit(true)
                }}
              />
            </>
          )}
        ></Column>
      </DataTable>
    </>
  );
};

export default MyCapaignTable;
