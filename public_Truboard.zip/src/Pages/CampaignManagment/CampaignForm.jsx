import { Fragment, memo, useEffect, useMemo, useRef, useState } from "react";
import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  FormGroup,
  Input,
  Label,
  Row,
} from "reactstrap";
import * as yup from "yup";
import CustomField from "../../components/Field";
import Select, { components } from "react-select";
import {
  CHARACTER_ONLY,
  COMMA_PINCODE,
  COMMA_SEPARATED_TEXT,
  COMMA_SEPARATED_TEXT_NUMBER,
  DECIMAL_NUMBER,
  NUMBER_ONLY,
} from "../../utils/regex";
import { useFormik } from "formik";
import { Dialog } from "primereact/dialog";
import { useSelector } from "react-redux";
import axios from "axios";
import Swal from "sweetalert2";
import classNames from "classnames";

const CampaignForm = (props) => {
  const [optionLabel, setOptionLabel] = useState("");
  const [selectedPincode, setSelectedPincode] = useState("");
  const [activePincodes, setActivePincodes] = useState([]);
  const [maxPincodePages, setMaxPincodePages] = useState(0);
  const [pincodeList, setPincodeList] = useState([]);
  const [options, setOptions] = useState([]);
  const [pincodeId, setPincodeId] = useState("");
  const [optiondata, setoptiondata] = useState(null);
  const [inputType, setInputType] = useState(false);
  const [currentPincodePage, setCurrentPincodePage] = useState(1);
  const [priview, setPrivew] = useState(false);
  const [isSelected, setIsSelected] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});
  const [insertModal, setInsertModal] = useState(false);
  const [filterValue, setFilterValue] = useState([]);
  const [text, setText] = useState("");
  const textareaRef = useRef(null);
  const user = useSelector((state) => state.user.data);
  const IS_EDIT = useMemo(
    () => Boolean(Object.keys(props?.selectedData)?.length),
    []
  );
  const initialValues = {
    campaignTemplateId: IS_EDIT
      ? props?.selectedData?.campaignTemplateId
      : null,
    templateName: IS_EDIT ? props?.selectedData?.templateName : "",
    channel: IS_EDIT ? props?.selectedData?.channel : "",
    templateType: IS_EDIT ? props?.selectedData?.templateType : "",
    option: "",
    value: "",
    subject: IS_EDIT ? props?.selectedData?.subject : "",
    templateBodies: IS_EDIT ? props?.selectedData?.templateBody : "",
    active: IS_EDIT ? props?.selectedData?.active : true,
    templateId: IS_EDIT ? props?.selectedData?.templateId || "" : "",
    smsType: IS_EDIT ? props?.selectedData?.smsType || "" : "",
    templateFilter: IS_EDIT ? props?.selectedData?.templateFilter : [],
  };
  const onkeyEnterPincode = (event, setFieldValue, preValues) => {
    if (event.key === "Enter") {
      event.preventDefault();
      const filtered_people = activePincodes.filter((person) =>
        pincodeList.includes(person?.label?.toString())
      );
      setFieldValue("pincode", [...preValues, ...filtered_people]);
    }
  };
  const validation = yup.object({
    templateName: yup
      .string()
      .min(1, "Too Short!")
      .max(30, "Too Long!")
      .required("Required"),
    channel: yup.string().required("Required"),
    templateFilter: yup
      .array()
      .test("templateType", "Atleast 1 filter is required", (val) => {
        return Boolean(filterValue.length);
      }),
    subject: yup.string().when("channel", {
      is: (channel) => channel === "Email",
      then: () =>
        yup
          .string()
          .required("Required")
          .max(100, "Too Long!")
          .min(1, "Too Short!"),
    }),
    active: yup.string(),
    templateId: yup.number().when("channel", {
      is: (ChannelVal) => ChannelVal === "SMS",
      then: () =>
        yup
          .string()
          .required("Required")
          .test(
            "len",
            "Must be exactly 100 characters",
            (val) => val.toString().length <= 100
          ),
    }),
    smsType: yup.string().when("channel", {
      is: (ChannelVal) => ChannelVal === "SMS",
      then: () => yup.string().required("Required"),
    }),
  });
  const filterValidation = yup.object().shape({
    templateType: yup
      .string()
      .required("Required")
      // .test('templateType', "The Agency filter can't be applied with other existing filters", (val) => {
      //     return !(val === "Agency" && filterValue?.length > 0)
      // })
      .test(
        "templateType",
        "The customer filter can't be applied with other existing filters",
        (val) => {
          return !(val === "Customer" && filterValue?.length > 0);
        }
      ),
    option: yup.string().when(["channel", "templateType"], {
      is: (channel, templateType) =>
        [
          "Agency",
          "Zone",
          "Region",
          "City",
          "State",
          "Lender",
          "Portfolio",
          "Product",
          "Payment Status",
          "Bucket",
          "DPD",
          "POS",
          "TOS",
          "Dormancy",
          "Amount",
          "Status",
        ]?.includes(templateType),
      then: () =>
        yup
          .string()
          .required("Required")
          .test(
            "check",
            "Can't apply '>' or '<' operator with '=' operator",
            (val, b) => {
              return !filterValue?.find(
                (a) =>
                  [
                    "Bucket",
                    "DPD",
                    "POS",
                    "TOS",
                    "Dormancy",
                    "Amount",
                  ]?.includes(a?.templateType) &&
                  a?.option === "=" &&
                  a?.templateType === b?.parent?.templateType &&
                  [">", "<"]?.includes(val)
              );
            }
          )
          .test(
            "check",
            "Can't apply '=' operator with '<' or '>' operator",
            (val, b) => {
              return !filterValue?.find(
                (a) =>
                  [
                    "Bucket",
                    "DPD",
                    "POS",
                    "TOS",
                    "Dormancy",
                    "Amount",
                  ]?.includes(a?.templateType) &&
                  ["<", ">"]?.includes(a?.option) &&
                  a?.templateType === b?.parent?.templateType &&
                  val === "="
              );
            }
          )
          .test("check", "isAlready exist.", (val, b) => {
            return !(
              Object.keys(
                filterValue?.find(
                  (a) =>
                    a?.option === val &&
                    a?.templateType === b?.parent?.templateType
                ) || {}
              ).length > 0
            );
          }),
    }),
    value: yup.string().when(["channel", "templateType"], {
      is: (channel, templateType) =>
        [
          "LAN ID",
          "Bucket",
          "DPD",
          "POS",
          "TOS",
          "Dormancy",
          "Amount",
        ]?.includes(templateType),
      then: () =>
        yup
          .string()
          .required("Required")
          .test("check", "Enter valid number", (val, b) => {
            return ["Amount", "POS", "TOS"]?.includes(b?.parent?.templateType)
              ? DECIMAL_NUMBER.test(val) || val === ""
              : true;
          })
          .test("check", "Enter valid pincode", (val, b) => {
            return ["Pincode"]?.includes(b?.parent?.templateType)
              ? COMMA_PINCODE.test(val) || val === ""
              : true;
          }),
    }),
  });
  const filterOption = ({ label }, filterValue) => {
    if (filterValue === "") return true;
    const filterValueSplit = filterValue.split(/[, ]+/);
    for (const filterValue of filterValueSplit) {
      if (
        filterValue !== "" &&
        label
          ?.toString()
          ?.toLowerCase()
          ?.includes(filterValue?.toString()?.toLowerCase())
      )
        return true;
    }
    return false;
  };
  const handleSubmit = async (values, { resetForm }) => {
    const payload = {
      campaignTemplateId: values?.campaignTemplateId,
      templateName: values.templateName,
      channel: values.channel,
      templateType: "Customer",
      subject: values.subject || "",
      uid: user?.userId,
      active: values.active,
      submit: false,
      templateBody: text,
      templateId: values?.templateId || null,
      smsType: values?.smsType || null,
      selectedPincodes: values.option, // Include selected pincodes
      templateFilter: filterValue?.map((a) => {
        const templateType = a?.templateType || "";
        const value = a?.value || "";
        const templateForParts = [templateType, value].filter(
          (part) => part.trim() !== ""
        );
        const templateFor = templateForParts.join(" ");
        return {
          campaignTemplateFilterId: a?.campaignTemplateFilterId || null,
          templateFor: templateFor,
          operator: [
            "DPD",
            "Amount",
            "Bucket",
            "POS",
            "TOS",
            "Dormancy",
          ].includes(templateType)
            ? a?.option
            : null,
          value: ["DPD", "Amount", "Bucket", "POS", "TOS", "Dormancy"].includes(
            templateType
          )
            ? value
            : null,
          masterName: ["LAN ID"].includes(templateType)
            ? value
            : [
                "Product",
                "Agency",
                "Pincode",
                "Zone",
                "Region",
                "City",
                "State",
                "Lender",
                "Portfolio",
                "Payment Status",
                "Status",
              ].includes(templateType)
            ? a?.option
            : null,
        };
      }),
    };
    try {
      // if (payload?.campaignTemplateId ) {
      const res = await axios
        .post(`/addCampaignTemplate`, payload)
        .then((res) => {
          if (res?.data?.msgKey === "Success") {
            resetForm({
              values: {
                campaignTemplateId: "",
                templateName: "",
                channel: "",
                templateType: "",
                subject: "",
                uid: "",
                active: true,
                submit: false,
                templateBodies: "",
                templateId: "",
              },
            });
            if (IS_EDIT) {
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${"Campaign Template updated successfully"}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
            if (!IS_EDIT) {
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${"Campaign Template added successfully"}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
            props?.getTableDetails();
            props?.onClose();
          } else {
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${res?.data?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        });
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const formik = useFormik({
    initialValues,
    validationSchema: validation,
    onSubmit: handleSubmit,
  });
  const { setFieldValue, values, handleChange, handleBlur, touched, errors } =
    formik;
  const channelOptions = useMemo(
    () => [
      { label: "Email", value: "Email" },
      { label: "SMS", value: "SMS" },
    ],
    []
  );
  const tamplateTypeoptins = useMemo(
    () => [
      { label: "Customer", value: "Customer" },
      { label: "LAN ID", value: "LAN ID" },
      { label: "Agency", value: "Agency" },
      { label: "Lender", value: "Lender" },
      { label: "Portfolio", value: "Portfolio" },
      { label: "Product", value: "Product" },
      { label: "Zone", value: "Zone" },
      { label: "Region", value: "Region" },
      { label: "State", value: "State" },
      { label: "City", value: "City" },
      { label: "Pincode", value: "Pincode" },
      { label: "Payment Status", value: "Payment Status" },
      { label: "Bucket", value: "Bucket" },
      { label: "DPD", value: "DPD" },
      { label: "POS", value: "POS" },
      { label: "TOS", value: "TOS" },
      { label: "Dormancy", value: "Dormancy" },
      { label: "Amount", value: "Amount" },
      { label: "Status", value: "Status" },
    ],
    []
  );
  const operatorsOption = useMemo(
    () => [
      { label: ">", value: ">" },
      { label: "<", value: "<" },
      { label: "=", value: "=" },
    ],
    []
  );
  const statusOption = useMemo(
    () => [
      { label: "In Progress", value: "In Progress" },
      { label: "Exception", value: "Exception" },
      { label: "Payment", value: "Payment" },
      { label: "PTP", value: "PTP" },
      { label: "Dispute", value: "Dispute" },
      { label: "Surrender", value: "Surrender" },
      { label: "Schedule Visit", value: "Schedule Visit" },
    ],
    []
  );
  const paymentStatusOptions = useMemo(
    () => [
      { label: "Approved", value: "Approved" },
      { label: "Reject", value: "Reject" },
    ],
    []
  );

  const removeFilter = (i) => {
    const updatedFilter = filterValue?.filter((a, index) => i !== index);
    setFilterValue(updatedFilter);
  };
  const clickAddFilter = (values, isAdd, isCommaSeparated) => {
    if (!filterValue?.find((a) => a?.templateType === "Customer")) {
      filterValidation
        .validate(values, { abortEarly: false })
        .then(() => {
          setValidationErrors({});
          if (isAdd) {
            if (isCommaSeparated) {
              const val = [];
              values?.value.split(",")?.map((a) => {
                val.push({
                  id: filterValue?.length + val?.length + 1,
                  templateType: values?.templateType,
                  option: values?.option,
                  value: values?.value,
                });
              });
              setFilterValue([...filterValue, ...val]);
            } else {
              const val = {
                id: filterValue?.length + 1,
                templateType: values?.templateType,
                option: values?.option,
                value: values?.value,
              };
              setFilterValue([...filterValue, val]);
            }
          }
        })
        .catch((errors) => {
          setValidationErrors({});
          const errorsObject = {};
          errors?.inner?.forEach((error) => {
            errorsObject[error.path] = error.message;
          });
          setValidationErrors(errorsObject);
        });
    }
  };
  const getAllPincodes = async () => {
    try {
      const res = await axios.get("/getAllPincodes/1/10");
      const ops = [];
      res?.data?.response?.forEach((data) => {
        if (data?.active === "Y") {
          ops.push({
            label: data.pincode,
            value: data.pincodeId,
          });
        }
      });
      setActivePincodes(ops);
    } catch (error) {
      setActivePincodes([]);
    }
  };
  const getAllPincodeByCity = async (pincodeId, isRestart) => {
    if (pincodeId?.length) {
      try {
        const res = await axios.get(
          `/getPincodeByCity/${pincodeId}/${
            isRestart ? 1 : currentPincodePage
          }/30`
        );

        const ops = res?.data?.response?.map((a) => ({
          label: a.pincode,
          value: a.pincodeId,
        }));
        const maxNumberOfPage = Math.ceil(
          res?.data?.totalApplicationCount / 30 || 0
        );
        setMaxPincodePages(maxNumberOfPage);
        if (isRestart) {
          setActivePincodes(ops);
        } else {
          setActivePincodes([...activePincodes, ...ops]);
        }
        setPincodeId(pincodeId);
      } catch (error) {
        setPincodeId("");
        setActivePincodes([]);
      }
    } else {
      getAllPincodes();
      setPincodeId("");
    }
  };
  useEffect(() => {
    if (pincodeId && currentPincodePage > 1) {
      getAllPincodeByCity(pincodeId, false);
    }
  }, [currentPincodePage]);
  useEffect(() => {
    const opLabel = [
      "DPD",
      "Amount",
      "Bucket",
      "POS",
      "TOS",
      "Dormancy",
    ]?.includes(formik?.values?.templateType)
      ? "Operators"
      : formik?.values?.templateType === "Agency"
      ? "Agency"
      : formik?.values?.templateType === "Zone"
      ? "Zone"
      : formik?.values?.templateType === "Region"
      ? "Region"
      : formik?.values?.templateType === "State"
      ? "State"
      : formik?.values?.templateType === "City"
      ? "City"
      : formik?.values?.templateType === "Pincode"
      ? "Pincode"
      : formik?.values?.templateType === "Lender"
      ? "Lender"
      : formik?.values?.templateType === "Product"
      ? "Product"
      : formik?.values?.templateType === "Portfolio"
      ? "Portfolio"
      : formik?.values?.templateType === "Payment Status"
      ? "Payment Status"
      : formik?.values?.templateType === "Status" && "Status";
    setOptionLabel(opLabel);

    const op = ["DPD", "Amount", "Bucket", "POS", "TOS", "Dormancy"]?.includes(
      formik?.values?.templateType
    )
      ? operatorsOption
      : formik?.values?.templateType === "Agency"
      ? props?.agencyData
      : formik?.values?.templateType === "Zone"
      ? props?.zoneData
      : formik?.values?.templateType === "Region"
      ? props?.regionData
      : formik?.values?.templateType === "City"
      ? props?.cityData
      : formik?.values?.templateType === "Pincode"
      ? props?.pincodeData
      : formik?.values?.templateType === "State"
      ? props?.stateData
      : formik?.values?.templateType === "Lender"
      ? props?.lenderData
      : formik?.values?.templateType === "Product"
      ? props?.productData
      : formik?.values?.templateType === "Portfolio"
      ? props?.portfolioData
      : formik?.values?.templateType === "Payment Status"
      ? paymentStatusOptions
      : formik?.values?.templateType === "Status" && statusOption;
    setOptions(op);

    const inType = [
      "DPD",
      "Amount",
      "Bucket",
      "POS",
      "TOS",
      "Dormancy",
      "LAN ID",
    ]?.includes(formik?.values?.templateType);
    setInputType(inType);
  }, [formik?.values?.templateType]);

  useEffect(() => {
    if (IS_EDIT) {
      const filter = props?.selectedData?.templateFilter?.map((a) => ({
        campaignTemplateFilterId: a?.campaignTemplateFilterId,
        templateType: a?.templateFor,
        option: ["DPD", "Amount", "Bucket", "POS", "TOS", "Dormancy"]?.includes(
          a?.templateFor
        )
          ? a?.operator
          : [
              "Product",
              "Pincode",
              "Agency",
              "Region",
              "City",
              "State",
              "Lender",
              "Zone",
              "Portfolio",
              "Payment Status",
              "Status",
            ]?.includes(a?.templateFor)
          ? a?.masterName
          : null,
        value: ["DPD", "Amount", "Bucket", "POS", "TOS", "Dormancy"]?.includes(
          a?.templateFor
        )
          ? a?.value
          : ["LAN ID"]?.includes(a?.templateFor)
          ? a?.masterName
          : null,
      }));
      setFilterValue(filter);
    }
  }, [IS_EDIT]);
  useEffect(() => {
    formik?.setFieldValue("templateType", "");
    formik?.setFieldValue("option", "");
    formik?.setFieldValue("value", "");
  }, [filterValue]);
  useEffect(() => {
    if (IS_EDIT) {
      setText(props?.selectedData?.templateBody);
    }
  }, [IS_EDIT]);
  let appendedText = "";
  useEffect(() => {
    if (!optiondata || !textareaRef.current) {
      return; // Skip the effect if optiondata is null or textareaRef is not available
    }
    const startPos = textareaRef.current.selectionStart;
    const endPos = textareaRef.current.selectionEnd;
    const newText =
      text.substring(0, startPos) + optiondata + text.substring(endPos);
    setText(newText);
    textareaRef.current.selectionStart = textareaRef.current.selectionEnd =
      startPos + optiondata.length;
    setInsertModal(false);
    setoptiondata(null);
  }, [text, optiondata, textareaRef]);
  useEffect(() => {
    const search = setTimeout(async () => {
      if (pincodeList?.filter(Boolean).length) {
        const payload = {
          pincode: pincodeList.map((str) => parseInt(str, 10)),
        };
        await axios
          .post(`/getPincodeByPincodeForCommaSeperated/0/0`, payload)
          .then(({ data }) => {
            if (data.response && data.response.length > 0) {
              data.response.forEach((item, index) => {
                // console.log(`Response Item ${index + 1}:`, item);
              });
              const tempData = [];
              data.response.forEach((item) => {
                if (item.active === "Y") {
                  tempData.push({
                    label: item.pincode,
                    value: item.pincodeId,
                  });
                }
              });
              setActivePincodes(tempData);
              // console.log("Active Pincodes after API call:", tempData); // Log the pincodes after setting
            } else {
              console.log("No response data found.");
            }
          })
          .catch((error) => {
            console.log("API Error:", error);
          });
      }
    }, 1000);
    return () => {
      clearTimeout(search);
    };
  }, [pincodeList]);
  return (
    <Fragment>
      <Form onSubmit={formik.handleSubmit}>
        <Card className="mb-3 p-3">
          <CardBody>
            <Row>
              <Col md={6} sm={12}>
                <CustomField
                  isRequired
                  label="Template Name"
                  errorMessage={
                    formik?.touched?.templateName &&
                    formik?.errors?.templateName
                  }
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="templateName"
                    placeholder="Template Name"
                    value={formik?.values.templateName}
                    onChange={formik?.handleChange}
                    onBlur={formik?.handleBlur}
                    invalid={
                      formik?.touched?.templateName &&
                      Boolean(formik?.errors?.templateName)
                    }
                  />
                </CustomField>
              </Col>
              <Col md={6} sm={12}>
                <CustomField
                  isRequired
                  label="Channel Mode"
                  errorMessage={
                    formik?.touched?.channel && formik?.errors?.channel
                  }
                >
                  <Select
                    bsSize="sm"
                    options={channelOptions}
                    type="text"
                    id="channel"
                    placeholder="Channel Mode"
                    value={channelOptions?.filter(
                      (a) => a?.value === formik?.values.channel
                    )}
                    onChange={(e) => {
                      formik?.setFieldValue("channel", e?.value);
                      setIsSelected(true);
                    }}
                    onBlur={formik?.handleBlur}
                    invalid={
                      formik?.touched?.channel &&
                      Boolean(formik?.errors?.channel)
                    }
                    className={classNames({
                      abc:
                        formik?.touched?.channel &&
                        Boolean(formik?.errors?.channel),
                    })}
                    is
                    classNamePrefix="react-select"
                  />
                </CustomField>
              </Col>
            </Row>
            <Row className="createCampaignFilter bg-light">
              <Col sm={12} md={3}>
                <CustomField
                  isRequired
                  label="Template For"
                  errorMessage={
                    validationErrors?.templateType ||
                    (formik?.touched?.templateType &&
                      (formik?.errors?.templateType ||
                        formik?.errors?.templateFilter))
                  }
                  containerClassName="campaignFilterField"
                >
                  <Select
                    bsSize="sm"
                    options={tamplateTypeoptins}
                    id="templateType"
                    placeholder="Template For"
                    value={tamplateTypeoptins?.filter(
                      (a) => a?.value === formik?.values.templateType
                    )}
                    onChange={(e) => {
                      formik?.setFieldValue("templateType", e?.value);
                      formik?.setFieldValue("option", "");
                      formik?.setFieldValue("value", "");
                      setValidationErrors({});
                      clickAddFilter({
                        ...formik?.values,
                        templateType: e?.value,
                      });
                    }}
                    onBlur={formik?.handleBlur}
                    invalid={
                      formik?.touched?.templateType &&
                      Boolean(formik?.errors?.templateType)
                    }
                    className={classNames({
                      abc:
                        formik?.touched?.templateType &&
                        Boolean(formik?.errors?.templateType),
                    })}
                    classNamePrefix="react-select"
                    isDisabled={filterValue?.find((a) =>
                      ["Customer"]?.includes(a?.templateType)
                    )}
                  />
                </CustomField>
              </Col>
              {optionLabel && (
                <Col sm={12} md={3}>
                  <CustomField
                    isRequired
                    label={optionLabel}
                    errorMessage={validationErrors?.option}
                    containerClassName="campaignFilterField"
                  >
                    {optionLabel === "Pincode" ? (
                      <>
                        <Select
                          bsSize="sm"
                          options={activePincodes}
                          ids={"pincode"}
                          value={activePincodes.filter((a) =>
                            formik?.values.option?.includes(a.label)
                          )} // Set selected options
                          onChange={(selectedOptions) => {
                            const values = Array.isArray(selectedOptions)
                              ? selectedOptions.map((option) => option.label)
                              : selectedOptions
                              ? [selectedOptions.label]
                              : [];
                            const optionString = values.join(", "); // Join values to create a string
                            formik?.setFieldValue("option", optionString); // Set option as a string
                            formik?.setFieldValue("value", ""); // Clear any other field if necessary
                            clickAddFilter({
                              ...formik?.values,
                              option: optionString,
                            }); // Pass the updated option string for the payload
                          }}
                          onBlur={formik?.handleBlur}
                          isMulti
                          onInputChange={(e) => setPincodeList(e.split(","))}
                          onKeyDown={(e) =>
                            onkeyEnterPincode(e, setFieldValue, values?.pincode)
                          }
                          filterOption={filterOption}
                          onMenuScrollToBottom={(e) => {
                            if (currentPincodePage < maxPincodePages) {
                              setCurrentPincodePage((prev) => prev + 1);
                            }
                          }}
                        />
                        <h2>{selectedPincode}</h2>{" "}
                        {/* Display the selected pincode label here */}
                      </>
                    ) : (
                      <Select
                        bsSize="sm"
                        options={options}
                        id="option"
                        value={
                          options?.find(
                            (a) => a?.value === formik?.values.option
                          ) || null
                        }
                        onChange={(e) => {
                          formik?.setFieldValue("option", e?.value);
                          formik?.setFieldValue("value", e?.label); // Assuming 'label' is the user-friendly name of the selected option
                          clickAddFilter({
                            ...formik?.values,
                            option: e?.value,
                            value: e?.label,
                          });
                        }}
                        onBlur={formik?.handleBlur}
                        invalid={
                          formik?.touched?.option &&
                          Boolean(formik?.errors?.option)
                        }
                        className={classNames({
                          abc:
                            formik?.touched?.option &&
                            Boolean(formik?.errors?.option),
                        })}
                        classNamePrefix="react-select"
                      />
                    )}
                  </CustomField>
                </Col>
              )}
              {inputType && (
                <Col sm={12} md={3}>
                  <CustomField
                    isRequired
                    label="Value"
                    errorMessage={validationErrors?.value}
                    containerClassName="campaignFilterField"
                  >
                    <Input
                      type="text"
                      name="value"
                      onChange={(e) => {
                        const isComma =
                          e.target.value[e.target.value?.length - 1] === ",";
                        if (formik?.values?.templateType === "Pincode") {
                          if (
                            COMMA_PINCODE.test(e?.target?.value) ||
                            e?.target?.value === "" ||
                            isComma
                          ) {
                            formik?.setFieldValue("value", e?.target?.value);
                            clickAddFilter({
                              ...formik?.values,
                              value: e?.target?.value,
                            });
                          }
                        } else if (
                          ["State", "City"]?.includes(
                            formik?.values?.templateType
                          )
                        ) {
                          if (
                            COMMA_SEPARATED_TEXT.test(e?.target?.value) ||
                            e?.target?.value === "" ||
                            isComma
                          ) {
                            formik?.setFieldValue("value", e?.target?.value);
                            clickAddFilter({
                              ...formik?.values,
                              value: e?.target?.value,
                            });
                          }
                        } else if (
                          ["DPD", "Bucket", "Dormancy"]?.includes(
                            formik?.values?.templateType
                          )
                        ) {
                          if (
                            NUMBER_ONLY.test(e?.target?.value) ||
                            e?.target?.value === ""
                          ) {
                            formik?.setFieldValue("value", e?.target?.value);
                            clickAddFilter({
                              ...formik?.values,
                              value: e?.target?.value,
                            });
                          }
                        } else if (
                          ["Amount", "POS", "TOS"]?.includes(
                            formik?.values?.templateType
                          )
                        ) {
                          const isDot =
                            e?.target?.value?.indexOf(".") ===
                            e?.target?.value?.length - 1;
                          if (
                            DECIMAL_NUMBER.test(e?.target?.value) ||
                            e?.target?.value === "" ||
                            isDot
                          ) {
                            formik?.setFieldValue("value", e?.target?.value);
                            clickAddFilter({
                              ...formik?.values,
                              value: e?.target?.value,
                            });
                          }
                        } else if (
                          ["LAN ID"]?.includes(formik?.values?.templateType)
                        ) {
                          if (
                            COMMA_SEPARATED_TEXT_NUMBER.test(
                              e?.target?.value
                            ) ||
                            e?.target?.value === "" ||
                            isComma
                          ) {
                            formik?.setFieldValue("value", e?.target?.value);
                            clickAddFilter({
                              ...formik?.values,
                              value: e?.target?.value,
                            });
                          }
                        } else if (
                          CHARACTER_ONLY.test(e?.target?.value) ||
                          e?.target?.value === ""
                        ) {
                          formik?.setFieldValue("value", e?.target?.value);
                          clickAddFilter({
                            ...formik?.values,
                            value: e?.target?.value,
                          });
                        }
                      }}
                      value={formik?.values?.value}
                      onBlur={formik?.handleBlur}
                      size="sm"
                    />
                  </CustomField>
                </Col>
              )}
              <Col sm={12} md={3}>
                <Button
                  type="button"
                  size="sm"
                  color="primary"
                  className="addFilterBtn"
                  onClick={() => {
                    const filterData = formik?.values;
                    clickAddFilter(
                      filterData,
                      true,
                      ["Pincode", "LAN ID", "State", "City"].includes(
                        filterData?.templateType
                      )
                    );
                  }}
                >
                  Add Filter
                </Button>
                <Button
                  type="button"
                  size="sm"
                  color="danger"
                  className="addFilterBtn"
                  onClick={() => {
                    setValidationErrors({});
                    setFilterValue([]);
                  }}
                >
                  Clear Filter
                </Button>
              </Col>
              <div className="filterValueContainer">
                {filterValue?.map((a, i) => (
                  <span key={a?.id} className="filterSingleValue">
                    <p>
                      {a?.templateType}
                      {a?.templateType === "Pincode" && a?.option ? (
                        <>
                          &nbsp; - {/* Hyphen before the option */}
                          {Array.isArray(a.option)
                            ? a.option.join(", ")
                            : a.option}
                        </>
                      ) : (
                        ""
                      )}
                      {a?.templateType !== "Pincode" && a?.value ? (
                        <>
                          &nbsp; - {a?.value} {/* Hyphen before the value */}
                        </>
                      ) : (
                        ""
                      )}
                    </p>
                    <p onClick={() => removeFilter(i)}>X</p>
                  </span>
                ))}
              </div>
            </Row>
            <div>
              {formik?.values?.channel === "Email" ? (
                <Col lg={12} md={6} sm={12}>
                  <CustomField isRequired label="Subject">
                    <Input
                      bsSize="sm"
                      type="text"
                      id="subject"
                      placeholder="Subject"
                      value={formik?.values.subject}
                      onChange={formik?.handleChange}
                      onBlur={formik?.handleBlur}
                    />
                  </CustomField>
                </Col>
              ) : (
                <>
                  <Col lg={12} md={6} sm={12}>
                    <CustomField
                      isRequired
                      label="Template Id"
                      errorMessage={
                        formik?.touched?.templateId &&
                        formik?.errors?.templateId
                      }
                    >
                      <Input
                        bsSize="sm"
                        type="text"
                        id="templateId"
                        placeholder="Template Id"
                        value={formik?.values.templateId}
                        onChange={formik?.handleChange}
                        onBlur={formik?.handleBlur}
                        invalid={
                          formik?.touched?.templateId &&
                          Boolean(formik?.errors?.templateId)
                        }
                      />
                    </CustomField>
                  </Col>
                  <Col lg={12} md={6} sm={12}>
                    <CustomField
                      isRequired
                      label="SMS Type"
                      errorMessage={
                        formik?.touched?.smsType && formik?.errors?.smsType
                      }
                    >
                      <Input
                        bsSize="sm"
                        type="text"
                        id="smsType"
                        placeholder="SMS Type"
                        value={formik?.values.smsType}
                        onChange={formik?.handleChange}
                        onBlur={formik?.handleBlur}
                        invalid={
                          formik?.touched?.smsType &&
                          Boolean(formik?.errors?.smsType)
                        }
                      />
                    </CustomField>
                  </Col>
                </>
              )}
            </div>
            <Col lg={12} md={6} sm={12}>
              <CustomField
                isRequired
                label="Template Body"
                errorMessage={
                  formik?.touched?.templateBodies &&
                  formik?.errors?.templateBodies
                }
              >
                <textarea
                  required
                  style={{ width: "100%" }}
                  bsSize="sm"
                  ref={textareaRef}
                  maxLength={1500}
                  rows={3}
                  cols={50}
                  id="templateBodies"
                  placeholder="Template Body"
                  value={text}
                  onChange={(e) => {
                    setText(e.target.value);
                  }}
                />
              </CustomField>
            </Col>
            <Col lg={12} md={6} sm={12}>
              <CustomField label="Active">
                <FormGroup switch className="ms-2">
                  <Input
                    type="switch"
                    checked={formik?.values.active === true}
                    onChange={(e) =>
                      formik?.setFieldValue(
                        "active",
                        e.target.checked ? true : false
                      )
                    }
                    id="active"
                    readOnly
                  />
                </FormGroup>
              </CustomField>
            </Col>
            <Col>
              <div className="d-flex justify-content-end  p-2">
                <Button
                  color="warning"
                  type="button"
                  className="me-1"
                  size="sm"
                  onClick={() => setInsertModal(true)}
                >
                  Insert Variable
                </Button>
              </div>
            </Col>
            <div className="d-flex justify-content-end mt-2">
              <Button
                type="button"
                className="me-1"
                color="primary"
                size="sm"
                onClick={() => setPrivew(true)}
              >
                Preview Template
              </Button>
              <Button color="primary" type="submit" className="me-1" size="sm">
                Submit
              </Button>{" "}
              <Button
                size="sm"
                color="danger"
                type="button"
                style={{ color: "#fff" }}
                onClick={() => {
                  props?.onClose();
                  setFilterValue([]);
                  setValidationErrors({});
                }}
              >
                Cancel
              </Button>
            </div>
          </CardBody>
        </Card>
      </Form>
      <Dialog
        header="Insert Variable"
        visible={insertModal}
        style={{ width: "30vw" }}
        onHide={() => setInsertModal(!insertModal)}
      >
        <div className="insertContainer">
          {props?.getVariables?.map((data) => {
            return (
              <Label className="insertLabel">
                <Input
                  type="checkbox"
                  id="selectOption"
                  onChange={(e) => {
                    const startPos = e.target.selectionStart;
                    const endPos = e.target.selectionEnd;
                    formik?.setFieldValue(
                      "templateBodies",
                      formik?.values?.templateBodies + `{{${data}}}` + " "
                    );
                    const finaldata = `{{${data}}}`;
                    setoptiondata(finaldata);
                    setInsertModal(false);
                  }}
                />
                {data}
              </Label>
            );
          })}
        </div>
      </Dialog>
      <Dialog
        header="Preview Template"
        visible={priview}
        style={{ width: "30vw", height: "45vh" }}
        onHide={() => setPrivew(!priview)}
      >
        <Card className="bg-light" style={{ height: "30vh" }}>
          <CardBody style={{ height: "100%", overflow: "auto" }}>
            <div dangerouslySetInnerHTML={{ __html: text }} />
          </CardBody>
        </Card>
        <div className="d-flex justify-content-end mt-3">
          <Button
            size="sm"
            color="danger"
            type="button"
            style={{ color: "#fff" }}
            onClick={() => setPrivew(false)}
          >
            Close
          </Button>
        </div>
      </Dialog>
    </Fragment>
  );
};
export default memo(CampaignForm);
