import { Formik, useFormik } from "formik";
import { Fragment, memo, useEffect, useMemo, useState } from "react";
import { Button, Form, Input } from "reactstrap";
import Field from "../../components/Field";
import Select from "react-select";
import axios from "axios";
import styles from "./Reports.module.scss";
import * as yup from "yup";
import ReportTable from "./ReportTable";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch, useSelector } from "react-redux";
import MultiSelect from "../../components/Selection/MultiSelect";
const ReportFilter = (props) => {
  const [reportOption, setReportOption] = useState([]);
  const [productOption, setProductOption] = useState([]);
  const [productvalue, setProductValue] = useState([]);
  const [landerOption, setLenderOption] = useState([]);
  const [landervalue, setlanderValue] = useState([]);
  const [campaignOption, setCampaignOption] = useState([]);
  const [campaignvalue, setCampaignValue] = useState([]);
  const initialValues = {
    report: "",
    from: new Date()?.toISOString()?.split("T")[0],
    to: new Date()?.toISOString()?.split("T")[0],
    agency: "",
    productCode: [],
    landerName: [],
    campaignName: [],
  };
  const [agencyOptions, setAgencyOptions] = useState([]);
  const user = useSelector((state) => state.user.data);
  const dispatch = useDispatch()
  const reportOptionSchema = useMemo(
    () => [
      { value: 3, label: "Agency Report", permission: user?.masterRole?.reports_agencyreport },
      { value: 4, label: "Lender Report", permission: user?.masterRole?.reports_lenderreport },
      { value: 5, label: "Product Report", permission: user?.masterRole?.reports_productreport },
      { value: 6, label: "Call Attendance Report", permission: user?.masterRole?.reports_callattendancereport },
      { value: 7, label: "Payment Report", permission: user?.masterRole?.reports_paymentreport },
      { value: 8, label: "Cash Collect Report", permission: user?.masterRole?.reports_cashcollectreport },
      { value: 9, label: "Product Lender Report", permission: user?.masterRole?.reports_productlenderreport },
      { value: 10, label: "Lender DPD Report", permission: user?.masterRole?.reports_lenderdpdreport },
      { value: 11, label: "Attendance Report", permission: user?.masterRole?.reports_attendancereport },
      { value: 12, label: "Monthly Deal Collection Amount Report", permission: user?.masterRole?.reports_monthlydealcollectionamountreport },
      { value: 13, label: "Collection Through Cc and Fos Report", permission: user?.masterRole?.reports_collectionthroughccandfosreport },
      { value: 14, label: "Settlement & Closure Report", permission: user?.masterRole?.reports_settlementandclosurereport },
      { value: 15, label: "Pool Wise PTP & Paid Summary Report", permission: user?.masterRole?.reports_poolwiseptpandpaidsummaryreport },
      { value: 16, label: "Login Report", permission: user?.masterRole?.reports_loginreport },
      { value: 17, label: "User Portfolio Report", permission: user?.masterRole?.reports_userportfolioreport },
      { value: 18, label: "Campaign Report", permission: user?.masterRole?.reports_allocationreport },
      { value: 19, label: "User Tracking Hourly Report", permission: user?.masterRole?.reports_allocationreport }
      // { value: 19, label: "User Tracking Hourly Report", permission: user?.masterRole?.reports_allocationreport },
    ],
    []
  );
  const handleSubmit = async (values) => {
    props?.onSearch(values); // Pass the form values (including date range) to parent or child component
  };
  const validationSchema = yup.object().shape({
    from: yup.string().required("From date is required"),
    to: yup.string().required("To date is required"),
  });
  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      props?.onSearch(values); // Call handleExport here if needed
    },
  });
  const getAllAgency = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllAgency");
      dispatch(setLoader(false))

      const option =
        res?.data?.data?.map((a) => ({
          label: a?.agencyName,
          value: a?.agencyId,
        })) || [];

      setAgencyOptions(option);
    } catch (error) {
      dispatch(setLoader(false))
    }
  };
  const getAllProducts = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllProduct")
      // console.log(res, "allproduct")
      const option =
        res?.data?.data?.map((a) => ({
          label: a?.productDescription,
          value: a?.productCode,
        })) || [];

      // console.log(option, "productOption")
      setProductOption(option)
      dispatch(setLoader(false))
    } catch (error) {
      dispatch(setLoader(false))
    }
  }
  // console.log(productOption, "myyy")
  const getAllLender = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getLenderNames")
      const option =
        res?.data?.data?.map((a) => ({
          label: a,
          value: a,
        })) || [];

      // console.log(option, "LenderOption")
      setLenderOption(option)
      dispatch(setLoader(false))
    } catch (error) {
      dispatch(setLoader(false))
    }
  }
  const getAllCampignName = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllCampaignName")
      const option =
        res?.data?.data?.map((a) => ({
          label: a,
          value: a,
        })) || [];

      // console.log(res, "compaignoption")
      setCampaignOption(option)
      dispatch(setLoader(false))
    } catch (error) {
      dispatch(setLoader(false))
    }
  }
  // console.log(landerOption, "finaloption")
  useEffect(() => {
    getAllAgency();
    getAllProducts();
    getAllLender();
    getAllCampignName()
  }, []);

  useEffect(() => {
    setReportOption(reportOptionSchema?.filter(a => a?.permission))
  }, [])
  // console.log(initialValues, "reportOption")
  return (
    <Fragment>
      <Form onSubmit={formik?.handleSubmit} className={styles?.formContainer}>
        <Field
          label="Select Report"
          containerClassName={styles?.fieldContainer}
        >
          <Select
            placeholder="Select Report"
            options={reportOption}
            onChange={(e) => {
              formik?.setFieldValue("report", e);
              setlanderValue([])
              setCampaignValue([])
              setProductValue([])
            }}
            classNamePrefix="react-select"
            closeMenu={false}
            isClearable={true}
            name="report"
          />
        </Field>
        <Field label="From" containerClassName={styles?.fieldContainer} isRequired errorMessage={formik.touched.from && formik.errors.from}>
          <Input
            type="date"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.from}
            size="sm"
            name="from"
          />
        </Field>
        <Field label="To" containerClassName={styles?.fieldContainer} isRequired errorMessage={formik.touched.to && formik.errors.to}>
          <Input
            type="date"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.to}
            size="sm"
            name="to"
            min={formik?.values?.from && new Date(formik?.values?.from)?.toISOString()?.split("T")[0]}
          />
        </Field>

        {formik?.values?.report?.label == "Campaign Report" ? ("") : (
          <Field
            label="Select Agency"
            containerClassName={styles?.fieldContainer}
          >
            <Select
              placeholder="Select Agency"
              options={agencyOptions}
              onChange={(e) => {
                formik?.setFieldValue("agency", e);
              }}
              classNamePrefix="react-select"
              closeMenu={false}
              isClearable={true}
              name="agency"
            />

          </Field>
        )}
        {/* {console.log(campaignvalue, "campaignvaluecampaignvalue")} */}
        {
          formik?.values?.report?.label == "Campaign Report" ? (
            <>
              <Field
                label="Product"
                containerClassName={styles?.fieldContainer}
              >

                <MultiSelect
                  placeholder="Product"
                  options={productOption}
                  onChange={(e) => setProductValue(e)}
                  closeMenu={false}
                  value={productvalue}
                  isClearable
                />

              </Field>
              <Field
                label="Lender"
                containerClassName={styles?.fieldContainer}
              >
                <MultiSelect
                  placeholder="lender Name"
                  options={landerOption}
                  onChange={(e) => setlanderValue(e)}
                  closeMenu={false}
                  value={landervalue}
                  isClearable
                />
              </Field>
              <Field
                label="Campaign Name"
                containerClassName={styles?.fieldContainer}
              >
                <MultiSelect
                  placeholder="Campaign Name"
                  options={campaignOption}
                  onChange={(e) => setCampaignValue(e)}
                  closeMenu={false}
                  value={campaignvalue}
                  isClearable
                />
              </Field>
            </>
          ) : ""
        }
        <ReportTable searchValues={formik?.values} lenderName={landervalue} campaignName={campaignvalue} productoption={productvalue} />
      </Form>
    </Fragment>
  );
};
export default memo(ReportFilter);