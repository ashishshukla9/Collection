import React, { useEffect, useState } from "react";
import ReportFilter from "./ReportFilter";
import ReportTable from "./ReportTable";
import styles from './Reports.module.scss'
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export default function Reports() {
  const user = useSelector((state) => state.user.data);
  const navigator=useNavigate()

  // useEffect(()=>{
  //   if(!user?.masterRole?.reports_all){
  //     navigator('/')
  //   }
  // },[user])

  return(
    <div className={styles?.container}>
      <ReportFilter />
    </div>
  )
}

