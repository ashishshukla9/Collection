import React, { useEffect, useState } from "react";
import {
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  Col,
  Button,
  FormFeedback,
  Card,
  CardBody,
  CardHeader,
  ButtonGroup,
  Container,
} from "reactstrap";
import { ProfileSchema, validationSchema } from "../../Schema/ProfileSchema";
import { useFormik, Formik } from "formik";
import Swal from "sweetalert2";
import axios from "axios";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import Select from "react-select";
import cx from "classnames";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import SearchBarHeader from "../../components/Header/SearchBarHeader";
import Field from "../../components/Field";
import { setLoader } from "../../reducer/globalReducer";

export default function Profile({ access }) {
  const [visible, setVisible] = useState(false);
  const [viewModal, setViewModal] = useState(false);
  const [profileDetails, setProfileDetails] = useState("");
  const [userType, setUserType] = useState([]);
  const [userTypeOptions, setUserTypeOptions] = useState([]);
  const [data, setData] = useState({});
  const [updateModal, setUpdateModal] = useState(false);

  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();
  const dispatch=useDispatch()

  const getAllProfile = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get('getAllProfile')
      dispatch(setLoader(false))

      if (res?.data?.msgKey === "Success") {
        setProfileDetails(res?.data?.data)
      } else {
        setProfileDetails([])
      }

    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: error.message,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  const searchProfile = async (val) => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getProfileName/${val}`)
      dispatch(setLoader(false))

      if (res?.data?.msgKey === "Success") {
        setProfileDetails(res?.data?.data)
      } else {
        setProfileDetails([])
      }

    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  const formik = useFormik({
    initialValues: ProfileSchema,
    validationSchema: validationSchema,
    onSubmit: (values, { resetForm }) => {
      handleSubmit(values, resetForm);
    },
  });
  // add new profile
  const handleSubmit = (formObj, resetForm) => {
    axios
      .post("/createProfile", formObj)
      .then((response) => {
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Records has been saved",
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        getAllProfile()
        setVisible(false)
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: error.code,
          text: error.response.data.error,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  const handleUpdate = (formObj) => {
    axios
      .put(`/updateProfile/${formObj.profileId}`, formObj)
      .then(() => {
        getAllProfile()
        setUpdateModal(false)
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Records has been saved",
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: error.code,
          text: error.response.data.error,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  //get all profile
  useEffect(() => {
    axios
      .get("/getAllUserType")
      .then(({ data }) => {
        setUserType([...data.data]);
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: error.message,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  }, []);

  useEffect(() => {
    let userTypeTemp = [];
    userType.forEach((type) => {
      if (type.isActive === "Y")
        userTypeTemp.push({ label: type.description, value: type.code });
    });
    setUserTypeOptions([...userTypeTemp]);
  }, [userType]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => searchProfile(data)}
        getAllAPI={() => getAllProfile()}
        onClick={() => {
          setVisible(true)
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">Profile</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={profileDetails}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            globalFilterFields={["userTypeId", "status"]}
            sortMode="multiple"
            removableSort
          >
            <Column field="fieldCode" header="Profile Code" sortable></Column>
            <Column field="profileName" header="Profile Name" sortable></Column>
            <Column
              field="userType"
              header="User Type"
              body={(rowData) => {
                let filterLabel = userType.filter(
                  (v) => v.code === rowData.userType
                );
                if (filterLabel.length > 0) {
                  return filterLabel[0].description;
                } else {
                  return "";
                }
              }}
              sortable
            ></Column>
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData.isActive === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            >
              1
            </Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setViewModal(!viewModal);
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setUpdateModal(!updateModal);
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i
                    className="bi bi-trash"
                    style={{ cursor: "pointer" }}
                    onClick={() => deleteRow(rowData.profileId)}
                  /> */}
                </ButtonGroup>
              )}
            >
              1
            </Column>
          </DataTable>
        </CardBody>
      </Card>

      <Dialog
        header="Profile"
        visible={visible}
        // style={{ width: "60vw" }}
        onHide={() => setVisible(!visible)}
      >
        <section>
          <Form onSubmit={formik.handleSubmit}>
            <Row>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Profile Code"
                  errorMessage={formik.touched.fieldCode && formik.errors.fieldCode}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="fieldCode"
                    placeholder="Profile Code"
                    value={formik.values.fieldCode}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={
                      formik.touched.fieldCode &&
                      Boolean(formik.errors.fieldCode)
                    }
                    maxLength={4}
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Profile Name"
                  errorMessage={formik.touched.profileName && formik.errors.profileName}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="profileName"
                    placeholder="Profile Name"
                    value={formik.values.profileName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={
                      formik.touched.profileName &&
                      Boolean(formik.errors.profileName)
                    }
                    maxLength={35}
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="User Type"
                  errorMessage={formik.touched.userType && formik.errors.userType}
                >
                  <Select
                    inputId="userType"
                    name="userType"
                    isClearable={true}
                    options={userTypeOptions}
                    closeMenuOnSelect={true}
                    hideSelectedOptions={false}
                    onChange={(e) =>
                      formik.setFieldValue("userType", e?.value)
                    }
                    value={userTypeOptions.filter(
                      (v) => v.value === formik.values.userType
                    )}
                    className={cx({
                      abc:
                        formik.touched.userType &&
                        Boolean(formik.errors.userType),
                    })}
                    onBlur={formik.handleBlur}
                    menuPosition={"fixed"}
                    classNamePrefix="react-select"
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field
                  label="Active"
                >
                  <FormGroup switch className="ms-2">
                    <Input
                      type="switch"
                      checked={formik.values.isActive === "Y"}
                      onChange={(e) => {
                        formik.setFieldValue(
                          "isActive",
                          e.target.checked ? "Y" : "N"
                        );
                      }}
                      id="isActive"
                      readOnly
                    />
                  </FormGroup>
                </Field>
              </Col>
            </Row>
            <div className="d-flex justify-content-end">
              <Button color="primary" type="submit" className="me-1" size="sm">
                Submit
              </Button>{" "}
              <Button
                size="sm"
                color="danger"
                type="button"
                style={{ color: "#fff" }}
                onClick={() => setVisible(!visible)}
              >
                Cancel
              </Button>
            </div>
          </Form>
        </section>
      </Dialog>

      {/* Edit Modal Dialog */}
      <Dialog
        header="Profile"
        visible={updateModal}
        // style={{ width: "60vw" }}
        onHide={() => setUpdateModal(!updateModal)}
      >
        <Formik
          initialValues={data}
          validationSchema={validationSchema}
          onSubmit={handleUpdate}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleSubmit,
            handleBlur,
            setFieldValue,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Profile Code"
                    errorMessage={touched.fieldCode && errors.fieldCode}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="fieldCode"
                      placeholder="Profile Code"
                      value={values.fieldCode}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched.fieldCode && Boolean(errors.fieldCode)}
                      disabled
                      maxLength={4}
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Profile Name"
                    errorMessage={touched.profileName && errors.profileName}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="profileName"
                      placeholder="Profile Name"
                      value={values.profileName}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.profileName && Boolean(errors.profileName)
                      }
                      maxLength={35}
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="User Type"
                    errorMessage={touched.userType && errors.userType}
                  >
                    <Select
                      inputId="userType"
                      name="userType"
                      isClearable={true}
                      options={userTypeOptions}
                      closeMenuOnSelect={true}
                      hideSelectedOptions={false}
                      onChange={(e) => setFieldValue("userType", e?.value)}
                      value={userTypeOptions.filter(
                        (v) => v.value === values.userType
                      )}
                      className={cx({
                        abc: Boolean(errors.userType),
                      })}
                      onBlur={handleBlur}
                      menuPosition={"fixed"}
                      classNamePrefix="react-select"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    label="Active"
                  >
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.isActive === "Y"}
                        onChange={(e) => {
                          setFieldValue(
                            "isActive",
                            e.target.checked ? "Y" : "N"
                          );
                        }}
                        id="isActive"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <Button color="primary" type="submit" className="me-1" size="sm">
                  Submit
                </Button>{" "}
                <Button
                  size="sm"
                  color="danger"
                  type="button"
                  style={{ color: "#fff" }}
                  onClick={() => setUpdateModal(!updateModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>

      {/* View Modal */}
      <Dialog
        header="Profile"
        visible={viewModal}
        // style={{ width: "60vw" }}
        onHide={() => setViewModal(!viewModal)}
      >
        <Formik initialValues={data} validationSchema={validationSchema}>
          {({ values }) => (
            <Form>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    label="Profile Code"
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="fieldCode"
                      placeholder="Profile Code"
                      value={values.fieldCode}
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    label="Profile Name"
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="profileName"
                      placeholder="Profile Name"
                      value={values.profileName}
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    label="User Type"
                  >
                    <Select
                      inputId="userType"
                      name="userType"
                      value={userTypeOptions.filter(
                        (v) => v.value === values.userType
                      )}
                      isDisabled
                      classNamePrefix="react-select"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    label="Active"
                  >
                    <FormGroup switch className="ms-2">
                      <Input
                        type="switch"
                        checked={values.isActive === "Y"}
                        id="isActive"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
            </Form>
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}
