import { createAsyncThunk,createSlice } from '@reduxjs/toolkit';
import axios from 'axios';
import { baseUrl } from '../../../App.config';
import { setLoader } from '../../../reducer/globalReducer';

export const getAllProfile = createAsyncThunk(
  'profile/getAllProfile', 
  async (params,{dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + "/getAllProfile"); 
      dispatch(setLoader(false))   
      return {
        list:response?.data?.data,
      }
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch profile data.');
    }
  }
);

export const addprofile = createAsyncThunk(
  'profile/addprofile', 
  async (params, {dispatch}) => {
    try {
      dispatch(setLoader(true))
      await axios.post(baseUrl() + "/createprofile",params); 
      dispatch(setLoader(false))  
      dispatch(getAllProfile()) 
      return true
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch profile data.');
    }
  }
);
export const editprofile = createAsyncThunk(
  'profile/editprofile', 
  async (params, {dispatch}) => {
    try {
      dispatch(setLoader(true))
      await axios.put(baseUrl() + `/updateprofile/${params?.id}`,params);   
      dispatch(setLoader(false))
      dispatch(getAllProfile()) 
      return true
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch profile data.');
    }
  }
);

export const searchprofile = createAsyncThunk(
  'profile/searchprofile', 
  async (search,{dispatch}) => {
    try {
      dispatch(setLoader(true))
      const response = await axios.get(baseUrl() + `/getAllProfileByprofileName/${search}`);    
      dispatch(setLoader(false))
      return {
        list:response?.data?.data,
      }
    } catch (error) {
      dispatch(setLoader(false))
      throw new Error('Failed to fetch profile data.');
    }
  }
);


export const profile = createSlice({
  name: 'profile',
  initialState: { 
    list: [], 
    loader: false, 
    error: '',
    selected:null
  },
  reducers: {
    setSelected:(state,action)=>{
      action.payload === null ? state.selected = null : state.selected = action.payload 
    },
    setLoder:(state,action)=>{
      state.loader = action.payload 
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllProfile.fulfilled, (state, action) => {
        state.loader = false;
        state.list = action.payload.list;
      })
  },
});  

export const { setSelected,setLoder } = profile.actions;

export default profile.reducer;
