import { Formik } from "formik"
import { memo, useEffect, useState } from "react"
import { Button, Form, Input } from "reactstrap"
import Field from "../../components/Field"
import styles from './Request.module.scss'
import axios from "axios"
import Swal from "sweetalert2"
import { useDispatch, useSelector } from "react-redux"
import { setLoader } from "../../reducer/globalReducer"

import { Link } from "react-router-dom"
const RequestDipositionForm = (props) => {
    const [btnName, setBtnName] = useState('')

    const dispatch = useDispatch()
    const user = useSelector((state) => state.user.data);
    const initialValues = {
        bankName: props?.data?.bankName,
        branchName: props?.data?.branchName,
        paymentCollectionMode: props?.data?.paymentCollectionMode,
        lans: props?.data?.lans?.map((res) => res),
        paymentIds: props?.data?.paymentIds?.map((res) => res),
        amount: props?.data?.amount,
        remarks: props?.data?.remark,
        adminRemark: props?.data?.adminRemark
        // props?.formData?.remark 
    }

    const data = { ...props?.formData }

    const handleSubmit = async (values) => {
        try {
            const payload = {
                // ...props?.formData,
                // remark: values?.adminRemarks,
                adminRemark: values?.adminRemark,
                activityType: "Deposition",
                status: btnName === "Approve" ? "Approved" : btnName === "Reject" ? "Rejected" : "",
                userId: user?.userId

            }

            delete payload?.createdTime
            delete payload?.lastModifiedTime

            dispatch(setLoader(true))
            const res = await axios.put(`/updateDepositionRequest/${props?.formData?.requestManagementId}`, payload)
            dispatch(setLoader(false))
            props?.onSuccess()
            Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });

        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }

    return (
        <Formik
            initialValues={initialValues}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                setFieldValue,
                handleSubmit,
                handleReset,
                resetForm,
            }) => {
                // console.log(values, "formic value")
                return (
                    <Form onSubmit={handleSubmit}>
                        <Field
                            label="Bank Name"
                        >
                            <Input
                                bsSize="sm"
                                name="bankName"
                                value={values?.bankName}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Branch Name"
                        >
                            <Input
                                bsSize="sm"
                                name="branchName"
                                value={values?.branchName}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Payment Collection Mode"
                        >
                            <Input
                                bsSize="sm"
                                name="paymentCollectionMode"
                                value={values?.paymentCollectionMode}
                                disabled
                            />
                        </Field>
                        <Field
                            label="LAN IDs"
                        >
                                    <div style={{border:"0.2px solid gray", overflowY:"scroll",  width:"325px", height:"50px", borderRadius:"5px" }} >

                            {
                                values?.lans?.map((a) =>
                                (
                                        <Link
                                            to={`/case_profile/ALL/calling/${a}`}
                                            className="caseId"
                                           
                                        >

                                            <button style={{ paddingLeft: "2px", background: "transparent", border: "none" , color:"#2e9be8" , textDecoration:"underline"}}>{`${a},`}</button>
                                            {/* {console.log(values?.lans, "values?.lans")} */}
                                        </Link>

                                )
                                )
                            }
                                    </div>

                        </Field>
                        <Field
                            label="Payment ID"
                        >
                            <Input
                                bsSize="sm"
                                name="paymentIds"
                                value={values?.paymentIds}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Amount"
                        >
                            <Input
                                bsSize="sm"
                                name="amount"
                                value={values?.amount}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Remarks"
                        >
                            <Input
                                bsSize="sm"
                                name="remark"
                                value={values?.remarks}
                                disabled
                            />
                        </Field>
                        <Field
                            label="Approval  Remarks"
                        >
                            <Input
                                bsSize="sm"
                                type="textarea"
                                name="adminRemark"
                                onChange={handleChange}
                                value={values?.adminRemark}
                                disabled={props?.formData?.status !== "Pending"}
                            />
                        </Field>
                        {props?.formData?.status === "Pending" &&
                            <div className={styles?.buttonGroup}>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Approve')}
                                >
                                    Approve
                                </Button>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    onMouseOver={() => setBtnName('Reject')}
                                >
                                    Reject
                                </Button>
                            </div>
                        }
                    </Form>
                )
            }}
        </Formik>
    )
}

export default memo(RequestDipositionForm)