import { Formik } from "formik";
import { memo, useState } from "react";
import { Button, Form, Input } from "reactstrap";
import Field from "../../components/Field";
import Swal from "sweetalert2";
import axios from "axios";
import styles from "./Request.module.scss";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";

const RequestDisputeForm = (props) => {
  const [btnName, setBtnName] = useState("");
  const dispatch=useDispatch()

  const dispute = props?.disputeReason[props?.data?.disputeReason];
  const initialValues = {
    dispute: dispute,
    adminRemarks: props?.formData?.remark,
  };

  const handleSubmit = async (values) => {
  
    try {
      const payload = {
        ...props?.formData,
        remark: values?.adminRemarks,
        status:
          btnName === "Approve"
            ? "Approved"
            : btnName === "Reject"
            ? "Rejected"
            : "Pending",
      };
      delete payload?.createdTime;
      delete payload?.lastModifiedTime;
      dispatch(setLoader(true))
      const res = await axios.put(
        `/updateRequestManagement/${props?.formData?.requestManagementId}`,
        payload
      );
      dispatch(setLoader(false))
      if (res?.data?.msgKey === "success") {
        const disputePayload = {
          ...props?.data,
          status: res?.data?.data?.status,
        };

        delete disputePayload?.lastModifiedTime;
        delete disputePayload?.createdTime;
       
        dispatch(setLoader(true))

        const disputeRes = await axios.put(
          `/updateDisputeOrRtp/${props?.data?.disputeOrRtpId}`,
          disputePayload
        );
        dispatch(setLoader(false))
      }
      props?.onSuccess();
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
      
    } catch (error) {
      dispatch(setLoader(false))
      
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  return (
    <Formik initialValues={initialValues} onSubmit={handleSubmit}>
      {({
        values,
        errors,
        touched,
        handleChange,
        handleBlur,
        setFieldValue,
        handleSubmit,
        handleReset,
        resetForm,
      }) => {
        return (
          <Form onSubmit={handleSubmit}>
            <Field label="Dispute Reason">
              <Input
                bsSize="sm"
                name="dispute"
                value={values?.dispute}
                disabled
              />
            </Field>

            <Field label="Approver`s Remarks">
              <Input
                bsSize="sm"
                type="textarea"
                name="adminRemarks"
                onChange={handleChange}
                value={values?.adminRemarks}
                disabled={props?.formData?.status !== "Pending"}
              />
            </Field>

            {props?.formData?.status === "Pending" && (
              <div className={styles?.buttonGroup}>
                <Button
                  type="submit"
                  size="sm"
                  color="primary"
                  onMouseOver={() => setBtnName("Approve")}
                >
                  Approve
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  color="primary"
                  onMouseOver={() => setBtnName("Reject")}
                >
                  Reject
                </Button>
              </div>
            )}
          </Form>
        );
      }}
    </Formik>
  );
};

export default memo(RequestDisputeForm);
