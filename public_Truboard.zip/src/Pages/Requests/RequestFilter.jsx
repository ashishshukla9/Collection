import { Formik } from "formik"
import { memo, useMemo, useState } from "react";
import Select from "react-select";
import { Button, Form, Input } from "reactstrap";
import styles from './Request.module.scss'
import axios from "axios";
import Swal from "sweetalert2";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";

const RequestFilter = (props) => {
    const status = useMemo(() => [{ label: 'Pending', value: 'Pending' }, { label: 'Approved', value: 'Approved' }, { label: 'Rejected', value: 'Rejected' }, { label: 'Escalate To TruBoard', value: 'Escalate To TruBoard' }])

    const dispatch=useDispatch()
    const clearFilter = () => {
        props?.setIsFilterActive(false)
        props?.getAPICall()
    }

    const handleSubmit = async (values,{resetForm}) => {
        if (Object.values(values)?.filter(Boolean).length) {
            props?.setIsFilterActive(true)
            try {
                const params = {
                    lan: values?.lanId || '',
                    status: values?.status?.value || ''
                }
                dispatch(setLoader(true))
                const res = await axios.get(`/getRequestManagementByLanAndStatus/${props?.userId}/${props?.currentPage}/${props?.numberOfDataPerPage}`, { params })
                dispatch(setLoader(false))
                if(res?.data?.messageKey === 'success') {
                    props?.onSuccess(res?.data, params)
                }else if(res?.data?.message === "failure"){
                    props?.onFailed()
                }
            } catch (error) {
                dispatch(setLoader(false))
                props?.onFailed()
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            }
        } else {
            resetForm()
            clearFilter()
        }
    }
    return (
        <Formik
            initialValues={{
                status: '',
                lanId: ''
            }}
            onSubmit={handleSubmit}
        >
            {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                setFieldValue,
                handleSubmit,
                handleReset,
                resetForm,
            }) => {
                return (
                    <Form onSubmit={handleSubmit} className={styles?.filterForm}>
                        <Select
                            placeholder="Please Select Status"
                            options={status}
                            onChange={(e) => {
                                setFieldValue('status', e)
                            }}
                            classNamePrefix="react-select"
                            closeMenu={false}
                            value={values?.status}
                            isClearable={true}
                        />
                        <Input
                            type="text"
                            name="lanId"
                            placeholder="Search LAN Id"
                            className={styles?.input}
                            onChange={handleChange}
                            value={values?.lanId}
                        />
                        <Button
                            type="submit"
                            size="sm"
                            color="primary"
                        >
                            Search
                        </Button>
                        {props?.isFilterActive &&
                            <Button
                                type="button"
                                size="sm"
                                color="danger"
                                onClick={() => {
                                    resetForm()
                                    clearFilter()
                                }}
                            >
                                Clear
                            </Button>
                        }
                    </Form>
                )
            }}
        </Formik>
    )
}

export default memo(RequestFilter)