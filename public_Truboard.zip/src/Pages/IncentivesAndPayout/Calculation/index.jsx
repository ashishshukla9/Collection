import { Pie } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Colors, CategoryScale, registerables } from 'chart.js';
import styles from './Calculation.module.scss'
import { Formik } from "formik";
import Field from "../../../components/Field";
import { AccordionBody, AccordionHeader, AccordionItem, Button, ButtonGroup, Form, Input, UncontrolledAccordion } from "reactstrap";
import { scrollToErrorMessage } from "../../../utils/commonFun";
import Select from "react-select";
import { useMemo, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import * as yup from "yup";
import CalculationDetails from "./CalculationDetails";
import { setLoader } from "../../../reducer/globalReducer";
ChartJS.register(ArcElement, Tooltip, Legend, Colors, CategoryScale, ...registerables);
const Index = () => {
    const [data, setData] = useState([])
    const [paramsObj, setParamsObj] = useState({})
    const user = useSelector((state) => state.user.data);
    const dispatch = useDispatch()
    const reportTypeOptions = useMemo(() => [{ value: 'yearly', label: 'Yearly' }, { value: 'quarterly', label: 'Quarterly' }, { value: 'monthly', label: 'Monthly' }])
    const monthOptions = useMemo(() => [{ value: 1, label: 'January' }, { value: 2, label: 'February' }, { value: 3, label: 'March' }, { value: 4, label: 'April' }, { value: 5, label: 'May' }, { value: 6, label: 'June' }, { value: 7, label: 'July' }, { value: 8, label: 'August' }, { value: 9, label: 'September' }, { value: 10, label: 'October' }, { value: 11, label: 'November' }, { value: 12, label: 'December' }], [])
    const quarterlyOptions = useMemo(() => [{ value: 4, label: 'Quarter 1' }, { value: 7, label: 'Quarter 2' }, { value: 10, label: 'Quarter 3' }, { value: 1, label: 'Quarter 4' }])
    const yearOptions = useMemo(() => {
        const currentYear = new Date().getFullYear()
        const finalYear = []
        for (let index = currentYear; 2000 <= index; index--) {
            finalYear.push({
                label: index,
                value: index
            })
        }
        return finalYear;
    })
    const initialValues = {
        month: '',
        year: '',
        reportType: '',
        quarter: ''
    }
    const validationSchema = yup.object().shape({
        year: yup.mixed().required("This field is required."),
        month: yup.mixed().when('reportType', {
            is: (reportType) => (reportType?.value !== 'yearly' && reportType?.value !== 'quarterly'),
            then: () => yup.mixed().required("This field is required")
        }),
        quarter: yup.mixed().when('reportType', {
            is: (reportType) => (reportType?.value === 'quarterly'),
            then: () => yup.mixed().required("This field is required")
        })
    })
    const handleSubmit = async (values) => {
        dispatch(setLoader(true))
        try {
            const params = {
                month: values?.reportType?.value === "yearly" ? 0 : values?.reportType?.value === "quarterly" ? values?.quarter?.value : values?.month?.value,
                year: values?.year?.value,
                reportType: values?.reportType?.value
            }
            setParamsObj(params)
            const res = await axios.get(`/getIncentiveCalculationByUserId/${user?.userId}`, { params })
            dispatch(setLoader(false))
            if (res?.data?.messageKey) {
                setData([{ ...res?.data?.response, id: user?.userId }])
            } else {
                setData([])
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${res?.data?.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            }
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    }
    const onSuccess = (apiRes, selectedUser, i) => {
        const obj = { ...apiRes, id: selectedUser?.userId, name: `${selectedUser?.firstName} ${selectedUser?.lastName}` }
        const duplicateData = data
        duplicateData.splice(i + 1, duplicateData.length, obj)
        setData([...duplicateData])
    }
    const handleClear = () => {
        setData([])
        setParamsObj({})
    }
    return (
        <div className={styles?.pageContainer}>
            <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={handleSubmit}
            >
                {({
                    values,
                    errors,
                    handleChange,
                    handleBlur,
                    touched,
                    handleSubmit,
                    setFieldValue,
                    setFieldError,
                    isSubmitting,
                    resetForm
                }) => {
                    const err = Object.keys(errors)[0]
                    scrollToErrorMessage(isSubmitting, err)
                    return (
                        <Form onSubmit={handleSubmit} className={styles?.formContainer}>
                            <Field
                                label="Report Type"
                                containerClassName={styles?.fieldContainer}
                            >
                                <Select
                                    name="reportType"
                                    bsSize="sm"
                                    isClearable={true}
                                    options={reportTypeOptions}
                                    hideSelectedOptions={false}
                                    closeMenuOnSelect={true}
                                    onChange={e => {
                                        setFieldValue('reportType', e || "")
                                    }}
                                    onBlur={(e) => {
                                        handleBlur(e)
                                    }}
                                    menuPosition={"fixed"}
                                    classNamePrefix="react-select"
                                    value={values?.reportType}
                                />
                            </Field>
                            {values?.reportType?.value !== 'yearly' && values?.reportType?.value !== 'quarterly' &&
                                <Field
                                    label="Month"
                                    containerClassName={styles?.fieldContainer}
                                    errorMessage={touched?.month && errors?.month}
                                >
                                    <Select
                                        name="month"
                                        bsSize="sm"
                                        isClearable={true}
                                        options={monthOptions}
                                        hideSelectedOptions={false}
                                        closeMenuOnSelect={true}
                                        onChange={e => {
                                            setFieldValue('month', e || "")
                                        }}
                                        onBlur={(e) => {
                                            handleBlur(e)
                                        }}
                                        menuPosition={"fixed"}
                                        classNamePrefix="react-select"
                                        value={values?.month}
                                    />
                                </Field>
                            }
                            {values?.reportType?.value !== 'yearly' && values?.reportType?.value !== 'monthly' &&
                                <Field
                                    label="Quarter"
                                    containerClassName={styles?.fieldContainer}
                                    errorMessage={touched?.quarter && errors?.quarter}
                                >
                                    <Select
                                        name="quarter"
                                        bsSize="sm"
                                        isClearable={true}
                                        options={quarterlyOptions}
                                        hideSelectedOptions={false}
                                        closeMenuOnSelect={true}
                                        onChange={e => {
                                            setFieldValue('quarter', e || "")
                                        }}
                                        onBlur={(e) => {
                                            handleBlur(e)
                                        }}
                                        menuPosition={"fixed"}
                                        classNamePrefix="react-select"
                                        value={values?.quarter}
                                    />
                                </Field>
                            }
                            <Field
                                isRequired
                                label="Year"
                                containerClassName={styles?.fieldContainer}
                                errorMessage={touched?.year && errors?.year}
                            >
                                <Select
                                    name="year"
                                    bsSize="sm"
                                    isClearable={true}
                                    options={yearOptions}
                                    hideSelectedOptions={false}
                                    closeMenuOnSelect={true}
                                    onChange={e => {
                                        setFieldValue('year', e)
                                    }}
                                    onBlur={(e) => {
                                        handleBlur(e)
                                    }}
                                    menuPosition={"fixed"}
                                    classNamePrefix="react-select"
                                    value={values?.year}
                                />
                            </Field>
                            <ButtonGroup className={styles?.btnGrp}>
                                <Button
                                    type="submit"
                                    size="sm"
                                    color="primary"
                                    className={`${styles.filterBtn} ${touched?.year && errors?.year && styles?.filterBtnError}`}
                                >
                                    Filter
                                </Button>
                                <Button
                                    type="reset"
                                    size="sm"
                                    color="danger"
                                    className={`${styles.filterBtn} ${touched?.year && errors?.year && styles?.filterBtnError}`}
                                    onClick={() => {
                                        resetForm()
                                        handleClear()
                                    }}
                                >
                                    Clear
                                </Button>
                            </ButtonGroup>
                        </Form>
                    )
                }}
            </Formik>
            <UncontrolledAccordion stayOpen>
                <div className={styles?.detailsContainer}>
                    {data?.map((a, i) => {
                        if (i === 0) {
                            return (
                                <CalculationDetails
                                    data={a}
                                    params={paramsObj}
                                    onSuccess={(apiRes, selectedUser) => onSuccess(apiRes, selectedUser, i)}
                                    userIds={data?.map(a => a?.id)}
                                    lastIndex={data?.length === (i + 1)}
                                />
                            )
                        } else {
                            return (
                                <AccordionItem>
                                    <AccordionHeader targetId={i?.toString()}>
                                        <div className={styles?.accordionHeader}>
                                            <p>{a?.name} Details</p>
                                            {/* <Button 
                                            size="sm"
                                            type="button"
                                            color="danger"
                                            onClick={(e)=>onClearDetails(e,a,i)}
                                        >
                                            Clear
                                        </Button> */}
                                        </div>
                                    </AccordionHeader>
                                    <AccordionBody accordionId={i?.toString()}>
                                        <CalculationDetails
                                            data={a}
                                            params={paramsObj}
                                            onSuccess={(apiRes, selectedUser) => onSuccess(apiRes, selectedUser, i)}
                                            userIds={data?.map(a => a?.id)}
                                            lastIndex={data?.length === (i + 1)}
                                        />
                                    </AccordionBody>
                                </AccordionItem>
                            )
                        }
                    })}
                </div>
            </UncontrolledAccordion>
        </div>
    )
}
export default Index;