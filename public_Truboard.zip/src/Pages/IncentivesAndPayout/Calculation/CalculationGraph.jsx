import { memo, useMemo } from "react"
import { Doughnut, Pie } from "react-chartjs-2"
import styles from './Calculation.module.scss'
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Colors, CategoryScale, registerables } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend, Colors, CategoryScale, ...registerables);

const CalculationGraph = (props) => {
    const options = useMemo(() => {
        return {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: "bottom",
                    align: 'start'
                },
            }
        }
    }, [])

    const graph = (data, graphType) => {
        switch (graphType) {
            case "Doughnut":
                return (
                    <Doughnut
                        data={data}
                        options={{ ...options, rotation: 270, circumference: 180 }}
                        className={styles?.chart}
                    />
                )
                break;

            default:
                break;
        }
    }

    return (
        <div className={styles?.graphBox}>
            <p className={styles?.header}>{props?.header}</p>
            <p className={styles?.percentage}>{props?.percentage?.toString()?.includes('.') ? props?.percentage?.toFixed(2) : props?.percentage} %</p>
            <p className={styles?.amountDetails}>Allocated POS: <b>₹ {props?.amountDetails?.allocatedPos?.toString()?.includes('.') ? props?.amountDetails?.allocatedPos?.toFixed(2) : props?.amountDetails?.allocatedPos}</b></p>
            <p className={styles?.amountDetails}>Collected Amount: <b>₹ {props?.amountDetails?.collectedAmount?.toString()?.includes('.') ? props?.amountDetails?.collectedAmount?.toFixed(2) : props?.amountDetails?.collectedAmount}</b></p>
            <p className={styles?.amountDetails}>Incentive Amount: <b>₹ {props?.amountDetails?.incentiveAmount?.toString()?.includes('.') ? props?.amountDetails?.incentiveAmount?.toFixed(2) : props?.amountDetails?.incentiveAmount}</b></p>
            {graph(props?.data, props?.graphType)}
        </div>
    )
}

export default memo(CalculationGraph)