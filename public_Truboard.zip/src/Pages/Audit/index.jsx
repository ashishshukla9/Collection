import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import AuditFilter from "./AuditFilter";
import styles from './Audit.module.scss'
import AuditTable from "./AuditTable";
import axios from "axios";
import Swal from "sweetalert2";
import { setLoader } from "../../reducer/globalReducer";

const Index = ({ access }) => {
  const [totalCount,setTotalCount]=useState(0)
  const [data,setData]=useState([])
  const [currentPage, setCurrentPage] = useState(1)
  const [numberOfDataPerPage, setNumberOfDataPerPage] = useState(10)
  const [params,setParams]=useState({})

  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate()

  const dispatch=useDispatch()

  const getAPI=async()=>{
    try {
      const paramsObj={
          module: params?.module || "",
          from: params?.from || "",
          to: params?.to || "",
          page: params?.page || currentPage,
          size: params?.size || numberOfDataPerPage
      }
      dispatch(setLoader(true))

      const res=await axios.get('/getPaginatedAuditTrails',{params:paramsObj})
      dispatch(setLoader(false))
      setData(res?.data?.response?.content || [])
      setTotalCount(res?.data?.response?.totalElements || 0)

      if(!res?.data?.messageKey){
          Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${res?.data?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
          });
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  useEffect(() => {
    if (!user?.masterRole?.[`${access}`]) {
      navigate('*')
    }
  }, [])

  useEffect(()=>{
      getAPI()
  },[numberOfDataPerPage,currentPage,params])

  return (
    <div className={styles?.container}>
      <AuditFilter
        currentPage={currentPage}
        numberOfDataPerPage={numberOfDataPerPage}
        params={params}
        setParams={setParams}
        setCurrentPage={setCurrentPage}
      />

      <AuditTable
        currentPage={currentPage}
        numberOfDataPerPage={numberOfDataPerPage}
        params={params}
        data={data}
        totalCount={totalCount}
        setCurrentPage={setCurrentPage}
        setNumberOfDataPerPage={setNumberOfDataPerPage} 
      />
    </div>
  )
}

export default Index