import { Fragment, memo, useEffect, useState } from "react"
import { Button, ButtonGroup, Form, Input } from "reactstrap"
import Field from "../../components/Field"
import Select from "react-select";
import styles from './Audit.module.scss'
import axios from "axios";
import { useFormik } from "formik";
import * as yup from "yup";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";

const AuditFilter = (props) => {
    const [module, setModule] = useState([])
    const [isFilter,setIsFilter] = useState(false)

    const dispatch=useDispatch()

    const initialValues = {
        module: '',
        fromDate: '',
        toDate: ''
    }

    const validationSchema=yup.object().shape({
        fromDate: yup.string().when('toDate',{
            is: toDate=> toDate,
            then: ()=> yup.string()?.required("Required")
        })
    })

    const handleSubmit = async(values) => {
        const params={
            module: values?.module?.value,
            page: isFilter ? props?.currentPage : 1,
            size: props?.numberOfDataPerPage,
            from: values?.fromDate,
            to: values?.toDate ? values?.toDate : values?.fromDate ? new Date()?.toISOString()?.split('T')[0] : ''
        }
        setIsFilter(true)
        props?.setParams(params)
    }

    const formik = useFormik({
        initialValues: initialValues,
        validationSchema: validationSchema,
        onSubmit: handleSubmit
    });

    const getModule = async () => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get('/getAuditModules')
            dispatch(setLoader(false))
            const op = res?.data?.response?.map(a => ({
                label: a,
                value: a
            }))

            setModule(op)
        } catch (error) {
            dispatch(setLoader(false))

        }
    }

    useEffect(() => {
        getModule()
    }, [])

    return (
        <Fragment>
            <Form onSubmit={formik.handleSubmit} className={styles?.formContainer}>
                <Field
                    label="Select Module"
                    containerClassName={styles?.fieldContainer}
                >
                    <Select
                        name="module"
                        isClearable={true}
                        options={module}
                        onChange={(e) => {
                            formik?.setFieldValue("module", e)
                        }}
                        value={formik?.values?.module}
                        menuPosition="fixed"
                        classNamePrefix="react-select"
                    />
                </Field>
                <Field
                    label="Start Date"
                    containerClassName={styles?.fieldContainer}
                    errorMessage={formik?.touched?.fromDate && formik?.errors?.fromDate}
                >
                    <Input
                        size={"sm"}
                        type="date"
                        name="fromDate"
                        value={formik?.values?.fromDate}
                        onChange={formik?.handleChange}
                        max={new Date()?.toISOString()?.split("T")[0]}
                        onBlur={formik?.handleBlur}
                    />
                </Field>
                <Field
                    label="End Date"
                    containerClassName={styles?.fieldContainer}
                >
                    <Input
                        size={"sm"}
                        type="date"
                        name="toDate"
                        value={formik?.values?.toDate}
                        onChange={formik?.handleChange}
                        min={formik?.values?.fromDate && new Date(formik?.values?.fromDate)?.toISOString()?.split("T")[0]}
                        max={new Date()?.toISOString()?.split("T")[0]}
                        onBlur={formik?.handleBlur}
                    />
                </Field>
                <ButtonGroup className={styles?.btnGrp}>
                    <Button
                        type="submit"
                        size="sm"
                        color="primary"
                        className={`${styles.filterBtn} ${formik?.touched?.fromDate && formik?.errors?.fromDate && styles?.filterBtnError}`}
                    >
                        Filter
                    </Button>
                    <Button
                        type="reset"
                        size="sm"
                        color="danger"
                        className={`${styles.filterBtn} ${formik?.touched?.fromDate && formik?.errors?.fromDate && styles?.filterBtnError}`}
                        onClick={() => {
                            formik?.resetForm()
                            setIsFilter(false)
                            props?.setCurrentPage(1)
                            if(Object.keys(props?.params)?.length){
                                props?.setParams({})
                            }
                        }}
                    >
                        Clear
                    </Button>
                </ButtonGroup>
            </Form>
        </Fragment>
    )
}

export default memo(AuditFilter)