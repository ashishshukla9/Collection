import React, { useState, useEffect } from "react";
import CreateLender from "./CreateLender";
import {
  Container,
  Input,
  Button,
  Card,
  CardBody,
  CardHeader,
  ButtonGroup,
} from "reactstrap";
import axios from "axios";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import SearchBarHeader from "../../components/Header/SearchBarHeader";
import { setLoader } from "../../reducer/globalReducer";

export default function Lender({ access }) {
  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [lenderDetails, setLenderDetails] = useState([]);
  const [createModal, setCreateModal] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  const [viewModal, setViewModal] = useState(false);

  const dispatch=useDispatch()
  const getAllLender = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get('/getAllLender')
      dispatch(setLoader(false))

      if (res?.data?.msgKey === "Success") {
        setLenderDetails(res?.data?.data);
      } else {
        setLenderDetails([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  const onSuccess=()=>{
    getAllLender()
    setCreateModal(false)
    setUpdateModal(false)
  }
  const searchLender = async (val) => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getLenderName/${val}`)
      dispatch(setLoader(false))

      if (res?.data?.msgKey === "Success") {
        setLenderDetails(res?.data?.data);
      } else {
        setLenderDetails([])
      }
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);
 
  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data)=> searchLender(data)}
        getAllAPI={()=>getAllLender()}
        onClick={()=>{
          setCreateModal(!createModal);
        }}
        permission={user?.masterRole?.[access]}
      />

      <Card className="flex-grow-1 mb-1">
        {/* <CardHeader className="p-2 d-flex justify-content-between align-items-center">
          <p className="m-0">Lender</p>
          {user?.masterRole[access] === "V" || (
            <Button size={"sm"} color="primary">
              Upload Data
            </Button>
          )}
        </CardHeader> */}
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={lenderDetails}
            paginator
            className="commonTable"
            rowsPerPageOptions={[10, 25, 50, 100]}
            rows={10}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="lenderId" header="Lender Id" sortable></Column>
            <Column field="lenderName" header="Lender Name" sortable></Column>
            <Column field="shortName" header="Short Name" sortable></Column>
            <Column 
              field="lenderName" 
              header="Start Date" 
              body={rowData=>{
                const date=new Date(rowData?.startDate)?.toLocaleDateString()?.split('/')
                return(
                  <span>{`${date[1]}/${date[0]}/${date[2]}`}</span>
                )
              }}
              sortable
            ></Column>
            <Column 
              field="shortName" 
              header="End Date" 
              body={rowData=>{
                const date=new Date(rowData?.endDate)?.toLocaleDateString()?.split('/')
                return(
                  <span>{`${date[1]}/${date[0]}/${date[2]}`}</span>
                )
              }}
              sortable
            ></Column>
            {/* <Column field="maskingMobileNo" header="Contact" sortable></Column> */}
            <Column
              field="status"
              header="Status"
              body={(rowData) =>
                rowData.status === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        rowData.startDate = rowData.startDate?.split("T")[0];
                        rowData.endDate = rowData.endDate?.split("T")[0];
                        let temp = JSON.parse(JSON.stringify(rowData));
                        // let temp=rowData?.map ((ele)=>({...ele}))
                        temp.branches.forEach((branch) => {
                          branch.pincode = Number(branch.pincode);
                          branch.emailId = JSON.parse(branch.emailId);
                          branch.contactNo = JSON.parse(branch.contactNo);
                        });
                        // console.log(temp);
                        setData({ ...temp });

                        setViewModal(!viewModal);
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        rowData.startDate = rowData.startDate?.split("T")[0];
                        rowData.endDate = rowData.endDate?.split("T")[0];

                        // let temp = { ...rowData };
                        let temp = JSON.parse(JSON.stringify(rowData));

                        temp.branches.forEach((branch) => {
                          branch.pincode = Number(branch.pincode);
                          branch.emailId = JSON.parse(branch.emailId);
                          branch.contactNo = JSON.parse(branch.contactNo);
                        });
                        // console.log(temp);
                        setData({ ...temp });
                        setUpdateModal(!updateModal);
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>

                  <i
                    className="bi bi-trash-fill text-danger"
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      deleteRow(rowData.lenderId);
                    }}
                  ></i> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>

      <Dialog
        header="Lender"
        visible={createModal}
        style={{ width: "90vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <CreateLender cancelModal={setCreateModal} onSuccess={onSuccess} />
      </Dialog>

      <Dialog
        header="Lender"
        visible={updateModal}
        style={{ width: "90vw" }}
        onHide={() => setUpdateModal(!updateModal)}
      >
        <CreateLender
          cancelModal={setUpdateModal}
          isUpdate={true}
          isView={false}
          data={data}
          onSuccess={onSuccess}
        />
      </Dialog>

      <Dialog
        header="Lender Details"
        visible={viewModal}
        style={{ width: "90vw" }}
        onHide={() => setViewModal(!viewModal)}
      >
        <CreateLender
          cancelModal={setViewModal}
          isUpdate={false}
          isView={true}
          data={data}
        />
      </Dialog>
    </Container>
  );
}
