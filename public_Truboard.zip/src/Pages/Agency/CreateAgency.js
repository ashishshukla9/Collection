import React, { useEffect, useState } from "react";
import { Form, FormGroup, Input, Row, Col, Button, FormFeedback, Card, CardBody, Table, CardHeader, } from "reactstrap";
import { FieldArray, Formik, } from "formik";
import Swal from "sweetalert2";
import cx from "classnames";
import Select from "react-select";
import axios from "axios";
import { scrollToErrorMessage } from "../../utils/commonFun";
import Field from "../../components/Field";
import * as yup from "yup";
import FileUpload from "../../components/FileUpload";
import FileTable from "../../components/FileTable";
import MultiSelectComma from "../../components/Selection/MultiSelectComma";
import { useDispatch, useSelector } from "react-redux";
import { getActiveDocumentData } from "../Master/LookupMaster/lookupSlice";
import { setLoader } from "../../reducer/globalReducer";
import { RxCross1 } from "react-icons/rx";
import { MultiSelect } from "react-multi-select-component";


export default function CreateAgency({ isUpdate, isView, data, cancelModal, onSuccess }) {
  // console.log(data, "datadatadata")
  // const [ageny, setAgency] = useState("");
  const [allPincode, setAllPincode] = useState([]);
  const [activeAgencyType, setActiveAgencyType] = useState([]);
  const [activeNatureOfService, setActivenatureOfService] = useState([]);
  const [activeCities, setActiveCities] = useState([]);
  const [activeCitiesSpoc, setActiveCitiesSpoc] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [selectedCity, setSelectedCity] = useState(null);
  const [inputValueSpoc, setInputValueSpoc] = useState(null);
  const [selectedCitySpoc, setSelectedCitySpoc] = useState(null);
  const [kycDocument, setKycDocument] = useState([]);
  const [kycDoc, setKycDoc] = useState([])
  const [kycDocEdit, setKycDocEdit] = useState([])
  const [rcuDoc, setRcuDoc] = useState([])
  const [aggDoc, setAggDoc] = useState([])
  const [rcuDocEdit, setRcuDocEdit] = useState([])
  const [aggDocEdit, setAggDocEdit] = useState([])
  const [rcaDocument, setRcaDocument] = useState([]);
  const [aggDocument, setAggDocument] = useState([]);
  const [kycCount, setKycCount] = useState(1);
  const [activeUsers, setActiveUser] = useState([]);
  const [editDocument, setEditDocument] = useState({
    visible: false,
    name: ''
  });
  const [addKycs, setAddKycs] = useState(false);
  const [addRcu, setAddRcu] = useState(false);
  const [addAgg, setAddAgg] = useState(false);
  const [agencyUser, setAgencyUser] = useState([]);
  const [mappedUser, setMappedUser] = useState([]);
  const [activeState, setActiveState] = useState([])
  const [selectedState, setselectedState] = useState([])
  const [selectedPincode, setselectedPincode] = useState([])

  // const [activeCity, setActiveCity] = useState([])
  // const [isSearchCity, setIsSearchCity] = useState(false)
  // const [searchCity, setSearchCity] = useState('')
  const [State, setSearchState] = useState('')
  // const [menuIsOpenCity, setMenuIsOpenCity] = useState(false)
  const [activePincode, setActivePincode] = useState([])
  const [StateIds, setStateIds] = useState([]);
  const [CityIds, setCityIds] = useState([]);
  const [isSearchPincode, setIsSearchPincode] = useState(false)
  const [isSearchState, setIsSearchState] = useState(false)
  const [searchPincode, setSearchPincode] = useState('')
  const [menuIsOpenPincode, setMenuIsOpenPincode] = useState(false)
  const [formik, setFormik] = useState({});
  const [isSearchPincodeBranch, setIsSearchPincodeBranch] = useState(false)
  const [searchPincodeBranch, setSearchPincodeBranch] = useState('')
  const [menuIsOpenPincodeBranch, setMenuIsOpenPincodeBranch] = useState(false)
  const [activePincodeBranch, setActivePincodeBranch] = useState([])
  const [documentOptions, setDocumentOptions] = useState([])
  const [userCurrentPage, setUserCurrentPage] = useState(1)
  const [userTotalPage, setUserTotalPages] = useState(1)
  const [isformdata, setisFormdata] = useState(false)
  const [aggrementDoc, setAgreementDoc] = useState([])
  const [RUCDoc, setRUCDoc] = useState([])
  const [isSelectAll, setIsSelectAll] = useState(false);


  const [activeCity, setActiveCity] = useState([]);
  const [searchCity, setSearchCity] = useState('');
  const [isSearchCity, setIsSearchCity] = useState(false);
  const [menuIsOpenCity, setMenuIsOpenCity] = useState(false);


  const formikRef = React.useRef();
  const activeDocumentData = useSelector((state) => state?.lookup?.activeDocumentData);
  const dispatch = useDispatch()
  // console.log(data?.agencyOwnerDetails, 'uguyguy')
  const initialValues = {
    agencyName: (isView || isUpdate) ? data?.agencyName : "",
    shortName: (isView || isUpdate) ? data?.shortName : "",
    agencyType: (isView || isUpdate) ? data?.agencyType : "",
    agencyAddress: (isView || isUpdate) ? data?.agencyAddress : "",
    pincode: (isView || isUpdate) ? data?.pincode?.length ? data?.pincode?.map(a => ({ ...a, label: a?.pincode, value: a?.pincodeId })) : [] : [],
    city: (isView || isUpdate) ? data?.city?.length ? data?.city?.map(a => ({ ...a, label: a?.cityName, value: a?.cityId })) : [] : [],
    state: (isView || isUpdate) ? data?.state?.length ? data?.state?.map(a => ({ ...a, label: a?.stateName, value: a?.stateId })) : [] : selectedState,
    // pincode: (isView || isUpdate) ? data?.pincode?.length ? data?.pincode?.map(a => ({ ...a, label: a?.pincode, value: a?.pincodeId })) : [] : [],
    // city: (isView || isUpdate) ? data?.city?.length ? data?.city?.map(a => ({ ...a, label: a?.cityName, value: a?.cityId })) : [] : [],
    // state: (isView || isUpdate) ? data?.state?.length ? data?.state?.map(a => ({ ...a, label: a?.stateName, value: a?.stateId })) : [] : [],
    // state: (isView || isUpdate) ? data?.state?.length ? data?.state?.map(a => ({ ...a, label: a?.stateName, value: a?.stateId })) : [] : selectedState,

    natureOfService: (isView || isUpdate) ? data?.natureOfService : [],
    contactPersonName: (isView || isUpdate) ? data?.contactPersonName : "",
    contactEmailId: (isView || isUpdate) ? data?.contactEmailId : "",
    contactMobileNo: (isView || isUpdate) ? data?.contactMobileNo : "",
    usingSystemDialer: (isView || isUpdate) ? data?.usingSystemDialer : "Y",
    expiryNotification: (isView || isUpdate) ? data?.expiryNotification : "Y",
    startDate: (isView || isUpdate) ? data?.startDate : "",
    endDate: (isView || isUpdate) ? data?.endDate : "",
    aggrementScanning: (isView || isUpdate) ? "a" : "",
    ruc: (isView || isUpdate) ? "a" : "",
    agencyBranches: (isView || isUpdate) ? data?.agencyBranches?.map(branch => ({
      ...branch,
      branchPincode: data?.pincode?.filter(pincode => branch?.branchPincode?.includes(pincode?.pincode)).map(branch => ({
        ...branch,
        label: branch?.pincode,
        value: branch?.pincodeId
      }))
    })) : [{ branchCode: "", branchName: "", branchPincode: [] }],
    agencyOwnerDetails: (isView || isUpdate) ? data?.agencyOwnerDetails : [
      {
        ownerPersonName: "",
        ownerEmailId: "",
        ownerMobileNumber: "",
        city: "",
        state: "",
      },
    ],

    agencySpocDetails: (isView || isUpdate) ? data?.agencySpocDetails : [
      {
        spocPersonName: "",
        spocEmailId: "",
        spocMobileNo: "",
        city: "",
        state: "",
      },
    ],

    kycs: (isView || isUpdate) ? data?.kycs : [
      {
        KYC: "",
        docType: ""
      },
    ],

    managedBy: (isView || isUpdate) ? data?.managedBy : "",
    userMapping: (isView || isUpdate) ? data?.userMapping : "",
    status: (isView || isUpdate) ? data?.status : "Y",
    allCity: '',
    // allState: '',
    allPincode: ''
  };


  // console.log(initialValues, "initilalala")
  const validationSchema = yup.object({
    agencyName: yup.string().required("Required"),
    shortName: yup.string().required("Required"),
    agencyType: yup.string().required("Required"),
    agencyAddress: yup.string().required("Required"),
    pincode: yup.array().min(1, "Required").required("Required"),
    natureOfService: yup.array().min(1, "Required").required("Required"),
    startDate: yup.string().required("Required"),
    endDate: yup.string().required("Required"),
    // aggrementScanning: yup.mixed().required("Required"),
    // ruc: yup.mixed().required("Required"),
    managedBy: yup.string().required("Required"),
    agencyBranches: yup.array().of(
      yup.object({
        branchCode: yup.string().required("Required"),
        branchName: yup.string().required("Required")
      })
    ),
    agencyOwnerDetails: yup.array().of(
      yup.object({
        ownerPersonName: yup.string().required("Required"),
        ownerEmailId: yup.string().required("Required"),
        ownerMobileNumber: yup.string().required("Required"),
        city: yup.string().required("Required"),
        state: yup.string().required("Required"),
      })
    ),
    agencySpocDetails: yup.array().of(
      yup.object({
        spocPersonName: yup.string().required("Required"),
        spocEmailId: yup.string().required("Required"),
        spocMobileNo: yup.string().required("Required"),
        city: yup.string().required("Required"),
        state: yup.string().required("Required"),
      })
    ),
    // kycs: yup.array().of(
    //   yup.object({
    //     KYC: yup.string().required("Required"),
    //     docType: yup.string().required("Required")
    //   })
    // )
  })

  const fileUpload = (value, content) => {
    // console.log(value, "valuesuykuku")
    // if (value?.length >= 1) {
    //   setisFormdata(true)
    // }
    setisFormdata(true)
    const formData = new FormData()
    for (let i = 0; i < value.length; i++) {
      // console.log(value[i], "hfhh", content)
      formData.append(content, value[i]);
    }
    console.log(formData, "===>")
    return formData;
  }

  const handleCreate = async (values) => {
    // console.log(values, "valuesfgfd");
    let tempValues = { ...values };
    // console.log(tempValues, "TEMOOO")
    let natureOfService = [];
    tempValues.natureOfService.forEach((service) => {
      natureOfService.push(service.value);
    });

    tempValues["natureOfService"] = JSON.stringify(natureOfService);
    let aggFormData = fileUpload(tempValues.aggrementScanning, "content");
    let formData = fileUpload(tempValues.ruc, "content");
    // console.log(aggFormData, formData, "formDataformDataformData");

    tempValues['agencyBranches'] = tempValues?.agencyBranches?.map(data => ({
      ...data,
      branchPincode: data?.branchPincode?.map(pincode => Number(pincode?.label)).join(',')
    }));

    // tempValues['city'] = [...new Map(tempValues?.city?.map(item => [item.cityId, item])).values()]0
    tempValues['state'] = [...new Map(tempValues?.state?.map(item => [item?.stateId, item])).values()];
    delete tempValues["aggrementScanning"];
    delete tempValues["ruc"];
    delete tempValues["kycs"];
    // console.log(tempValues, "finnaltemp");

    // tempValues = { ...tempValues, allCity: tempValues?.allCity ? 'allCity' : '', allPincode: tempValues?.allPincode ? 'allPincode' : '' }
    tempValues = {
      ...tempValues,

      city: tempValues.city.map(city => ({ cityId: city.value, city_name: city.label })),
      allCity: tempValues?.allCity ? 'allCity' : 'city',
      pincode: tempValues.pincode.map(pincode => ({ pincodeId: Number(pincode.value), pincode: pincode.label })),
      state: tempValues.state.map(state => ({ stateId: Number(state.value), stateName: state.label })),
      allPincode: tempValues?.allPincode ? 'allPincode' : 'pincode',
      allState: tempValues?.allState ? 'allState' : 'state'
    };


    // console.log(tempValues, 'temevluss')
    // console.log(aggFormData, "tememeeme");
    dispatch(setLoader(true));
    axios
      .post(`/createAgency`, tempValues)
      .then(async ({ data }) => {
        dispatch(setLoader(false));
        // console.log(aggFormData, "aggformdata");

        if (aggFormData?.getAll('content')?.length) {
          dispatch(setLoader(true));
          try {
            const aggRes = await axios.post(`/upload-document-agency-aggrement-scanning/${data?.data?.agencyId}/ok`, aggFormData);
            dispatch(setLoader(false));
            setisFormdata(false);
          } catch (error) {
            dispatch(setLoader(false));
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        }

        if (values?.kycs?.length) {
          values.kycs.forEach(async (a) => {
            if (a?.KYC) {
              const kycFormData = new FormData();
              kycFormData.append("content", a.KYC);
              if (kycFormData.getAll('content').length) {
                dispatch(setLoader(true));
                try {
                  const kycRes = await axios.post(`/upload-document-agency-kyc/${data?.data?.agencyId}/ok/${a.docType}`, kycFormData);
                  // console.log(kycRes);
                  dispatch(setLoader(false));
                } catch (error) {
                  dispatch(setLoader(false));
                  Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `${error.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                  });
                }
              }
            }
          });
        }

        if (formData?.getAll('content')?.length) {
          dispatch(setLoader(true));
          try {
            const rcaRes = await axios.post(`/upload-document-agency-rca/${data?.data?.agencyId}/ok`, formData);
            dispatch(setLoader(false));
          } catch (error) {
            dispatch(setLoader(false));
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        }

        Swal.fire({
          position: "top-end",
          icon: "success",
          title: 'Agency Created Successfully.',
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });

        onSuccess();
      })
      .catch((error) => {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };
  const handleUpdate = async (values) => {
    let tempValues = { ...values };

    let natureOfService = tempValues.natureOfService.map(service => service.value);
    tempValues.natureOfService = JSON.stringify(natureOfService);

    // tempValues.agencyBranches = tempValues.agencyBranches.map(data => ({
    //   ...data,
    //   branchPincode: data.branchPincode.map(pincode => pincode.pincode).join(',')
    // }));

    // tempValues['agencyBranches'] = tempValues?.agencyBranches?.map(data => ({
    //   ...data,
    //   branchPincode: data?.branchPincode?.map(pincode => Number(pincode?.label)).join(',')
    // }));
    tempValues['agencyBranches'] = tempValues?.agencyBranches?.map(data => ({
      ...data,
      branchPincode: data?.branchPincode
        ?.map(pincode => {
          // Ensure pincode.label exists and is a valid number
          const numericPincode = Number(pincode?.label);
          return isNaN(numericPincode) ? null : numericPincode; // Return null if invalid
        })
        .filter(pincode => pincode !== null) // Remove null values
        .join(',') // Join valid pincodes into a string
    }));

    // tempValues['agencyBranches'] = tempValues?.agencyBranches?.map(data => ({
    //   ...data,
    //   branchPincode: data?.branchPincode
    //     ?.map(pincode => {
    //       // Ensure pincode.label exists and is a valid number
    //       const numericPincode = Number(pincode?.label);
    //       return isNaN(numericPincode) ? null : numericPincode; // Return null if invalid
    //     })
    //     .filter(pincode => pincode !== null) // Remove null values
    // })); // No need to join, leave as an array



    // tempValues.city = tempValues.city.map(item => ({
    //   cityId: item.value
    // }));

    // tempValues.state = [...new Map(tempValues.state.map(item => [item.stateId, item])).values()];

    tempValues.allCity = tempValues.allCity ? 'allCity' : '';
    tempValues.allPincode = tempValues.allPincode ? 'allPincode' : '';

    tempValues['city'] = [...new Map(tempValues?.city?.map(item => [item.cityId, item])).values()]
    tempValues['state'] = [...new Map(tempValues?.state?.map(item => [item?.stateId, item])).values()]
    tempValues = { ...tempValues, allCity: tempValues?.allCity ? 'allCity' : '', allPincode: tempValues?.allPincode ? 'allPincode' : '' }

    // console.log("Formatted tempValues:", tempValues);
    const editKycDoc = kycDocument?.filter(a => !a?.docKycAgencyId)
    dispatch(setLoader(true))
    // console.log(tempValues['state'], "tempValuestempValuestempValues")
    axios
      .put(`/updateAgency/${data.agencyId}`, tempValues)
      .then(async (res) => {
        dispatch(setLoader(false))
        if (res?.data?.msgKey === "Success") {
          if (kycDocEdit?.length > 0) {
            kycDocEdit?.map(async (kycDoc) => {
              const kycDocFormData = new FormData()
              kycDocFormData.append('content', kycDoc?.data)
              dispatch(setLoader(true))
              try {
                const kycDocRes = await axios.put(`/update-document-agency-kyc/${data?.agencyId}/${kycDoc?.id}/ok`, kycDocFormData)
                dispatch(setLoader(false))
              } catch (error) {
                dispatch(setLoader(false))
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${error.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            })
          } else if (editKycDoc?.length) {
            editKycDoc?.map(async (kycDoc) => {
              const kycDocFormData = new FormData()
              kycDocFormData.append('content', kycDoc?.file)
              dispatch(setLoader(true))
              try {
                const kycDocRes = await axios.post(`/upload-document-agency-kyc/${data?.agencyId}/ok/${kycDoc?.docType}`, kycDocFormData)
                dispatch(setLoader(false))
              } catch (error) {
                dispatch(setLoader(false))
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${error.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            })
          }

          let rcuFormData = fileUpload(rcuDoc, "content");
          if (rcuFormData?.getAll('content')?.length) {
            dispatch(setLoader(true))
            try {
              const rcuRes = await axios.post(`/upload-document-agency-rca/${data?.agencyId}/ok`, rcuFormData)
              dispatch(setLoader(false))
              if (rcuRes?.data?.msgKey === "Failure") {
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${rcuRes?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              } else {
                Swal.fire({
                  position: "top-end",
                  icon: "success",
                  title: `${rcuRes?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            } catch (error) {

              dispatch(setLoader(false))
              Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
          }
          if (rcuDocEdit?.length > 0) {
            rcuDocEdit?.map(async (kycDoc) => {
              const rcuDocFormData = new FormData()
              rcuDocFormData.append('content', kycDoc?.data)
              dispatch(setLoader(true))
              try {
                const kycDocRes = await axios.put(`/update-document-agency-rca/${data?.agencyId}/${kycDoc?.id}/ok`, rcuDocFormData)
                dispatch(setLoader(false))
              } catch (error) {
                dispatch(setLoader(false))
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${error.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            })
          }

          let aggFormData = fileUpload(aggDoc, "content");
          if (aggFormData?.getAll('content')?.length) {
            dispatch(setLoader(true))
            try {
              const aggRes = await axios.post(`/upload-document-agency-aggrement-scanning/${data?.agencyId}/ok`, aggFormData)
              dispatch(setLoader(false))
              if (aggRes?.data?.msgKey === "Failure") {
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${aggRes?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              } else {
                Swal.fire({
                  position: "top-end",
                  icon: "success",
                  title: `${aggRes?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            } catch (error) {
              dispatch(setLoader(false))
              Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
            }
          }
          if (aggDocEdit?.length > 0) {
            aggDocEdit?.map(async (kycDoc) => {
              const aggDocFormData = new FormData()
              aggDocFormData.append('content', kycDoc?.data)
              dispatch(setLoader(true))
              try {
                const kycDocRes = await axios.put(`/update-document-agency-aggrement-scanning/${data?.agencyId}/${kycDoc?.id}/ok`, aggDocFormData)
                dispatch(setLoader(false))
              } catch (error) {
                dispatch(setLoader(false))
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${error.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            })
          }

          Swal.fire({
            position: "top-end",
            icon: "success",
            title: 'Agency Updated Successfully.',
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          onSuccess()
        } else {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${res?.data?.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        dispatch(setLoader(false))
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };


  const onKycSave = (data, docType) => {
    setKycDocument([
      ...kycDocument,
      {
        name: data?.name,
        file: data,
        docType: docType,
        lastModifiedTime: new Date().toISOString(),
        createdTime: new Date().toISOString(),
        uniquekycdoc: Math.random()
      }
    ])
    setKycDoc([
      ...kycDoc,
      data
    ])
    setAddKycs(false)
  }

  const onRcuSave = (data) => {
    setRcaDocument([
      ...rcaDocument,
      {
        name: data?.name,
        lastModifiedTime: new Date().toISOString(),
        createdTime: new Date().toISOString(),
        uniquercudoc: Math.random()
      }
    ])
    setRcuDoc([
      ...rcuDoc,
      data
    ])
    setAddRcu(false)
  }

  const onAggSave = (data) => {
    // console.log(data, "rowdata")
    setAggDocument([
      ...aggDocument,
      {
        name: data?.name,
        lastModifiedTime: new Date().toISOString(),
        createdTime: new Date().toISOString(),
        aggducuniue: Math.random()
      }
    ])
    setAggDoc([
      ...aggDoc,
      data
    ])
    setAddAgg(false)
  }

  useEffect(() => {
    if (isView) {
      var agencyUserList = [];
      axios
        .get(`/getUserByAgency/${data?.agencyId}`)
        .then((response) => {
          for (let i of response?.data?.data) {
            agencyUserList.push(i?.firstName + " " + i?.lastName);
          }
          setAgencyUser([...agencyUserList]);
        })
        .catch((error) => { });

      axios
        .get(`/getMappedUserByAgenyId/${data?.agencyId}`)
        .then((response) => {
          let data = response?.data?.data;
          setMappedUser(data?.firstName + " " + data?.lastName);
        })
        .catch((error) => { });
    }
  }, []);

  useEffect(() => {
    if (data) {
      axios
        .get(`/documentAgencyAggrementScanningId/${data?.agencyId}`)
        .then((response) => {
          setAggDocument([...response.data]);
        })
        .catch((error) => {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
      axios
        .get(`/documentAgencyKycByAgencyId/${data?.agencyId}`)
        .then((response) => {
          setKycDocument([...response.data]);
        })
        .catch((error) => {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
      axios
        .get(`/documentAgencyRcaId/${data?.agencyId}`)
        .then((response) => {
          setRcaDocument([...response.data]);
        })
        .catch((error) => {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    }
  }, [data]);

  // const handleInputvalue = (event) => {
  //   if (event.target && event.target.value) {
  //     const value = event.target.value.toLowerCase();
  //   }
  //   setInputValue(event.target.value);
  //   event.preventdefault()
  // };



  const getAllPincodes = async () => {
    try {
      const res = await axios.get("/getAllPincodes/1/1000"); // Adjust endpoint as needed
      // console.log(res?.data, "Pincodes response");

      if (res?.data?.messageKey === "Success") {
        const allPincodes = res.data.response.map(item => ({
          label: item.pincode, // Adjust according to your API response
          value: item.pincodeId // Adjust according to your API response
        }));

        setActivePincode(allPincodes);
        setAllPincode(allPincodes);

        return allPincodes; // Return all pincodes to be used in onChange handler
      }
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };


  useEffect(() => {
    axios
      .get("/getAllPincodes/1/1000")
      .then(({ data }) => {
        setAllPincode([...data.response]);
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    axios
      .get("/getAllActiveAgencyType")
      .then(({ data }) => {
        let tempActive = [];
        data.data.forEach((e) => {
          if (e.isActive === "Y")
            tempActive.push({ label: e.description, value: e.description });
        });
        setActiveAgencyType([...tempActive]);
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
    axios
      .get("/getAllActiveNatureOfService")
      .then(({ data }) => {
        let temp = [];
        data.data.forEach((service) => {
          temp.push({ label: service.description, value: service.description });
        });
        setActivenatureOfService([...temp]);
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });





    // SPOC city


  }, []);

  // useEffect(()=>{
  //   if (inputValue != "") {
  //     axios
  //       .get(`/getCityByCityName/${inputValue}/0/0`)
  //       .then(({ data }) => {
  //         console.log(data, "all city")
  //         let tempCities = [];
  //         console.log("data.response",data.response);
  //         data.response.forEach((city) => {
  //           if (city.active === "Y")
  //             return tempCities.push({
  //               label: city.cityName,
  //               value: city.cityCode,
  //               stateCode: city.state.stateCode,
  //               state: city.state.stateName,
  //             });
  //             console.log("all cities", tempCities)
  //         });
  //         console.log("tempCities",[...tempCities]);
  //         setActiveCities([...tempCities]);
  //         console.log("activeCities",activeCities);
  //       })
  //       .catch((error) => {

  //       });
  //   }
  // },[inputValue]); 

  // const handleCityChange = (e, index, setFieldValue) => {
  //   console.log("activeCitiesactiveCities", activeCities);
  //   // Set the city value in the form
  //   setFieldValue(`agencyOwnerDetails.${index}.city`, e?.value);

  //   // Immediately call the API to fetch state information
  //   axios.get(`/getCityByCityName/${e.label}/0/0`)
  //     .then(({ data }) => {
  //       console.log("API Response:", data.response);
  //       let tempCities = [];
  //       data.response.forEach((city) => {
  //         if (city.active === "Y") {
  //           tempCities.push({
  //             label: city.cityName,
  //             value: city.cityCode,
  //             stateCode: city.state.stateCode,
  //             state: city.state.stateName,
  //           });
  //         }
  //       });

  //       const selectedCityData = tempCities.find(city => city.label === e.label);
  //       if (selectedCityData) {
  //         setFieldValue(`agencyOwnerDetails.${index}.state`, selectedCityData.state);
  //         setSelectedCity(selectedCityData); // Update the selected city state
  //       }
  //       setActiveCities(prevCities => {
  //       const newCities = [...prevCities, ...tempCities];

  //       // Optionally, you can filter out duplicates if needed
  //       const uniqueCities = Array.from(new Set(newCities.map(city => city.value)))
  //         .map(value => newCities.find(city => city.value === value));

  //       return uniqueCities;
  //     });
  //     })
  // };

  const handleCityChange = (e, index, setFieldValue) => {
    // Set the city value in the form
    setFieldValue(`agencyOwnerDetails.${index}.city`, e?.value);

    axios.get(`/getCityByCityName/${e.label}/0/0`)
      .then(({ data }) => {
        // console.log("API Response:", data.response);
        const tempCities = [];
        data.response.forEach(city => {
          if (city.active === "Y") {
            tempCities.push({
              label: city.cityName,
              value: city.cityCode,
              stateCode: city.state.stateCode,
              stateId: city.state.stateId, // Add stateId
              stateName: city.state.stateName // Add stateName
            });
          }
        });

        const selectedCityData = tempCities.find(city => city.label === e.label);
        if (selectedCityData) {
          setFieldValue(`agencyOwnerDetails.${index}.state`, selectedCityData.stateId); // Store stateId
          setFieldValue(`agencyOwnerDetails.${index}.stateName`, selectedCityData.stateName); // Store stateName
          setSelectedCity(selectedCityData);
        }

        // Merge new cities with existing ones
        setActiveCities(prevCities => {
          const newCities = [...prevCities, ...tempCities];

          // Filter out duplicates
          const uniqueCities = Array.from(new Set(newCities.map(city => city.value)))
            .map(value => newCities.find(city => city.value === value));

          return uniqueCities;
        });
      });
  };

  // console.log(activeCities, 'bbujui')

  // const fetchCities = async (value, setActiveCities) => {
  //   if (value.trim() !== "") {
  //     try {
  //       const { data } = await axios.get(`/getCityByCityName/${value}/0/0`);
  //       console.log("API Response:", data.response);
  //       const tempCities = data.response
  //         .filter(city => city.active === "Y")
  //         .map(city => ({
  //           label: city.cityName,
  //           value: city.cityCode,
  //           stateCode: city.state.stateCode,
  //           state: city.state.stateName,
  //         }));

  //       setActiveCities(tempCities);
  //     } catch (error) {
  //       console.error("Error fetching cities:", error);
  //     }
  //   }
  // };

  const fetchCities = async (value, setActiveCities) => {
    if (value.trim() !== "") {
      try {
        const { data } = await axios.get(`/getCityByCityName/${value}/0/0`);
        // console.log("API Response:", data.response);
        const tempCities = data.response
          .filter(city => city.active === "Y")
          .map(city => ({
            label: city.cityName,
            value: city.cityCode,
            stateCode: city.state.stateCode,
            state: city.state.stateName,
          }));

        setActiveCities(tempCities);
      } catch (error) {
        console.error("Error fetching cities:", error);
      }
    }
  };

  useEffect(() => {
    if (inputValue != "") {
      axios
        .get(`/getCityByCityName/${inputValue}/0/0`)
        .then(({ data }) => {
          // console.log(data, "all city")
          let tempCities = [];
          data.response.forEach((city) => {
            if (city.active === "Y")
              return tempCities.push({
                label: city.cityName,
                value: city.cityCode,
                stateCode: city.state.stateCode,
                state: city.state.stateName,
              });
          });
          setActiveCitiesSpoc([...tempCities]);
        })
        .catch((error) => {

        });
    }
  }, [inputValue])

  const handleCitySpocChange = (e, index, setFieldValue) => {
    // Set the city value in the form
    setFieldValue(`agencySpocDetails.${index}.city`, e?.value);

    axios.get(`/getCityByCityName/${e.label}/0/0`)
      .then(({ data }) => {
        // console.log("API Response:", data.response);
        const tempCities = [];
        data.response.forEach(city => {
          if (city.active === "Y") {
            tempCities.push({
              label: city.cityName,
              value: city.cityCode,
              stateCode: city.state.stateCode,
              stateId: city.state.stateId, // Add stateId
              stateName: city.state.stateName // Add stateName
            });
          }
        });

        const selectedCityData = tempCities.find(city => city.label === e.label);
        if (selectedCityData) {
          setFieldValue(`agencySpocDetails.${index}.state`, selectedCityData.stateId); // Store stateId
          setFieldValue(`agencySpocDetails.${index}.stateName`, selectedCityData.stateName); // Store stateName
          setSelectedCitySpoc(selectedCityData);
        }

        // Merge new cities with existing ones
        setActiveCitiesSpoc(prevCities => {
          const newCities = [...prevCities, ...tempCities];

          // Filter out duplicates
          const uniqueCities = Array.from(new Set(newCities.map(city => city.value)))
            .map(value => newCities.find(city => city.value === value));

          return uniqueCities;
        });
      });
  };

  // console.log(activeCitiesSpoc, 'vhgftyfytf')
  const fetchCitiesSpoc = async (value, setActiveCitiesSpoc) => {
    if (value.trim() !== "") {
      try {
        const { data } = await axios.get(`/getCityByCityName/${value}/0/0`);
        // console.log("API Response:", data.response);
        const tempCities = data.response
          .filter(city => city.active === "Y")
          .map(city => ({
            label: city.cityName,
            value: city.cityCode,
            stateCode: city.state.stateCode,
            state: city.state.stateName,
          }));

        setActiveCitiesSpoc(tempCities);
      } catch (error) {
        console.error("Error fetching cities:", error);
      }
    }
  };


  useEffect(() => {
    if (inputValueSpoc != "") {
      axios
        .get(`/getCityByCityName/${inputValueSpoc}/0/0`)
        .then(({ data }) => {
          // console.log(data, "all city")
          let tempCities = [];
          data.response.forEach((city) => {
            if (city.active === "Y")
              return tempCities.push({
                label: city.cityName,
                value: city.cityCode,
                stateCode: city.state.stateCode,
                state: city.state.stateName,
              });
          });
          setActiveCitiesSpoc([...tempCities]);
        })
        .catch((error) => {

        });
    }
  }, [inputValueSpoc])

  useEffect(() => {
    if (userCurrentPage <= userTotalPage) {
      const apiCall = async () => {
        try {
          // const res = await axios.get(`/getAllUserList/${userCurrentPage}/25`)
          const res = await axios.get(`/getUserForAllocation`)
          const op = res?.data?.data?.map(user => {
            // if (user?.status === "Y") {
            return {
              label: `${user?.firstName} ${user?.lastName}`,
              value: user?.userId
            }
            // }
          })

          setActiveUser([...activeUsers, ...op])
          setUserTotalPages(res?.data?.data?.totalPages)
        } catch (error) {
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      }

      apiCall()
    }
  }, [userCurrentPage])

  const onBtnClickKyc = () => {
    setAddKycs(!addKycs)
  }
  const onEditClickKyc = (id, index) => {
    setEditDocument({
      visible: true,
      name: 'KYC',
      index,
      docId: id
    })
  }

  const onBtnClickRcu = () => {
    setAddRcu(!addRcu)
  }
  const onEditClickRcu = (id, index) => {
    setEditDocument({
      visible: true,
      name: 'RCU',
      index,
      docId: id
    })
  }

  const onBtnClickAgg = () => {
    setAddAgg(!addAgg)
  }

  const onEditClickAgg = (id, index) => {
    setEditDocument({
      visible: true,
      name: 'AGGREMENT',
      index,
      docId: id
    })
  }

  const onEditDocSave = (data) => {
    if (editDocument?.name === "KYC") {
      let duplicateDocKyc = kycDocument
      duplicateDocKyc[editDocument?.index].name = data?.name
      setKycDocEdit([...kycDocEdit, { data, id: editDocument?.docId }])
    } else if (editDocument?.name === "RCU") {
      let duplicateDocKyc = rcaDocument
      duplicateDocKyc[editDocument?.index].name = data?.name
      setRcuDocEdit([...rcuDocEdit, { data, id: editDocument?.docId }])
    } else if (editDocument?.name === "AGGREMENT") {
      let duplicateDocKyc = aggDocument
      duplicateDocKyc[editDocument?.index].name = data?.name
      setAggDocEdit([...aggDocEdit, { data, id: editDocument?.docId }])
    }

    setEditDocument({
      visible: false,
      name: ''
    })
  }

  const onInputChangeCity = (val) => {
    setSearchCity(val)
    setIsSearchCity(true)
  }

  const onStateChange = (val) => {
    setSearchState(val)
    setIsSearchState(true)
  }
  const onInputChangePincode = (val) => {
    setSearchPincode(val?.toString())
    setIsSearchPincode(true)
  }
  const onInputChangePincodeBranch = (val) => {
    setSearchPincodeBranch(val?.toString())
    setIsSearchPincodeBranch(true)
  }

  // useEffect(() => {
  //   const search = setTimeout(() => {
  //     if (searchCity?.length > 2) {
  //       const getSearchAPI = async () => {
  //         try {
  //           setMenuIsOpenCity(false)
  //           const payload = selectedState?.map(a => a?.value)
  //           dispatch(setLoader(true))
  //           const res = await axios.post(`/getCityByCityNameSelectedState/${searchCity}/0/0`, payload)
  //           dispatch(setLoader(false))
  //           if (res?.data?.msgKey === "Success") {
  //             const op = []
  //             res?.data?.data?.map(a => {
  //               if (a?.active === "Y") {
  //                 op?.push({
  //                   label: a?.cityName,
  //                   value: a?.cityId,
  //                   ...a
  //                 });
  //               }
  //             })
  //             setActiveCity(op)
  //             setTimeout(() => {
  //               setMenuIsOpenCity(true)
  //             }, 1000)
  //           }
  //         } catch (error) {
  //           dispatch(setLoader(false))
  //         }
  //       }
  //       getSearchAPI()
  //     }
  //   }, 1000)

  //   return () => {
  //     clearTimeout(search)
  //   }
  // }, [searchCity])

  useEffect(() => {
    const search = setTimeout(() => {
      if (searchCity?.length > 2) {
        const getSearchAPI = async () => {
          try {
            setMenuIsOpenCity(false);
            const payload = selectedState.map((a) => a.value);
            dispatch(setLoader(true));
            const res = await axios.post(`/getCityByCityNameSelectedState/${searchCity}/0/0`, payload);
            dispatch(setLoader(false));
            if (res?.data?.msgKey === "Success") {
              const op = [];
              res?.data?.data?.forEach((a) => {
                if (a?.active === "Y") {
                  op.push({
                    label: a?.cityName,
                    value: a?.cityId,
                    state: a?.stateName,
                    stateCode: a?.stateCode,
                    ...a
                  });
                }
              });
              setActiveCity(op);
              setTimeout(() => {
                setMenuIsOpenCity(true);
              }, 1000);
            }
          } catch (error) {
            dispatch(setLoader(false));
          }
        };
        getSearchAPI();
      }
    }, 1000);

    return () => {
      clearTimeout(search);
    };
  }, [searchCity, selectedState]);

  useEffect(() => {
    const search = setTimeout(() => {
      if (searchPincode?.length > 2) {
        const getSearchAPI = async () => {
          // console.log(formik?.values, selectedState, "finalvaluesusus")
          try {
            setMenuIsOpenCity(false)
            const payload = {
              selectedCity: formik?.values?.allCity ? [0] : formik?.values?.city?.map(a => a?.value),
              selectedStates: selectedState?.map(a => a?.value)
            }
            dispatch(setLoader(true))
            const res = await axios.post(`/getByPincodeForCityForSelectedState/${searchPincode}/${formik?.values?.allCity ? "Y" : "N"}`, payload)
            dispatch(setLoader(false))
            if (res?.data?.msgKey === "Success") {
              const op = []
              res?.data?.data?.map(a => {
                if (a?.active === "Y") {
                  op?.push({
                    label: a?.pincode,
                    value: a?.pincodeId,
                    ...a
                  });
                }
              })
              setActivePincode(op)
              setTimeout(() => {
                setMenuIsOpenPincode(true)
              }, 1000)
            }
          } catch (error) {
            dispatch(setLoader(false))
          }
        }
        getSearchAPI()
      }
    }, 1000)

    return () => {
      clearTimeout(search)
    }
  }, [searchPincode])


  useEffect(() => {
    const search = setTimeout(() => {
      if (searchPincodeBranch?.length > 2) {
        const getSearchAPI = async () => {
          try {
            setMenuIsOpenCity(false)
            const payload = {
              selectedCity: formik?.values?.allCity ? [0] : formik?.values?.city?.map(a => a?.value),
              selectedStates: formik?.values?.state?.map(a => a?.value)
            }
            dispatch(setLoader(true))
            const res = await axios.post(`/getByPincodeForCityForSelectedState/${searchPincodeBranch}/${formik?.values?.allCity ? "Y" : "N"}`, payload)
            dispatch(setLoader(false))
            if (res?.data?.msgKey === "Success") {
              const op = []
              res?.data?.data?.map(a => {
                if (a?.active === "Y") {
                  op?.push({
                    label: a?.pincode,
                    value: a?.pincodeId,
                    ...a
                  });
                }
              })
              setActivePincodeBranch(op)
              // setActivePincodeBranch([{label:"Select All", value:"Select All"},...op])
              setTimeout(() => {
                setMenuIsOpenPincodeBranch(true)
              }, 1000)
            }
          } catch (error) {
            dispatch(setLoader(false))

          }
        }
        getSearchAPI()
      }
    }, 1000)

    return () => {
      clearTimeout(search)
    }
  }, [searchPincodeBranch])

  useEffect(() => {
    // const search = setTimeout(() => {
    // if (State?.length > 2) {

    const getState = async () => {
      try {
        dispatch(setLoader(true))
        const res = await axios.get('/getAllStates')
        dispatch(setLoader(false))

        const options = []
        if (res?.data?.data?.length) {
          res?.data?.data?.map(a => {
            if (a?.active === "Y") {
              options.push({
                label: a?.stateName,
                value: a?.stateId,
                ...a
              })
            }
          })
        }
        const allOptions = [...options];
        setActiveState(allOptions || [])
      } catch (error) {
        dispatch(setLoader(false))

      }
    }
    getState()
    // }
    // }, 1000)
    // return () => {
    //   clearTimeout(search)
    // }
  }, [])

  useEffect(() => {
    dispatch(getActiveDocumentData())
  }, [])
  useEffect(() => {
    if (activeDocumentData?.length) {
      const op = activeDocumentData?.map(a => ({
        label: a?.description,
        value: a?.description
      }))

      setDocumentOptions(op)
    }
  }, [activeDocumentData])

  const getAllCity = async () => {
    try {
      const res = await axios.get("getAllCities/0/0"); // Adjust endpoint as needed
      // console.log(res?.data, "finnalyresponse");

      if (res?.data?.messageKey === "Success") {
        const allCities = res.data.response
          .filter(item => item.active === "Y")
          .map(item => ({ label: item.cityName, value: item.cityId }));

        setActiveCity(allCities);
        setActiveCities(allCities);
        setActiveCitiesSpoc(allCities);


        return allCities; // Return all cities to be used in onChange handler
      }
    } catch (error) {
      console.error("Error fetching cities:", error);
    }
  };


  const fetchCitiesByState = async (stateIds) => {
    try {
      const stateIdsString = stateIds.join(',');
      const url = `/getCityByState/${stateIdsString}/1/10000`; // Adjust pagination as needed
      const res = await axios.get(url);

      if (res?.data?.messageKey === "Success") {
        const cities = res.data.response
          .filter(item => item.active === "Y")
          .map(item => ({ label: item.cityName, value: item.cityId }));

        setActiveCity(cities);
        setActiveCities(cities);
        setActiveCitiesSpoc(cities);

        return cities; // Return cities for use in onChange handler
      }
    } catch (error) {
      console.error("Error fetching cities:", error);
    }
  };

  // const allOptions = [
  //   // { value: '<SELECT_ALL>', label: 'Select All' },
  //   ...activePincode, // Your existing options
  // ];
  const totalOptionsCount = activePincode.length


  const fetchPincodesByCity = async (cityIds) => {
    try {
      const cityIdsString = cityIds.join(',');
      const url = `/getPincodeByCity/${cityIdsString}/1/1000`; // Assuming this fetches all pincodes
      const res = await axios.get(url);

      if (res?.data?.messageKey === "Success") {
        const pincodes = res.data.response
          .filter(item => item.active === "Y")
          .map(item => ({ label: item.pincode, value: item.pincodeId }));

        setActivePincode(pincodes);
        setAllPincode(pincodes);

        return pincodes; // Return pincodes for use in onChange handler
      }
    } catch (error) {
      console.error("Error fetching pincodes:", error);
    }
  };






  //

  useEffect(() => {
    if (StateIds?.length == 0) {
      setActiveCity([])
      setActivePincode([])

    }
    if (CityIds?.length == 0) {
      setActivePincode([])
    }

  }, [StateIds, CityIds])



  useEffect(() => {
    // getAllCity()
  }, [])
  return (
    <section style={{ marginBottom: "5px" }}>
      <Formik
        enableReinitialze={true}
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={isUpdate ? handleUpdate : handleCreate}
        innerRef={formikRef}
      >
        {({
          values,
          errors,
          handleChange,
          handleBlur,
          touched,
          handleSubmit,
          setTouched,
          setFieldValue,
          isSubmitting
        }) => {
          const err = Object.keys(errors)[0]
          scrollToErrorMessage(isSubmitting, err)
          // console.log(values, "finalizevalue")


          return (
            <>
              <Form onSubmit={handleSubmit}>
                <Card>
                  <CardBody>
                    <Row>
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Agency Name"
                          errorMessage={touched.agencyName && errors.agencyName}
                        >
                          <Input
                            bsSize="sm"
                            type="text"
                            id="agencyName"
                            placeholder="Agency Name"
                            value={values.agencyName}
                            onChange={handleChange}
                            maxLength={65}
                            onBlur={handleBlur}
                            invalid={
                              touched.agencyName && Boolean(errors.agencyName)
                            }
                            disabled={isView}
                          />
                        </Field>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Short Name"
                          errorMessage={touched.shortName && errors.shortName}
                        >
                          <Input
                            bsSize="sm"
                            type="text"
                            id="shortName"
                            placeholder="Short Name"
                            value={values.shortName}
                            maxLength={65}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={touched.shortName && Boolean(errors.shortName)}
                            disabled={isView}
                          />
                        </Field>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Agency Type"
                          errorMessage={touched.agencyType && errors.agencyType}
                        >
                          <Select
                            bsSize="sm"
                            type="text"
                            id="agencyType"
                            inputId="agencyType"
                            isClearable={true}
                            isSearchable
                            options={activeAgencyType}
                            value={activeAgencyType.filter(
                              (e) => e.value === values.agencyType
                            )}
                            closeMenuOnSelect={true}
                            onChange={(e) => setFieldValue("agencyType", e?.value)}
                            className={cx({
                              abc: touched.agencyType && Boolean(errors.agencyType),
                            })}
                            classNamePrefix="react-select"
                            onBlur={handleBlur}
                            menuPosition={"fixed"}
                            isDisabled={isView}
                          />
                        </Field>
                      </Col>

                      <Col lg={6} md={6} sm={12}></Col>

                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Agency Address"
                          errorMessage={touched.agencyAddress && errors.agencyAddress}
                        >
                          <Input
                            bsSize="sm"
                            type="textarea"
                            id="agencyAddress"
                            placeholder="Agency Address"
                            value={values.agencyAddress}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={
                              touched.agencyAddress && Boolean(errors.agencyAddress)
                            }
                            disabled={isView}
                            maxLength={65}
                          />
                        </Field>
                      </Col>

                      {/* {console.log(selectedState, "statevalues")} */}
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="State"
                        >
                          <MultiSelect
                            options={activeState}
                            value={(isView || isUpdate) ? values?.state : selectedState}
                            onChange={(e) => {
                              const selectedStateIds = e?.map(state => state.value);
                              setStateIds(selectedStateIds);
                              setselectedState(e);
                              setFieldValue("state", e);

                              // When states are selected, fetch cities for those states
                              if (selectedStateIds.length > 0) {
                                fetchCitiesByState(selectedStateIds);
                              } else {
                                setActiveCity([]);
                              }
                            }}
                            overrideStrings={{
                              selectSomeItems: "Select...",
                              allItemsAreSelected: "Select All",
                              selectAll: "Select All",
                            }}
                            labelledBy={"Select"}
                            isCreatable={true}
                          />
                        </Field>
                      </Col>


                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="City"
                          errorMessage={touched?.city && errors?.city}
                        >
                          <MultiSelect
                            options={activeCity}
                            onChange={(selectedOptions) => {
                              // Determine if all options are selected
                              if (selectedOptions.length === activeCity.length) {
                                fetchCitiesByState(StateIds).then((filteredCities = []) => {
                                  setFieldValue('city', filteredCities);
                                  setFieldValue('allCity', true);
                                  if (filteredCities.length) {
                                    fetchPincodesByCity(filteredCities.map(city => city.value));
                                  } else {
                                    setFieldValue('city', []);
                                  }
                                });
                              } else if (selectedOptions.length === 0) {
                                // No options selected
                                setIsSearchCity(false);
                                setSearchCity('');
                                setActivePincode([]);
                                setFieldValue('city', []);
                                setFieldValue('allCity', false);
                              } else {
                                // Some options selected
                                setFieldValue('city', selectedOptions);
                                setFieldValue('allCity', false);
                                fetchPincodesByCity(selectedOptions.map(city => city.value));
                              }
                              setFormik({ values, setFieldValue });
                            }}
                            closeMenu={false}
                            value={values?.city || []}
                            isClearable
                            isDisabled={isView}
                            onInputChange={(value) => {
                              setFormik({ values, setFieldValue });
                              onInputChangeCity(value);
                            }}
                            searchValue={searchCity}
                            isSearch={isSearchCity}
                            setIsSearch={setIsSearchCity}
                            menuIsOpen={menuIsOpenCity}
                            isMulti={true}
                            overrideStrings={{
                              selectSomeItems: "Select...",
                              allItemsAreSelected: "Select All",
                              selectAll: "Select All",
                            }}
                          />

                        </Field>

                      </Col>





                      {/* {console.log(values, "finalllystate")} */}
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Pincode"
                          errorMessage={touched.pincode && errors.pincode}
                        >
                          <MultiSelect
                            options={activePincode.map(pincode => ({
                              label: String(pincode.label),
                              value: String(pincode.value),
                            }))}
                            value={values?.pincode.map(pincode => ({
                              label: String(pincode.label),
                              value: String(pincode.value),
                            }))}
                            onChange={(selectedOptions) => {
                              const selectedCount = selectedOptions.length;

                              if (selectedCount === totalOptionsCount) {
                                const cityIds = (values.city || []).map(city => city.value);
                                if (cityIds.length > 0) {
                                  fetchPincodesByCity(cityIds).then((allPincodes) => {
                                    setFieldValue('pincode', allPincodes.map(pincode => ({
                                      label: String(pincode.label),
                                      value: String(pincode.value),
                                    })));
                                    setFieldValue('allPincode', 'allPincode');
                                  });
                                } else {
                                  setFieldValue('pincode', []);
                                }
                              } else if (selectedCount === 0) {
                                setIsSearchPincode(false);
                                setSearchPincode('');
                                setFieldValue('pincode', []);
                                setFieldValue('allPincode', false);
                              } else {
                                setFieldValue('pincode', selectedOptions.map(option => ({
                                  label: String(option.label),
                                  value: String(option.value),
                                })));
                                setFieldValue('allPincode', false);
                              }

                              setFormik({ values, setFieldValue });
                            }}
                            closeMenu={false}
                            isClearable
                            isDisabled={isView}
                            onInputChange={(value) => {
                              if (typeof value === 'string') {
                                setSearchPincode(value);
                                setFormik({ values, setFieldValue });
                                onInputChangePincode(value);
                              } else {
                                console.error('Invalid input change value:', value); // Debugging log
                              }
                            }}
                            searchValue={searchPincode}
                            isSearch={isSearchPincode}
                            setIsSearch={setIsSearchPincode}
                            menuIsOpen={menuIsOpenPincode}
                            isMulti={true}
                            overrideStrings={{
                              selectSomeItems: "Select...",
                              allItemsAreSelected: "Select All",
                              selectAll: "Select All",
                            }}
                            labelledBy={"Select"}
                          />
                        </Field>
                      </Col>



                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Nature of Service"
                          errorMessage={touched.natureOfService && errors.natureOfService}
                        >
                          <Select
                            bsSize="sm"
                            type="select"
                            id="natureOfService"
                            inputId="natureOfService"
                            value={values.natureOfService}
                            isMulti
                            options={activeNatureOfService}
                            onChange={(e) => {
                              setFieldValue("natureOfService", e);
                            }}
                            // filterOption={filterOption(activeNatureOfService)}
                            closeMenuOnSelect={false}
                            className={cx({
                              abc:
                                touched.natureOfService &&
                                Boolean(errors.natureOfService),
                            })}
                            classNamePrefix="react-select"
                            onBlur={handleBlur}
                            menuPosition={"fixed"}
                            isDisabled={isView}
                          />
                        </Field>
                      </Col>
                      <Col lg={6} md={6} sm={12}></Col>
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          label="Contact Person Name"
                        >
                          <Input
                            bsSize="sm"
                            type="text"
                            id="contactPersonName"
                            placeholder="Contact Person Name"
                            value={values.contactPersonName}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={
                              touched.contactPersonName &&
                              Boolean(errors.contactPersonName)
                            }
                            disabled={isView}
                            maxLength={50}
                          />
                        </Field>
                      </Col>

                      <Col lg={6} md={6} sm={12}>
                        <Field
                          label="Email"
                        >
                          <Input
                            bsSize="sm"
                            type="text"
                            id="contactEmailId"
                            placeholder="Contact Person Email"
                            value={values.contactEmailId}
                            onChange={handleChange}
                            disabled={isView}
                            maxLength={65}
                            invalid={
                              touched.contactEmailId &&
                              Boolean(errors.contactEmailId)
                            }
                            onBlur={handleBlur}
                          />
                        </Field>
                      </Col>
                      <Col lg={6} md={6} sm={12}>
                        {/* <Field
                          label="Contact Mobile"
                        >
                          <Input
                            bsSize="sm"
                            type="number"
                            id="contactMobileNo"
                            placeholder="Contact Mobile Number"
                            value={values.contactMobileNo}
                            // onChange={(e) => {
                            //   if (e.target.value.length <= 10)
                            //     setFieldValue("contactMobileNo", e.target.value);
                            // }}
                            onChange={(e) => {
                              const value = e.target.value;
                              // Allow only digits (0-9) and limit to 10 characters
                              if (/^\d{0,10}$/.test(value)) {
                                setFieldValue("contactMobileNo", value);
                              }
                            }}
                            disabled={isView}
                            onBlur={handleBlur}
                            invalid={
                              touched.contactMobileNo &&
                              Boolean(errors.contactMobileNo)
                            }
                          />
                        </Field> */}
                        <Field label="Contact Mobile">
                          <Input
                            bsSize="sm"
                            type="text"
                            id="contactMobileNo"
                            placeholder="Contact Mobile Number"
                            value={values.contactMobileNo}
                            onChange={(e) => {
                              const value = e.target.value;
                              // Allow only digits (0-9) and limit to 10 characters
                              if (/^\d{0,10}$/.test(value)) {
                                setFieldValue("contactMobileNo", value);
                              }
                            }}
                            disabled={isView}
                            onBlur={handleBlur}
                            invalid={
                              touched.contactMobileNo &&
                              (Boolean(errors.contactMobileNo) || (values.contactMobileNo.length < 10 && !errors.contactMobileNo))
                            }
                          />
                          {touched.contactMobileNo && values.contactMobileNo.length < 10 && (
                            <FormFeedback style={{ display: "block" }}>
                              Please re-enter a valid contact number (10 digits required).
                            </FormFeedback>
                          )}
                        </Field>


                      </Col>

                      <Col lg={12} md={12} sm={12}>
                        <Field
                          label="User System Dialler?"
                        >
                          <div role="group" aria-labelledby="my-radio-group">
                            <label>
                              <Input
                                type="radio"
                                id="usingSystemDialer"
                                name="usingSystemDialer"
                                value="Y"
                                defaultChecked={values.usingSystemDialer === "Y"}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                invalid={
                                  touched.usingSystemDialer &&
                                  Boolean(errors.usingSystemDialer)
                                }
                                disabled={isView}
                              />
                              Yes
                            </label>
                            <label style={{ marginLeft: "20px" }}>
                              <Input
                                type="radio"
                                id="usingSystemDialer"
                                name="usingSystemDialer"
                                value="N"
                                defaultChecked={values.usingSystemDialer === "N"}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                invalid={
                                  touched.usingSystemDialer &&
                                  Boolean(errors.usingSystemDialer)
                                }
                                disabled={isView}
                              />
                              No
                            </label>
                          </div>
                        </Field>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
                <Card className="mt-3">
                  <CardBody>
                    <Row>
                      <Col lg={4} md={4} sm={12}>
                        <Field
                          isRequired
                          label="Start Date"
                          errorMessage={touched.startDate && errors.startDate}
                        >
                          <Input
                            bsSize="sm"
                            type="date"
                            id="startDate"
                            placeholder="Mobile Number"
                            value={values.startDate}
                            max={values.endDate}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={touched.startDate && Boolean(errors.startDate)}
                            disabled={isView}
                          />
                        </Field>
                      </Col>
                      <Col lg={4} md={4} sm={12}>
                        <Field
                          isRequired
                          label="End Date"
                          errorMessage={touched.endDate && errors.endDate}
                        >
                          <Input
                            bsSize="sm"
                            type="date"
                            id="endDate"
                            placeholder="End Date"
                            value={values.endDate}
                            min={values.startDate}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={touched.endDate && Boolean(errors.endDate)}
                            disabled={isView}
                          />
                        </Field>
                      </Col>
                      <Col lg={4} md={4} sm={12}>
                        <Field
                          label="Expire Notification"
                        >
                          <FormGroup switch className="ms-2">
                            <Input
                              type="switch"
                              defaultChecked={values.expiryNotification === "Y"}
                              onChange={(e) =>
                                setFieldValue(
                                  "expiryNotification",
                                  e.target.checked ? "Y" : "N"
                                )
                              }
                              id="expiryNotification"
                              readOnly
                              disabled={isView}
                            />
                          </FormGroup>
                        </Field>
                      </Col>
                      {!(isView || isUpdate) ? (
                        <>
                          <Col lg={6} md={6} sm={12} className="d">
                            <label
                              htmlFor="aggrementScanning"
                              className={cx({
                                "btn-outline-primary": !(
                                  touched.aggrementScanning
                                ),
                                "btn btn-sm upload-button": true,
                                "is-invalid btn-outline-primary":
                                  touched.aggrementScanning
                              })}
                            >
                              {/* &&
                                  Boolean(errors.aggrementScanning) */}
                              <i className="bi bi-upload uploadIcon"></i>
                              <span>Aggrement Scanning</span>
                              <input
                                type="file"
                                id="aggrementScanning"
                                style={{ display: "none" }}
                                onChange={(event) => {
                                  const file = event.target?.files;
                                  setFieldValue("aggrementScanning", file);
                                  if (file) {
                                    const fileArray = Array.from(file);
                                    setAgreementDoc(fileArray)
                                  }
                                }}
                                multiple
                              />
                            </label>
                            {/* {<FormFeedback>{errors.aggrementScanning}</FormFeedback>} */}
                          </Col>
                          <Col lg={6} md={6} sm={12}>
                            <label
                              htmlFor="ruc"
                              className={cx({
                                "btn-outline-primary": !(
                                  touched.ruc
                                ),
                                "btn btn-sm upload-button": true,
                                "is-invalid btn-outline-primary":
                                  touched.ruc
                              })}
                            >
                              <i className="bi bi-upload uploadIcon"></i>
                              <span>
                                {"RCU Report"}
                              </span>
                              <input
                                type="file"
                                id="ruc"
                                style={{ display: "none" }}
                                onChange={(event) => {
                                  const file = event.target.files || null;
                                  setFieldValue("ruc", file);
                                  if (file) {
                                    const fileArray = Array.from(file);
                                    setRUCDoc(fileArray)
                                  }
                                }}
                                multiple
                              />
                            </label>
                            {/* {<FormFeedback>{errors.ruc}</FormFeedback>} */}

                          </Col>
                          {/* {console.log(aggrementDoc, "aggressss")} */}
                          <Col style={{ marginTop: "5px" }} >
                            <Card>
                              {
                                // console.log(values, "valdjdj")
                                aggrementDoc?.map((file, index) => (
                                  < Row style={{ display: "flex", alignItems: "center" }}>
                                    <Col >
                                      <p key={index}>{index + 1}</p>
                                    </Col>
                                    <Col>
                                      <p key={index}>{file.name}</p>
                                    </Col>
                                    <Col>
                                      <div style={{ background: "transparent", borderRadius: "50%", border: "none", cursor: "pointer" }} onClick={() => {
                                        const filterAggrementDetails = aggrementDoc?.filter((item) => item?.name !== file?.name)
                                        setFieldValue("aggrementScanning", filterAggrementDetails);
                                        setAgreementDoc(filterAggrementDetails)
                                      }}><RxCross1 height={50} width={50} /></div>
                                    </Col>
                                  </Row>
                                ))}
                            </Card>
                          </Col>
                          <Col style={{ marginTop: "5px" }} >
                            <Card>
                              {/* RUCDoc */}
                              {
                                RUCDoc?.map((file, index) => (
                                  < Row style={{ display: "flex", alignItems: "center" }}>
                                    <Col >
                                      <p key={index}>{index + 1}</p>
                                    </Col>
                                    <Col>
                                      <p key={index}>{file.name}</p>
                                    </Col>
                                    <Col>
                                      <div style={{ background: "transparent", borderRadius: "50%", border: "none", cursor: "pointer" }} onClick={() => {
                                        const filterRucDetails = RUCDoc?.filter((item) => item?.name !== file?.name)
                                        setFieldValue("ruc", filterRucDetails);
                                        setRUCDoc(filterRucDetails)
                                      }}><RxCross1 height={50} width={50} /></div>
                                    </Col>
                                  </Row>

                                ))
                              }
                            </Card>
                          </Col>
                        </>
                      ) : null}
                    </Row>
                  </CardBody>
                </Card>
                <Card className="mt-3 mb-3">
                  <CardBody>
                    <FieldArray
                      name="agencyBranches"
                      render={(helperMethod) => (
                        <>
                          <Button
                            type="button"
                            className="mb-2"
                            color="primary"
                            size="sm"
                            onClick={() =>
                              helperMethod.push({
                                branchCode: "",
                                branchName: "",
                              })
                            }
                            disabled={isView}
                          >
                            ADD BRANCH
                          </Button>
                          {
                            values?.agencyBranches?.map((branch, index) => {
                              let branchOptions = [];
                              const op = values?.allPincode ? activePincodeBranch : values?.pincode;
                              // console.log("op", op);
                              branchOptions = values?.agencyBranches?.filter((a, i) => i !== index)?.map(a => a?.branchPincode?.map(b => b?.pincode));

                              branchOptions = [].concat.apply([], branchOptions);


                              branchOptions = op?.filter(a => !branchOptions.includes(a?.pincode));

                              branchOptions = branchOptions?.map(pincode => ({
                                label: pincode.label,
                                value: pincode.value
                              }));
                              // console.log("branchOptions", branchOptions);

                              return (
                                <div className="agencyBranchRow">
                                  <div>
                                    <Field
                                      isRequired
                                      label="Branch Code"
                                      errorMessage={touched.agencyBranches?.[index]?.branchCode && errors.agencyBranches?.[index]?.branchCode}
                                    >
                                      <Input
                                        bsSize="sm"
                                        className="form-control form-control-sm"
                                        type="text"
                                        placeholder="Branch Code"
                                        id={`agencyBranches.${index}.branchCode`}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        invalid={
                                          touched.agencyBranches?.[index]?.branchCode &&
                                          Boolean(
                                            errors.agencyBranches?.[index]?.branchCode
                                          )
                                        }
                                        value={values.agencyBranches[index].branchCode}
                                        disabled={isView}
                                        maxLength={8}
                                      />
                                    </Field>
                                  </div>
                                  <div>
                                    <Field
                                      isRequired
                                      label="Branch Name"
                                      errorMessage={touched.agencyBranches?.[index]?.branchName && errors.agencyBranches?.[index]?.branchName}
                                    >
                                      <Input
                                        bsSize="sm"
                                        type="text"
                                        id={`agencyBranches.${index}.branchName`}
                                        placeholder=" Branch Name"
                                        value={values.agencyBranches[index].branchName}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        invalid={
                                          touched.agencyBranches?.[index]?.branchName &&
                                          Boolean(
                                            errors.agencyBranches?.[index]?.branchName
                                          )
                                        }
                                        disabled={isView}
                                        maxLength={25}
                                      />
                                    </Field>
                                  </div>
                                  <div>
                                    <Field
                                      label="Branch Pincode"
                                    >

                                      <MultiSelect
                                        key={index}
                                        options={branchOptions}
                                        value={values.agencyBranches[index].branchPincode}
                                        onChange={(e, isSelectAll) => {
                                          if (!e?.length || isSelectAll) {
                                            setIsSearchPincodeBranch(false);
                                            setSearchPincodeBranch('');
                                            setActivePincodeBranch([]);
                                          }
                                          setFieldValue(`agencyBranches.${index}.branchPincode`, e);
                                          setFormik({ values, setFieldValue });
                                        }}


                                        closeMenu={false}
                                        id={`agencyBranches.${index}.branchPincode`}
                                        isClearable
                                        isDisabled={isView}
                                        onInputChange={(value) => {
                                          setFormik({ values, setFieldValue });
                                          onInputChangePincodeBranch(value);
                                        }}
                                        searchValue={searchPincodeBranch}
                                        isSearch={isSearchPincodeBranch}
                                        setIsSearch={setIsSearchPincodeBranch}
                                        menuIsOpen={menuIsOpenPincodeBranch}
                                        isMulti={true}
                                        invalid={
                                          touched.agencyBranches?.[index]?.branchPincode &&
                                          Boolean(errors.agencyBranches?.[index]?.branchPincode)
                                        }
                                        className={cx({
                                          abc:
                                            touched.agencyBranches?.[index]?.branchPincode &&
                                            Boolean(errors.agencyBranches?.[index]?.branchPincode),
                                        })}

                                        overrideStrings={{
                                          selectSomeItems: "Select...",
                                          allItemsAreSelected: "Select All",
                                          selectAll: "Select All",
                                        }}
                                        labelledBy={"Select"}
                                        isCreatable={true}
                                      />


                                    </Field>
                                  </div>
                                  <div>
                                    {index > 0 && (
                                      <button
                                        title="Delete"
                                        type="button"
                                        className="btn btn-sm btn-danger mx-auto d-flex"
                                        style={{ borderRadius: "20%", color: "#fff" }}
                                        onClick={() => {
                                          Swal.fire({
                                            title: "Are you sure?",
                                            text: "You won't be able to revert this!",
                                            icon: "warning",
                                            showCancelButton: true,
                                            confirmButtonColor: "#3085d6",
                                            cancelButtonColor: "#d33",
                                            confirmButtonText: "Yes, delete it!",
                                          }).then((result) => {
                                            if (result.isConfirmed) {
                                              helperMethod.remove(index);
                                            }
                                          });
                                        }}
                                        disabled={isView}
                                      >
                                        X
                                      </button>
                                    )}
                                  </div>
                                </div>
                              )
                            })}
                        </>
                      )}
                    />
                  </CardBody>

                  <CardBody>
                    <FieldArray
                      name="agencyOwnerDetails"
                      render={(helperMethod) => (
                        <>
                          <Button
                            type="button"
                            size="sm"
                            color="primary"
                            className="mb-2"
                            onClick={() =>
                              helperMethod.push({
                                name: "",
                                email: "",
                                mobile: "",
                                city: "",
                                state: "",
                              })
                            }
                            disabled={isView}
                          >
                            ADD OWNER
                          </Button>
                          <CardBody>
                            {values?.agencyOwnerDetails?.map((branch, index) => (
                              <Card key={`owner${index}`} className="mb-3">
                                {index > 0 && (
                                  <button
                                    type="button"
                                    className="btn btn-sm ms-auto d-flex"
                                    style={{
                                      borderRadius: "20%",
                                      color: "red",
                                    }}
                                    onClick={() => {
                                      Swal.fire({
                                        title: "Are you sure?",
                                        text: "You won't be able to revert this!",
                                        icon: "warning",
                                        showCancelButton: true,
                                        confirmButtonColor: "#3085d6",
                                        cancelButtonColor: "#d33",
                                        confirmButtonText: "Yes, delete it!",
                                      }).then((result) => {
                                        if (result.isConfirmed) {
                                          helperMethod.remove(index);
                                        }
                                      });
                                    }}
                                    disabled={isView}
                                  >
                                    <i className="bi bi-x-lg"></i>
                                  </button>
                                )}
                                <CardBody className={cx({ "pt-0": index > 0 })}>
                                  <Row>
                                    <Col lg={4} md={4} sm={12}>
                                      <Field
                                        isRequired
                                        label="Name"
                                        errorMessage={touched.agencyOwnerDetails?.[index]?.ownerPersonName && errors.agencyOwnerDetails?.[index]?.ownerPersonName}
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="text"
                                          id={`agencyOwnerDetails.${index}.ownerPersonName`}
                                          placeholder="Owner Person Name"
                                          value={
                                            values.agencyOwnerDetails[index]
                                              .ownerPersonName
                                          }
                                          onChange={handleChange}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.agencyOwnerDetails?.[index]
                                              ?.ownerPersonName &&
                                            Boolean(
                                              errors.agencyOwnerDetails?.[index]
                                                ?.ownerPersonName
                                            )
                                          }
                                          disabled={isView}
                                          maxLength={65}
                                        />
                                      </Field>
                                    </Col>
                                    <Col lg={4} md={4} sm={12}>
                                      <Field
                                        isRequired
                                        label="Email"
                                        errorMessage={touched.agencyOwnerDetails?.[index]?.ownerEmailId && errors.agencyOwnerDetails?.[index]?.ownerEmailId}
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="email"
                                          id={`agencyOwnerDetails.${index}.ownerEmailId`}
                                          placeholder="Owner Email ID"
                                          value={
                                            values.agencyOwnerDetails[index]
                                              .ownerEmailId
                                          }
                                          onChange={handleChange}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.agencyOwnerDetails?.[index]
                                              ?.ownerEmailId &&
                                            Boolean(
                                              errors.agencyOwnerDetails?.[index]
                                                ?.ownerEmailId
                                            )
                                          }
                                          disabled={isView}
                                          maxLength={65}
                                        />
                                      </Field>
                                    </Col>
                                    <Col lg={4} md={4} sm={12}>
                                      <Field
                                        isRequired
                                        label="Mobile"
                                        errorMessage={touched.agencyOwnerDetails?.[index]?.ownerMobileNumber && errors.agencyOwnerDetails?.[index]?.ownerMobileNumber}
                                      >
                                        {/* <Input
                                          bsSize="sm"
                                          type="number"
                                          id={`agencyOwnerDetails.${index}.ownerMobileNumber`}
                                          placeholder="Owner Mobile Number"
                                          value={
                                            values.agencyOwnerDetails[index]
                                              .ownerMobileNumber
                                          }
                                          onChange={(e) => {
                                            if (e.target.value.length <= 10)
                                              setFieldValue(
                                                `agencyOwnerDetails.${index}.ownerMobileNumber`,
                                                e.target.value
                                              );
                                          }}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.agencyOwnerDetails?.[index]
                                              ?.ownerMobileNumber &&
                                            Boolean(
                                              errors.agencyOwnerDetails?.[index]
                                                ?.ownerMobileNumber
                                            )
                                          }
                                          disabled={isView}
                                        /> */}
                                        <Input
                                          bsSize="sm"
                                          type="text" // Change to type="text" for regex validation
                                          id={`agencyOwnerDetails.${index}.ownerMobileNumber`}
                                          placeholder="Owner Mobile Number"
                                          value={values.agencyOwnerDetails[index].ownerMobileNumber}
                                          onChange={(e) => {
                                            const value = e.target.value;
                                            // Allow only digits (0-9) and limit to 10 characters
                                            if (/^\d{0,10}$/.test(value)) {
                                              setFieldValue(`agencyOwnerDetails.${index}.ownerMobileNumber`, value);
                                            }
                                          }}
                                          onBlur={handleBlur}
                                          invalid={
                                            touched.agencyOwnerDetails?.[index]?.ownerMobileNumber &&
                                            Boolean(errors.agencyOwnerDetails?.[index]?.ownerMobileNumber)
                                          }
                                          disabled={isView}
                                        />

                                      </Field>
                                    </Col>
                                  </Row>
                                  <Row>

                                    <Col lg={4} md={4} sm={12}>
                                      <Field
                                        isRequired
                                        label="City"
                                        errorMessage={touched.agencyOwnerDetails?.[index]?.city && errors.agencyOwnerDetails?.[index]?.city}
                                      >
                                        {isView ? (
                                          <Input
                                            bsSize="sm"
                                            type="text"
                                            id={`agencyOwnerDetails.${index}.city`}
                                            value={values.agencyOwnerDetails[index].cityName || ''}
                                            disabled
                                          />
                                        ) : (
                                          <Select
                                            bsSize="sm"
                                            options={activeCities}
                                            inputId={`agencyOwnerDetails.${index}.city`}
                                            value={selectedCity || activeCities.find(
                                              (e) => e.value === values.agencyOwnerDetails[index].city
                                            ) || (values.agencyOwnerDetails[index].cityName ?
                                              { label: values.agencyOwnerDetails[index].cityName, value: values.agencyOwnerDetails[index].city }
                                              : null)
                                            }
                                            onChange={(e) => handleCityChange(e, index, setFieldValue)} // Use the function here
                                            onInputChange={(value) => {
                                              setInputValue(value);
                                              fetchCities(value, setActiveCities); // Call the fetchCities function
                                            }}
                                            onBlur={handleBlur}
                                            className={cx({
                                              abc: touched.agencyOwnerDetails?.[index]?.city && Boolean(errors.agencyOwnerDetails?.[index]?.city),
                                            })}
                                            classNamePrefix="react-select"
                                            isDisabled={isView}
                                          />


                                        )}
                                      </Field>
                                    </Col>

                                    <Col lg={4} md={4} sm={8}>
                                      <Field
                                        isRequired
                                        label="State"
                                        errorMessage={touched.agencyOwnerDetails?.[index]?.state && errors.agencyOwnerDetails?.[index]?.state}
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="text"
                                          id={`agencyOwnerDetails.${index}.state`}
                                          value={values.agencyOwnerDetails[index].stateName} // This should be stateId
                                          disabled
                                        />
                                      </Field>
                                      {/* <h2>
                                        {`State ID: ${values.agencyOwnerDetails[index].state} - State Name: ${values.agencyOwnerDetails[index].stateName}`}
                                      </h2> */}
                                    </Col>


                                    {/* <Col lg={4} md={4} sm={8}>
                                      <Field
                                        isRequired
                                        label="City"
                                        errorMessage={touched.agencyOwnerDetails?.[index]?.city && errors.agencyOwnerDetails?.[index]?.city}
                                      >
                                        {isView ? (
                                          // Display cityName when in view mode
                                          <Input
                                            bsSize="sm"
                                            type="text"
                                            id={`agencyOwnerDetails.${index}.city`}
                                            value={values.agencyOwnerDetails[index].cityName || ''}
                                            disabled
                                          />
                                        ) : (
                                          // Display Select component when not in view mode
                                          <Select
                                            bsSize="sm"
                                            options={activeCities}
                                            inputId={`agencyOwnerDetails.${index}.city`}
                                            value={selectedCitySpoc || activeCities.find(
                                              (e) => e.value === values.agencyOwnerDetails[index].city
                                            ) || (values.agencyOwnerDetails[index].cityName ?
                                              { label: values.agencyOwnerDetails[index].cityName, value: values.agencyOwnerDetails[index].city }
                                              : null)} // Ensure `null` if no match is found
                                            onChange={(e) => handleCityChange(e, index, setFieldValue)}

                                            onInputChange={(value) => {
                                              setInputValue(value); // Set input value for tracking
                                              fetchCities(value, setActiveCities); // Call the fetchCitiesSpoc function
                                            }}
                                            onBlur={handleBlur}
                                            className={cx({
                                              abc: touched.agencyOwnerDetails?.[index]?.city && Boolean(errors.agencyOwnerDetails?.[index]?.city),
                                            })}
                                            classNamePrefix="react-select"
                                            isDisabled={isView}
                                          />

                                        )}
                                      </Field>
                                    </Col>
                                    <Col lg={4} md={4} sm={8}>
                                      <Field
                                        isRequired
                                        label="State"
                                        errorMessage={touched.agencyOwnerDetails?.[index]?.state && errors.agencyOwnerDetails?.[index]?.state}
                                      >
                                        <Input
                                          bsSize="sm"
                                          type="text"
                                          id={`agencyOwnerDetails.${index}.state`}
                                          value={values.agencyOwnerDetails[index].state}
                                          // defaultValue={
                                          //   activeCities.filter(
                                          //     (e) => e.value === values.agencyOwnerDetails[index].city
                                          //   )[0]?.state || values.agencyOwnerDetails[index].stateName
                                          // }
                                          disabled
                                        />
                                      </Field>
                                    </Col> */}


                                  </Row>


                                </CardBody>
                              </Card>
                            ))}
                          </CardBody>
                        </>
                      )}
                    />
                  </CardBody>
                  <CardBody>
                    <FieldArray
                      name="agencySpocDetails"
                      render={(helperMethod) => (
                        <>
                          <Button
                            type="button"
                            className="mb-2"
                            color="primary"
                            onClick={() =>
                              helperMethod.push({
                                name: "",
                                email: "",
                                mobile: "",
                                city: "",
                                state: "",
                              })
                            }
                            size="sm"
                            disabled={isView}
                          >
                            ADD SPOC
                          </Button>
                          <CardBody>
                            {values?.agencySpocDetails?.map(
                              (agencySpocDetails, index) => (
                                <Card key={`SPOC${index}`}>
                                  {index > 0 && (
                                    <button
                                      title="Delete"
                                      type="button"
                                      className="btn btn-sm ms-auto d-flex"
                                      style={{
                                        borderRadius: "20%",
                                        color: "red",
                                      }}
                                      onClick={() => {
                                        Swal.fire({
                                          title: "Are you sure?",
                                          text: "You won't be able to revert this!",
                                          icon: "warning",
                                          showCancelButton: true,
                                          confirmButtonColor: "#3085d6",
                                          cancelButtonColor: "#d33",
                                          confirmButtonText: "Yes, delete it!",
                                        }).then((result) => {
                                          if (result.isConfirmed) {
                                            helperMethod.remove(index);
                                          }
                                        });
                                      }}
                                      disabled={isView}
                                    >
                                      <i className="bi bi-x-lg"></i>
                                    </button>
                                  )}
                                  <CardBody>
                                    <Row>
                                      <Col lg={4} md={4} sm={8}>
                                        <Field
                                          isRequired
                                          label="Name"
                                          errorMessage={touched.agencySpocDetails?.[index]?.spocPersonName && errors.agencySpocDetails?.[index]?.spocPersonName}
                                        >
                                          <Input
                                            bsSize="sm"
                                            type="text"
                                            id={`agencySpocDetails.${index}.spocPersonName`}
                                            placeholder="SPOC Person Name"
                                            value={
                                              values.agencySpocDetails[index]
                                                .spocPersonName
                                            }
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            invalid={
                                              touched.agencySpocDetails?.[index]
                                                ?.spocPersonName &&
                                              Boolean(
                                                errors.agencySpocDetails?.[index]
                                                  ?.spocPersonName
                                              )
                                            }
                                            maxLength={65}
                                            disabled={isView}
                                          />
                                        </Field>
                                      </Col>
                                      <Col lg={4} md={4} sm={8}>
                                        <Field
                                          isRequired
                                          label="Email"
                                          errorMessage={touched.agencySpocDetails?.[index]?.spocEmailId && errors.agencySpocDetails?.[index]?.spocEmailId}
                                        >
                                          <Input
                                            bsSize="sm"
                                            type="email"
                                            id={`agencySpocDetails.${index}.spocEmailId`}
                                            placeholder="SPOC Email ID"
                                            value={
                                              values.agencySpocDetails[index]
                                                .spocEmailId
                                            }
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            invalid={
                                              touched.agencySpocDetails?.[index]
                                                ?.spocEmailId &&
                                              Boolean(
                                                errors.agencySpocDetails?.[index]
                                                  ?.spocEmailId
                                              )
                                            }
                                            disabled={isView}
                                            maxLength={65}
                                          />
                                        </Field>
                                      </Col>
                                      <Col lg={4} md={4} sm={8}>
                                        <Field
                                          isRequired
                                          label="Mobile"
                                          errorMessage={touched.agencySpocDetails?.[index]?.spocMobileNo && errors.agencySpocDetails?.[index]?.spocMobileNo}
                                        >
                                          <Input
                                            bsSize="sm"
                                            type="text" // Change to type="text" for better control over input
                                            id={`agencySpocDetails.${index}.spocMobileNo`}
                                            placeholder="SPOC Mobile"
                                            value={values.agencySpocDetails[index].spocMobileNo}
                                            onChange={(e) => {
                                              const value = e.target.value;
                                              // Allow only digits (0-9) and limit to 10 characters
                                              if (/^\d{0,10}$/.test(value)) {
                                                setFieldValue(`agencySpocDetails.${index}.spocMobileNo`, value);
                                              }
                                            }}
                                            onBlur={handleBlur}
                                            invalid={
                                              touched.agencySpocDetails?.[index]?.spocMobileNo &&
                                              Boolean(errors.agencySpocDetails?.[index]?.spocMobileNo)
                                            }
                                            disabled={isView}
                                          />

                                        </Field>
                                      </Col>
                                    </Row>
                                    {/* {console.log(values.activecities[0], 'Cities Data not getting')} */}
                                    <Row>



                                      <Col lg={4} md={4} sm={8}>
                                        <Field
                                          isRequired
                                          label="City"
                                          errorMessage={touched.agencySpocDetails?.[index]?.city && errors.agencySpocDetails?.[index]?.city}
                                        >
                                          {isView ? (
                                            // Display cityName when in view mode
                                            <Input
                                              bsSize="sm"
                                              type="text"
                                              id={`agencySpocDetails.${index}.city`}
                                              value={values.agencySpocDetails[index].cityName || ''}
                                              disabled
                                            />
                                          ) : (
                                            // Display Select component when not in view mode
                                            <Select
                                              bsSize="sm"
                                              options={activeCitiesSpoc}
                                              inputId={`agencySpocDetails.${index}.city`}
                                              value={selectedCitySpoc || activeCitiesSpoc.find(
                                                (e) => e.value === values.agencySpocDetails[index].city
                                              ) || (values.agencySpocDetails[index].cityName ?
                                                { label: values.agencySpocDetails[index].cityName, value: values.agencySpocDetails[index].city }
                                                : null)} // Ensure `null` if no match is found
                                              onChange={(e) => handleCitySpocChange(e, index, setFieldValue)}

                                              onInputChange={(value) => {
                                                setInputValueSpoc(value); // Set input value for tracking
                                                fetchCitiesSpoc(value, setActiveCitiesSpoc); // Call the fetchCitiesSpoc function
                                              }}
                                              onBlur={handleBlur}
                                              className={cx({
                                                abc: touched.agencySpocDetails?.[index]?.city && Boolean(errors.agencySpocDetails?.[index]?.city),
                                              })}
                                              classNamePrefix="react-select"
                                              isDisabled={isView}
                                            />

                                          )}
                                        </Field>
                                      </Col>




                                      <Col lg={4} md={4} sm={8}>
                                        <Field
                                          isRequired
                                          label="State"
                                          errorMessage={touched.agencySpocDetails?.[index]?.state && errors.agencySpocDetails?.[index]?.state}
                                        >
                                          <Input
                                            bsSize="sm"
                                            type="text"
                                            id={`agencySpocDetails.${index}.state`}
                                            value={values.agencySpocDetails[index].stateName} // This should be stateId
                                            disabled
                                          />
                                        </Field>
                                        {/* <h2>
                                          {`State ID: ${values.agencySpocDetails[index].state} - State Name: ${values.agencySpocDetails[index].stateName}`}
                                        </h2> */}
                                      </Col>

                                    </Row>
                                  </CardBody>
                                </Card>
                              )
                            )}
                          </CardBody>
                        </>
                      )}
                    />
                  </CardBody>
                </Card>
                {!(isView || isUpdate) && (
                  <Card className="mt-3">
                    <FieldArray
                      name="kycs"
                      render={(helperMethod) => (
                        <CardBody>
                          {/* {kycCount < 3 && ( */}
                          <Button
                            type="button"
                            className="mb-2"
                            color="primary"
                            onClick={() => {
                              helperMethod.push({
                                KYC: "",
                                docType: ""
                              });
                              setKycCount(kycCount + 1);
                            }}
                            size="sm"
                          >
                            ADD KYC
                          </Button>
                          {/* )} */}
                          <Row>
                            {values.kycs?.map((kycs, index) => (
                              <Col
                                key={`kyc${index}`}
                                lg={6}
                                md={6}
                                sm={12}
                                className="mb-3"
                              >
                                <Row>
                                  <Col sm={6}>
                                    <Field
                                      // isRequired
                                      label="Select Document Type"
                                    // errorMessage={touched.kycs?.[index]?.docType && errors.kycs?.[index]?.docType}
                                    >
                                      <Select
                                        bsSize="sm"
                                        type="text"
                                        id={`kycs.${index}.docType`}
                                        isClearable={true}
                                        isSearchable
                                        options={documentOptions}
                                        value={documentOptions.filter((e) => e.value === values?.kycs[index]?.docType)}
                                        closeMenuOnSelect={true}
                                        onChange={(e) => setFieldValue(`kycs.${index}.docType`, e?.value)}
                                        // className={cx({
                                        //   abc: touched.kycs?.[index]?.docType && Boolean(errors.kycs?.[index]?.docType),
                                        // })}
                                        classNamePrefix="react-select"
                                        onBlur={handleBlur}
                                        menuPosition={"fixed"}
                                        isDisabled={isView}
                                      />
                                    </Field>
                                  </Col>
                                  <Col className="mt-4" sm={4}>
                                    <Field
                                    // isRequired

                                    // errorMessage={touched.kycs?.[index]?.docType && errors.kycs?.[index]?.docType}
                                    ></Field>
                                    <div className="d-flex align-items-center">
                                      <label
                                        className={cx({
                                          "btn-outline-primary": !(
                                            touched.kycs?.[index]?.KYC &&
                                            Boolean(errors.kycs?.[index]?.KYC)
                                          ),
                                          "btn btn-sm upload-button": true,
                                          "is-invalid btn-outline-danger":
                                            touched.kycs?.[index]?.KYC && Boolean(errors.kycs?.[index]?.KYC),
                                        })}
                                      >
                                        <i className="bi bi-upload uploadIcon"></i>
                                        <span>
                                          {values.kycs?.[index].KYC ? values.kycs?.[index].KYC.name : "KYC File"}
                                        </span>
                                        <input
                                          type="file"
                                          id={`kycs.${index}.KYC`}
                                          style={{ display: "none" }}
                                          multiple
                                          onClick={(e) => {
                                            setTouched({
                                              ...touched,
                                              [`kycs.${index}.KYC`]: true,
                                            });
                                          }}
                                          onChange={(event) => {
                                            const file = event.target.files[0] || null;
                                            setFieldValue(`kycs.${index}.KYC`, file);
                                          }}
                                          disabled={!values?.kycs[index]?.docType}
                                        />
                                      </label>
                                      {values.kycs?.[index].KYC && (
                                        <span

                                          className="text-black text-lg ms-2" // Use ms-2 for margin start
                                          onClick={() => setFieldValue(`kycs.${index}.KYC`, null)}
                                        >
                                          <i className="bi bi-x-circle"></i>
                                        </span>
                                      )}
                                    </div>
                                    <FormFeedback>
                                      {/* {errors.kycs?.[index]?.KYC} */}
                                    </FormFeedback>
                                  </Col>


                                  {/* <Col className="mt-4" sm={4}>
                                    <Field
                                    >
                                    </Field>
                                    <label
                                      className={cx({
                                        "btn-outline-primary": !(
                                          touched.kycs?.[index]?.KYC &&
                                          Boolean(errors.kycs?.[index]?.KYC)
                                        ),
                                        "btn btn-sm upload-button": true,
                                        "is-invalid btn-outline-danger":
                                          touched.kycs?.[index]?.KYC &&
                                          Boolean(errors.kycs?.[index]?.KYC),
                                      })}
                                    >
                                      <i className="bi bi-upload uploadIcon"></i>
                                      <span>
                                        {values.kycs?.[index].KYC
                                          ? values.kycs?.[index].KYC.name
                                          : "KYC File"}
                                      </span>
                                      <input
                                        type="file"
                                        id={`kycs.${index}.KYC`}
                                        style={{ display: "none" }}
                                        multiple
                                        onClick={(e) => {
                                          setTouched({
                                            ...touched,
                                            [`kycs.${index}.KYC`]: true,
                                          });
                                        }}
                                        onChange={(event) => {
                                          const file = event.target.files[0] || null;
                                          // Handle the selected file here
                                          setFieldValue(`kycs.${index}.KYC`, file);
                                        }}
                                        disabled={!values?.kycs[index]?.docType}
                                      />
                                    </label>
                                    {
                                      <FormFeedback>
                                        {/* {errors.kycs?.[index]?.KYC} */}
                                  {/* </FormFeedback> */}
                                  {/* } */}
                                  {/* </Col>  */}
                                  <Col sm={2}>
                                    {index > 0 && (
                                      <button
                                        title="Delete"
                                        type="button"
                                        className="btn btn-sm btn-danger mx-auto d-flex"
                                        style={{
                                          borderRadius: "20%",
                                          color: "#fff",
                                        }}
                                        onClick={() => {
                                          Swal.fire({
                                            title: "Are you sure?",
                                            text: "You won't be able to revert this!",
                                            icon: "warning",
                                            showCancelButton: true,
                                            confirmButtonColor: "#3085d6",
                                            cancelButtonColor: "#d33",
                                            confirmButtonText: "Yes, delete it!",
                                          }).then((result) => {
                                            if (result.isConfirmed) {
                                              helperMethod.remove(index);
                                              setKycCount(kycCount - 1);
                                            }
                                          });
                                        }}
                                      >
                                        X
                                      </button>
                                    )}
                                  </Col>
                                </Row>
                              </Col>
                            ))}
                          </Row>
                        </CardBody>
                      )}
                    />
                  </Card>
                )}
                <Card className="mt-3">
                  <CardBody>
                    <Row>
                      <Col lg={6} md={6} sm={12}>
                        <Field
                          isRequired
                          label="Managed By"
                          errorMessage={touched.managedBy && errors.managedBy}
                        >
                          <Select
                            type="select"
                            id="managedBy"
                            options={activeUsers}
                            value={activeUsers?.filter(
                              (user) => user.value === Number(values.managedBy)
                            )}
                            onChange={(e) => setFieldValue("managedBy", e?.value)}
                            className={cx({
                              abc: touched.managedBy && Boolean(errors.managedBy),
                            })}
                            classNamePrefix="react-select"
                            isDisabled={isView}
                            onMenuScrollToBottom={(e) => {
                              if (userCurrentPage <= userTotalPage) {
                                setUserCurrentPage(prev => prev + 1)
                              }
                            }}
                          />
                        </Field>
                      </Col>
                      <Col lg={4} md={4} sm={12}>
                        <Field
                          label="Status"
                        >
                          <FormGroup switch className="ms-2">
                            <Input
                              type="switch"
                              checked={values.status === "Y"}
                              onChange={(e) => {
                                setFieldValue(
                                  "status",
                                  e.target.checked ? "Y" : "N"
                                );
                              }}
                              id="status"
                              readOnly
                              disabled={isView}
                            />
                          </FormGroup>
                        </Field>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
                {/* new start */}
                <div className="d-flex gap-md-5">
                  {isView ? (
                    <Card className="mt-3 w-50">
                      <CardHeader className="h5">Mapped Users</CardHeader>
                      <CardBody>
                        <Table className="text-center">
                          <thead>
                            <tr>
                              <th>No.</th>
                              <th>User Name</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>{1}</td>
                              <td>{mappedUser}</td>
                            </tr>
                          </tbody>
                        </Table>
                      </CardBody>
                    </Card>
                  ) : null}
                  {/* new end  */}
                  {/* new start */}
                  {isView ? (
                    <Card className="mt-3 w-50">
                      <CardHeader className="h5">Agency Users</CardHeader>
                      <CardBody>
                        <Table className="text-center">
                          <thead>
                            <tr>
                              <th>No.</th>
                              <th>User Name</th>
                            </tr>
                          </thead>
                          <tbody>
                            {/* <tr> */}
                            {agencyUser.map((value, index) => (
                              <tr>
                                <td>{index + 1}</td>
                                <td>{value}</td>
                              </tr>
                            ))}
                            {/* <td>1</td>
                                  <td>2</td> */}
                            {/* </tr> */}
                          </tbody>
                        </Table>
                      </CardBody>
                    </Card>
                  ) : null}
                </div>
                {/* new end  */}

                {(isView || isUpdate) && (
                  <Card className="mt-3">
                    <CardHeader className="h5">Documents Uploaded</CardHeader>
                    <CardBody>
                      <FileTable
                        onBtnClick={onBtnClickAgg}
                        isView={isView}
                        btnName="Add Aggrement Document"
                        docData={aggDocument}
                        setAggDocument={setAggDocument}
                        id="docAgencyAggrementScanningId"
                        downloadURL="/download-aggrement-scanning"
                        onEditClick={onEditClickAgg}
                      />
                    </CardBody>
                    <CardBody>
                      <FileTable
                        onBtnClick={onBtnClickRcu}
                        isView={isView}
                        btnName="Add RCU Document"
                        docData={rcaDocument}
                        setRcaDocument={setRcaDocument}
                        id="documentAgencyRCAId"
                        downloadURL="/download-agency-rca"
                        onEditClick={onEditClickRcu}
                      />
                    </CardBody>
                    <CardBody>
                      <FileTable
                        onBtnClick={onBtnClickKyc}
                        isView={isView}
                        btnName="Add KYC Document"
                        docData={kycDocument}
                        setKycDocument={setKycDocument}
                        id="docKycAgencyId"
                        downloadURL="/download-kyc"
                        onEditClick={onEditClickKyc}
                      />
                    </CardBody>
                  </Card>
                )}

                {isView || (
                  <div className="d-flex justify-content-end mt-2">
                    <Button color="primary" type="submit" className="me-1" size="sm">
                      Submit
                    </Button>{" "}
                    <Button
                      color="danger"
                      type="button"
                      className="ml-2"
                      style={{ color: "#fff" }}
                      onClick={() => cancelModal(false)}
                      size="sm"
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </Form >
            </>
          )
        }}
      </Formik>

      {
        addKycs &&
        <FileUpload
          header="Add KYC"
          visible={addKycs}
          setVisible={setAddKycs}
          onSave={onKycSave}
          documentOptions={documentOptions}
        />
      }

      {
        addRcu &&
        <FileUpload
          header="Add RCU"
          visible={addRcu}
          setVisible={setAddRcu}
          onSave={onRcuSave}
        />
      }

      {
        addAgg &&
        <FileUpload
          header="Add Aggrement"
          visible={addAgg}
          setVisible={setAddAgg}
          onSave={onAggSave}
        />
      }

      {
        editDocument?.visible &&
        <FileUpload
          header={`Edit ${editDocument?.name} Document`}
          visible={editDocument?.visible}
          setVisible={() => {
            setEditDocument({
              visible: false,
              name: ''
            })
          }}
          onSave={onEditDocSave}
        />
      }
    </section >
  );
}