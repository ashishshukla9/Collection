import React, { useEffect, useState } from "react";
import {
  Container,
  Input,
  Button,
  Card,
  CardBody,
  CardHeader,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import CreateAgency from "./CreateAgency";
import axios from "axios";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import SearchBarHeader from "../../components/Header/SearchBarHeader";
import { setLoader } from "../../reducer/globalReducer";

// ... existing imports

export default function Agency({ access }) {
  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();

  const [view, setView] = useState(false);
  const [update, setUpdate] = useState(false);
  const [open, setOpen] = useState(false);

  const [agencyData, setAgencyData] = useState([]);
  const [data, setData] = useState(null);

  const dispatch = useDispatch();

  // Fetch agencies
  const getAllAgency = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllAgency");
      dispatch(setLoader(false));

      if (res?.data?.msgKey === "Success") {
        // console.log("agency all", res?.data);
        setAgencyData(res?.data?.data);
      } else {
        setAgencyData([]);
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  // console.log("agencyDataagencyData", agencyData);
  // Search agency by name
  const searchAgency = async (val) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getAgencyByAgencyName/${val}`);
      dispatch(setLoader(false));

      if (res?.data?.msgKey === "Success") {
        // console.log("agency by name", res?.data);
        setAgencyData(res?.data?.data);
      } else {
        setAgencyData([]);
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  // Handle successful data update
  const onSuccess = () => {
    setOpen(false);
    setUpdate(false);
    getAllAgency();
  };

  useEffect(() => {
    getAllAgency();
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => searchAgency(data)}
        getAllAPI={getAllAgency}
        onClick={() => setOpen(!open)}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        {/* <CardHeader className="p-2 d-flex justify-content-between align-items-center">
          <p className="m-0">Agencies</p>
          {user?.masterRole[access] === "V" || (
            <Button size={"sm"} color="primary">
              Upload Data
            </Button>
          )}
        </CardHeader> */}
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={agencyData}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="agencyName" header="Agency Name" sortable></Column>
            <Column field="agencyType" header="Agency Type" sortable></Column>
            <Column
              field="startDate"
              header="Start Date"
              body={(rowData) => {
                const date = new Date(rowData?.startDate)?.toLocaleDateString()?.split('/');
                return <span>{`${date[1]}/${date[0]}/${date[2]}`}</span>;
              }}
              sortable
            ></Column>
            <Column
              field="endDate"
              header="End Date"
              body={(rowData) => {
                const date = new Date(rowData?.endDate)?.toLocaleDateString()?.split('/');
                return <span>{`${date[1]}/${date[0]}/${date[2]}`}</span>;
              }}
              sortable
            ></Column>
            <Column
              field="status"
              header="Status"
              body={(rowData) =>
                rowData.status === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let tempValues = JSON.parse(JSON.stringify(rowData));
                        tempValues.startDate = rowData.startDate?.split("T")[0];
                        tempValues.endDate = rowData.endDate?.split("T")[0];
                        tempValues.natureOfService = JSON.parse(rowData.natureOfService);
                        let tempNature = tempValues.natureOfService.map((nature) => ({
                          label: nature,
                          value: nature,
                        }));
                        tempValues.natureOfService = tempNature;
                        setData(tempValues);
                        setView(true);
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let tempValues = JSON.parse(JSON.stringify(rowData));
                        tempValues.startDate = rowData.startDate?.split("T")[0];
                        tempValues.endDate = rowData.endDate?.split("T")[0];
                        tempValues.natureOfService = JSON.parse(rowData.natureOfService);
                        let tempNature = tempValues.natureOfService.map((nature) => ({
                          label: nature,
                          value: nature,
                        }));
                        tempValues.natureOfService = tempNature;
                        setData(tempValues);
                        setUpdate(true);
                      }}
                    />
                  )}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header="Agency"
        visible={open}
        style={{ width: "95vw" }}
        onHide={() => setOpen(false)}
      >
        <CreateAgency
          isUpdate={false}
          isView={false}
          cancelModal={() => setOpen(false)}
          onSuccess={onSuccess}
        />
      </Dialog>
      <Dialog
        header="Agency"
        visible={update}
        style={{ width: "95vw" }}
        onHide={() => setUpdate(false)}
      >
        <CreateAgency
          isUpdate={true}
          isView={false}
          data={data}
          cancelModal={() => setUpdate(false)}
          onSuccess={onSuccess}
        />
      </Dialog>
      <Dialog
        header="Agency"
        visible={view}
        style={{ width: "95vw" }}
        onHide={() => setView(false)}
      >
        <CreateAgency
          isUpdate={false}
          isView={true}
          data={data}
          cancelModal={() => setView(false)}
        />
      </Dialog>
    </Container>
  );
}
