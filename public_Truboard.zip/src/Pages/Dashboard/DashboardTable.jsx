import { DataTable } from "primereact/datatable"
import { memo } from "react"
import styles from './Dashboard.module.scss'
import { Column } from "primereact/column"

const DashboardTable = (props) => {
    return (
        <div className={styles?.tableContainer}>
            <p>Top 5 Defaulters as of Amount</p>
            <DataTable
                value={props?.data}
            >
                {props?.column?.map(col => (
                    <Column
                        {...col}
                    />
                ))}
            </DataTable>
        </div>
    )
}

export default memo(DashboardTable)