import React, { useEffect } from 'react'
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import "./Enablelocation.css"
import { Image } from 'primereact/image';
import step1 from "../../assets/images/01.png";
import step2 from "../../assets/images/02.png";
import step3 from "../../assets/images/04.png";



const EnableLocation = (props) => {
    // console.log(props?.locationState, "locationStatelocationStatelocationState")
    const show = (position) => {
        props?.setPosition(position);
        props?.setVisible(true);
    };

    useEffect(() => {
        show('top-right')
    }, [])
    return (
        <Dialog header="Guide For Enable Current Loaction" visible={props?.visible} position={props?.position} style={{ width: '30vw' }}   onHide={() => props?.setVisible(false)} draggable={false} resizable={false}>
            <div style={{ border: "0.5px solid #ddd7d7", width: "100%", height: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", boxShadow: "2px solid gray", borderRadius: "5px" }}>
                <div style={{ paddingTop: "10px", textAlign: "center", display: "flex", justifyContent: "center", alignContent: "center", }}>
                    <p><span style={{ fontWeight: "bold", fontStyle: "italic" }} >Step 1: </span>Click The Block Locaton Icon!!</p>
                </div>
                <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <Image src={step1} alt="Image" width='200' height="50" style={{ padding: "10px" }} />
                </div>
            </div>
            <br />
            <div style={{ border: "0.5px solid #ddd7d7", width: "100%", height: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", boxShadow: "2px solid gray", borderRadius: "5px" }}>
                <div style={{ paddingTop: "10px", textAlign: "center" }}>
                    <p><span style={{ fontWeight: "bold", fontStyle: "italic" }} >Step 2: </span>Always Allow Your Application To Access Your Current Location!!</p>
                    <br />
                    <p><span style={{ fontWeight: "bold", fontStyle: "italic" }} >Step 3: </span>After Allow Your Current Location Click The Done Button !! </p>

                </div>
                <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <Image src={step2} alt="Image" width='250' height="175" style={{ padding: "10px" }} />
                </div>
            </div>


        </Dialog>


    )
}

export default EnableLocation
