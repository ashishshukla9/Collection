import React, { lazy, useMemo, useState } from 'react'
// import DashboardChart from './DashboardChart'
import axios from 'axios';
import { MultiSelect } from "react-multi-select-component";
import { useSelector } from 'react-redux';
import "./pullwise.scss"
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
const DashboardChart=React.lazy(()=> import("./DashboardChart"))


const PullWise = () => {
  const navigate = useNavigate()
  const [dashboardData, setDashboardData] = useState({})
  const [selected, setSelected] = useState([]);
  const user = useSelector(state => state.user.data);
  const allPayload = useSelector((state) => state.allpayload);
  const ChartType = useSelector((state) => state.Allcharttype);
  const prePayload = allPayload?.allpayload;

  const options = useMemo(() => [
    { label: "January", value: 1 },
    { label: "February", value: 2 },
    { label: "March", value: 3 },
    { label: "April", value: 4 },
    { label: "May", value: 5 },
    { label: "June", value: 6 },
    { label: "July", value: 7 },
    { label: "August", value: 8 },
    { label: "September", value: 9 },
    { label: "October", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 },
  ])


  
  useEffect(() => {
    if (prePayload.length != 0) {
      const getAllAllocation = async () => {
        const isAllMonths = prePayload?.isAllMonths
        const payload = {
          ...prePayload,
          months: isAllMonths?.includes("selectAll") ? [] : selected?.map(a => a.value),
        }
        try {
          // const res = await axios.post(`/data/${user?.userId}`, payload)
          const res1 = await axios.post(`/graph/${user?.userId}`, payload)
          const res2 = await axios.post(`/FieldVsCallGraph/${user?.userId}`, payload)
          setDashboardData({...res1?.data?.data, ...res2?.data?.data})
        } catch (error) {
          console.log(error)
        }
      }
      getAllAllocation()
    } else {
      navigate("/dashboard")
    }
  }, [prePayload, selected]);
  
  return (
    <div className="pullwise-container">
      <div className="search-section">
        <div className="searchbox">
          <h5>Allocation month</h5>
          <div style={{ width: "70%", marginLeft: "1rem" }}>
            <MultiSelect
              options={options}
              value={selected}
              onChange={setSelected}
              labelledBy={"Select"}
              isCreatable={true}
            />
          </div>
        </div>
      </div>
      <div className="chart-section">
        {
          ChartType.charttype.includes("All vs Call") ? <DashboardChart
            chartClassNames={"barLineChart"}
            header={"hader"}
            chartHeader="Alloxn Vs Collxn Pool Wise"
            chartType="Bar-Line"
            chartData={{
              labels: dashboardData?.allocationVsCollection?.map(a => a?.month),
              datasets: [{
                type: 'line',
                label: 'Collected Amount',
                yAxisID: 'y1',
                data: dashboardData?.allocationVsCollection?.map(a => a?.cashCollected),
                backgroundColor: '#12239e',
                borderColor: '#12239e'
              }, {
                type: 'bar',
                label: 'POS',
                yAxisID: 'y',
                data: dashboardData?.allocationVsCollection?.map(a => a?.totalPos),
                backgroundColor: '#118dff',
                barThickness:80
              }]
            }}
            options={{
              scales: {
                y: {
                  type: 'linear',
                  display: true,
                  position: 'left'
                },
                y1: {
                  type: 'linear',
                  display: true,
                  position: 'right'
                }
              }
            }}
            chartOtherDetails={{
              // otherChart: <Link to={"/pullwise"} style={{ textDecoration: "none", color: "black" }}>Pull Wise</Link>,
              // filter: 
              //     <div className={styles?.filterContainer}>
              //         <p className={styles?.filterBtn}>Secure</p>
              //         <p className={styles?.filterBtn}>Unsecure</p>
              //     </div>
            }}
          />
            : ChartType.charttype.includes("All") ? <DashboardChart
              chartClassNames={"barLineChart"}
              header={"hader"}
              chartHeader="Allocation"
              chartType="Bar-Line"
              chartData={{
                labels: dashboardData?.allocation?.map(a => a?.month),
                datasets: [{
                  type: 'line',
                  label: 'Resolved Cases',
                  yAxisID: 'y1',
                  data: dashboardData?.allocation?.map(a => a?.resolvedCasesCount),
                  backgroundColor: '#12239e',
                  borderColor: '#12239e'
                }, {
                  type: 'bar',
                  label: 'Count of Cases',
                  yAxisID: 'y',
                  data: dashboardData?.allocation?.map(a => a?.countOfCases),
                  backgroundColor: '#118dff',
                  barThickness:80

                }]
              }}
              options={{
                scales: {
                  y: {
                    type: 'linear',
                    display: true,
                    position: 'left'
                  },
                  y1: {
                    type: 'linear',
                    display: true,
                    position: 'right'
                  }
                }
              }}
              chartOtherDetails={{
                // otherChart: <Link to={"/pullwise"} style={{textDecoration:"none",color:"black"}}>Pull Wise</Link>,
                // filter:
                //   <div className={styles?.filterContainer}>
                //     <p className={styles?.filterBtn}>Secure</p>
                //     <p className={styles?.filterBtn}>Unsecure</p>
                //   </div>
              }}
            /> : ChartType.charttype.includes("Field vs Call Center") ? <DashboardChart
              chartClassNames={"barLineChart"}
              chartHeader="Field vs Call Center"
              header={"hader"}
              chartType="Bar-Line"
              chartData={{
                labels: [ 'Call Center',"Field"],
                datasets: [{
                  type: 'line',
                  label: 'Amount Collected',
                  yAxisID: 'y1',
                  data: [dashboardData?.fieldVsCallCenter?.callCollection?.cashCollected, dashboardData?.fieldVsCallCenter?.fieldCollection?.cashCollected, dashboardData?.fieldVsCallCenter?.totalFieldVsCall?.cashCollected],
                  backgroundColor: '#12239e',
                  borderColor: '#12239e'
                }, {
                  type: 'bar',
                  label: 'POS',
                  yAxisID: 'y',
                  data: [dashboardData?.fieldVsCallCenter?.callCollection?.totalPos, dashboardData?.fieldVsCallCenter?.fieldCollection?.totalPos, dashboardData?.fieldVsCallCenter?.totalFieldVsCall?.totalPos],
                  backgroundColor: '#118dff',
                  barThickness:80
                }]
              }}
              options={{
                scales: {
                  y: {
                    type: 'linear',
                    display: true,
                    position: 'left'
                  },
                  y1: {
                    type: 'linear',
                    display: true,
                    position: 'right'
                  }
                }
              }}
              chartOtherDetails={{
                // otherChart: <button onClick={() => { handleNavigate("Field vs Call Center") }} style={{ textDecoration: "none", color: "black" }}>Pull Wise</button>,
                // filter:
                //     <div className={styles?.filterContainer}>
                //         <p className={styles?.filterBtn}>Secure</p>
                //         <p className={styles?.filterBtn}>Unsecure</p>
                //     </div>
              }}
            /> : ""
        }
      </div>
    </div>
  )
}

export default PullWise



