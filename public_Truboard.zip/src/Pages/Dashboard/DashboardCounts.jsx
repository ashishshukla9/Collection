import { memo } from "react"
import styles from './Dashboard.module.scss'
const DashboardCounts = (props) => {
    return (
        <div className={styles?.countContainer}>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Total Cases</p>
                <p className={styles?.value}>{props?.dashboardCountData?.totalCases || 0}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Cases for Calling</p>
                <p className={styles?.value}>{props?.dashboardCountData?.connectedCallsCount || 0}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Cases for Field</p>
                <p className={styles?.value}>{props?.dashboardCountData?.caseForFOS || 0}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Resolved Cases</p>
                <p className={styles?.value}>{props?.dashboardCountData?.resolvedCasesCount || 0}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Collected Amount</p>
                <p className={styles?.value}>{(props?.dashboardCountData?.collectedAmount || 0)?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            })}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Total POS</p>
                <p className={styles?.value}>{(props?.dashboardCountData?.totalPos || 0)?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            })}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Outstanding POS</p>
                <p className={styles?.value}>{(props?.dashboardCountData?.outstandingPos || 0)?.toLocaleString('en-IN',{
                    style: 'currency',
                    currency: 'INR'
            })}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Untouched Cases</p>
                <p className={styles?.value}>{props?.dashboardCountData?.untouchedCasesCount || 0}</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Recovery Rate</p>
                <p className={styles?.value}>{(props?.dashboardCountData?.recoveryRate || 0)?.toLocaleString('en-IN')}%</p>
            </div>
            <div className={styles?.countBox}>
                <p className={styles?.header}>Cure Rate</p>
                <p className={styles?.value}>{(props?.dashboardCountData?.cureRate || 0)?.toLocaleString('en-IN')}%</p>
            </div>
        </div>
    )
}
export default memo(DashboardCounts)