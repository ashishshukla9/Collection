import DashboardCounts from "./DashboardCounts";
import DashboardFilter from "./DashboardFilter";
import styles from './Dashboard.module.scss'
import DashboardChart from "./DashboardChart";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { setAllChartTypa, setGeoLocation } from "./Features"
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";
import EnableLocation from "./EnableLocation";
const Index = () => {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const [dashboardChartData, setDashboardChartData] = useState({})
    const [dashboardFieldChartData, setDashboardFieldChartData] = useState({})
    const [dashboardData, setDashboardData] = useState({})
    const [selectChart, setSelectChart] = useState("")
    const [locationPermission, setLocationPermission] = useState(null);
    const [visible, setVisible] = useState(false);
    const [position, setPosition] = useState('center');
    const [locationState, setLocationState] = useState(null)
    const [geoData, setGeoData] = useState([])
    const user = useSelector((state) => state.user.data);
    const handleNavigate = async (chart) => {
        if (chart == "All") {
            dispatch(setAllChartTypa(chart))
            navigate("/poolwise")
        } else if (chart == "All vs Call") {
            dispatch(setAllChartTypa(chart))
            navigate("/poolwise")
        } else if (chart == "Field vs Call Center") {
            dispatch(setAllChartTypa(chart))
            navigate("/poolwise")
        }
    }
    const handleLocation = () => {
        if (navigator.permissions) {
            navigator.permissions.query({ name: 'geolocation' }).then((result) => {
                setLocationState(result?.state)
                if (result.state === 'granted') {
                    setLocationPermission(true);
                    setPosition(false)
                } else if (result.state === 'denied') {
                    setVisible(false)
                    setLocationPermission(false);
                } else if (result.state === 'prompt') {
                    setLocationPermission(null);
                    setVisible(false)
                }
            });
        } else {
            console.error('Permissions API is not supported by this browser.');
            setLocationPermission(false);
        }
    };
    const handleAllowLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setVisible(false)
                    const location = position?.coords
                    const lat = location?.latitude;
                    const long = location?.longitude;
                    const finalgeo = {
                        lat,
                        long
                    }
                    dispatch(setGeoLocation(finalgeo))
                    setLocationPermission(true);
                },
                (error) => {
                    setVisible(true)
                    console.error('Error getting location:', error);
                    setLocationPermission(false);
                }
            );
        } else {
            console.error('Geolocation is not supported by this browser.');
            setLocationPermission(false);
        }
    };
    return (
        <div className={styles?.dashboardContainer}>
            <DashboardFilter
                setDashboardData={setDashboardData}
                setDashboardChartData={setDashboardChartData}
                setDashboardFieldChartData={setDashboardFieldChartData}
            />
            <div className={styles?.rightSideContainer}>
                <DashboardCounts
                    dashboardCountData={dashboardData?.dashboardDTO}
                />
                <div className={styles?.chartContainer}>
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Allocation"
                        chartType="Bar-Line"
                        chartData={{
                            labels: dashboardChartData?.allocation?.map(a => a?.month),
                            datasets: [{
                                type: 'line',
                                label: 'Resolved Cases',
                                yAxisID: 'y1',
                                data: dashboardChartData?.allocation?.map(a => a?.resolvedCasesCount),
                                backgroundColor: '#12239e',
                                borderColor: '#12239e'
                            },
                            {
                                type: 'bar',
                                label: 'Count of Cases',
                                yAxisID: 'y',
                                data: dashboardChartData?.allocation?.map(a => a?.countOfCases),
                                backgroundColor: '#118dff',
                                barThickness: 80
                            }]
                        }}
                        options={{
                            scales: {
                                y: {
                                    type: 'linear',
                                    display: true,
                                    position: 'left'
                                },
                                y1: {
                                    type: 'linear',
                                    display: true,
                                    position: 'right'
                                }
                            }
                        }}
                        chartOtherDetails={{
                            otherChart: <button className={styles?.pullbtn} onClick={() => { handleNavigate("All") }} style={{ textDecoration: "none", color: "black" }}>Pool wise</button>,
                            filter:
                                <div className={styles?.filterContainer}>
                                    <p className={styles?.filterBtn}>secured</p>
                                    <p className={styles?.filterBtn}>unsecured</p>
                                </div>
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Allocation vs Collection"
                        chartType="Bar-Line"
                        chartData={{
                            labels: dashboardChartData?.allocationVsCollection?.map(a => a?.month),
                            datasets: [{
                                type: 'line',
                                label: 'Collected Amount',
                                yAxisID: 'y1',
                                data: dashboardChartData?.allocationVsCollection?.map(a => a?.cashCollected),
                                backgroundColor: '#12239e',
                                borderColor: '#12239e'
                            }, {
                                type: 'bar',
                                label: 'POS',
                                yAxisID: 'y',
                                data: dashboardChartData?.allocationVsCollection?.map(a => a?.totalPos),
                                backgroundColor: '#118dff',
                                barThickness: 80

                            }]
                        }}
                        options={{
                            scales: {
                                y: {
                                    type: 'linear',
                                    display: true,
                                    position: 'left'
                                },
                                y1: {
                                    type: 'linear',
                                    display: true,
                                    position: 'right'
                                }
                            }
                        }}
                        chartOtherDetails={{
                            otherChart: <button className={styles?.pullbtn} onClick={() => { handleNavigate("All vs Call") }} style={{ textDecoration: "none", color: "black" }}>Pool wise</button>,
                            filter:
                                <div className={styles?.filterContainer}>
                                    <p className={styles?.filterBtn}>secured</p>
                                    <p className={styles?.filterBtn}>unsecured</p>
                                </div>
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Field vs Call Center"
                        chartType="Bar-Line"
                        chartData={{
                            labels: ['Call Center', "Field "],
                            datasets: [{
                                type: 'line',
                                label: 'Amount Collected',
                                yAxisID: 'y1',
                                data: [dashboardFieldChartData?.fieldVsCallCenter?.callCollection?.cashCollected, dashboardFieldChartData?.fieldVsCallCenter?.fieldCollection?.cashCollected, dashboardFieldChartData?.fieldVsCallCenter?.totalFieldVsCall?.cashCollected],
                                backgroundColor: '#12239e',
                                borderWidth: 1,
                                borderColor: '#12239e'
                            }, {
                                type: 'bar',
                                label: 'POS',
                                yAxisID: 'y',
                                data: [dashboardFieldChartData?.fieldVsCallCenter?.callCollection?.totalPos, dashboardFieldChartData?.fieldVsCallCenter?.fieldCollection?.totalPos, dashboardFieldChartData?.fieldVsCallCenter?.totalFieldVsCall?.totalPos],
                                backgroundColor: '#118dff',
                                barThickness: 80
                            }]
                        }}
                        options={{
                            scales: {
                                y: {
                                    type: 'linear',
                                    display: true,
                                    position: 'left',

                                },
                                y1: {
                                    type: 'linear',
                                    display: true,
                                    position: 'right'
                                },
                                xAxes: [{
                                    barPercentage: 0.5
                                }]
                            }
                        }}
                        chartOtherDetails={{
                            otherChart: <button className={styles?.pullbtn} onClick={() => { handleNavigate("Field vs Call Center") }} style={{ textDecoration: "none", color: "black" }}>Pool wise</button>,
                            filter:
                                <div className={styles?.filterContainer}>
                                    <p className={styles?.filterBtn}>secured</p>
                                    <p className={styles?.filterBtn}>unsecured</p>
                                </div>
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Type of Dispositions vs POS"
                        chartType="Doughnut"
                        chartData={{
                            labels: ['PTP', 'Payment', 'Dispute/RTP', 'Raise Exception'],
                            datasets: [{
                                label: '# of Votes',
                                label: 'My First Dataset',
                                data: ['20', '10', '25', '15', '5'],
                                backgroundColor: [
                                    'rgb(255, 99, 132)',
                                    'rgb(54, 162, 235)',
                                    'rgb(255, 205, 86)',
                                    'rgb(84, 12, 235)',
                                    'rgb(100, 205, 86)'
                                ],
                                hoverOffset: 4
                            }]
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Region wise pool"
                        chartType="Pie"
                        chartData={{
                            labels: ['North', 'East', 'West', 'South'],
                            datasets: [{
                                label: '# of Votes',
                                label: 'My First Dataset',
                                data: ['20', '10', '25', '15', '5'],
                                backgroundColor: [
                                    'rgb(255, 99, 132)',
                                    'rgb(54, 162, 235)',
                                    'rgb(255, 205, 86)',
                                    'rgb(84, 12, 235)',
                                    'rgb(100, 205, 86)'
                                ],
                                hoverOffset: 4
                            }]
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Product Type vs No. of Cases"
                        chartType="Pie"
                        chartData={{
                            labels: ['PL', 'HL', 'Vehicle loan', 'DIGIPL'],
                            datasets: [{
                                label: '# of Votes',
                                label: 'My First Dataset',
                                data: ['20', '10', '25', '15', '5'],
                                backgroundColor: [
                                    'rgb(255, 99, 132)',
                                    'rgb(54, 162, 235)',
                                    'rgb(255, 205, 86)',
                                    'rgb(84, 12, 235)',
                                    'rgb(100, 205, 86)'
                                ],
                                hoverOffset: 4
                            }]
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="POS Range vs No. of Cases"
                        chartType="Pie"
                        chartData={{
                            labels: ['0 to 20,000', '20,000- 40,000', '40,000 - 60,000', ' 60,000+'],
                            datasets: [{
                                label: '# of Votes',
                                label: 'My First Dataset',
                                data: ['20', '10', '25', '15', '5'],
                                backgroundColor: [
                                    'rgb(255, 99, 132)',
                                    'rgb(54, 162, 235)',
                                    'rgb(255, 205, 86)',
                                    'rgb(84, 12, 235)',
                                    'rgb(100, 205, 86)'
                                ],
                                hoverOffset: 4
                            }]
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Days DPD vs No. of Cases"
                        chartType="Pie"
                        chartData={{
                            labels: ['1 - 90', '91 - 180', '181 - 365', '366 - 730', '730+'],
                            datasets: [{
                                label: '# of Votes',
                                label: 'My First Dataset',
                                data: ['20', '10', '25', '15', '5'],
                                backgroundColor: [
                                    'rgb(255, 99, 132)',
                                    'rgb(54, 162, 235)',
                                    'rgb(255, 205, 86)',
                                    'rgb(84, 12, 235)',
                                    'rgb(100, 205, 86)'
                                ],
                                hoverOffset: 4
                            }]
                        }}
                    />
                    <DashboardChart
                        chartClassNames={styles?.barLineChart}
                        chartHeader="Lender type collection"
                        chartType="Pie"
                        chartData={{
                            labels: ['1 - 90', '91 - 180', '181 - 365', '366 - 730', '730+'],
                            datasets: [{
                                label: '# of Votes',
                                label: 'My First Dataset',
                                data: ['20', '10', '25', '15', '5'],
                                backgroundColor: [
                                    'rgb(255, 99, 132)',
                                    'rgb(54, 162, 235)',
                                    'rgb(255, 205, 86)',
                                    'rgb(84, 12, 235)',
                                    'rgb(100, 205, 86)'
                                ],
                                hoverOffset: 4
                            }]
                        }}
                    />
                    {
                        visible && <EnableLocation visible={visible} setVisible={setVisible} position={position} locationState={locationState} setPosition={setPosition} />
                    }
                </div>
            </div>
        </div>
    )
}
export default Index;