import { createSlice } from "@reduxjs/toolkit";

const payloadDetails = createSlice({
  name: "payloadDetails",
  initialState: {
    allpayload: [],
    charttype:"",
    dashbaordData:{},
    geoData:null
  },
  reducers: {
    setAllPayload: (state, action) => {
      state.allpayload = action.payload;
    },
    setAllChartTypa:(state, action)=>{
      state.charttype=action.payload;
    },
    setAllDashboardData:(state, action)=>{
       state.dashbaordData=action.payload
    },
    setGeoLocation :(state, action) => {
      state.geoData =  action.payload;
    }
  }
});

export const { setAllPayload, setAllChartTypa, setAllDashboardData, setGeoLocation  } = payloadDetails.actions;
export default payloadDetails.reducer;
