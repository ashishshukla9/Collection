import { useFormik } from "formik"
import { Form } from "reactstrap"
import Field from "../../components/Field"
import Select from "react-select";
import { memo, useEffect, useMemo, useState } from "react";
import styles from './Dashboard.module.scss'
import axios from "axios";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch, useSelector } from "react-redux";
import MultiSelected from "../../components/Selection/MultiSelect";
import { setAllPayload } from "./Features";

const DashboardFilter = (props) => {
    const [lenderOptions, setLenderOptions] = useState([])
    const [portfolioOptions, setPortfolioOptions] = useState([])
    const [productOptions, setProductOptions] = useState([])
    const [zoneOptions, setZoneOptions] = useState([])
    const [regionOptions, setRegionOptions] = useState([])
    const [stateOptions, setStateOptions] = useState([])
    const [cityOptions, setCityOptions] = useState([])
    const [newCityOptions, setNewCityOptions] = useState([])
    const [agencyOptions, setAgencyOptions] = useState([])
    const [cityPage, setCityPage] = useState(1)
    const [isCitySelectAll, setIsCitySelectAll] = useState(false)

    const user = useSelector((state) => state.user.data);
    const dispatch = useDispatch()

    const monthOptions = useMemo(() => [{ value: 1, label: 'January' }, { value: 2, label: 'February' }, { value: 3, label: 'March' }, { value: 4, label: 'April' }, { value: 5, label: 'May' }, { value: 6, label: 'June' }, { value: 7, label: 'July' }, { value: 8, label: 'August' }, { value: 9, label: 'September' }, { value: 10, label: 'October' }, { value: 11, label: 'November' }, { value: 12, label: 'December' }], [])

    const DelinquencyOptions = useMemo(()=>[{value:["0","30"], label:"0 - 30"}, {value:["31","60"], label:"31 - 60"}, {value:["61","90"], label:"61 - 90"}, {value:["91","120"], label:"91 - 120"}, {value:["120","9999"], label:"120 - 9999"}], [])

    const collectionOptions= useMemo(()=>[{value:"Calling", label:"Calling"}, {value:"Field", label:"Field"}])
    const selectAll = useMemo(() => {
        return {
            label: "Select All",
            value: 'selectAll'
        }
    }, [])

    const initialValues = {
        lenderType: '',
        lenderName: ['isAllSelected'],
        allocationMonth: ['isAllSelected'],
        category: ['isAllSelected'],
        productType: ['isAllSelected'],
        delinquencyType: DelinquencyOptions, // Directly use DelinquencyOptions here
        zone: ['isAllSelected'],
        region: ['isAllSelected'],
        state: ['isAllSelected'],
        city: ['isAllSelected'],
        typeOfCollection: [],
        agencies: '',
        allocatedManager: '',
    };
    

    const formik = useFormik({initialValues})

    useEffect(() => {
        if (user) { 
        try {
            const api = async () => {
                dispatch(setLoader(true))
                const portfolioRes = await axios.get('/getAllPortfolio')
                const portfolioOps = portfolioRes?.data?.data?.map(a => {
                    return {
                        label: a?.portfolioDescription,
                        value: a?.portfolioDescription,
                        op: a?.portfolioId
                    }
                })
                setPortfolioOptions([...portfolioOps])

                const zoneRes = await axios.get('/getAllZones')
                const zoneOps = zoneRes?.data?.data?.map(a => {
                    return {
                        label: a?.zoneName,
                        value: a?.zoneName,
                        op: a?.zoneId
                    }
                })
                setZoneOptions([...zoneOps])

                const agencyRes = await axios.get('/getAllAgency')
                const agencyOps = agencyRes?.data?.data?.map(a => {
                    return {
                        label: a?.agencyName,
                        value: a?.agencyId
                    }
                })
                setAgencyOptions([...agencyOps])
                dispatch(setLoader(false))
            }
            api()
        } catch (error) {
            dispatch(setLoader(false))
        }
    }
    }, [user])

    useEffect(() => {
        if (formik?.values?.category.length && portfolioOptions.length && user  ) {
            const api = async () => {
                try {
                    const categoryId = formik?.values?.category?.includes('isAllSelected') ? portfolioOptions?.map(a => a?.op)?.join(',') : formik?.values?.category?.map(a => a?.op)?.join(',')
                    const res = await axios.get(`/getProductByPortfolio/${categoryId}`)
                    const options = res?.data?.data?.map(a => {
                        return {
                            label: a?.productDescription,
                            value: a?.productCode
                        }
                    })
                    setProductOptions(options)
                } catch (error) {

                }
            }
            api()
        } else {
            setProductOptions([user])
        }
    }, [formik?.values?.category, zoneOptions, user])

    useEffect(() => {
        if (formik?.values?.zone.length && zoneOptions.length && user ) {
            const api = async () => {
                try {
                    const zoneId = formik?.values?.zone?.includes('isAllSelected') ? zoneOptions?.map(a => a?.op)?.join(',') : formik?.values?.zone?.map(a => a?.op)?.join(',')
                    const res = await axios.get(`/getRegionByZone/${zoneId}`)
                    const options = res?.data?.data?.map(a => {
                        return {
                            label: a?.regionName,
                            value: a?.regionName,
                            op: a?.regionId
                        }
                    })
                    setRegionOptions(options)
                } catch (error) {
                }
            }
            api()
        } else {
            setRegionOptions([])
        }
    }, [formik?.values?.zone, zoneOptions, user])

    useEffect(() => {
        if (regionOptions.length && user) {
            const api = async () => {
                try {
                    const regionId = formik?.values?.region?.includes('isAllSelected') ? regionOptions?.map(a => a?.op)?.join(',') : formik?.values?.region?.map(a => a?.op)?.join(',')
                    const zoneId = formik?.values?.zone?.includes('isAllSelected') ? zoneOptions?.map(a => a?.op)?.join(',') : formik?.values?.zone?.map(a => a?.op)?.join(',')
                    const id = formik?.values?.region.length ? regionId : zoneId
                    const url = formik?.values?.region.length ? 'getStateByRegion' : '/getStateByZone'
                    const res = await axios.get(`${url}/${id}`)
                    const options = res?.data?.data?.map(a => {
                        return {
                            label: a?.stateName,
                            value: a?.stateName,
                            op: a?.stateId
                        }
                    })
                    setStateOptions(options)
                   

                } catch (error) {
                    
                }
            }
            api()
        } else {
            setStateOptions([])
        }
    }, [formik?.values?.region, regionOptions, user])

    useEffect(() => {
        if (formik?.values?.state.length && stateOptions.length && user  ) {
            const api = async () => {
                try {
                    const stateId = formik?.values?.state?.includes('isAllSelected') ? stateOptions?.map(a => a?.op)?.join(',') : formik?.values?.state?.map(a => a?.op)?.join(',')
                    const res = await axios.get(`/getCityByState/${stateId}/${cityPage}/10`)
                    const options = res?.data?.response?.map(a => {
                        return {
                            label: a?.cityName,
                            value: a?.cityName,
                            op: a?.cityId
                        }
                    })

                    if (cityOptions?.length) {
                        setCityOptions([...cityOptions, ...options])
                    } else {
                        setCityOptions(options)
                    }

                    if (isCitySelectAll) {
                        formik.setFieldValue('city', [...formik?.values?.city, ...options])
                    }
                    setNewCityOptions(options)
                } catch (error) {

                }
            }

            api()
        } else {
            setCityOptions([])
        }
    }, [formik?.values?.state, stateOptions, cityPage, user])


 
    // count
    useEffect(() => {
        const cancelToken = axios.CancelToken;
        const source = cancelToken.source();
        
        if (Boolean(Object.values(formik.values).filter(Boolean)?.filter(a => a?.length).length) && user) {
            const getSearch = async () => {
                let flattenedArray = [];
if (!formik?.values?.delinquencyType.includes('isAllSelected')) {
    flattenedArray = formik?.values?.delinquencyType?.reduce((acc, curr) => {
        if (curr?.value && Array.isArray(curr.value)) {
            return acc.concat(curr.value); // No need for filter as value is already checked to be an array
        }
        return acc;
    }, []) || [];
}

                
                try {
                    dispatch(setLoader(true))
                    const payload = {
                        lenderName: formik?.values?.lenderName.includes('isAllSelected') ? [] : formik?.values?.lenderName?.map(a=>a?.value),
                        months: formik?.values?.allocationMonth.includes('isAllSelected') ? [] : formik?.values?.allocationMonth?.map(a=>a?.value),
                        category: formik?.values?.category.includes('isAllSelected') ? [] : formik?.values?.category?.map(a=>a?.value),
                        loanProducts: formik?.values?.productType.includes('isAllSelected') ? [] : formik?.values?.productType?.map(a=>a?.value),
                        zone: formik?.values?.zone.includes('isAllSelected') ? [] : formik?.values?.zone?.map(a=>a?.value),
                        region: formik?.values?.region.includes('isAllSelected') ? [] : formik?.values?.region?.map(a=>a?.value),
                        state: formik?.values?.state.includes('isAllSelected') ? [] : formik?.values?.state?.map(a=>a?.value),
                        city: formik?.values?.city.includes('isAllSelected')  ? [] : formik?.values?.city?.map(a=>a?.value),
                        delinquencyType: formik?.values?.delinquencyType.includes('isAllSelected')  ? [] : flattenedArray,
                        typeOfCollection:formik?.values?.typeOfCollection.includes('isAllSelected')  ? [] : formik?.values?.typeOfCollection?.value,
        
                        isAllLenderName: formik?.values?.lenderName.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllMonths: formik?.values?.allocationMonth.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllCategory: formik?.values?.category.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllLoanProducts: formik?.values?.productType.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllDelinquency: formik?.values?.delinquencyType.includes('isAllSelected')  ? 'selectAll' : 'notAll',
                        // isAllZone: formik?.values?.zone.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllRegion: formik?.values?.region.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllState: formik?.values?.state.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllCity: formik?.values?.city.includes('isAllSelected') ? 'selectAll' : 'notAll',
                    }
                    dispatch(setAllPayload(payload))
                    const res = await axios.post(`/data/${user?.userId}`, payload,{cancelToken: source?.token})
                    // const res1 = await axios.post(`/graph/${user?.userId}`, payload,{cancelToken: source?.token})
                    // const res2 = await axios.post(`/FieldVsCallGraph/${user?.userId}`, payload,{cancelToken: source?.token})
                   
                //    props?.setDashboardChartData({...res1?.data?.data})
                //    props?.setDashboardFieldChartData({...res2?.data?.data})
                    props?.setDashboardData({...res?.data?.data})
                    // dispatch
                    dispatch(setLoader(false))
                } catch (error) {
                    if(axios.isCancel(error)){
                        dispatch(setLoader(true))
                    }else{
                        dispatch(setLoader(false))
                    }
                }
            }

            getSearch()
        }

        return () => {
            source.cancel('Request canceled: Component unmounted');
        };
    }, [formik.values, user])


    // chart 
    useEffect(() => {
        const cancelToken = axios.CancelToken;
        const source = cancelToken.source();
        
        if (Boolean(Object.values(formik.values).filter(Boolean)?.filter(a => a?.length).length) && user) {
            const getSearch = async () => {
                try {
                    let flattenedArray = formik?.values?.delinquencyType?.reduce((acc, curr) => acc.concat(curr.value), []);
                    // console.log("flattenedArray",flattenedArray);
                    dispatch(setLoader(true))
                    const payload = {
                        lenderName: formik?.values?.lenderName.includes('isAllSelected') ? [] : formik?.values?.lenderName?.map(a=>a?.value),
                        months: formik?.values?.allocationMonth.includes('isAllSelected') ? [] : formik?.values?.allocationMonth?.map(a=>a?.value),
                        category: formik?.values?.category.includes('isAllSelected') ? [] : formik?.values?.category?.map(a=>a?.value),
                        loanProducts: formik?.values?.productType.includes('isAllSelected') ? [] : formik?.values?.productType?.map(a=>a?.value),
                        zone: formik?.values?.zone.includes('isAllSelected') ? [] : formik?.values?.zone?.map(a=>a?.value),
                        region: formik?.values?.region.includes('isAllSelected') ? [] : formik?.values?.region?.map(a=>a?.value),
                        state: formik?.values?.state.includes('isAllSelected') ? [] : formik?.values?.state?.map(a=>a?.value),
                        city:  formik?.values?.city.includes('isAllSelected') ? [] : formik?.values?.city?.map(a=>a?.value),
                        delinquencyType: formik?.values?.delinquencyType.includes('isAllSelected')  ? [] : flattenedArray,
                        typeOfCollection:formik?.values?.typeOfCollection.includes('isAllSelected')  ? [] : formik?.values?.typeOfCollection?.map(a=>a?.value),
                        // isAllLenderName: formik?.values?.lenderName.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllMonths: formik?.values?.allocationMonth.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllCategory: formik?.values?.category.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllLoanProducts: formik?.values?.productType.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllDelinquency: formik?.values?.delinquencyType.includes('isAllSelected')  ? 'selectAll' : 'notAll',
                        // isAllZone: formik?.values?.zone.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllRegion: formik?.values?.region.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllState: formik?.values?.state.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllCity: formik?.values?.city.includes('isAllSelected') ? 'selectAll' : 'notAll',
                    }
                    dispatch(setAllPayload(payload))
                    // const res = await axios.post(`/data/${user?.userId}`, payload,{cancelToken: source?.token})
                    const res1 = await axios.post(`/graph/${user?.userId}`, payload,{cancelToken: source?.token})
                    // const res2 = await axios.post(`/FieldVsCallGraph/${user?.userId}`, payload,{cancelToken: source?.token})
                    
                   props?.setDashboardChartData({...res1?.data?.data})
                //    props?.setDashboardFieldChartData({...res2?.data?.data})
                    // props?.setDashboardData({...res?.data?.data})
                    // dispatch
                    dispatch(setLoader(false))
                } catch (error) {
                    if(axios.isCancel(error)){
                        dispatch(setLoader(true))
                    }else{
                        dispatch(setLoader(false))
                    }
                }
            }

            getSearch()
        }

        return () => {
            source.cancel('Request canceled: Component unmounted');
        };
    }, [formik.values, user])


    // field vs call
    useEffect(() => {
        const cancelToken = axios.CancelToken;
        const source = cancelToken.source();
        
        if (Boolean(Object.values(formik.values).filter(Boolean)?.filter(a => a?.length).length) && user) {
            const getSearch = async () => {
                try {
                    let flattenedArray = formik?.values?.delinquencyType?.reduce((acc, curr) => acc.concat(curr.value), []);
                    dispatch(setLoader(true))
                    const payload = {
                        lenderName: formik?.values?.lenderName.includes('isAllSelected') ? [] : formik?.values?.lenderName?.map(a=>a?.value),
                        months: formik?.values?.allocationMonth.includes('isAllSelected') ? [] : formik?.values?.allocationMonth?.map(a=>a?.value),
                        category: formik?.values?.category.includes('isAllSelected') ? [] : formik?.values?.category?.map(a=>a?.value),
                        loanProducts: formik?.values?.productType.includes('isAllSelected') ? [] : formik?.values?.productType?.map(a=>a?.value),
                        zone: formik?.values?.zone.includes('isAllSelected') ? [] : formik?.values?.zone?.map(a=>a?.value),
                        region: formik?.values?.region.includes('isAllSelected') ?  []:formik?.values?.region?.map(a=>a?.value) ,
                        state: formik?.values?.state.includes('isAllSelected') ? [] : formik?.values?.state?.map(a=>a?.value),
                        city: formik?.values?.city.includes('isAllSelected')  ? [] :  formik?.values?.city?.map(a=>a?.value),
                        delinquencyType: formik?.values?.delinquencyType.includes('isAllSelected')  ? [] : flattenedArray,
                        typeOfCollection:formik?.values?.typeOfCollection.includes('isAllSelected')  ? [] : formik?.values?.typeOfCollection?.map(a=>a?.value),


                        // isAllLenderName: formik?.values?.lenderName.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllMonths: formik?.values?.allocationMonth.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllCategory: formik?.values?.category.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllLoanProducts: formik?.values?.productType.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        isAllDelinquency: formik?.values?.delinquencyType.includes('isAllSelected')  ? 'selectAll' : 'notAll',
                        // isAllZone: formik?.values?.zone.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllRegion: formik?.values?.region.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllState: formik?.values?.state.includes('isAllSelected') ? 'selectAll' : 'notAll',
                        // isAllCity: formik?.values?.city.includes('isAllSelected') ? 'selectAll' : 'notAll',
                    }

                    // console.log(payload, "finalpayload")
                    dispatch(setAllPayload(payload))
                    // const res = await axios.post(`/data/${user?.userId}`, payload,{cancelToken: source?.token})
                    // const res1 = await axios.post(`/graph/${user?.userId}`, payload,{cancelToken: source?.token})
                    const res2 = await axios.post(`/FieldVsCallGraph/${user?.userId}`, payload,{cancelToken: source?.token})
                //    props?.setDashboardChartData({...res1?.data?.data})
                   props?.setDashboardFieldChartData({...res2?.data?.data})
                    dispatch(setLoader(false))
                } catch (error) {
                    if(axios.isCancel(error)){
                        dispatch(setLoader(true))
                    }else{
                        dispatch(setLoader(false))
                    }
                }
            }
            getSearch()
        }
        return () => {
            source.cancel('Request canceled: Component unmounted');
        };
    }, [formik.values, user])



    useEffect(() => {
    if (user) {
        const getAllLendersName = async () => {
            dispatch(setLoader(true))
            try {
                const res = await axios.get('/getAllLenderNames')
                const lenderOps = res?.data?.data?.map(a => {
                    return {
                        label: a,
                        value: a
                    }
                })
                setLenderOptions([...lenderOps])
            } catch (error) {
                dispatch(setLoader(false))
            }
        }
        getAllLendersName()
    }
    }, [user])


    return (
        <Form onSubmit={formik.handleSubmit}>
            {/* <Field
                label="Lender Type"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <Select
                    placeholder="Select Lender Type"
                    // options={reportOption}
                    onChange={(e) => {
                        formik?.setFieldValue("lenderType", e);
                    }}
                    classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={true}
                    name="lenderType"
                />
            </Field> */}
            <Field
                label="Lender Name"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select Lender Name"
                    options={lenderOptions}
                    onChange={e => {
                        formik.setFieldValue('lenderName', e)
                    }}
                    closeMenu={false}
                    name="lenderName"
                    value={formik?.values?.lenderName}
                    isClearable
                    isAllSelected={formik?.values?.lenderName?.includes('isAllSelected')}
                    // isDisabled={true}
                />
                {/* <Select
                    isOptionSelected={true}
                    placeholder="Select Lender Name"
                    options={lenderOptions}
                    onChange={(e,action) => {
                        const isArray = Array.isArray(e)
                        const isAllSelected = isArray ? e?.some(a=>a?.value === "selectAll") : e?.value === 'selectAll'

                        console.log(isArray,'isArray');
                        console.log(isAllSelected,'isAllSelected');
                        console.log(e,'e');
                        console.log(action,'action');
                        let val = []
                        if(action?.action === "select-option" && isAllSelected && action?.option?.value === 'selectAll'){
                            val = lenderOptions?.map(a=>a?.value)
                        }else if((action?.action === "deselect-option" || action?.action === 'remove-value') && isAllSelected){
                            val = []
                        }else if(!isAllSelected && !isArray){
                            val = [e?.value]
                        }else if(isAllSelected && isArray){
                            val = lenderOptions?.filter(a=> a?.value !== action?.option?.value && a?.value !== 'selectAll')?.map(a=>a?.value)
                            console.log(val,'val');
                        }else if(!isAllSelected && !isArray){
                            val = formik?.values?.lenderName?.filter(a=>a!== e?.value)
                            console.log(val,'val 2');
                        }

                        // if(action?.value === 'selectAll' && isSelectAllSelected){
                        //     val = []
                        // }else if()
                        formik?.setFieldValue("lenderName",val);
                    }}
                    value={formik?.values?.lenderName?.includes('selectAll') ? [selectAll] : lenderOptions?.filter(a => formik?.values?.lenderName?.find(b => b === a?.value))}
                    isMulti={formik?.values?.lenderName?.length > 1 || Boolean(formik?.values?.lenderName?.find(a => a === "selectAll"))}
                    classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={false}
                    closeMenuOnSelect={false}
                    hideSelectedOptions={false}
                    name="lenderName"
                /> */}
            </Field>
            <Field
                label="Allocation Month"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select Allocation Month"
                    options={monthOptions}
                    onChange={e => {
                        formik.setFieldValue('allocationMonth', e)
                    }}
                    closeMenu={false}
                    name="allocationMonth"
                    value={formik?.values?.allocationMonth}
                    isClearable
                    isAllSelected={formik?.values?.allocationMonth?.includes('isAllSelected')}
                    // isDisabled={true}
                />
                {/* <Select
                    placeholder="Select Allocation Month"
                    // options={reportOption}
                    onChange={(e) => {
                        formik?.setFieldValue("allocationMonth", e);
                    }}
                    classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={true}
                    name="allocationMonth"
                /> */}
            </Field>
            <Field
                label="Category"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select Category"
                    options={portfolioOptions}
                    onChange={e => {
                        formik.setFieldValue('category', e)
                    }}
                    closeMenu={false}
                    name="category"
                    value={formik?.values?.category}
                    isClearable
                    isAllSelected={formik?.values?.category?.includes('isAllSelected')}
                    // isDisabled={true}
                />
            </Field>
            <Field
                label="Product Type"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select Product Type"
                    options={productOptions}
                    onChange={e => {
                        formik.setFieldValue('productType', e)
                    }}
                    closeMenu={false}
                    name="productType"
                    value={formik?.values?.productType}
                    isClearable
                    isAllSelected={formik?.values?.productType?.includes('isAllSelected')}
                    // isDisabled={true}
                />
            </Field>
            <Field
                label="Delinquency Type"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                {/* <Select
                    placeholder="Select Delinquency Type"
                    options={DelinquencyOptions}
                    onChange={(e) => {
                        formik?.setFieldValue("delinquencyType", e);
                    }}
                    // classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={true}
                    name="delinquencyType"
                    // isAllSelected={formik?.values?.delinquencyType?.includes('isAllSelected')}

                    // isDisabled={true}
                /> */}
                <MultiSelected
                    placeholder="Select Delinquency Type"
                    options={DelinquencyOptions}
                    onChange={e => {
                        formik?.setFieldValue('delinquencyType', e)
                    }}
                    closeMenu={false}
                    name="delinquencyType"
                    value={formik?.values?.delinquencyType}
                    isClearable
                    isAllSelected={formik?.values?.delinquencyType?.includes('isAllSelected')}
                    // isDisabled={true}
                />
            </Field>
            <Field
                label="Zone"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select Zone"
                    options={zoneOptions}
                    onChange={(e) => {
                        formik?.setFieldValue("zone", e);
                    }}
                    closeMenu={false}
                    name="zone"
                    value={formik?.values?.zone}
                    isClearable
                    isAllSelected={formik?.values?.zone?.includes('isAllSelected')}
                    // isDisabled={true}
                />
            </Field>
            <Field
                label="Region"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select Region"
                    options={regionOptions}
                    onChange={(e) => {
                        formik?.setFieldValue("region", e);
                    }}
                    closeMenu={false}
                    name="region"
                    value={formik?.values?.region}
                    isClearable
                    isAllSelected={formik?.values?.region?.includes('isAllSelected')}
                    // isDisabled={true}
                />
            </Field>
            <Field
                label="State"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select State"
                    options={stateOptions}
                    onChange={(e) => {
                        formik?.setFieldValue("state", e);
                    }}
                    closeMenu={false}
                    name="state"
                    value={formik?.values?.state}
                    isClearable
                    isAllSelected={formik?.values?.state?.includes('isAllSelected')}
                    // isDisabled={true}
                />
            </Field>
            <Field
                label="City"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <MultiSelected
                    placeholder="Select City"
                    options={cityOptions}
                    onChange={(e, actionMeta, condition) => {
                        // alert("selected")
                        setIsCitySelectAll(condition)
                         formik?.setFieldValue("city", e) 
                    }}
                    closeMenu={false}
                    name="city"
                    value={formik?.values?.city}
                    isClearable
                    isAllSelected={formik?.values?.city?.includes('isAllSelected')}

                    onMenuScrollToBottom={() => {
                        setCityPage(prev => prev + 1)
                    }}
                    // isDisabled={true}
                />
                {/* <Select
                    placeholder="Select City"
                    options={cityOptions}
                    onChange={(e) => {
                        formik?.setFieldValue("city", e);
                    }}
                    isMulti
                    hideSelectedOptions={false}
                    closeMenuOnSelect={false}
                    value={formik?.values?.city}
                    classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={true}
                    name="city"
                    onMenuScrollToBottom={()=>{
                        setCityPage(prev=> prev + 1)
                    }}
                    // onMenuScrollToTop={()=>{
                    //     setCityPage(prev=> prev === 1 ? 1 : prev - 1)
                    // }}
                /> */}
            </Field>
            <Field
                label="Type Of Collection"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <Select
                    placeholder="Select Type Of Collection"
                    options={collectionOptions}
                    onChange={(e) => {
                        formik?.setFieldValue("typeOfCollection", e);
                    }}
                    classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={true}
                    name="typeOfCollection"
                    isDisabled={true}
                />
            </Field>
            <Field
                label="Agencies"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <Select
                    placeholder="Select Agencies"
                    // options={reportOption}
                    onChange={(e) => {
                        formik?.setFieldValue("agencies", e);
                    }}
                    classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={true}
                    name="agencies"
                    isDisabled={true}
                />
            </Field>
            <Field
                label="Allocated Manager"
                containerClassName={styles?.field}
                labelClassName={styles?.label}
            >
                <Select
                    placeholder="Select Allocated Manager"
                    // options={reportOption}
                    onChange={(e) => {
                        formik?.setFieldValue("allocatedManager", e);
                    }}
                    classNamePrefix="react-select"
                    closeMenu={false}
                    isClearable={true}
                    name="allocatedManager"
                    isDisabled={true}
                />
            </Field>
        </Form>
    )
}

export default memo(DashboardFilter)