import { ButtonGroup, Card, CardBody, CardHeader, Container } from "reactstrap";
import SearchBarHeader from "../../../components/Header/SearchBarHeader";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import { getDocumentData, searchDocumentData } from "./lookupSlice";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import DocumentForm from "./DocumentForm";

const Documents = ({ access }) => {
    const [visible, setVisible] = useState(false)
    const [formType,setFormType] = useState('')
    const [selectedData,setSelectedData]=useState({})

    const user = useSelector((state) => state.user.data);
    const documentData = useSelector((state) => state?.lookup?.documentData);

    const dispatch = useDispatch();

    const onSuccess = () => {
        setSelectedData({});
        setVisible(false)
        setFormType("")
        dispatch(getDocumentData())
    }

    return (
        <Container fluid className="d-flex flex-column flex-grow-1 p-0">
            <SearchBarHeader
                serachAPI={(data) => dispatch(searchDocumentData(data))}
                getAllAPI={() => dispatch(getDocumentData())}
                onClick={() => {
                    setVisible(true);
                    setFormType("Create")
                }}
                permission={user?.masterRole?.[access]}
            />
            <Card className="flex-grow-1 mb-1">
                <CardHeader className="p-2"> Documents </CardHeader>
                <CardBody className="tableCardBody p-1">
                    <DataTable
                        value={documentData}
                        paginator
                        className="commonTable"
                        rows={10}
                        rowsPerPageOptions={[10, 20, 40, 80, "All"]}
                        tableStyle={{ minWidth: "50rem" }}
                    >
                        <Column header="Code" field="code" />
                        <Column header="Document Name" field="description" />
                        <Column
                            header="Status"
                            field="isActive"
                            body={(rowData) =>
                                rowData.isActive === "Y" ? (
                                    <b className="text-success">Active</b>
                                ) : (
                                    <b className="text-secondary">Inactive</b>
                                )
                            } />
                        <Column
                            header="Actions"
                            body={(rowData) => (
                                <ButtonGroup>
                                    {["V", "F"].includes(user?.masterRole[access]) && (
                                        <i
                                            className="bi bi-eye-fill text-primary"
                                            style={{ cursor: "pointer" }}
                                            onClick={() => {
                                                setSelectedData(rowData);
                                                setVisible(true)
                                                setFormType("View")
                                            }}
                                        ></i>
                                    )}
                                    {user?.masterRole[access] === "F" && (
                                        <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                                    )}
                                    {["E", "F"].includes(user?.masterRole[access]) && (
                                        <i
                                            className="bi bi-pencil-square text-danger"
                                            style={{ cursor: "pointer" }}
                                            onClick={() => {
                                                setSelectedData(rowData);
                                                setVisible(true)
                                                setFormType("Edit")
                                            }}
                                        ></i>
                                    )}
                                </ButtonGroup>
                            )}
                        />
                    </DataTable>
                </CardBody>
            </Card>

            {visible &&
                <Dialog
                    header={`${formType} Document`}
                    visible={visible}
                    onHide={() => {
                        setSelectedData({});
                        setVisible(false)
                        setFormType("")
                    }}
                >
                    <DocumentForm
                        onSuccess={onSuccess}
                        formType={formType}
                        data={selectedData}
                    />
                </Dialog>
            }
        </Container>
    )
}

export default Documents