import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { setLoader } from "../../../reducer/globalReducer";

const initialState = {
  userTypeData: [],
  agencyTypeData: [],
  rejectReasonData: [],
  userDesignationData: [],
  exceptionTypeData: [],
  disputeReasonData: [],
  requestTypeData: [],
  natureServiceData: [],
  addressTypeData: [],
  documentData: [],
  outComeTypeData: [],
  outComeData: [],
  activeDocumentData: [],
};

export const getUserTypeData = createAsyncThunk(
  "lookup/getUserTypeData",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllUserType");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getGridTypeData = createAsyncThunk(
  "lookup/getGridTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllGrid");
      dispatch(setLoader(false));
      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchUserTypeData = createAsyncThunk(
  "lookup/searchUserTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getFindUserType/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getAgencyTypeData = createAsyncThunk(
  "lookup/getAgencyTypeData",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllAgencyType");
      // console.log(res, "finalllalakjddb");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchAgencyTypeData = createAsyncThunk(
  "lookup/searchAgencyTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getAgencyTypeName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getRejectReasonData = createAsyncThunk(
  "lookup/getRejectReasonData",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllRejectReasonMaster");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchRejectReasonData = createAsyncThunk(
  "lookup/searchRejectReasonData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getRejectReasonMasterName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getUserDesignationData = createAsyncThunk(
  "lookup/getUserDesignationData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllUserDesignation");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchUserDesignationData = createAsyncThunk(
  "lookup/searchUserDesignationData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getUserDesignationName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getExceptionTypeData = createAsyncThunk(
  "lookup/getExceptionTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllExceptionType");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchExceptionTypeData = createAsyncThunk(
  "lookup/searchExceptionTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getExceptionTypeName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getDisputeReasonData = createAsyncThunk(
  "lookup/getDisputeReasonData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllDisputeReasonMaster");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchDisputeReasonData = createAsyncThunk(
  "lookup/searchDisputeReasonData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getDisputeReasonMasterName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getRequestTypeData = createAsyncThunk(
  "lookup/getRequestTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllRequestType");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchRequestTypeData = createAsyncThunk(
  "lookup/searchRequestTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getRequestTypeName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getNatureServiceData = createAsyncThunk(
  "lookup/getNatureServiceData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllActiveNatureOfService");
      dispatch(setLoader(false));
      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchNatureServiceData = createAsyncThunk(
  "lookup/searchNatureServiceData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getNatureOfServiceName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getAddressTypeData = createAsyncThunk(
  "lookup/getAddressTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllAddressType");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const searchAddressTypeData = createAsyncThunk(
  "lookup/searchAddressTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getAddressTypeName/${val}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
    }
  }
);
export const getDocumentData = createAsyncThunk(
  "lookup/getDocumentData",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllDocumentType");
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      console.log(error);
    }
  }
);
export const searchDocumentData = createAsyncThunk(
  "lookup/searchDocumentData",
  async (name, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getDocumentTypeName/${name}`);
      dispatch(setLoader(false));

      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      console.log(error);
    }
  }
);
export const getOuteComeTypeData = createAsyncThunk(
  "lookup/getOutComeTypeData",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get("/getAllOutcomeType");
      dispatch(setLoader(false));
      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      console.log(error);
    }
  }
);
export const searchOuteComeTypeData = createAsyncThunk(
  "lookup/searchOuteComeTypeData",
  async (val, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getFindOutcomeType/${val}`);
      dispatch(setLoader(false));
      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      console.log(error);
    }
  }
);
export const getActiveDocumentData = createAsyncThunk(
  "lookup/getActiveDocumentData",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getAllActiveDocumentType`);
      dispatch(setLoader(false));
      return {
        data: res?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      console.log(error);
    }
  }
);
const lookupSlice = createSlice({
  name: "lookupSlice",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getUserTypeData.fulfilled, (state, action) => {
      state.userTypeData = action?.payload?.data;
    });
    builder.addCase(searchUserTypeData.fulfilled, (state, action) => {
      state.userTypeData = action?.payload?.data;
    });
    builder.addCase(getAgencyTypeData.fulfilled, (state, action) => {
      state.agencyTypeData = action?.payload?.data;
    });
    builder.addCase(searchAgencyTypeData.fulfilled, (state, action) => {
      state.agencyTypeData = action?.payload?.data;
      // console.log(action?.payload?.data, "actionpayload");
    });
    builder.addCase(getRejectReasonData.fulfilled, (state, action) => {
      state.rejectReasonData = action?.payload?.data;
    });
    builder.addCase(searchRejectReasonData.fulfilled, (state, action) => {
      state.rejectReasonData = action?.payload?.data;
    });
    builder
      .addCase(getGridTypeData.pending, (state) => {
        state.loading = true;
      })
      .addCase(getGridTypeData.fulfilled, (state, action) => {
        state.gridTypeData = action?.payload?.data;
        state.loading = false; // Reset loading after data is fetched
      })
      .addCase(getGridTypeData.rejected, (state) => {
        state.loading = false; // Reset loading on error
      });
    builder.addCase(getUserDesignationData.fulfilled, (state, action) => {
      state.userDesignationData = action?.payload?.data;
    });
    builder.addCase(searchUserDesignationData.fulfilled, (state, action) => {
      state.userDesignationData = action?.payload?.data;
    });
    builder.addCase(getExceptionTypeData.fulfilled, (state, action) => {
      state.exceptionTypeData = action?.payload?.data;
    });
    builder.addCase(searchExceptionTypeData.fulfilled, (state, action) => {
      state.exceptionTypeData = action?.payload?.data;
    });
    builder.addCase(getDisputeReasonData.fulfilled, (state, action) => {
      state.disputeReasonData = action?.payload?.data;
    });
    builder.addCase(searchDisputeReasonData.fulfilled, (state, action) => {
      state.disputeReasonData = action?.payload?.data;
    });
    builder.addCase(getRequestTypeData.fulfilled, (state, action) => {
      state.requestTypeData = action?.payload?.data;
    });
    builder.addCase(searchRequestTypeData.fulfilled, (state, action) => {
      state.requestTypeData = action?.payload?.data;
    });
    builder.addCase(getNatureServiceData.fulfilled, (state, action) => {
      state.natureServiceData = action?.payload?.data;
    });
    builder.addCase(searchNatureServiceData.fulfilled, (state, action) => {
      state.natureServiceData = action?.payload?.data;
    });
    builder.addCase(getAddressTypeData.fulfilled, (state, action) => {
      state.addressTypeData = action?.payload?.data;
    });
    builder.addCase(searchAddressTypeData.fulfilled, (state, action) => {
      state.addressTypeData = action?.payload?.data;
    });
    builder.addCase(getDocumentData.fulfilled, (state, action) => {
      state.documentData = action?.payload?.data;
    });
    builder.addCase(searchDocumentData.fulfilled, (state, action) => {
      state.documentData = action?.payload?.data;
    });
    builder.addCase(getActiveDocumentData.fulfilled, (state, action) => {
      state.activeDocumentData = action?.payload?.data;
    });
    builder.addCase(getOuteComeTypeData.fulfilled, (state, action) => {
      state.outComeTypeData = action?.payload?.data;
    });
    builder.addCase(searchOuteComeTypeData.fulfilled, (state, action) => {
      state.outComeTypeData = action?.payload?.data;
    });
  },
});
export default lookupSlice.reducer;