import React, { useState, useEffect } from 'react'
import Swal from "sweetalert2"


import {
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  Col,
  Button,
  FormFeedback,
  Card,
  CardBody,
  CardHeader,
  ButtonGroup,
  Container,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik, useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import SearchBarHeader from '../../../components/Header/SearchBarHeader';
import { getOuteComeTypeData, searchOuteComeTypeData } from "./lookupSlice";
import {
  requestTypeSchema,
  validationSchema1,
} from "../../../Schema/RequestTypeSchema";
import axios from "axios";
import { setLoader } from "../../../reducer/globalReducer";
import Field from "../../../components/Field";

const Outcome = ({ access }) => {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [visible, setVisible] = useState(false)
  const [data, setData] = useState(null);
  const [isView, setView] = useState(false);
  const [isEdit, setEdit] = useState(false);
  const user = useSelector((state) => state.user.data)
  const outcomeTypeData = useSelector((state) => state?.lookup?.outComeTypeData)



  //Create Details
  const formik = useFormik({
    initialValues: requestTypeSchema,
    validationSchema: validationSchema1,
    onSubmit: (values, { resetForm }) => {
      resetForm({ values: "" });
      dispatch(setLoader(true))
      axios
        // .post("/createBank", values)
        .post("/createOutcomeType", values)
        .then((response) => {
          if (response?.data.msgKey === "Success") {
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: `${response?.data?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
            setVisible(false);
            resetForm({ values: "" });
            dispatch(getOuteComeTypeData());
            dispatch(setLoader(false))
          } else {
            dispatch(setLoader(false))
            Swal.fire({
              position: "top-end",
              icon: response?.data?.msgKey === "Failure" ? "error" : "success",
              title: `${response.data.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        })
        .catch((error) => {
          dispatch(setLoader(false))
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    },
  });


  //Edit 
  const handleUpdate = (formObj) => {
    dispatch(setLoader(true))
    axios
      .put(`/updateOutcomeType/${formObj.id}`, formObj)
      .then((response) => {
        if (response?.data.msgKey === "Success") {
          dispatch(setLoader(false))
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `${response?.data?.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          setEdit(false);
          dispatch(getOuteComeTypeData());
        } else {
          dispatch(setLoader(false))
          Swal.fire({
            position: "top-end",
            icon: response?.data?.msgKey === "Failure" ? "error" : "success",
            title: `${response.data.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        dispatch(setLoader(false))
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };
  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard")
    }
    // dispatch(getOuteComeTypeData())
  }, [user])
  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchOuteComeTypeData(data))}
        // visible={visible}
        getAllAPI={() => dispatch(getOuteComeTypeData())}
        onClick={() => (setVisible(true))}
        permission={user?.masterRole?.[access]}
      />
      <Card className='flex-grow-1 mb-1'>
        <CardHeader className='p-2'>Outcome Type</CardHeader>
        <DataTable
          value={outcomeTypeData}
          paginator
          className='commonTable'
          rows={10}
          rowsPerPageOptions={[10, 20, 40, 80, "All"]}
          tableStyle={{ minWidth: "50rem" }}
          globalFilterFields={["natureofServiceId", "status"]}
        >
          <Column field='code' header={"Code"}>
          </Column>
          <Column field='description' header="Description"></Column>
          <Column
            field='isActive'
            header="Status"
            body={(rowData) => rowData.isActive === "Y" ? (<b className='text-success'>Active</b>) : (<b className='text-success'>Inactive</b>)}
          >
            1
          </Column>
          <Column header="Action"
            body={(rowData) => (
              <ButtonGroup>
                {/* view icon */}
                {
                  ["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className='bi bi-eye-fill text-primary'
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setView(!isView);
                      }}
                    ></i>
                  )
                }
                {/* sepration part  */}
                {
                  user?.masterRole[access] === 'F' && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )
                }

                {/* edit icon */}
                {
                  ["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setEdit(!isEdit);
                      }}
                    ></i>
                  )
                }
              </ButtonGroup>
            )}
          >
          </Column>
        </DataTable>
      </Card >

      {/* Dialog to view the form */}
      <Dialog 
        header="OutCome Type"
        visible={isView}
        style={{ width: "60vw" }}
        onHide={() => setView(!isView)}
      >
        <section>
          <Row>
            <Col lg={6} md={6} sm={12}>
              <Field isRequired label="Code">
                <Input bsSize="sm" type="text" value={data?.code} disabled />
              </Field>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <Field isRequired label="Name">
                <Input
                  bsSize="sm"
                  type="text"
                  value={data?.description}
                  disabled
                />
              </Field>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <Field label="Active">
                <FormGroup switch className="ms-2">
                  <Input
                    type="switch"
                    checked={data?.isActive === "Y"}
                    id="active"
                    disabled
                  />
                </FormGroup>
              </Field>
            </Col>
          </Row>
        </section>
      </Dialog>
      {/* modal from create a type  */}
      < Dialog
        header="OutCome Type"
        visible={visible}
        style={{ width: "60vw" }}
        onHide={() => setVisible(false)}
      >
        <section>
          <Form onSubmit={formik.handleSubmit}>
            <Row>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Code"
                  errorMessage={formik.touched.code && formik.errors.code}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="code"
                    placeholder="Request type Code"
                    value={formik?.values?.code}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={formik.touched.code && Boolean(formik.errors.code)}
                    autoComplete="off"
                  />
                </Field>
              </Col>

              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Name"
                  errorMessage={
                    formik.touched.description && formik.errors.description
                  }
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="description"
                    placeholder="Request Name "
                    value={formik.values.description}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={
                      formik.touched.description &&
                      Boolean(formik.errors.description)
                    }
                    autoComplete="off"
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field label="Active">
                  <FormGroup switch className="ms-2">
                    <Input
                      type="switch"
                      checked={formik.values.isActive === "Y"}
                      onChange={(e) => {
                        formik.setFieldValue(
                          "isActive",
                          e.target.checked ? "Y" : "N"
                        );
                      }}
                      id="isActive"
                      readOnly
                    />
                  </FormGroup>
                </Field>
              </Col>
            </Row>
            <div className="text-end">
              <Button type="submit" color="primary" size="sm">
                Submit
              </Button>{" "}
              <Button
                size="sm"
                color="danger"
                type="button"
                className="ml-2"
                style={{ color: "#fff" }}
                onClick={() => setVisible(false)}
              >
                Close
              </Button>
            </div>
          </Form>
        </section>
      </ Dialog>


      {/* updated modal  */}
      <Dialog Dialog
        header="OutCome Type"
        visible={isEdit}
        onHide={() => setEdit(!isEdit)}
      >
        <section>
          <Formik
            initialValues={data}
            validationSchema={validationSchema1}
            onSubmit={handleUpdate}
          >{({
            values,
            errors,
            touched,
            handleBlur,
            handleChange,
            handleSubmit,
            setFieldValue
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row >
                <Col lg={6} md={6} sm={12}>
                  <Field isRequired label="Code">
                    <Input
                      bsSize='sm'
                      type='text'
                      id='code'
                      placeholder='lookup value code '
                      value={values.code}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched.code && Boolean(errors.code)}
                      autoComplete='off'
                      disabled
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field isRequired label="Name">
                    <Input
                      bsSize='sm'
                      type='text'
                      description="description"
                      id='description'
                      placeholder='lookup value code '
                      value={values.description}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={touched.description && Boolean(errors.description)}
                      autoComplete='off'
                    />
                  </Field>
                </Col>
                <Col lg={6} md={10} sm={12}>
                  <Field label={"Active"}>
                    <FormGroup switch className='ms-2' >
                      <Input
                        type='switch'
                        checked={values.isActive === "Y"}
                        onChange={(e) => {
                          setFieldValue(
                            "isActive",
                            e.target.checked ? "Y" : "N"
                          )
                        }}
                        id='active'
                      >
                      </Input>
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div className="text-end">
                <Button type="submit" color="primary" size="sm">
                  Submit
                </Button>{" "}
                <Button
                  size="sm"
                  color="danger"
                  type="button"
                  className="ml-2"
                  style={{ color: "#fff" }}
                  onClick={() => setEdit(!isEdit)}
                >
                  Close
                </Button>
              </div>
            </Form>
          )}
          </Formik>
        </section>
      </Dialog>
    </Container >

  )
}

export default Outcome
