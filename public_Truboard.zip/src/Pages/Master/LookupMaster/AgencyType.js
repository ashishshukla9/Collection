import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";

import {
  Form,
  FormGroup,
  Input,
  Label,
  Row,
  Col,
  Button,
  FormFeedback,
  Card,
  CardBody,
  CardHeader,
  ButtonGroup,
  Container,
} from "reactstrap";
import {
  agencyTypeSchema,
  validationSchema,
} from "../../../Schema/AgencyTypeSchema";
import { useFormik, Formik } from "formik";
import axios from "axios";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getAgencyTypeData, searchAgencyTypeData } from "./lookupSlice";
import SearchBarHeader from "../../../components/Header/SearchBarHeader";
import Field from "../../../components/Field";
import { setLoader } from "../../../reducer/globalReducer";
export default function AgencyType({ access }) {
  const [visible, setVisible] = useState(false);
  const [data, setData] = useState(null);
  const [isView, setView] = useState(false);
  const [isEdit, setEdit] = useState(false);

  const user = useSelector((state) => state.user.data);
  const agencyTypeDetails = useSelector(
    (state) => state?.lookup?.agencyTypeData
  );

  // console.log(agencyTypeDetails, "agencyTypeDetailsagencyTypeDetails")
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  //Create Details
  const formik = useFormik({
    initialValues: agencyTypeSchema,
    validationSchema: validationSchema,
    onSubmit: (values, { resetForm }) => {
      dispatch(setLoader(true));

      resetForm({ values: "" });
      setVisible(false);
      axios
        .post("createAgencyType", values)
        .then((response) => {
          dispatch(getAgencyTypeData());
          dispatch(setLoader(false));

          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Records has been saved",
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          setVisible(false);
        })
        .catch((error) => {
          dispatch(setLoader(false));

          console.log(error);
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: `${error.message}`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        });
    },
  });

  //Edit Bank
  const handleUpdate = (formObj) => {
    dispatch(setLoader(true));
    axios
      .put(`/updateAgencyType/${formObj.id}`, formObj)
      .then(() => {
        dispatch(getAgencyTypeData());
        dispatch(setLoader(false));

        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Records Updated Successfully",
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        setEdit(false);
      })
      .catch((error) => {
        dispatch(setLoader(false));

        console.log(error);
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  // console.log(agencyTypeDetails, "agencyTypeDetailsagencyTypeDetailsagencyTypeDetailsnd")
  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchAgencyTypeData(data))}
        getAllAPI={() => dispatch(getAgencyTypeData())}
        onClick={() => {
          setVisible(true);
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">Agency Type</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={agencyTypeDetails}
            paginator
            className="commonTable"
            rows={10}
            // rowsPerPageOptions={[10, 20, 40, 80, "All"]}
            tableStyle={{ minWidth: "50rem" }}
            globalFilterFields={["agencyTypeId", "status"]}
          >
            <Column field="code" header="Agency Code"></Column>
            <Column field="description" header="Agency Name"></Column>
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData.isActive === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            >
              1
            </Column>
            <Column
              // field="isActive"
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setView(!isView);
                      }}
                    ></i>
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setEdit(!isEdit);
                      }}
                    ></i>
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  <i
                    className="bi bi-trash-fill text-danger"
                    style={{ cursor: "pointer" }} 
                    onClick={() => {
                      deleteRow(rowData.id);
                    }}
                  ></i> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>

      {/* Dialog to create a type */}
      <Dialog
        header="Agency Type"
        visible={visible}
        // style={{ width: "60vw" }}
        onHide={() => setVisible(false)}
      >
        <section>
          <Form onSubmit={formik.handleSubmit}>
            <Row>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Agency Code"
                  errorMessage={formik.touched.code && formik.errors.code}
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="code"
                    placeholder="Agency Code"
                    value={formik.values.code}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={formik.touched.code && Boolean(formik.errors.code)}
                    autoComplete="off"
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field
                  isRequired
                  label="Agency Name"
                  errorMessage={
                    formik.touched.description && formik.errors.description
                  }
                >
                  <Input
                    bsSize="sm"
                    type="text"
                    id="description"
                    placeholder="Agency Name"
                    value={formik.values.description}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    invalid={
                      formik.touched.description &&
                      Boolean(formik.errors.description)
                    }
                    autoComplete="off"
                  />
                </Field>
              </Col>
              <Col lg={6} md={6} sm={12}>
                <Field label="Active">
                  <FormGroup switch className="ms-2">
                    <Input
                      type="switch"
                      checked={formik.values.isActive === "Y"}
                      onChange={(e) => {
                        formik.setFieldValue(
                          "isActive",
                          e.target.checked ? "Y" : "N"
                        );
                      }}
                      id="isActive"
                      readOnly
                    />
                  </FormGroup>
                </Field>
              </Col>
            </Row>
            <div className="d-flex justify-content-end">
              <Button type="submit" color="primary" className="me-1" size="sm">
                Submit
              </Button>{" "}
              <Button
                size="sm"
                color="danger"
                type="button"
                style={{ color: "#fff" }}
                onClick={() => setVisible(false)}
              >
                Close
              </Button>
            </div>
          </Form>
        </section>
      </Dialog>

      {/* Dialog to view the form */}
      <Dialog
        header="Agency Type"
        visible={isView}
        // style={{ width: "60vw" }}
        onHide={() => setView(!isView)}
      >
        <section>
          <Row>
            <Col lg={6} md={6} sm={12}>
              <Field isRequired label="Agency Code">
                <Input bsSize="sm" type="text" value={data?.code} disabled />
              </Field>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <Field isRequired label="Agency Name">
                <Input
                  bsSize="sm"
                  type="text"
                  value={data?.description}
                  disabled
                />
              </Field>
            </Col>
            <Col lg={6} md={6} sm={12}>
              <Field label="Active">
                <FormGroup switch className="ms-2">
                  <Input
                    type="switch"
                    checked={data?.isActive === "Y"}
                    id="active"
                    disabled
                  />
                </FormGroup>
              </Field>
            </Col>
          </Row>
        </section>
      </Dialog>

      {/* Dialog to Edit type */}
      <Dialog
        header=" Agency Type"
        visible={isEdit}
        // style={{ width: "60vw" }}
        onHide={() => setEdit(!isEdit)}
      >
        <section>
          <Formik
            initialValues={data}
            validationSchema={validationSchema}
            onSubmit={(values) => {
              handleUpdate(values);
            }}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
              setFieldValue,
            }) => (
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col lg={6} md={6} sm={12}>
                    <Field isRequired label="Agency Code">
                      <Input
                        bsSize="sm"
                        type="text"
                        id="code"
                        placeholder="Agency code"
                        value={values.code}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={touched.code && Boolean(errors.code)}
                        autoComplete="off"
                        disabled
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Agency Name"
                      errorMessage={touched.description && errors.description}
                    >
                      <Input
                        bsSize="sm"
                        type="text"
                        name="description"
                        id="description"
                        placeholder="Agency Name"
                        value={values.description}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={
                          touched.description && Boolean(errors.description)
                        }
                      />
                    </Field>
                  </Col>

                  <Col lg={6} md={6} sm={12}>
                    <Field label="Active">
                      <FormGroup switch className="ms-2">
                        <Input
                          type="switch"
                          checked={values.isActive === "Y"}
                          onChange={(e) => {
                            setFieldValue(
                              "isActive",
                              e.target.checked ? "Y" : "N"
                            );
                          }}
                          id="active"
                          // readOnly
                        />
                      </FormGroup>
                    </Field>
                  </Col>
                </Row>

                <div className="d-flex justify-content-end">
                  <Button
                    type="submit"
                    color="primary"
                    className="me-1"
                    size="sm"
                  >
                    Submit
                  </Button>
                  <Button
                    size="sm"
                    color="danger"
                    type="button"
                    style={{ color: "#fff" }}
                    onClick={() => setEdit(!isEdit)}
                  >
                    Close
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </section>
      </Dialog>
    </Container>
  );
}
