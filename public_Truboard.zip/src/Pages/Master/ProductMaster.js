import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import Swal from "sweetalert2";
import axios from "axios";
import Select from "react-select";
import cx from "classnames";

import {
  ProductMasterSchema,
  productMasterValidation,
} from "../../Schema/ProductMaster";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  useAddProductMutation
} from "./store/productSlice";
import SearchBarHeader from "../../components/Header/SearchBarHeader";
import { getPortfolioData } from "./store/portfolioMasterSlice";
import { getProductData, searchProductData } from "./store/productMasterSlice";
import { setLoader } from "../../reducer/globalReducer";
import { NO_SPACE } from "../../utils/regex";
import './style.css'

export default function PortfolioMaster({ access }) {
  const [createModal, setCreateModal] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  const [viewModal, setViewModal] = useState(false);

  const [activePortfolio, setActivePortfolio] = useState([]);
  const [data, setData] = useState({});

  const [addProduct] = useAddProductMutation();
  const portfolioData = useSelector(state => state?.portfolioMaster?.data)
  const productData = useSelector(state => state?.productMaster)
  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();
  const dispatch = useDispatch()

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  const handleFormSubmit = async (values) => {
    dispatch(setLoader(true))
    let tempValues = {
      ...values,
    };
    tempValues["portfolio"] = portfolioData?.filter(
      (e) => e.portfolioCode === values.portfolioCode
    )[0];

    const res = await addProduct(tempValues);
    if (res?.data?.msgKey == "Success") {
      setCreateModal(false);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } else {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }

    setTimeout(() => {
      dispatch(getProductData())
      dispatch(setLoader(false))
      
    }, 1000)
  };
  const handleUpdate = (values) => {
    dispatch(setLoader(true))
    let tempValues = { ...values };
    tempValues["portfolio"] = portfolioData?.filter(
      (e) => e.portfolioCode === values.portfolioCode
    )[0];
    axios
      .put(`/updateProduct/${values.productId}`, tempValues)
      .then((res) => {
        dispatch(getProductData())

        setUpdateModal(false)
        setCreateModal(false);
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      })
      .catch((error) => {
        setCreateModal(false);
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };
  useEffect(() => {
    dispatch(getPortfolioData())
  }, []);
  useEffect(() => {
    let tempPortfolio = [];
    portfolioData.forEach((portfolio) => {
      // if ()
      tempPortfolio.push({
        label: portfolio.portfolioDescription,
        value: portfolio.portfolioCode,
        disabled: portfolio.active !== "Y"
      });
    });
    setActivePortfolio([...tempPortfolio]);
  }, [portfolioData]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchProductData(data))}
        getAllAPI={() => dispatch(getProductData())}
        onClick={() => {
          setCreateModal(!createModal);
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">Product Master</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={productData?.data}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="productCode" header="Code" sortable></Column>
            <Column
              field="portfolio.portfolioCode"
              header="Portfolio"
              body={(rowData) =>
                portfolioData.filter(
                  (e) => e?.portfolioCode === rowData.portfolio?.portfolioCode
                )[0]?.portfolioDescription
              }
              sortable
            ></Column>
            <Column field="productDescription" header="Description" sortable></Column>
            <Column
              field="isActive"
              header="Status"
              body={(rowData) =>
                rowData.isActive === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({
                          ...rowData,
                          portfolioCode: rowData.portfolio.portfolioCode,
                        });
                        setViewModal(!viewModal);
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({
                          ...rowData,
                          portfolioCode: rowData.portfolio.portfolioCode,
                        });
                        setUpdateModal(!updateModal);
                      }}
                    />
                  )}
                  {/* <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                <i className="bi bi-trash" style={{ cursor: "pointer" }} /> */}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header="Create Product"
        visible={createModal}
        style={{ width: "60vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={ProductMasterSchema}
          validationSchema={productMasterValidation}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup
                    row
                    className="align-i
                  tems-center"
                  >
                    <Label sm={4} for="productCode">
                      Code
                      <span className="required" style={{ color: "red" }}>
                        *
                      </span>
                    </Label>
                    <Col sm={8}>
                      <Input
                        bsSize="sm"
                        type="text"
                        id="productCode"
                        placeholder="Code"
                        value={values.productCode}
                        onChange={e => {
                          if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                            setFieldValue('productCode', e?.target?.value)
                          }
                        }}
                        onBlur={handleBlur}
                        invalid={
                          touched.productCode && Boolean(errors.productCode)
                        }
                        autoComplete="off"
                      ></Input>
                      <FormFeedback>
                        {touched.productCode && errors.productCode}
                      </FormFeedback>
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="code">
                      Portfolio
                      <span className="required" style={{ color: "red" }}>
                        *
                      </span>
                    </Label>
                    <Col sm={8}>
                      <Select
                        inputId="portfolioCode"
                        name="portfolioCode"
                        isClearable={true}
                        options={activePortfolio}
                        closeMenuOnSelect={true}
                        hideSelectedOptions={false}
                        onChange={(e) =>
                          setFieldValue("portfolioCode", e?.value)
                        }
                        value={activePortfolio.filter(
                          (v) => v.value === values.portfolioCode
                        )}
                        className={cx({
                          abc:
                            touched.portfolioCode &&
                            Boolean(errors.portfolioCode),
                        })}
                        onBlur={handleBlur}
                        menuPosition={"fixed"}
                        classNamePrefix="react-select"
                        isOptionDisabled={(option) => option.disabled}
                      />
                      {touched.portfolioCode &&
                        Boolean(errors.portfolioCode) && (
                          <FormFeedback style={{ display: "block" }}>
                            {errors.portfolioCode}
                          </FormFeedback>
                        )}
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="productDescription">
                      Description
                      <span className="required" style={{ color: "red" }}>
                        *
                      </span>
                    </Label>
                    <Col sm={8}>
                      <Input
                        bsSize="sm"
                        type="text"
                        id="productDescription"
                        placeholder="Description"
                        value={values.productDescription}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={
                          touched.productDescription &&
                          Boolean(errors.productDescription)
                        }
                        autoComplete="off"
                      ></Input>
                      <FormFeedback>
                        {touched.productDescription &&
                          errors.productDescription}
                      </FormFeedback>
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="isActive">
                      Active
                    </Label>
                    <Col sm={8}>
                      <FormGroup switch className="ms-2">
                        <Input
                          type="switch"
                          checked={values.isActive === "Y"}
                          onChange={(e) => {
                            setFieldValue(
                              "isActive",
                              e.target.checked ? "Y" : "N"
                            );
                          }}
                          id="isActive"
                          readOnly
                        />
                      </FormGroup>
                    </Col>
                  </FormGroup>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <Button type="submit" color="primary" className="me-1" size="sm">
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setCreateModal(!createModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>

      {/* Modal to Update data */}
      <Dialog
        header="Update Product"
        visible={updateModal}
        style={{ width: "60vw" }}
        onHide={() => setUpdateModal(!updateModal)}
      >
        <Formik
          initialValues={data}
          validationSchema={productMasterValidation}
          onSubmit={handleUpdate}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="productCode">
                      Code
                      <span className="required" style={{ color: "red" }}>
                        *
                      </span>
                    </Label>
                    <Col sm={8}>
                      <Input
                        bsSize="sm"
                        type="text"
                        id="productCode"
                        placeholder="Code"
                        value={values.productCode}
                        disabled
                      ></Input>
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="code">
                      Portfolio
                      <span className="required" style={{ color: "red" }}>
                        *
                      </span>
                    </Label>
                    <Col sm={8}>
                      <Select
                        inputId="portfolioCode"
                        name="portfolioCode"
                        isClearable={true}
                        options={activePortfolio}
                        closeMenuOnSelect={true}
                        hideSelectedOptions={false}
                        onChange={(e) =>
                          setFieldValue("portfolioCode", e?.value)
                        }
                        value={activePortfolio.filter(
                          (v) => v.value === values.portfolioCode
                        )}
                        className={cx({
                          abc:
                            touched.portfolioCode &&
                            Boolean(errors.portfolioCode),
                        })}
                        onBlur={handleBlur}
                        menuPosition={"fixed"}
                        classNamePrefix="react-select"
                        isOptionDisabled={(option) => option.disabled}
                      />
                      {touched.portfolioCode &&
                        Boolean(errors.portfolioCode) && (
                          <FormFeedback style={{ display: "block" }}>
                            {errors.portfolioCode}
                          </FormFeedback>
                        )}
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="productDescription">
                      Description
                      <span className="required" style={{ color: "red" }}>
                        *
                      </span>
                    </Label>
                    <Col sm={8}>
                      <Input
                        bsSize="sm"
                        type="text"
                        id="productDescription"
                        placeholder="Description"
                        value={values.productDescription}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={
                          touched.productDescription &&
                          Boolean(errors.productDescription)
                        }
                        autoComplete="off"
                      ></Input>
                      <FormFeedback>
                        {touched.productDescription &&
                          errors.productDescription}
                      </FormFeedback>
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="isActive">
                      Active
                    </Label>
                    <Col sm={8}>
                      <FormGroup switch className="ms-2">
                        <Input
                          type="switch"
                          checked={values.isActive === "Y"}
                          onChange={(e) => {
                            setFieldValue(
                              "isActive",
                              e.target.checked ? "Y" : "N"
                            );
                          }}
                          id="isActive"
                          readOnly
                        />
                      </FormGroup>
                    </Col>
                  </FormGroup>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <Button type="submit" color="primary" className="me-1" size="sm">
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setUpdateModal(!updateModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>

      {/* Modal to View data */}
      <Dialog
        visible={viewModal}
        style={{ width: "60vw" }}
        onHide={() => setViewModal(!viewModal)}
      >
        <Formik initialValues={data}>
          {({ values }) => (
            <Form>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="productCode">
                      Code
                    </Label>
                    <Col sm={8}>
                      <Input
                        bsSize="sm"
                        type="text"
                        id="productCode"
                        placeholder="Code"
                        value={values.productCode}
                        disabled
                        autoComplete="off"
                      ></Input>
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="code">
                      Portfolio
                    </Label>
                    <Col sm={8}>
                      <Select
                        inputId="portfolioCode"
                        name="portfolioCode"
                        value={activePortfolio.filter(
                          (v) => v.value === values.portfolioCode
                        )}
                        classNamePrefix="react-select"
                        isDisabled
                      />
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="productDescription">
                      Description
                    </Label>
                    <Col sm={8}>
                      <Input
                        bsSize="sm"
                        type="text"
                        id="productDescription"
                        placeholder="Description"
                        value={values.productDescription}
                        autoComplete="off"
                        disabled
                      ></Input>
                    </Col>
                  </FormGroup>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <FormGroup row className="align-items-center">
                    <Label sm={4} for="isActive">
                      Active
                    </Label>
                    <Col sm={8}>
                      <FormGroup switch className="ms-2">
                        <Input
                          type="switch"
                          checked={values.isActive === "Y"}
                          id="isActive"
                          readOnly
                        />
                      </FormGroup>
                    </Col>
                  </FormGroup>
                </Col>
              </Row>
            </Form>
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}
