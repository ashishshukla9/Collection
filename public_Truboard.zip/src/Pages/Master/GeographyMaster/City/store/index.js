import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../../../App.config";
import { setLoader } from "../../../../../reducer/globalReducer";
import Swal from "sweetalert2";

export const getAllCity = createAsyncThunk(
  "city/getAllCity",
  async (params, { dispatch }) => {
    try {
      dispatch(setLoader(true));
      const response = await axios.get(baseUrl() + `/getAllCities/${params?.currentPage || 1}/${params?.numberOfDataPerPage || 4000}`);
      // console.log(response, 'vhvgvg')
      dispatch(setLoader(false));
      return {
        list: response?.data?.response,
        totalCount: response?.data?.totalApplicationCount
      };
    } catch (error) {
      dispatch(setLoader(false));
      throw new Error("Failed to fetch city data.");
    }
  }
);

export const addCity = createAsyncThunk(
  "city/addRegion",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      const res = await axios.post(baseUrl() + "/createCity", params);

      dispatch(getAllCity());
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
      return true;
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
      throw new Error("Failed to fetch city data.");
    }
  }
);
export const editCity = createAsyncThunk(
  "city/editRegion",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      const res = await axios.put(baseUrl() + `/updateCity/${params?.id}`, params?.body);
      dispatch(getAllCity());
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
      return true;
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
      throw new Error("Failed to fetch city data.");
    }
  }
);

export const searchCity = createAsyncThunk("city/search", async (params) => {
  try {
    const res = await axios.get(`/getCityByCityName/${params?.search}/${params?.currentPage}/${params?.numberOfDataPerPage}`);
    return {
      list: res?.data?.response,
      totalCount: res?.data?.totalApplicationCount
    };
  } catch (error) {
    console.log(error);
  }
});

export const getStateName = createAsyncThunk(
  "city/getState",
  async (params) => {
    try {
      const response = await axios.get(
        baseUrl() + `/getStateByRegion/${params}`
      );
      return response?.data?.data;
    } catch (error) {
      throw new Error("Failed to fetch city data.");
    }
  }
);
// export const getStateName = createAsyncThunk("city/search", (params) =>
// axios.get( `getStateByRegion/${params}`),
// );

export const city = createSlice({
  name: "city",
  initialState: {
    list: [],
    loader: false,

    error: "",
    selected: null,
    totalCount: 0
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null ? (state.selected = null) : (state.selected = action.payload);
      console.log(action?.payload, "payload")
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllCity.fulfilled, (state, action) => {
      state.loading = false;
      state.list = action.payload.list;
      state.totalCount = action.payload?.totalCount
    });
    builder.addCase(searchCity.fulfilled, (state, action) => {
      state.list = action.payload.list;
      state.totalCount = action.payload?.totalCount
    });
    // .addCase(getAllCity.rejected, (state, action) => {
    //   state.loading = false;
    //   state.error = action.error.message;
    // });
  },
});

export const { setSelected, setLoder } = city.actions;

export default city.reducer;
