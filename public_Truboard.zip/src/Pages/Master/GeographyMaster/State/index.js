import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import {
  StateSchema,
  StateValidationSchema,
} from "../../../../Schema/GeographyMaster";
import Select from "react-select";
import cx from "classnames";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addState, editState, getAllStates, searchState, setSelected } from "./store";
import { getAllRegion } from "../Region/store";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";
import Field from "../../../../components/Field";
import { NO_SPACE } from "../../../../utils/regex";

export default function State({ access }) {
  const [createModal, setCreateModal] = useState(false);
  const [type, setType] = useState("");

  const [regionOptions, setRegionOptions] = useState([]);
  const regionLists = useSelector((state) => state?.region?.list);
  const { list, selected } = useSelector((state) => state?.state);
  const [regionId, setRegionId] = useState("");
  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleFormSubmit = (values) => {
    let region = regionLists.filter((e) => e.regionCode === values?.region);
    const payload={
      ...values,
      region: {
        active: region[0]?.active,
        regionCode: region[0]?.regionCode,
        regionId: region[0]?.regionId,
        regionName: region[0]?.regionName
      }
    }
    let resp = false;

    if (type === "Edit") {
      resp = dispatch(
        editState({ ...payload, id: selected?.stateId })
      );
    } else {
      resp = dispatch(addState({ ...payload }));
    }
    resp && setCreateModal(false);
  };

  const hanldeStateChange = (e, values) => {
    setRegionId(e?.value);
    return e?.value;
  };

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  useEffect(() => {
    setRegionId(createModal ? regionId : '')
  }, [createModal]);

  useEffect(() => {
    setRegionId(selected?.region?.regionCode);
  }, [selected]);

  useEffect(() => {
    dispatch(getAllRegion());
    let tempRegion = [];
    regionLists.forEach((e) => {
      if (e.active === "Y")
        tempRegion.push({ label: e.regionName, value: e.regionCode, ...e });
    });
    setRegionOptions([...tempRegion]);
  }, [type]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchState(data))}
        getAllAPI={() => dispatch(getAllStates())}
        onClick={() => {
          setCreateModal(!createModal);
          setType("Add");
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">States</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={list}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="stateCode" header="State Code" sortable></Column>
            <Column field="stateName" header="State Name" sortable></Column>
            <Column field="region.regionName" header="Region" sortable></Column>
            <Column
              field="active"
              header="Status"
              body={(rowData) =>
                rowData.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        dispatch(setSelected(rowData));
                        setCreateModal(!createModal);
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        dispatch(
                          setSelected({
                            ...rowData,
                          })
                        );
                        setCreateModal(!createModal);
                        setType("Edit");
                      }}
                    />
                  )}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header={`${type} State Details`}
        visible={createModal}
        style={{ width: "60vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={type !== "Add" ? {...selected,region: selected?.region?.regionCode} : StateSchema}
          validationSchema={StateValidationSchema}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => {
            return(
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="State Code"
                      errorMessage={touched.stateCode && errors.stateCode}
                    >
                      <Input
                        disabled={type !== "Add"}
                        bsSize="sm"
                        type="text"
                        id="stateCode"
                        placeholder="Code"
                        value={values.stateCode}
                        onChange={e=>{
                          if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                            setFieldValue('stateCode', e?.target?.value)
                          }
                        }}
                        onBlur={handleBlur}
                        invalid={touched.stateCode && Boolean(errors.stateCode)}
                        autoComplete="off"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="State Name"
                      errorMessage={touched.stateName && errors.stateName}
                    >
                      <Input
                        disabled={type !== "Add"}
                        bsSize="sm"
                        type="text"
                        id="stateName"
                        placeholder="State Code"
                        value={values.stateName}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={touched.stateName && Boolean(errors.stateName)}
                        autoComplete="off"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Region"
                      errorMessage={touched.region && errors.region}
                    >
                      <Select
                        isDisabled={type === "View"}
                        inputId="region"
                        name="region"
                        isClearable={true}
                        options={regionOptions}
                        closeMenuOnSelect={true}
                        hideSelectedOptions={false}
                        onChange={(e) =>{
                          setFieldValue("region", e?.value)
                        }}
                        value={regionOptions.filter(
                          (v) => v.value === values?.region
                        )}
                        className={cx({
                          abc: touched.region && Boolean(errors.region),
                        })}
                        onBlur={handleBlur}
                        menuPosition={"fixed"}
                        classNamePrefix="react-select"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Active"
                      errorMessage={touched.active && errors.active}
                    >
                      <FormGroup switch className="ms-2">
                        <Input
                          disabled={type === "View" ? true : false}
                          type="switch"
                          checked={values.active === "Y" ? true : false}
                          onChange={(e) => {
                            setFieldValue(
                              "active",
                              e.target.checked ? "Y" : "N"
                            );
                          }}
                          id="active"
                          readOnly
                        />
                      </FormGroup>
                    </Field>
                  </Col>
                </Row>
                <div
                  className={`${type === "View" && "d-none"
                    } d-flex justify-content-end`}
                >
                  <Button type="submit" color="primary" className="me-1" size="sm">
                    Submit
                  </Button>
                  <Button
                    size="sm"
                    type="button"
                    color="danger"
                    onClick={() => setCreateModal(!createModal)}
                  >
                    Cancel
                  </Button>
                </div>
              </Form>
            )
          }}
        </Formik>
      </Dialog>
    </Container>
  );
}
