import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../../../App.config";
import { setLoader } from "../../../../../reducer/globalReducer";
import Swal from "sweetalert2";

export const getAllRegion = createAsyncThunk(
  // "region/getAllRegion",
  "region/getAllRegion",
  
  async (params,{dispatch}) => {
    dispatch(setLoader(true));
    try {
      const response = await axios.get(baseUrl() + "/getAllRegions");
      dispatch(setLoader(false));
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      dispatch(setLoader(false));
      throw new Error("Failed to fetch region data.");
    }
  }
);
export const addRegion = createAsyncThunk(
  "region/addRegion",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
    const res=  await axios.post(baseUrl() + "/createRegion", params);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(setLoader(false));
      dispatch(getAllRegion());
      return true;
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(setLoader(false));
      throw new Error("Failed to fetch region data.");
    }
  }
);
export const editRegion = createAsyncThunk(
  "region/editRegion",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
    const res=  await axios.put(baseUrl() + `/updateRegion/${params?.id}`, params);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(setLoader(false));
      dispatch(getAllRegion());
      return true;
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(setLoader(false));
      throw new Error("Failed to fetch region data.");
    }
  }
);

export const searchRegion = createAsyncThunk(
  "region/searchRegion", 
  async(params,{dispatch}) =>{
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getRegionByRegionName/${params}`)
      dispatch(setLoader(false))
      return{
        list: res?.data?.data
      }
    } catch (error) {
      dispatch(setLoader(false))
    }
  }
);

export const region = createSlice({
  name: "region",
  initialState: {
    list: [],
    loader: false,
    error: "",
    selected: null,
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null
        ? (state.selected = null)
        : (state.selected = action.payload);
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllRegion.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.list;
      })
      .addCase(searchRegion.fulfilled, (state, action) => {
        state.list = action.payload.list
      });
  },
});

export const { setSelected, setLoder } = region.actions;

export default region.reducer;
