import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import { setLoader } from "../../../../reducer/globalReducer";
import {
  RegionSchema,
  RegionValidationSchema,
} from "../../../../Schema/GeographyMaster";
import Select from "react-select";
import cx from "classnames";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getAllRegion, searchRegion, setSelected } from "./store";
import { addRegion, editRegion } from "../Region/store";
import { getZone } from "../Zone/store";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";
import Field from "../../../../components/Field";
import { NO_SPACE } from "../../../../utils/regex";

export default function Region({ access }) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [createModal, setCreateModal] = useState(false);
  const [type, setType] = useState("");
  const [regionOptions, setRegionOptions] = useState([]);

  const zoneLists = useSelector((state) => state?.zone?.list);
  const user = useSelector((state) => state.user.data);
  let { list, selected } = useSelector((state) => state.region);

  const handleFormSubmit = (values) => {
    let myState = zoneLists.filter((e) => e?.zoneCode === values.zone);
    let resp = false;
    dispatch(setLoader(true))
    if (type === "Edit") {
      resp = dispatch(
        editRegion({ ...values, id: selected?.regionId, zone: myState[0] })
      );
    } else {
      resp = dispatch(addRegion({ ...values, zone: myState[0] }));
    }
    resp && setCreateModal(false);
  };

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }
  }, [user]);

  useEffect(() => { }, []);

  useEffect(() => {
    if (type === "Add" || type === "Edit") {
      dispatch(getZone());
    }
  }, [type]);

  useEffect(() => {
    let tempState = [];
    zoneLists.forEach((e) => {
      if (e?.active === "Y")
        tempState.push({ label: e?.zoneName, value: e?.zoneCode });
    });

    selected = { ...selected, state: tempState };
    setRegionOptions([...tempState]);
  }, [zoneLists]);

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchRegion(data))}
        getAllAPI={() => dispatch(getAllRegion())}
        onClick={() => {
          setCreateModal(!createModal);
          setType("Add");
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">States</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={list}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="regionCode" header="Region Code" sortable></Column>
            <Column field="regionName" header="Region Name" sortable></Column>
            <Column field="zone.zoneName" header="Zone" sortable></Column>
            <Column field="zone.country.countryName" header="Country" sortable></Column>
            <Column
              field="active"
              header="Status"
              body={(rowData) =>
                rowData?.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let zone = rowData.zone?.zoneCode;
                        dispatch(setSelected({ ...rowData, zone }));
                        setCreateModal(!createModal);
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        let zone = rowData.zone?.zoneCode;
                        dispatch(setSelected({ ...rowData, zone }));
                        setCreateModal(!createModal);
                        setType("Edit");
                      }}
                    />
                  )}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header="Region Details"
        visible={createModal}
        style={{ width: "40vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={type !== "Add" ? selected : RegionSchema}
          validationSchema={RegionValidationSchema}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            (
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Region Code"
                      errorMessage={touched.regionCode && errors.regionCode}
                    >
                      <Input
                        disabled={type !== "Add" ? true : false}
                        bsSize="sm"
                        type="text"
                        id="regionCode"
                        placeholder="Code"
                        value={values?.regionCode}
                        onChange={e=>{
                          if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                            setFieldValue('regionCode', e?.target?.value)
                          }
                        }}
                        onBlur={handleBlur}
                        invalid={
                          touched?.regionCode && Boolean(errors?.regionCode)
                        }
                        autoComplete="off"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Region Name"
                      errorMessage={touched.regionName && errors.regionName}
                    >
                      <Input
                        disabled={type === "View" ? true : false}
                        bsSize="sm"
                        type="text"
                        id="regionName"
                        name="regionName"
                        placeholder="Region Name"
                        value={values?.regionName}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        invalid={
                          touched.regionName && Boolean(errors.regionName)
                        }
                        autoComplete="off"
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Zone"
                      errorMessage={touched.zone && errors.zone}
                    >
                      <Select
                        isDisabled={type === "View" ? true : false}
                        inputId="zone"
                        name="zone"
                        isClearable={true}
                        options={regionOptions}
                        closeMenuOnSelect={true}
                        hideSelectedOptions={false}
                        onChange={(e) => setFieldValue("zone", e?.value)}
                        value={regionOptions.filter(
                          (v) => v.value === values?.zone
                        )}
                        className={cx({
                          abc: touched?.zone && Boolean(errors?.zone),
                        })}
                        classNamePrefix="react-select"
                        onBlur={handleBlur}
                        menuPosition={"fixed"}
                      />
                    </Field>
                  </Col>
                  <Col lg={6} md={6} sm={12}>
                    <Field
                      isRequired
                      label="Active"
                      errorMessage={touched.active && errors.active}
                    >
                      <FormGroup switch className="ms-2">
                        <Input
                          disabled={type === "View" ? true : false}
                          type="switch"
                          checked={values?.active === "Y" ? true : false}
                          onChange={(e) => {
                            setFieldValue(
                              "active",
                              e.target.checked ? "Y" : "N"
                            );
                          }}
                          id="active"
                          readOnly
                        />
                      </FormGroup>
                    </Field>
                  </Col>
                </Row>
                <div
                  className={`${type === "View" && "d-none"
                    } d-flex justify-content-end`}
                >
                  <Button type="submit" color="primary" className="me-1" size="sm">
                    Submit
                  </Button>
                  <Button
                    size="sm"
                    type="button"
                    color="danger"
                    onClick={() => setCreateModal(!createModal)}
                  >
                    Cancel
                  </Button>
                </div>
              </Form>
            )
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}
