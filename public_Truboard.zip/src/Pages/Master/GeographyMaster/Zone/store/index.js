import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../../../../App.config";
import { setLoader } from "../../../../../reducer/globalReducer";
import Swal from "sweetalert2";
export const getZone = createAsyncThunk(
  "zone/getZone",
  async (params, dispatch) => {
    try {
      const response = await axios.get(baseUrl() + "/getAllZones");
      return {
        list: response?.data?.data,
      };
    } catch (error) {
      throw new Error("Failed to fetch zone data.");
    }
  }
);

export const addZone = createAsyncThunk(
  "zone/addZone",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
      const res =await axios.post(baseUrl() + "/createZone", params);
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      dispatch(getZone());
      dispatch(setLoader(false));
      return true;
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      throw new Error("Failed to fetch Zone data.");
    }
  }
);
export const editZone = createAsyncThunk(
  "zone/editZone",
  async (params, { dispatch }) => {
    dispatch(setLoader(true));
    try {
     const res= await axios.put(baseUrl() + `/updateZone/${params?.id}`, params);
     Swal.fire({
      position: "top-end",
      icon: "success",
      title: `${res?.data?.message}`,
      showConfirmButton: false,
      toast: true,
      timer: 3000,
  });
      dispatch(getZone());
      dispatch(setLoader(false));
      
      return true;
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
    });
      throw new Error("Failed to fetch zone data.");
    }
  }
);

export const searchZone = createAsyncThunk("zone/search", async (params) => {
  try {
    const res = await axios.get(`/getZoneByZoneName/${params}`);
    return {
      list: res?.data?.data,
    };
  } catch (error) {
    console.log(error);
  }
});

export const zone = createSlice({
  name: "zone",
  initialState: {
    list: [],
    loader: false,
    error: "",
    selected: null,
  },
  reducers: {
    setSelected: (state, action) => {
      action.payload === null
        ? (state.selected = null)
        : (state.selected = {
            ...action.payload,
            country: action.payload.country?.countryCode,
          });
    },
    setLoder: (state, action) => {
      state.loader = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getZone.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.list;
      })
      .addCase(searchZone.fulfilled, (state, action) => {
        state.list = action.payload.list;
      });
    // .addCase(getZone.rejected, (state, action) => {
    //   state.loading = false;
    //   state.error = action.error.message;
    // });
  },
});

export const { setSelected, setLoder } = zone.actions;

export default zone.reducer;
