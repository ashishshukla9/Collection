import React, { useEffect, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Button,
  Form,
  Row,
  Col,
  FormGroup,
  Label,
  Input,
  FormFeedback,
  ButtonGroup,
} from "reactstrap";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dialog } from "primereact/dialog";
import { Formik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import {
  CountrySchema,
  CountryValidationSchema,
} from "../../../../Schema/GeographyMaster";
import {
  getAllCountry,
  addCountry,
  editCountry,
  setSelected,
  searchCountry,
} from "./store";
import { setLoader } from "../../../../reducer/globalReducer";
import SearchBarHeader from "../../../../components/Header/SearchBarHeader";
import Field from "../../../../components/Field";
import { NO_SPACE } from "../../../../utils/regex";

export default function Country({ access }) {
  const [createModal, setCreateModal] = useState(false);
  const [type, setType] = useState("");
  const [data, setData] = useState({});

  const user = useSelector((state) => state.user.data);
  const navigate = useNavigate();
  const { list, selected } = useSelector((state) => state.country);
  const dispatch = useDispatch();

  useEffect(() => {
    if (user?.masterRole[access] === null) {
      navigate("/dashboard");
    }

  }, [user]);

  const handleFormSubmit = (values) => {
    let resp = false;
    dispatch(setLoader(true))
    if (type === "Edit") {
      resp = dispatch(editCountry({ ...values, id: selected?.countryId }));
    } else {
      resp = dispatch(addCountry({ ...values }));
      
    }


    resp && setCreateModal(false);

  };

  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <SearchBarHeader
        serachAPI={(data) => dispatch(searchCountry(data))}
        getAllAPI={() => dispatch(getAllCountry())}
        onClick={() => {
          setCreateModal(!createModal);
          setType("Add");
        }}
        permission={user?.masterRole?.[access]}
      />
      <Card className="flex-grow-1 mb-1">
        <CardHeader className="p-2">Countries</CardHeader>
        <CardBody className="tableCardBody p-1">
          <DataTable
            value={list}
            paginator
            className="commonTable"
            rows={10}
            rowsPerPageOptions={[10, 20, 40, 80]}
            tableStyle={{ minWidth: "50rem" }}
            sortMode="multiple"
            removableSort
          >
            <Column field="countryCode" header="Country Code" sortable></Column>
            <Column field="countryName" header="Country Name" sortable></Column>
            <Column
              field="active"
              header="Status"
              body={(rowData) =>
                rowData.active === "Y" ? (
                  <b className="text-success">Active</b>
                ) : (
                  <b className="text-secondary">Inactive</b>
                )
              }
            ></Column>
            <Column
              header="Actions"
              body={(rowData) => (
                <ButtonGroup>
                  {["V", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-eye-fill text-primary"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setCreateModal(!createModal);
                        setType("View");
                      }}
                    />
                  )}
                  {user?.masterRole[access] === "F" && (
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                  )}
                  {["E", "F"].includes(user?.masterRole[access]) && (
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={() => {
                        setData({ ...rowData });
                        setCreateModal(!createModal);
                        dispatch(setSelected(rowData));
                        setType("Edit");
                      }}
                    />
                  )}
                </ButtonGroup>
              )}
            ></Column>
          </DataTable>
        </CardBody>
      </Card>
      <Dialog
        header="Country Details"
        visible={createModal}
        style={{ width: "40vw" }}
        onHide={() => setCreateModal(!createModal)}
      >
        <Formik
          initialValues={type !== "Add" ? data : CountrySchema}
          validationSchema={CountryValidationSchema}
          onSubmit={handleFormSubmit}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            setFieldValue,
            handleSubmit,
          }) => (
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Country Code"
                    errorMessage={touched.countryCode && errors.countryCode}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="countryCode"
                      placeholder="Code"
                      value={values.countryCode}
                      onChange={e => {
                        if (NO_SPACE.test(e?.target?.value) || e?.target?.value === "") {
                          setFieldValue('countryCode', e?.target?.value)
                        }
                      }}
                      onBlur={handleBlur}
                      invalid={
                        touched.countryCode && Boolean(errors.countryCode)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Country Name"
                    errorMessage={touched.countryName && errors.countryName}
                  >
                    <Input
                      bsSize="sm"
                      type="text"
                      id="countryName"
                      placeholder="Country Name"
                      value={values.countryName}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      invalid={
                        touched.countryName && Boolean(errors.countryName)
                      }
                      autoComplete="off"
                    />
                  </Field>
                </Col>
                <Col lg={6} md={6} sm={12}>
                  <Field
                    isRequired
                    label="Active"
                  >
                    <FormGroup switch>
                      <Input
                        disabled={type === "View"}
                        type="switch"
                        checked={values.active === "Y"}
                        onChange={(e) => {
                          setFieldValue(
                            "active",
                            e.target.checked ? "Y" : "N"
                          );
                        }}
                        id="active"
                        readOnly
                      />
                    </FormGroup>
                  </Field>
                </Col>
              </Row>
              <div
                className={`${type === "View" && "d-none"
                  } d-flex justify-content-end`}
              >
                <Button type="submit" color="primary" className="me-1" size="sm">
                  Submit
                </Button>
                <Button
                  size="sm"
                  type="button"
                  color="danger"
                  onClick={() => setCreateModal(!createModal)}
                >
                  Cancel
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </Dialog>
    </Container>
  );
}
