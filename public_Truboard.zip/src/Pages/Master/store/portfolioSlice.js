import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getPortfolio: builder.query({
      query: () => ({
        url: "/getAllPortfolio",
        method: "GET",
      }),
      providesTags: ["PORTFOLIO"],
    }),
    addPortfolio: builder.mutation({
      query: (values) => ({
        url: "/createPortfolio",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["PORTFOLIO"],
    }),
    updatePortfolio: builder.mutation({
      query: (values) => ({
        url: `/updatePortfolio/${values.portfolioId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["PORTFOLIO"],
    }),
  }),
});

export const {
  useGetPortfolioQuery,
  useAddPortfolioMutation,
  useUpdatePortfolioMutation,
} = extendedApiSlice;
