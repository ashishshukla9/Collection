import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAgency: builder.query({
      query: (values) => ({
        url: `/getAllAgency`,
        // url: "/getStateByRegion",

        method: "GET",
      }),

      providesTags: ["AGENCY"],
    }),
    addAgency: builder.mutation({
      query: (values) => ({
        url: "/createsAgencies",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["AGENCY"],
    }),
    updateCity: builder.mutation({
      query: (values) => ({
        url: `/updatesAgencies/${values.agencyId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["AGENCIES"],
    }),
  }),
});

export const {
  useGetAgencyQuery,
  useAddAgencyMutation,
  useUpdateAgencyMutation,
} = extendedApiSlice;
