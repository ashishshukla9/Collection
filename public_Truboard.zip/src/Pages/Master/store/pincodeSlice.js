import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getPincodeByCity: builder.query({
      query: ({ ids }) => ({
        url: `/getPincodeByCity/${ids && ids.length > 0 ? ids.join(",") : ""}/1/10`,
        method: "GET",
      }),

      providesTags: ["CITY"],
    }),
  }),
});

export const { useGetPincodeByCityQuery } = extendedApiSlice;
