import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import axios from "axios";
import { setLoader } from "../../../reducer/globalReducer";
const initialState = {
    data: []
}

export const getPortfolioData = createAsyncThunk(
    'portfolio/getPortfolioData',
    async (params,{dispatch}) => {
        try {
            dispatch(setLoader(true));
            const res = await axios.get('/getAllPortfolio')
            dispatch(setLoader(false));
            return {
                data: res?.data?.data
            }
        } catch (error) {
            dispatch(setLoader(false));
            console.log(error);
        }
    }
)

export const searchPortfolioData = createAsyncThunk(
    'portfolio/searchPortfolioData',
    async (val,{dispatch}) => {
       
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getPortfolioByPortfolioDescription/${val}`)
            dispatch(setLoader(false))
        
            return {
                data: res?.data?.data
            }
        } catch (error) {
            dispatch(setLoader(false))
        
            console.log(error);
        }
    }
)


const portfolioMasterSlice = createSlice({
    name: 'portfolioMasterSlice',
    initialState,
    extraReducers: (builder) => {
        builder.addCase(getPortfolioData.fulfilled, (state, action) => {
            state.data = action?.payload?.data
        })
        builder.addCase(searchPortfolioData.fulfilled, (state, action) => {
            state.data = action?.payload?.data
        })
    }
})

export default portfolioMasterSlice.reducer;