import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    
    getCity: builder.query({
      query: () => ({
        url: "/getAllCities/1/10",
        // url: "/getStateByRegion",

        method: "GET",
      }),

      providesTags: ["CITY"],
    }),
    getCityByState: builder.query({
      query: ({ ids }) => ({
        url: `/getCityByState/${ids && ids.length > 0 ? ids.join(",") : ""}/1/10`,
        method: "GET",
      }),

      providesTags: ["CITY"],
    }),
    addState: builder.mutation({
      query: (values) => ({
        url: "/createsStates",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["CITY"],
    }),
    updateCity: builder.mutation({
      query: (values) => ({
        url: `/updatesCities/${values.statesId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["CITIES"],
    }),
  }),
});

export const {
  useGetCityQuery,
  useGetCityByStateQuery,
  useAddCityMutation,
  useUpdateCityMutation,
} = extendedApiSlice;
