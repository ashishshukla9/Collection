import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getRole: builder.query({
      query: () => ({
        url: "/getAllRole",
        // url: "/getStateByRegion",

        method: "GET",
      }),

      providesTags: ["ROLE"],
    }),
    addRole: builder.mutation({
      query: (values) => ({
        url: "/createsRoles",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["ROLE"],
    }),
    updateRole: builder.mutation({
      query: (values) => ({
        url: `/updatesRoles/${values.roleId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["ROLES"],
    }),
  }),
});

export const { useGetRoleQuery, useAddRoleMutation, useUpdateRoleMutation } =
  extendedApiSlice;
