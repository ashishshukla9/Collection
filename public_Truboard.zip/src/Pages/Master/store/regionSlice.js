import { apiSlice } from "../../../features/api/apiSlice";

export const extendedApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getRegion: builder.query({
      query: () => ({
        url: "/getAllRegions",
        method: "GET",
      }),

      providesTags: ["REGIONS"],
    }),
    getRegionByZone: builder.query({
      query: ({ ids }) => ({
        url: `/getRegionByZone/${ids && ids.length > 0 ? ids.join(",") : ""}`,
        method: "GET",
      }),
      providesTags: ["REGIONS"],
    }),
    addRegion: builder.mutation({
      query: (values) => ({
        url: "/createRegions",
        body: values,
        method: "POST",
      }),
      invalidatesTags: ["REGIONS"],
    }),
    updateRegion: builder.mutation({
      query: (values) => ({
        url: `/updateRegions/${values.regionsId}`,
        body: values,
        method: "PUT",
      }),
      invalidatesTags: ["REGIONS"],
    }),
  }),
});

export const {
  useGetRegionQuery,
  useGetRegionByZoneQuery,
  useAddRegionMutation,
  useUpdateRegionMutation,
} = extendedApiSlice;
