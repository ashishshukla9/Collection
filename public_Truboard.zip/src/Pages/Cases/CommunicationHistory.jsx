import { memo } from "react";
import { AccordionBody, AccordionHeader, AccordionItem } from "reactstrap";
import styles from "./CaseProfile.module.scss";

const CommunicationHistory = (props) => {
  function formatDateTime(milliseconds) {
    if (!milliseconds) return null;
    var dateTime = new Date(milliseconds);
    var year = dateTime.getFullYear();
    var month = String(dateTime.getMonth() + 1).padStart(2, "0");
    var day = String(dateTime.getDate()).padStart(2, "0");
    var hours = String(dateTime.getHours()).padStart(2, "0");
    var minutes = String(dateTime.getMinutes()).padStart(2, "0");
    var seconds = String(dateTime.getSeconds()).padStart(2, "0");
    var formattedDateTime =
      day +
      "-" +
      month +
      "-" +
      year +
      " " +
      hours +
      ":" +
      minutes +
      ":" +
      seconds;
    return formattedDateTime;
  }
  return (
    <AccordionItem className="my-1">
      <AccordionHeader targetId={props?.data?.communicationHistoryId}>
        <div className="accordWidth d-flex justify-content-between">
          <div>{props?.data?.historyType}</div>
          <div>
            {/* Create  Date: {new Date(props?.data?.createdTime).toISOString().substring(0,10)} */}
            Create Date: {formatDateTime(props?.data?.createdTime)}
          </div>
        </div>
      </AccordionHeader>
      <AccordionBody accordionId={props?.data?.communicationHistoryId}>
        <p>
          Time:{" "}
          {new Date(props?.data?.createdTime).toLocaleTimeString("en-US", {
            hour12: true,
            hour: "2-digit",
            minute: "2-digit",
          })}
        </p>
        <p className={styles?.communicationMsg}>{props?.data?.msg}</p>
      </AccordionBody>
    </AccordionItem>
  );
};

export default memo(CommunicationHistory);
