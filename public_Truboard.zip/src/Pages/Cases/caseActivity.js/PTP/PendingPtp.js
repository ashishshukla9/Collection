import React, { useState } from "react";
import {
  Card,
  Col,
  Row,
  Table,
  Input,
  Button,
  FormFeedback,
  Form,
  FormGroup,
  Label,
  CardBody,
} from "reactstrap";
import { useFormik } from "formik";
import {
  pendingPTPSchema,
  validationSchema,
} from "../../../../Schema/Cases/PendingPTPSchema";
import Swal from "sweetalert2";
import axios from "axios";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import moment from "moment";
import { updateInProgressCase } from "../../store";
import AmountTable from "../Payment/AmountTable";

const PendingPtp = ({ cancelModal, isView, isUpdate, data, onAddSuccess, onEditSuccess }) => {
  const { lanId } = useParams();
  const [amountDisable, setAmountDisable] = useState(true);
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const user = useSelector((state) => state.user.data);
  const dispatch = useDispatch();

  const handleSubmit = (values) => {
    if (values.ptpType === "Charges") {
      if (values.sub_type.includes("Other charge")) {
        values["otherCharges"] = "Y";
      }
      if (values.sub_type.includes("DCP/LPP")) {
        values["dcpLpp"] = "Y";
      }
      if (values.sub_type.includes(" Cheque Bounce")) {
        values["chequeBounceCharges"] = "Y";
      }
    }
    let ptpMode = "";

    if (values.ptpType === "Outstanding" || values.ptpType === "Settlement") ptpMode = values.ptpMode;

    delete values.sub_type;

    values["totalOverdueAmount"] = caseProfile.totalOverdueAmount;
    values["pendingEmiAmount"] = caseProfile.pendingEmiAmount;
    values["charges"] =
      (Number(caseProfile["otherCharges"]) || 0) +
      (Number(
        caseProfile["dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty"]
      ) || 0) +
      (Number(caseProfile["chequeBounceCharges"]) || 0);
    values["settlementAmount"] = caseProfile.settlementAmount;
    values["emiAmount"] = caseProfile.emiAmount;
    values["loanAccountNumber"] = lanId;
    values["user"] = { userId: user.userId };
    values["status"] = "pending";

    axios
      .post("/addPtpDetails", { ...values, ptpMode })
      .then(({ data }) => {
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Records has been saved",
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        dispatch(updateInProgressCase({ userId: user?.userId, lanId, role: user?.role[0]?.roleCode, activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType }))
        onAddSuccess()
      })
      .catch((error) => {
        console.log(error);
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  const handleUpdate = (values) => {
    if (values.ptpType === "Charges") {
      if (values.sub_type.includes("Other charge")) {
        values["otherCharges"] = "Y";
      }
      if (values.sub_type.includes("DCP/LPP")) {
        values["dcpLpp"] = "Y";
      }
      if (values.sub_type.includes(" Cheque Bounce")) {
        values["chequeBounceCharges"] = "Y";
      }
    }
    let ptpMode = "";

    if (values.ptpType === "Outstanding" || values.ptpType === "Settlement") ptpMode = values.ptpMode;

    delete values.sub_type;

    values["totalOverdueAmount"] = caseProfile.totalOverdueAmount;
    values["pendingEmiAmount"] = caseProfile.pendingEmiAmount;
    values["charges"] =
      (Number(caseProfile["otherCharges"]) || 0) +
      (Number(
        caseProfile["dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty"]
      ) || 0) +
      (Number(caseProfile["chequeBounceCharges"]) || 0);
    values["settlementAmount"] = caseProfile.settlementAmount;
    values["emiAmount"] = caseProfile.emiAmount;
    values["loanAccountNumber"] = lanId;
    values["user"] = { userId: user.userId };
    values["status"] = "pending";

    axios
      .put(`/updatePtpDetails/${values.ptpId}`, { ...values, ptpMode })
      .then(({ data }) => {
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Records has been saved",
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
        dispatch(updateInProgressCase({ userId: user?.userId, lanId, role: user?.role[0]?.roleCode, activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType }))
        onEditSuccess()
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  };

  const formik = useFormik({
    initialValues: isView || isUpdate ? data : pendingPTPSchema,
    validationSchema: validationSchema,
    onSubmit: isUpdate ? handleUpdate : handleSubmit,
  });

  const button = [
    "Foreclosure",
    "Outstanding",
    "Charges",
    "Pending EMI",
    "Settlement",
    "Other",
    "EMI",
  ];

  const [visible, setVisible] = useState(false);

  useEffect(() => {
    switch (formik.values.ptpType) {
      case "Foreclosure":
        setAmountDisable(false);
        formik.setFieldValue("ptpAmount", caseProfile.ptpAmount);
        break;
      case "Outstanding":
        formik.setFieldValue("ptpAmount", caseProfile.ptpAmount);
        if (formik.values.ptpMode === "Full") {
          setAmountDisable(true);
        } else {
          setAmountDisable(false);
        }
        break;
      case "Charges":
        let amount = 0;
        setAmountDisable(true);
        formik.values?.sub_type.forEach((subType) => {
          if (subType === "Other charge") {
            amount += Number(caseProfile["otherCharges"]) || 0;
          } else if (subType === "DCP/LPP") {
            amount += Number(caseProfile["dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty"]) || 0;
          } else if (subType === "Cheque Bounce") {
            amount += Number(caseProfile["chequeBounceCharges"]) || 0;
          }
          
        });
        formik.setFieldValue("ptpAmount", amount.toFixed(2));
        break;
      case "Pending EMI":
        setAmountDisable(false);
        formik.setFieldValue("pendingEmiAmount", caseProfile.pendingEmiAmount);
        formik.setFieldValue("ptpAmount", caseProfile.pendingEmiAmount);
        break;
      case "Settlement":
        if (formik.values.ptpMode === "Full") {
          setAmountDisable(true);
        } else {
          setAmountDisable(false);
        }
        formik.setFieldValue("ptpAmount", caseProfile.settlementAmount);
        break;
      case "Other":
        setAmountDisable(false);
        // formik.setFieldValue("ptpAmount", 0);
        break;
      case "EMI":
        setAmountDisable(false);
        formik.setFieldValue("ptpAmount", caseProfile.emiAmount);
        break;
      default:
        formik.setFieldValue("ptpAmount", "");
    }
  }, [
    formik.values.ptpType,
    formik.values.sub_type,
    formik.values.ptpMode,
    caseProfile,
  ]);

  const onCheckboxBtnClick = (selected) => {
    const index = formik.values.sub_type.indexOf(selected);
    if (index < 0) {
      formik.values.sub_type.push(selected);
    } else {
      formik.values.sub_type.splice(index, 1);
    }
    formik.setFieldValue("sub_type", [...formik.values.sub_type]);
  };
  const currentDate = new Date();
  currentDate.setDate(currentDate.getDate() + 1);

  return (
    <Card className="m-0 p-0">
      <CardBody>
        <AmountTable />

        <Form onSubmit={formik.handleSubmit}>
          <FormGroup row className="align-items-center">
            <Label sm={3} for="ptpType">
              <span className="text-danger">*</span>
              PTP Type
            </Label>
            <Col lg={9} md={9} sm={12}>
              <div>
                {button.map((name, i) => {
                  return (
                    <Button
                      key={`ptpType-${i}`}
                      color="primary"
                      outline
                      onClick={() => {
                        if (!isView) {
                          formik.setFieldValue("ptpType", name);
                          if (name !== "Outstanding" || name !== "Settlement")
                            formik.setFieldValue("ptpMode", "Full");
                        }
                      }}
                      active={formik.values.ptpType === name}
                      size="sm"
                      className="m-1"
                    >
                      {name}
                    </Button>
                  );
                })}
              </div>
            </Col>
          </FormGroup>
          {(formik.values.ptpType === "Outstanding" || formik.values.ptpType === "Settlement") && (
            <FormGroup row className="align-items-center">
              <Label sm={3}>
                <span className="text-danger">*</span>
                PTP Mode
              </Label>
              <Col lg={9} md={9} sm={12}>
                <div>
                  <Button
                    size="sm"
                    color="primary"
                    outline
                    onClick={() => {
                      if (!isView) formik.setFieldValue("ptpMode", "Full");
                    }}
                    active={formik.values.ptpMode === "Full"}
                  >
                    Full
                  </Button>
                  <Button
                    color="primary"
                    size="sm"
                    outline
                    onClick={() => {
                      if (!isView) formik.setFieldValue("ptpMode", "Partial");
                    }}
                    active={formik.values.ptpMode === "Partial"}
                    className="ms-2"
                  >
                    Partial
                  </Button>
                </div>
              </Col>
            </FormGroup>
          )}
          {formik.values.ptpType === "Charges" && (
            <FormGroup row className="align-items-center">
              <Label sm={3}>
                <span className="text-danger">*</span>
                Sub Type
              </Label>
              <Col lg={9} md={9} sm={12}>
                <div>
                  <Button
                    size="sm"
                    color="primary"
                    outline
                    type="button"
                    className="me-1"
                    onClick={() => {
                      if (!isView)
                        onCheckboxBtnClick(
                          "Other charge",
                          formik.values.sub_type
                        );
                    }}
                    active={formik.values.sub_type?.includes("Other charge")}
                  >
                    Other charge
                  </Button>
                  <Button
                    size="sm"
                    type="button"
                    color="primary"
                    className="me-1"
                    outline
                    onClick={() => {
                      if (!isView)
                        onCheckboxBtnClick("DCP/LPP", formik.values.sub_type);
                    }}
                    active={formik.values.sub_type?.includes("DCP/LPP")}
                  >
                    DCP/LPP
                  </Button>
                  <Button
                    size="sm"
                    type="button"
                    color="primary"
                    className="me-1"
                    outline
                    onClick={() => {
                      if (!isView)
                        onCheckboxBtnClick(
                          "Cheque Bounce",
                          formik.values.sub_type
                        );
                    }}
                    active={formik.values.sub_type?.includes("Cheque Bounce")}
                  >
                    Cheque Bounce
                  </Button>
                </div>
                {formik.errors.sub_type && (
                  <FormFeedback style={{ display: "block" }}>
                    {formik.errors.sub_type}
                  </FormFeedback>
                )}
              </Col>
            </FormGroup>
          )}
          <FormGroup row className="align-items-center">
            <Label sm={3} for="ptpDate">
              <span className="text-danger">*</span>
              PTP Date
            </Label>
            <Col sm={9}>
              <Input
                bsSize="sm"
                type="date"
                id="ptpDate"
                name="ptpDate"
                min={moment().format("YYYY-MM-DD")}
                value={formik.values.ptpDate}
                onChange={formik.handleChange}
                invalid={
                  formik.touched.ptpDate && Boolean(formik.errors.ptpDate)
                }
                disabled={isView}
              />
              <FormFeedback>
                {formik.touched.ptpDate && formik.errors.ptpDate}
              </FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row className="align-items-center">
            <Label sm={3} for="ptpTime">
              <span className="text-danger">*</span>
              PTP Time
            </Label>
            <Col sm={9}>
              <Input
                bsSize="sm"
                type="time"
                id="ptpTime"
                name="ptpTime"
                min={moment().format("YYYY-MM-DD")}
                value={formik.values.ptpTime}
                onChange={formik.handleChange}
                invalid={
                  formik.touched.ptpTime && Boolean(formik.errors.ptpTime)
                }
                disabled={isView}
              />
              <FormFeedback>
                {formik.touched.ptpTime && formik.errors.ptpTime}
              </FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row className="align-items-center">
            <Label sm={3} for="followUpDate">
              <span className="text-danger">*</span>
              Follow-up
            </Label>
            <Col sm={9}>
              <Input
                bsSize="sm"
                type="datetime-local"
                id="followUpDate"
                name="followUpDate"
                min={moment(new Date(formik?.values?.ptpDate)).format("YYYY-MM-DD HH:MM")}
                value={formik.values.followUpDate}
                onChange={formik.handleChange}
                invalid={
                  formik.touched.followUpDate &&
                  Boolean(formik.errors.followUpDate)
                }
                disabled={isView}
              />
              <FormFeedback>
                {formik.touched.followUpDate && formik.errors.followUpDate}
              </FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row className="align-items-center">
            <Label sm={3} for="ptpAmount">
              <span className="text-danger">*</span>
              Amount
            </Label>
            <Col sm={9}>
              <Input
                bsSize="sm"
                id="ptpAmount"
                type="number"
                defaultValue={formik.values.ptpAmount}
                value={formik.values.ptpAmount}
                onChange={(e) => {
                  if (e.target.value.length < 19) {
                    formik.setFieldValue("ptpAmount", e.target.value);
                  }
                }}
                onBlur={formik.handleBlur}
                invalid={
                  formik.touched.ptpAmount && Boolean(formik.errors.ptpAmount)
                }
                disabled={isView || amountDisable}
              ></Input>
              <FormFeedback>
                {formik.touched.ptpAmount && formik.errors.ptpAmount}
              </FormFeedback>
            </Col>
          </FormGroup>
          <FormGroup row className="align-items-center">
            <Label sm={3} for="remark">
              <span className="text-danger">*</span>
              Remark
            </Label>
            <Col sm={9}>
              <Input
                bsSize="sm"
                id="remark"
                name="remark"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                value={formik.values.remark}
                type="textarea"
                disabled={isView}
                invalid={formik.touched.remark && Boolean(formik.errors.remark)}
              ></Input>
              <FormFeedback>
                {formik.touched.remark && formik.errors.remark}
              </FormFeedback>
            </Col>
          </FormGroup>
          {isView || (
            <div className="d-flex justify-content-end">
              <Button type="submit" className="me-1" color="primary" size="sm">
                Submit
              </Button>
              <Button
                size="sm"
                color="danger"
                type="button"
                onClick={() => cancelModal(false)}
              >
                Cancel
              </Button>
            </div>
          )}
        </Form>
      </CardBody>
    </Card>
  );
};

export default PendingPtp;
