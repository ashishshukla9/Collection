import axios from "axios";
import React, { useRef } from "react";
import { Dialog } from "primereact/dialog";
import { memo, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { Button, Card, Col, Row, Table } from "reactstrap";
import Swal from "sweetalert2";
import { getActivityHistory, getCommunicationHistory } from "../../store";
import { setLoader } from "../../../../reducer/globalReducer";
import { useReactToPrint } from "react-to-print";

const PaymentInfoData = (props) => {
  const [getData, setGetData] = useState();
  const [openpaymentPop, setOpenPaymentPop] = useState(false);
  const componentRef = useRef();
  const { lanId } = useParams();

  const user = useSelector((state) => state.user.data);
  const caseProfile = useSelector((state) => state.cases.caseProfile);

  const dispatch = useDispatch();

  const handleSend = async () => {
    const payload = {
      lenderId: getData?.lenderId,
      lenderName: getData?.lenderName,
      bankAccountNumber: getData?.bankAccountNumber,
      bankIfsc: getData?.bankIfsc,
      bankUpiAddress: getData?.bankUpiAddress,
      loanAccountNumber: lanId,
      smsFlag: true,
      user: {
        userId: user?.userId,
      },
    };
    if (props?.isContactCenter) {
      props?.onSuccess("addPaymentInfo", payload);
    } else {
      try {
        dispatch(setLoader(true));
        const res = await axios.post("addPaymentInfo", payload);
        dispatch(setLoader(false));

        if (res?.data?.message === "Success") {
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: `Payment information send successfully`,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
          setOpenPaymentPop(!openpaymentPop);
          if (props?.isContactCenter) {
            props?.onSuccess();
          } else {
            dispatch(getActivityHistory(lanId));
            dispatch(getCommunicationHistory(lanId));
          }
        }
      } catch (error) {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    }
  };
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  useEffect(() => {
    axios
      .get(`/getPaymentInfoByLAN/${lanId}`)
      .then(({ data }) => {
        if (data.msgKey !== "Failure") {
          setGetData(data.data);
        }
      })
      .catch((error) => {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      });
  }, []);
  return (
    <>
      {getData ? (
        <>
          <div
            className="border border-secondary-subtle rounded overflow-auto"
            ref={componentRef}
          >
            <Table
              size="sm"
              borderless
              className="table table-hover table-striped"
              responsive

              // style={{ padding: "0px !important" }}
            >
              <thead className="table-light text-center">
                <tr>
                  <th colSpan={2} className="text-center">
                    Details
                  </th>
                  {/* <th className="fw-normal">TBL563338211106</th> */}
                </tr>
              </thead>

              <tbody className="text-center">
                <tr>
                  <td>Lender ID</td>
                  {getData.lenderId?.length > 0 ? (
                    <td className="w-50">{getData.lenderId}</td>
                  ) : (
                    <td className="w-50">{" - "}</td>
                  )}
                </tr>
                <tr>
                  <td>Lender Name</td>
                  {getData.lenderName?.length > 0 ? (
                    <td className="w-50">{getData.lenderName}</td>
                  ) : (
                    <td className="w-50">{" - "}</td>
                  )}
                </tr>
                <tr>
                  <td>Bank Account Number</td>
                  {getData.bankAccountNumber?.length > 0 ? (
                    <td className="w-50">{getData.bankAccountNumber}</td>
                  ) : (
                    <td className="w-50">{" - "}</td>
                  )}
                </tr>
                <tr>
                  <td>Bank IFSC</td>
                  {getData.bankIfsc?.length > 0 ? (
                    <td className="w-50">{getData.bankIfsc}</td>
                  ) : (
                    <td className="w-50">{" - "}</td>
                  )}
                </tr>
                <tr>
                  <td>Bank UPI</td>
                  {getData.bankUpiAddress?.length > 0 ? (
                    <td className="w-50">{getData.bankUpiAddress}</td>
                  ) : (
                    <td className="w-50">{" - "}</td>
                  )}
                </tr>
                <tr>
                  <td>Bank repayment link</td>
                  {getData.bankRepaymentLink?.length > 0 ? (
                    <td className="w-50">{getData?.bankRepaymentLink}</td>
                  ) : (
                    <td className="w-50">{" - "}</td>
                  )}
                </tr>
              </tbody>
            </Table>
          </div>
          <Row className="my-3 text-sm text-md text-break text-center">
            {/* <Button  color="success">Send Repayment Information</Button> */}
            <Col>
              <Button
                size="sm"
                color="primary"
                style={{ cursor: "pointer" }}
                onClick={() => handleSend()}
                disabled={caseProfile?.forCloserRequestStatus === "approved"}
              >
                Send Payment Information
              </Button>
            </Col>
          </Row>
          {/* <Row className="my-3 text-sm text-md text-break text-center">

                    <Col>
                            <Button
                                size="sm"
                                color="primary"
                                style={{ cursor: "pointer" }}
                                onClick={handlePrint}
                                // disabled={caseProfile?.forCloserRequestStatus === "approved"}
                            >
                                Print Recipt
                            </Button>
                        </Col>
                        </Row> */}
        </>
      ) : (
        <p className="h2">No Details Found</p>
      )}
      <Dialog
        header="SMS has been sent!!"
        visible={openpaymentPop}
        style={{ minWidth: "500px" }}
        onHide={() => setOpenPaymentPop(false)}
      >
        <Card className="p-2 bg-light">
          <Row>
            <Col>Dear Customer,</Col>{" "}
          </Row>
          <Row>
            <Col className="mt-2">
              Please find the below bank details for payment:{" "}
            </Col>
          </Row>
          <Row>
            <Col>Lender Name : {getData?.lenderName}</Col>
          </Row>
          <Row>
            <Col>Bank A/C No.: {getData?.bankAccountNumber}</Col>
          </Row>
          <Row>
            <Col>IFSC Code: {getData?.bankIfsc}</Col>
          </Row>
          <Row>
            <Col>Bank UPI: {getData?.bankUpiAddress}</Col>
          </Row>
        </Card>
      </Dialog>
    </>
  );
};

export default memo(PaymentInfoData);
