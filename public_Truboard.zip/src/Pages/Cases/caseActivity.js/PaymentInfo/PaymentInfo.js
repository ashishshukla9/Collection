import React from "react";
import { Dialog } from "primereact/dialog";
import PaymentInfoData from "./PaymentInfoData";
// import { Button } from 'primereact/button';

const PaymentInfo = (props) => {
  const { repaymentInfo, setRepaymentInfo } = props;

  return (
    <Dialog
      header="Payment info"
      visible={repaymentInfo}
      style={{ minWidth: "50vw" }}
      onHide={() => setRepaymentInfo(false)}
    >
      <PaymentInfoData />
    </Dialog>
  );
};

export default PaymentInfo;
