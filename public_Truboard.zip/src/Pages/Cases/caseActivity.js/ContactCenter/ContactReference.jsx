import { Fragment, memo, useEffect, useState } from "react"
import { Accordion, AccordionBody, AccordionItem } from "reactstrap"
import ContactCenterAccordionHeader from "./ContactCenterAccordionHeader"
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import styles from './ContactCenter.module.scss'
import ReferenceForm from "./ReferenceForm";
import { Dialog } from "primereact/dialog";
import { setLoader } from "../../../../reducer/globalReducer";
const ContactReference = (props) => {
    const [openRefrance, setOpenRefrance] = useState("0");
    const [referenceData,setReferenceData] = useState([])
    const [modal,setModal]=useState(false)
    const caseProfile = useSelector((state) => state.cases.caseProfile);
    const dispatch=useDispatch()
    const toggleRef = (id) => {
        setOpenRefrance(openRefrance === id ? '' : id)
    };
    const getReference=async()=>{
        try {
            dispatch(setLoader(true))
            const res=await axios.get(`/getContactCentreReferenceBycontactCentreId/${props?.contactCenterId}`)
            dispatch(setLoader(false))
            let data=[]
            const keys=Object.keys(caseProfile)
            const emailKeys = keys.filter(a=>a.includes('referenceEmail'))
            const mobileKeys = keys.filter(a=>a.includes('referenceMobile'))
            const addressKeys = keys.filter(a=>a.includes('referenceAddress') && !a?.endsWith('GeoCoordinates'))
            const nameKeys = keys.filter(a=>a.includes('referenceName'))
            nameKeys?.map((a,i)=>{
                data?.push({
                    id: data?.length + 1,
                    name: caseProfile[a]
                })
            })
            emailKeys?.map((a,i)=>{
                data[i] = {
                    ...data[i],
                    email: caseProfile[a]
                }
            })
            mobileKeys?.map((a,i)=>{
                data[i] = {
                    ...data[i],
                    mobile: caseProfile[a]
                }
            })
            addressKeys?.map((a,i)=>{
                data[i] = {
                    ...data[i],
                    address: caseProfile[a]
                }
            })
            if(res?.data?.msgKey === "Success"){
                res?.data?.data?.map(a=>{
                    data?.push({
                        id: data?.length + 1,
                        name: a?.refrenceName,
                        email: a?.referenceEmail,
                        mobile: a?.referenceMobile,
                        address: a?.referenceAddress
                    })
                })
            }
            setReferenceData(data)
        } catch (error) {
            dispatch(setLoader(false))
        }
    }
    const onSuccess=()=>{
        props?.onSuccess()
        setModal(false)
        getReference()
    }
    useEffect(()=>{
        if (props?.contactCenterId) {
            getReference()
        }
    },[props?.contactCenterId, caseProfile])
    return (
        <Fragment>
            <Accordion open={openRefrance} toggle={toggleRef}>
                <AccordionItem>
                    <ContactCenterAccordionHeader
                        targetId="1"
                        header="Reference"
                        btnVisible
                        onClick={() => setModal(true)}
                        disabled={caseProfile?.forCloserRequestStatus === "approved"}
                    />
                    <AccordionBody accordionId="1">
                        <div className={styles?.referenceContainer}>
                            {referenceData?.map(a=>(
                                <div key={a?.id} className={styles?.referenceRow}>
                                    <p className={styles?.key}>Name</p>
                                    <p>{a?.name}</p>
                                    <p className={styles?.key}>Email</p>
                                    <p>{a?.email}</p>
                                    <p className={styles?.key}>Mobile</p>
                                    <p>{a?.mobile || '-'}</p>
                                    <p className={styles?.key}>Address</p>
                                    <p>{a?.address || '-'}</p>
                                </div>
                            ))}
                        </div>
                    </AccordionBody>
                </AccordionItem>
            </Accordion>
            {modal &&
                <Dialog
                    header="Add Reference"
                    visible={modal}
                    onHide={() => setModal(false)}
                    style={{ width: '500px' }}
                >
                    <ReferenceForm
                        handleClose={() => setModal(false)}
                        contactCenter={props?.contactCenterId}
                        onSuccess={onSuccess}
                    />
                </Dialog>
            }
        </Fragment>
    )
}
export default memo(ContactReference)