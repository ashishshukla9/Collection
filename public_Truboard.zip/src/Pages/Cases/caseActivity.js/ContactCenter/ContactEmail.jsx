import { Fragment, memo, useEffect, useState } from "react"
import { Accordion, AccordionBody, AccordionItem } from "reactstrap"
import ContactCenterAccordionHeader from "./ContactCenterAccordionHeader"
import styles from './ContactCenter.module.scss'
import { useDispatch, useSelector } from "react-redux"
import { BsEye, BsEyeSlash } from "react-icons/bs"
import axios from "axios"
import EmailForm from "./EmailForm"
import { Dialog } from "primereact/dialog"
import { setLoader } from "../../../../reducer/globalReducer"

const ContactEmail = (props) => {  
    const [email, setEmail] = useState([])
    const [open, setOpen] = useState("1");
    const [addEmailModal, setAddEmailModal] = useState(false)

    const caseProfile = useSelector((state) => state.cases.caseProfile);

    const dispatch=useDispatch()
    const onEyeClick = (i) => {
        const duplicate = [...email]
        duplicate[i] = { ...duplicate[i], visible: !duplicate[i]?.visible }
        setEmail(duplicate)
    }

    const toggle = (id) => {
        setOpen(open === id ? '' : id)
    };

    const getEmail = async () => {
        try {
            dispatch(setLoader(true))
            const res = await axios.get(`/getContactCentreEmailBycontactCentreId/${props?.contactCenterId}`)
            dispatch(setLoader(false))

            const keys = Object.keys(caseProfile)
            const data = []
            if (keys?.length) {
                data.push({
                    id: 1,
                    name: 'Email',
                    value: caseProfile?.email,
                    visible: false
                })
            }

            if (res?.data?.data?.length) {
                res?.data?.data?.map(a => {
                    data.push({
                        id: data?.length + 1,
                        name: 'Email',
                        value: a?.emailAddress,
                        visible: false
                    })
                })
            }
            setEmail(data)
        } catch (error) {
            dispatch(setLoader(false))

        }
    }

    const onSuccess = () => {
        props?.onSuccess()
        setAddEmailModal(false)
        getEmail()
    }

    useEffect(() => {
        if (props?.contactCenterId) {
            getEmail()
        }
    }, [props?.contactCenterId, caseProfile])

    return (
        <Fragment>
            <Accordion open={open} toggle={toggle}>
                <AccordionItem>
                    <ContactCenterAccordionHeader
                        targetId="1"
                        header="Email"
                        btnVisible
                        onClick={() => setAddEmailModal(true)}
                        disabled={caseProfile?.forCloserRequestStatus === "approved"}
                    />
                    <AccordionBody accordionId="1" >
                        <div className={styles?.emailContainer} >
                            {email?.map((a,i) => (
                                <div className={styles?.emailRow} key={a}>
                                    <p className={styles?.key}>Email</p>
                                    <div className={styles?.emailBox}>
                                        <p className={styles?.email} style={{overflow:"hidden"}}>
                                            {a?.visible ? a?.value : `********${a.value?.slice(-2)}`}
                                        </p>
                                        {a?.visible ?
                                            <BsEye
                                                className={styles?.eyeIcon}
                                                onClick={() => onEyeClick(i)}
                                            /> :
                                            <BsEyeSlash
                                                className={styles?.eyeIcon}
                                                onClick={() => onEyeClick(i)}
                                            />
                                        }
                                    </div>
                                </div>
                            ))}
                        </div>
                    </AccordionBody>
                </AccordionItem>
            </Accordion>

            {addEmailModal &&
                <Dialog
                    header="Add Email"
                    visible={addEmailModal}
                    onHide={() => setAddEmailModal(false)}
                    style={{ width: '500px' }}
                >
                    <EmailForm
                        handleClose={() => setAddEmailModal(false)}
                        contactCentre={props?.contactCenterId}
                        onSuccess={onSuccess}
                    />
                </Dialog>
            }
        </Fragment>
    )
}

export default memo(ContactEmail)