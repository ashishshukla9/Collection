import { Formik } from "formik";
import { memo, useMemo } from "react";
import { Button, Form, Input } from "reactstrap";
import Field from "../../../../components/Field";
import Select from "react-select";
import * as yup from "yup";
import classNames from "classnames";
import axios from "axios";
import Swal from "sweetalert2";
import { setLoader } from "../../../../reducer/globalReducer";
import { useDispatch } from "react-redux";
const AddressForm = (props) => {
  const dispatch = useDispatch();
  const addressOptions = useMemo(
    () => [
      { label: "Home Secondary Address", value: "Home Secondary Address" },
      { label: "Office Secondary Address", value: "Office Secondary Address" },
    ],
    []
  );
  const validationSchema = yup.object({
    address: yup
      .string()
      .required("Address is Required")
      .max(255, "Address cannot exceed 255 characters"), // Added max length validation for address

    addressType: yup.string().required("Address Type is Required"),
  });
  const handleSubmit = async (values) => {
    try {
      const payload = {
        address: values?.address,
        addressType: values?.addressType,
        contactCentre: props?.contactCenter,
      };
      // console.log(payload, "all payload");
      dispatch(setLoader(true));
      const res = await axios.post("/addContactCentreAddress", payload);
      dispatch(setLoader(false));
      props?.onSuccess();
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: `${res?.data?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  return (
    <Formik
      initialValues={{
        address: "",
        addressType: "",
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({
        values,
        errors,
        touched,
        handleSubmit,
        onSubmit,
        setFieldValue,
        handleBlur,
        handleChange,
        isSubmitting,
      }) => {
        return (
          <Form onSubmit={handleSubmit} autoComplete="off">
            <Field
              isRequired
              label="Address"
              errorMessage={touched?.address && errors?.address}
            >
              <Input
                type="textarea"
                bsSize="sm"
                id="address"
                placeholder="Enter Address"
                value={values?.address}
                onChange={handleChange}
                invalid={touched?.address && Boolean(errors?.address)}
                onBlur={handleBlur}
              />
            </Field>
            <Field
              isRequired
              label="Address Type"
              errorMessage={touched?.addressType && errors?.addressType}
            >
              <Select
                id="addressType"
                inputId="addressType"
                placeholder="Select an Option"
                options={addressOptions}
                closeMenuOnSelect={true}
                hideSelectedOptions={false}
                onChange={(e) => setFieldValue("addressType", e?.value)}
                value={addressOptions?.filter(
                  (e) => e.value === values.addressType
                )}
                className={classNames({
                  abc: touched.addressType && Boolean(errors.addressType),
                })}
                onBlur={handleBlur}
                menuPosition="fixed"
                classNamePrefix="react-select"
              />
            </Field>
            <div className="d-flex justify-content-end gap-2">
              <Button type="submit" color="primary" size="sm">
                Save
              </Button>
              <Button
                type="button"
                size="sm"
                onClick={() => props?.handleClose()}
              >
                Cancel
              </Button>
            </div>
          </Form>
        );
      }}
    </Formik>
  );
};
export default memo(AddressForm);