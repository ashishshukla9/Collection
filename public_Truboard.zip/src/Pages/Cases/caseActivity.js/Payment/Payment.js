import React from "react";
import {
  CardBody,
  Card
} from "reactstrap";
import AmountTable from "./AmountTable";
import PaymentForm from "./PaymentForm";
const Payment = ({ onSuccess, paymentCategory, cancelModal, data, isCancelHidden, isContactCenter, ptpId, selectedData, geoData }) => {
  return (
    <Card>
      <CardBody>
        <AmountTable />
        <PaymentForm 
        geoData={geoData}
          onSuccess={onSuccess}
          paymentCategory={paymentCategory}
          onClose={()=>cancelModal(false)}
          data={data}
          isCancelHidden={isCancelHidden}
          isContactCenter={isContactCenter}
          ptpId={ptpId}
          selectedData={selectedData}
        />
      </CardBody>
    </Card>
  );
};
export default Payment;