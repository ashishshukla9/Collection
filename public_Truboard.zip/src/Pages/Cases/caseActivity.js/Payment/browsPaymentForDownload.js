import { CardBody, Card, Button } from "reactstrap";
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import styles from './Payment.module.scss'
import { setLoader } from "../../../../reducer/globalReducer";
import { useDispatch } from "react-redux";
import { PDFDownloadLink } from "@react-pdf/renderer";
import PaymentReport from "./PaymentReport";

const DownloadPaymntRecipt = (props) => {
  const [data, setData] = useState({});

  const dateOfPayment = useMemo(() => {
    if (data?.dateOfPayment) {
      return data?.dateOfPayment?.split('-')?.reverse()?.join('-')
    } else {
      return '-'
    }
  }, [data?.dateOfPayment])

  const { id } = useParams();

  const dispatch = useDispatch()

  useEffect(() => {
    const getAPI = async () => {
      try {
        dispatch(setLoader(true))
        await axios.get(`/getPaymentRecieptDetails/${id}`).then((res) => {
          setData(res?.data?.data);
        });
        dispatch(setLoader(false))
      } catch (error) {
        dispatch(setLoader(false))
      }
    };

    getAPI();
  }, [id]);

  return (
    <>
      {/* <Container> */}
      <Card className={styles?.receiptContainer}>

        <CardBody>
          <p className={styles?.receiptHeader}>Payment Receipt</p>

          <div className={styles.detailsGrid}>
            <div>
              <div className={styles?.detailsCol}>
                <b>Lender Name:</b>
                <p>{data?.lenderName || "-"}</p>
              </div>
              <div className={styles?.detailsCol}>
                <b>Customer Name:</b>
                <p>{data?.customerName || "-"}</p>
              </div>
              <div className={styles?.detailsCol}>
                <b>Received Sum of Rupees:</b>
                <p>{`${data?.amountInWords} Rupees Only` || "-"}</p>
              </div>
              <div className={styles?.detailsCol}>
                <b>Payment Type:</b>
                <p>{data?.paymentType || "-"}</p>
              </div>
              <div className={styles?.detailsCol}>
                <b>Loan Account Number:</b>
                <p>{data?.lan || "-"}</p>
              </div>
            </div>

            <div>
              <div className={styles?.detailsCol}>
                <b>Receipt Number:</b>
                <p>{data?.receiptNo || "-"}</p>
              </div>
              <div className={styles?.detailsCol}>
                <b>Date of Payment:</b>
                <p>{dateOfPayment || "-"}</p>
              </div>
              <div className={styles?.detailsCol}>
                <b>Amount:</b>
                <p>{`${data?.amount ? `₹ ${data?.amount.toLocaleString('en-IN')}` : '-'}` || "-"}</p>
              </div>
              {/* <div className={styles?.detailsCol}>
                <b>Loan Account Number:</b>
                <p>{data?.lan || "-"}</p>
              </div> */}
              <div className={`${styles?.detailsCol} ${styles?.secondCol}`}>
                <b>Payment Mode:</b>
                <p>{data?.modeOfPayment || "-"}</p>
              </div>

              {data?.modeOfPayment === "Cheque" &&
                <div className={`${styles?.detailsCol} ${styles?.secondCol}`}>
                  <b>Cheque Number:</b>
                  <p>{data?.chequeNumber || "-"}</p>
                </div>
              }
              {data?.modeOfPayment === "Digital" &&
                <>
                  <div className={`${styles?.detailsCol} ${styles?.secondCol}`}>
                    <b>Digital Payment Mode:</b>
                    <p>{data?.digitalPaymentMode || "-"}</p>
                  </div>
                  <div className={`${styles?.detailsCol} ${styles?.secondCol}`}>
                    <b>Reference Number:</b>
                    <p>{data?.referenceNumber || "-"}</p>
                  </div>
                </>
              }
              {data?.modeOfPayment === "Demand Draft" &&
                <div className={`${styles?.detailsCol} ${styles?.secondCol}`}>
                  <b>Demand Draft Number:</b>
                  <p>{data?.demandDraftNumber || "-"}</p>
                </div>
              }
            </div>
          </div>
          <div className={styles.detailsGrid}>
            <div className={styles?.table1}>
              <div className={styles?.tableHeader}>
                <p>Nature Of Receipt</p>
                <p>Amount in Rupees</p>
              </div>
              <div className={styles?.tableValue}>
                <p>{data?.paymentType}</p>
                <p>{`${data?.amount ? `₹ ${data?.amount.toLocaleString('en-IN')}` : '-'}`}</p>
              </div>
            </div>

            <div className={styles?.table2}>
              <div className={styles?.table2Row}>
                <p className={styles?.key}>Reference Number</p>
                <p className={styles?.value}>{data?.referenceNumber || "-"}</p>
              </div>
              <div className={styles?.table2Row}>
                <p className={styles?.key}>Lender Name</p>
                <p className={styles?.value}>{data?.lenderName || "-"}</p>
              </div>
              <div className={styles?.table2Row}>
                <p className={styles?.key}>Branch</p>
                <p className={styles?.value}>{data?.referenceNumber || "-"}</p>
              </div>
              <div className={styles?.table2Row}>
                <p className={styles?.key}>Amount</p>
                <p className={styles?.value}>{`${data?.amount ? `₹ ${data?.amount.toLocaleString('en-IN')}` : '-'}`}</p>
              </div>
            </div>
          </div>

          <div className={styles.detailsGrid2}>
            <div className={styles?.detailsCol}>
              <b>Agency Name:</b>
              <p>Truboard Servicing Private Limited</p>
            </div>
            <div className={styles?.detailsCol}>
              <b>Agency Code:</b>
              {/* <p>{data?.agencyCode || "-"}</p> */}
              <p>00123</p>
            </div>
            <div className={styles?.detailsCol}>
              <b>Customer Number:</b>
              <p>{data?.mobileNumber || "-"}</p>
            </div>

            <div className={styles?.detailsCol}>
              <b>Payment Collect By:</b>
              <p>{data?.collectorName || "-"}</p>
            </div>
            {/* <div className={`${styles?.detailsCol} ${styles?.thirdCol}`}>
              <b>Customer PAN:</b>
              <p>{data?.customerPan || "-"}</p>
            </div> */}
          </div>
          <p className={styles?.note}>This is a System Generated document and it does not require a signature</p>


        </CardBody>

      </Card>
      <br />
      <PDFDownloadLink
        document={<PaymentReport paymentId={id} />}
        fileName="paymentReceipt"
        style={{ marginLeft: "80%", paddingTop: "20px" }}
      >
        {({ loading }) =>
          loading ? (
            <button>text</button>
          ) : (
            <Button style={{ backgroundColor: 'orange' }} className={styles?.downloadBtn} size="sm">Download Receipt</Button>
          )
        }
      </PDFDownloadLink>
      {/* </Container> */}
    </>
  );
};

export default DownloadPaymntRecipt;
