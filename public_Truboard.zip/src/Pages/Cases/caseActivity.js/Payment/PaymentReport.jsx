import { Document, Page, StyleSheet, Text, View } from "@react-pdf/renderer";
import axios from "axios";
import { memo, useEffect, useState } from "react";
import styles from "./Payment.module.scss";

const PaymentReport = (props) => {
  const [data, setData] = useState({});

  const fractalsPageSize = {
    width: 595,
    height: 842,
  };

  // Styles
  const Styles = StyleSheet.create({
    receiptContainer: {
      width: "90%",
      margin: "10px auto",
      border: "1px solid gray",
      padding: "10px",
      borderRadius: "5px",
    },
    flexContainer: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: "10px",
    },
    table: {
      width: "100%",
      marginTop: "10px",
    },
    tableHeader: {
      flexDirection: "row",
      backgroundColor: "#f0f0f0",
    },
    tableRow: {
      flexDirection: "row",
      marginBottom: "5px",
    },
    tableCell: {
      width: "50%",
      fontSize: "11px",
      padding: "5px",
    },
  });

  useEffect(() => {
    const getAPI = async () => {
      try {
        const res = await axios.get(
          `/getPaymentRecieptDetails/${props?.paymentId}`
        );
        console.log(res, "hfvyu");
        setData(res?.data?.data);
      } catch (error) {
        console.error(error);
      }
    };

    getAPI();
  }, [props.paymentId]);

  return (
    <Document title="Payment Receipt">
      <Page size={fractalsPageSize} style={Styles.page}>
        <Text
          style={{
            textAlign: "center",
            backgroundColor: "green",
            color: "white",
            fontSize: "17px",
            marginTop: "30px",
          }}
        >
          Payment Receipt
        </Text>

        <View style={Styles.receiptContainer}>
          {/* Displaying Payment Details */}
          <View style={Styles.table}>
            <View style={Styles.tableHeader}>
              <Text style={Styles.tableCell}>Description</Text>
              <Text style={Styles.tableCell}>Details</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Lender Name:</Text>
              <Text style={Styles.tableCell}>{data?.lenderName || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Receipt Number:</Text>
              <Text style={Styles.tableCell}>{data?.receiptNo || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Customer Name:</Text>
              <Text style={Styles.tableCell}>{data?.customerName || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Date of Payment:</Text>
              <Text style={Styles.tableCell}>{data?.dateOfPayment || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Received Sum of Rupees:</Text>
              <Text style={Styles.tableCell}>
                {data?.amountInWords || "-"} Rupees Only
              </Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Loan Account Number:</Text>
              <Text style={Styles.tableCell}>{data?.lan || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Payment Type:</Text>
              <Text style={Styles.tableCell}>{data?.paymentType || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Amount:</Text>
              <Text style={Styles.tableCell}>
                {data?.amount
                  ? `Rs ${data?.amount.toLocaleString("en-IN")}`
                  : "-"}
              </Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Payment Mode:</Text>
              <Text style={Styles.tableCell}>{data?.modeOfPayment || "-"}</Text>
            </View>
            {data?.modeOfPayment === "Cheque" && (
              <View style={Styles.tableRow}>
                <Text style={Styles.tableCell}>Cheque Number:</Text>
                <Text style={Styles.tableCell}>
                  {data?.chequeNumber || "-"}
                </Text>
              </View>
            )}
            {data?.modeOfPayment === "Digital" && (
              <View style={Styles.tableRow}>
                <Text style={Styles.tableCell}>Digital Payment Mode:</Text>
                <Text style={Styles.tableCell}>
                  {data?.digitalPaymentMode || "-"}
                </Text>
              </View>
            )}
            {data?.modeOfPayment === "Demand Draft" && (
              <View style={Styles.tableRow}>
                <Text style={Styles.tableCell}>Demand Draft Number:</Text>
                <Text style={Styles.tableCell}>
                  {data?.demandDraftNumber || "-"}
                </Text>
              </View>
            )}
            {data?.referenceNumber && (
              <View style={Styles.tableRow}>
                <Text style={Styles.tableCell}>Reference Number:</Text>
                <Text style={Styles.tableCell}>{data.referenceNumber}</Text>
              </View>
            )}
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Agency Name:</Text>
              <Text style={Styles.tableCell}>
                Truboard Servicing Private Limited
              </Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Agency Code:</Text>
              <Text style={Styles.tableCell}>{data?.agencyCode || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Customer Number:</Text>
              <Text style={Styles.tableCell}>{data?.mobileNumber || "-"}</Text>
            </View>
            <View style={Styles.tableRow}>
              <Text style={Styles.tableCell}>Payment Collected By:</Text>
              <Text style={Styles.tableCell}>{data?.collectorName || "-"}</Text>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default memo(PaymentReport);
