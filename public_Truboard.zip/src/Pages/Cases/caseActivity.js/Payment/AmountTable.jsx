import { memo } from "react"
import { useSelector } from "react-redux";
import { Table } from "reactstrap"

const AmountTable = () => {
    const caseProfile = useSelector((state) => state.cases.caseProfile);

    return (
        <Table
            size="sm"
            bordered
            striped
            responsive
        >
            <thead>
                <tr>
                    <th>
                        Pending Dues
                    </th>
                    <th>
                        Amount
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        Total overdue amount
                    </td>
                    <td>
                        { caseProfile?.totalOverdueAmount ?
                            Number(caseProfile?.totalOverdueAmount)?.toLocaleString('en-IN', {
                                style: 'currency',
                                currency: 'INR'
                            }) : '-'
                        }
                    </td>
                    {/* <td>
                        {parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(2) ? parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(2)?.toLocaleString('en-IN', {
                            style: 'currency',
                            currency: 'INR'
                        }) : 0}
                    </td> */}
                </tr>
                <tr>
                    <td>
                        Pending EMI amount
                    </td>
                    <td>
                        {caseProfile?.pendingEmiAmount ?
                            Number(caseProfile?.pendingEmiAmount)?.toLocaleString('en-IN', {
                                style: 'currency',
                                currency: 'INR'
                            }) : '-'
                        }
                    </td>
                    {/* <td>
                        {parseFloat(caseProfile?.pendingEmiAmount)?.toFixed(2)?.toLocaleString('en-IN', {
                            style: 'currency',
                            currency: 'INR'
                        })}
                    </td> */}
                </tr>
                <tr>
                    <td>
                        Charges
                    </td>
                    <td>
                        { (caseProfile?.otherCharges || 0) + (caseProfile?.chequeBounceCharges || 0) + (caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty || 0) ?
                            Number((caseProfile?.otherCharges || 0) + (caseProfile?.chequeBounceCharges || 0) + (caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty || 0))?.toLocaleString('en-IN', {
                                style: 'currency',
                                currency: 'INR'
                            }) : '-'
                        }
                    </td>
                    {/* <td>
                        {Number(parseFloat(caseProfile?.otherCharges)?.toFixed(2)) + Number(parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(2)) + Number(parseFloat(caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty)?.toFixed(2))}
                    </td> */}
                </tr>
                <tr>
                    <td>
                        Settlement Amount
                    </td>
                    <td>
                        { caseProfile?.settlementAmount ?
                            Number((caseProfile?.settlementAmount))?.toLocaleString('en-IN', {
                                style: 'currency',
                                currency: 'INR'
                            }) : '-'
                        }
                    </td>
                    {/* <td>
                        &#8377; {parseFloat(caseProfile?.settlementAmount)?.toFixed(2)}
                    </td> */}
                </tr>
                <tr>
                    <td>
                        EMI Amount
                    </td>
                    <td>
                        {caseProfile?.emiAmount ?
                            Number((caseProfile?.emiAmount))?.toLocaleString('en-IN', {
                                style: 'currency',
                                currency: 'INR'
                            }) : '-'
                        }
                    </td>
                    {/* <td>
                        &#8377; {parseFloat(caseProfile?.emiAmount)?.toFixed(2)}
                    </td> */}
                </tr>
            </tbody>
        </Table>
    )
}

export default memo(AmountTable)