import { Formik } from "formik";
import { Fragment, memo, useEffect, useMemo, useState } from "react";
import { Button, Form, Input } from "reactstrap";
import Field from "../../../../components/Field";
import styles from "./Payment.module.scss";
import { AMOUNT, NUMBER_ONLY } from "../../../../utils/regex";
import * as yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import Swal from "sweetalert2";
import axios from "axios";
import { getUserTypeData } from "../../../Master/LookupMaster/lookupSlice";
import { setLoader } from "../../../../reducer/globalReducer";

const PaymentForm = (props) => {
  // console.log(props?.geoData, "hjhhf");
  const [message, setmessage] = useState({});
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const user = useSelector((state) => state.user.data);
  const userTypeData = useSelector((state) => state?.lookup?.userTypeData);

  const { lanId } = useParams();

  const dispatch = useDispatch();

  const IS_EDIT = useMemo(
    () =>
      Boolean(
        props?.selectedData ? Object.keys(props?.selectedData).length : false
      ),
    [props?.selectedData]
  );
  const PAYMENT_TYPE_BUTTON = useMemo(
    () => [
      "Foreclosure",
      "Total Outstanding",
      "Charges",
      "Overdue EMI",
      "Settlement",
      "Other",
      "EMI",
    ],
    []
  );
  const PAYMENT_MEASURE_BUTTON = useMemo(() => ["Full", "Partial"], []);
  const SUB_TYPE_BUTTON = useMemo(
    () => ["Other Charges", "DCP/LPP", "Cheque Bounce"],
    []
  );
  const MODE_OF_PAYMENT_BUTTON = useMemo(() => [
    "Cash",
    "Cheque",
    "Digital",
    "Demand Draft",
  ]);
  const DIGITAL_PAYMENT_BUTTON = useMemo(() => ["NEFT", "RTGS", "IMPS", "UPI"]);
  const isPTPPayment = useMemo(() => props?.paymentCategory === "PTP", []);
  // console.log(props?.selectedData, "payment000");
  const items = props?.selectedData?.subType?.split(",");
  const obj = {};
  items?.forEach((item) => {
    if (item.includes("Other")) {
      obj["Other"] = item;
    } else if (item.includes("DCP")) {
      obj["DCP"] = item;
    } else if (item.includes("Cheque")) {
      obj["Cheque"] = item;
    }
  });
  const initialValues = {
    paymentType: isPTPPayment
      ? props?.data?.ptpType
      : IS_EDIT
      ? props?.selectedData?.paymentType
      : "Foreclosure",
    paymentMeasure: isPTPPayment
      ? props?.data?.ptpMode
      : IS_EDIT
      ? props?.selectedData?.paymentMeasure || ""
      : "Full",
    // subType: isPTPPayment? [obj?.Other && "Other Charges",obj?.DCP && "DCP/LPP",obj?.Cheque && "Cheque Bounce"].filter(Boolean): IS_EDIT ? props?.selectedData?.subType : ["Other Charges", "DCP/LPP", "Cheque Bounce"],
    subType: IS_EDIT
      ? [
          obj?.Other && "Other Charges",
          obj?.DCP && "DCP/LPP",
          obj?.Cheque && "Cheque Bounce",
        ].filter(Boolean)
      : ["Other Charges", "DCP/LPP", "Cheque Bounce"],

    amount: isPTPPayment
      ? props?.data?.ptpAmount
      : IS_EDIT
      ? props?.selectedData?.amount
      : "",
    paymentMode: IS_EDIT ? props?.selectedData?.paymentMode || "" : "",
    digitalPaymentMode: IS_EDIT
      ? props?.selectedData?.digitalPaymentMode || ""
      : "",
    referenceNumber: IS_EDIT ? props?.selectedData?.referenceNumber || "" : "",
    chequeNumber: IS_EDIT ? props?.selectedData?.chequeNumber || "" : "",
    dateOfPayment: isPTPPayment
      ? props?.data?.ptpDate
      : IS_EDIT
      ? props?.selectedData?.paymentDate || ""
      : "",
    timeOfPayment: isPTPPayment
      ? props?.data?.ptpTime
      : IS_EDIT
      ? props?.selectedData?.timeOfPayment || ""
      : "",
    paymentStatus: isPTPPayment
      ? props?.data?.status
      : IS_EDIT
      ? props?.selectedData?.paymentStatus
      : "Pending",
    phoneNumber: IS_EDIT ? props?.selectedData?.phoneNumber || "" : "",
    remark: isPTPPayment
      ? props?.data?.remark
      : IS_EDIT
      ? props?.selectedData?.remark || ""
      : "",
    evidence: "",
    demandDraftNumber: IS_EDIT ? props?.selectedData?.demandDraftNumber : "",
  };
  // console.log(paymentType, "payment type")
  const validationSchema = yup.object().shape({
    paymentType: yup.string().required("Required"),
    paymentMeasure: yup.string().when("paymentType", {
      is: (paymentType) => ["EMI", "Settlement"]?.includes(paymentType),
      then: () => {
        yup.string().required("Required");
      },
    }),
    subType: yup.array().when("paymentType", {
      is: (paymentType) => ["Charges"]?.includes(paymentType),
      then: () => yup.array().min(1, "Required"),
    }),

    // subType: yup
    //         .array()
    //         .when('paymentType', {
    //             is: (paymentType) => ['Charges']?.includes(paymentType),
    //             then: () => yup.array().min(1, 'Required')
    //         }),

    amount: yup.string().required("Required"),
    paymentMode: yup.string().required("Required"),
    digitalPaymentMode: yup.string().when("paymentMode", {
      is: (paymentMode) => ["Digital"]?.includes(paymentMode),
      then: () => yup.string().required("Required"),
    }),
    referenceNumber: yup.string().when("paymentMode", {
      is: (paymentMode) => ["Digital"]?.includes(paymentMode),
      then: () =>
        yup
          .string()
          .max(50, "Enter valid Reference Number")
          .required("Required"),
    }),
    // referenceNumber: yup.string().when('paymentMode', {
    //   is: (paymentMode) => ["Digital"].includes(paymentMode),
    //   then: yup.string().max(50, 'Enter valid Reference Number').required('Required'),
    // }),
    chequeNumber: yup.string().when("paymentMode", {
      is: (paymentMode) => "Cheque" === paymentMode,
      then: () =>
        yup.string().min(6, "Cheque Number is Invalid").required("Required"),
    }),
    demandDraftNumber: yup.string().when("paymentMode", {
      is: (paymentMode) => "Demand Draft" === paymentMode,
      then: () => yup.string().required("Required"),
    }),
    dateOfPayment: yup.string().required("Required"),
    timeOfPayment: yup.string().required("Required"),
    phoneNumber: yup
      .string()
      //   .matches(/^[0-9]{10}$/, "Invalid mobile number") // Matches only 10 digits
      .required("Mobile number is required")
      .max(10, "Please enter only 10 digits"),
    remark: yup.string().required("Required"),
  });

  const handleSubmit = async (values) => {
    const checkIsrequestPermission = ["F", "E"].includes(
      user?.masterRole?.requestmanagement_requestmanagement
    );
    const payload = {
      totalOverdueAmount: parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(
        2
      ),
      pendingEmiAmount: parseFloat(caseProfile?.pendingEmiAmount)?.toFixed(2),
      charges:
        values?.paymentType === "Charges"
          ? Number(parseFloat(caseProfile?.otherCharges)?.toFixed(2)) +
            Number(parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(2)) +
            Number(
              parseFloat(
                caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty
              )?.toFixed(2)
            )
          : null,
      settlementAmount: parseFloat(caseProfile?.settlementAmount)?.toFixed(2),
      emiAmount: parseFloat(caseProfile?.emiAmount)?.toFixed(2),
      loanAccountNumber: lanId,
      isDocument: values?.evidence ? "yes" : "No",
      otherCharges:
        values?.paymentType === "Charges"
          ? Number(
              parseFloat(caseProfile?.otherCharges)?.toFixed(2)
            )?.toString()
          : null,
      dcpLpp:
        values?.paymentType === "Charges"
          ? Number(
              parseFloat(
                caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty
              )?.toFixed(2)
            )?.toString()
          : null,
      chequeBounce:
        values?.paymentType === "Charges"
          ? Number(
              parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(2)
            )?.toString()
          : null,
      remark: values?.remark,
      amount: values?.amount,
      paymentStatus: checkIsrequestPermission ? "Success" : "Pending",
      paymentMode: values?.paymentMode,
      paymentType: values?.paymentType,
      paymentMeasure: ["EMI", "Settlement"]?.includes(values?.paymentType)
        ? values?.paymentMeasure
        : null,
      phoneNumber: values?.phoneNumber,
      paymentDate: values?.dateOfPayment,
      timeOfPayment: values?.timeOfPayment,
      chequeNumber:
        values?.paymentMode === "Cheque" ? values?.chequeNumber : null,
      digitalPaymentMode:
        values?.paymentMode === "Digital" ? values?.digitalPaymentMode : null,
      referenceNumber:
        values?.paymentMode === "Digital" ? values?.referenceNumber : null,
      status: "",
      subType:
        values?.paymentType === "Charges" ? values?.subType?.join(",") : "",
      paymentCategory: props?.paymentCategory,
      demandDraftNumber: values.demandDraftNumber,
      user: {
        userId: user?.userId,
      },
      agencyName: user.userType === "U103" ? user?.agency[0]?.agencyName : "",
    };

    if (props?.isContactCenter) {
      props?.onSuccess(
        "/addPayment",
        payload,
        values?.evidence,
        !checkIsrequestPermission
      );
    } else {
      try {
        dispatch(setLoader(true));
        const url = IS_EDIT
          ? `/updatePayment/${props?.selectedData?.paymentId}`
          : "/addPayment";
        const res = IS_EDIT
          ? await axios.put(url, payload)
          : await axios.post(url, {
              ...payload,
              geoCoordinates: `${props?.geoData?.lat}, ${props?.geoData?.long}`,
            });
        setmessage({ msg: res?.data?.message, msgkey: res?.data?.msgKey });
        dispatch(setLoader(false));
        if (
          res?.data?.msgKey === "Success" ||
          res?.data?.msgKey === "Failure"
        ) {
          // console.log(values?.evidence, "values?.evidence");

          if (values?.evidence) {
            const formData = new FormData();
            formData.append("paymentfile", values?.evidence);
            // console.log(formData, "formDataformData");
            const headers = {
              "Content-Type": "multipart/form-data", // Set the Content-Type header
            };

            dispatch(setLoader(true));
            const fileRes = await axios.post(
              `/upload-document-payment/${res?.data?.data?.paymentId}`,
              formData,
              { headers }
            );
            // console.log(fileRes, "fileRes");
            dispatch(setLoader(false));
          }

          if (isPTPPayment) {
            const ptpPayload = {
              ...props?.data,
              status: checkIsrequestPermission ? "Success" : "Pending",
              payment: res?.data?.data,
            };
            dispatch(setLoader(true));
            const ptpRes = await axios.put(
              `/updatePtpDetails/${props?.data?.ptpId}`,
              ptpPayload
            );
            dispatch(setLoader(false));
          }

          if (!checkIsrequestPermission) {
            const userType = {};
            userTypeData?.map((a) =>
              Object.assign(userType, { [a?.code]: `${a?.description}_Agent` })
            );
            const userRole = user?.role?.map((a) => a?.roleCode?.toLowerCase());

            if (!IS_EDIT) {
              const requestPayload = {
                activityId: res?.data?.data?.paymentId,
                activityType: "Payment",
                lan: lanId,
                status: res?.data?.data?.paymentStatus,
                remark: "",
                isDocument: values?.evidence ? "yes" : "No",
                selectedFieldAgentId: "",
                requestRaisedUserId: user?.userId,
                reportingManagerOfUser: "",
                userType: userRole?.includes("ca")
                  ? "CA"
                  : userRole?.includes("dra")
                  ? "DRA"
                  : userType[user?.userType],
                requestid: new Date().getTime().toString().slice(-5),
              };

              dispatch(setLoader(true));
              const requestRes = await axios.post(
                "/addRequestManagement",
                requestPayload
              );
              dispatch(setLoader(false));
            }
          }

          if (res?.data?.msgKey == "Success") {
            props?.onSuccess();
          }

          Swal.fire({
            position: "top-end",
            icon: res?.data?.msgKey == "Failure" ? "error" : "success",
            title: res?.data?.message,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        }
      } catch (error) {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    }
  };

  useEffect(() => {
    dispatch(getUserTypeData());
  }, []);

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({
        errors,
        touched,
        values,
        handleSubmit,
        setFieldValue,
        handleBlur,
        handleChange,
      }) => {
        // console.log(values, "valuwesus");
        return (
          <Form onSubmit={handleSubmit}>
            <Field
              isRequired
              label="Payment Type"
              childrenClassName={styles?.inlineButtonContainer}
              errorMessage={touched?.paymentType && errors?.paymentType}
            >
              {PAYMENT_TYPE_BUTTON?.map((btn) => (
                <Button
                  key={btn}
                  color="primary"
                  outline
                  size="sm"
                  active={values?.paymentType === btn}
                  name="paymentType"
                  onClick={() => {
                    let paymentMeasure = values?.paymentMeasure;
                    setFieldValue("paymentType", btn);
                    if (btn !== "Charges") {
                      setFieldValue("subType", []);
                    }
                    if (btn !== "EMI" && btn !== "Settlement") {
                      setFieldValue("paymentMeasure", "");
                    } else {
                      setFieldValue("paymentMeasure", "Full");
                      paymentMeasure = "Full";
                      setFieldValue(
                        "amount",
                        parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(2)
                      );
                    }

                    if (
                      ["Settlement"]?.includes(btn) &&
                      paymentMeasure === "Full"
                    ) {
                      setFieldValue(
                        "amount",
                        parseFloat(caseProfile?.settlementAmount)?.toFixed(2)
                      );
                    } else if (["Charges"].includes(btn)) {
                      const totalCharges =
                        Number(
                          parseFloat(caseProfile?.otherCharges)?.toFixed(2)
                        ) +
                        Number(
                          parseFloat(caseProfile?.chequeBounceCharges)?.toFixed(
                            2
                          )
                        ) +
                        Number(
                          parseFloat(
                            caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty
                          )?.toFixed(2)
                        );
                      setFieldValue("amount", totalCharges);
                      setFieldValue("subType", [
                        "Other Charges",
                        "DCP/LPP",
                        "Cheque Bounce",
                      ]);
                    } else if (["Foreclosure", "Other"].includes(btn)) {
                      setFieldValue("amount", "");
                    } else if (btn === "Pending EMI") {
                      setFieldValue(
                        "amount",
                        parseFloat(caseProfile?.pendingEmiAmount)?.toFixed(2)
                      );
                    } else if (btn === "EMI") {
                      setFieldValue(
                        "amount",
                        parseFloat(caseProfile?.emiAmount)?.toFixed(2)
                      );
                    } else if (btn === "Total Outstanding") {
                      setFieldValue(
                        "amount",
                        parseFloat(caseProfile?.totalOverdueAmount)?.toFixed(2)
                      );
                    } else if (btn === "Overdue EMI") {
                      setFieldValue(
                        "amount",
                        parseFloat(caseProfile?.pendingEmiAmount)?.toFixed(2)
                      );
                    }
                  }}
                  onBlur={handleBlur}
                  invalid={touched?.paymentType && Boolean(errors?.paymentType)}
                >
                  {btn}
                </Button>
              ))}
            </Field>
            {["EMI", "Settlement"]?.includes(values?.paymentType) && (
              <Field
                isRequired
                label="Payment Measure"
                childrenClassName={styles?.inlineButtonContainer}
                errorMessage={touched?.paymentMeasure && errors?.paymentMeasure}
              >
                {PAYMENT_MEASURE_BUTTON?.map((btn) => (
                  <Button
                    key={btn}
                    color="primary"
                    outline
                    size="sm"
                    name="paymentMeasure"
                    active={values?.paymentMeasure === btn}
                    onClick={() => {
                      setFieldValue("paymentMeasure", btn);
                      if (btn === "Full") {
                        const amount =
                          values?.paymentType === "EMI"
                            ? caseProfile?.emiAmount
                            : values?.paymentType === "Settlement"
                            ? caseProfile?.settlementAmount
                            : caseProfile?.totalOverdueAmount;
                        setFieldValue("amount", parseFloat(amount)?.toFixed(2));
                      }
                    }}
                    onBlur={handleBlur}
                    invalid={
                      touched?.paymentMeasure && Boolean(errors?.paymentMeasure)
                    }
                  >
                    {btn}
                  </Button>
                ))}
              </Field>
            )}

            {["Charges"].includes(values?.paymentType) && (
              <Field
                isRequired
                label="Sub Type"
                childrenClassName={styles?.inlineButtonContainer}
                errorMessage={touched?.subType && errors?.subType}
              >
                {SUB_TYPE_BUTTON?.map((btn) => (
                  <Button
                    key={btn}
                    color="primary"
                    outline
                    size="sm"
                    name="subType"
                    active={values?.subType?.includes(btn)}
                    onClick={() => {
                      const indexOf = values?.subType?.indexOf(btn);
                      let latestValue = [];
                      if (indexOf >= 0) {
                        let updatedValue = values?.subType;
                        updatedValue?.splice(indexOf, 1);
                        latestValue = updatedValue;
                        setFieldValue("subType", updatedValue);
                      } else {
                        latestValue = [...values?.subType, btn];
                        setFieldValue("subType", [...values?.subType, btn]);
                      }
                      let totalCharges = 0;
                      latestValue?.map((a) => {
                        if (a === "Cheque Bounce") {
                          totalCharges =
                            totalCharges +
                            Number(
                              parseFloat(
                                caseProfile?.chequeBounceCharges
                              )?.toFixed(2)
                            );
                        } else if (a === "Other Charges") {
                          totalCharges =
                            totalCharges +
                            Number(
                              parseFloat(caseProfile?.otherCharges)?.toFixed(2)
                            );
                        } else if (a === "DCP/LPP") {
                          totalCharges =
                            totalCharges +
                            Number(
                              parseFloat(
                                caseProfile?.dpcOrLppOrDelayPaymentChargesOrLatePaymentPenalty
                              )?.toFixed(2)
                            );
                        }
                      });
                      setFieldValue("amount", totalCharges);
                    }}
                    onBlur={handleBlur}
                    invalid={touched?.subType && Boolean(errors?.subType)}
                  >
                    {btn}
                  </Button>
                ))}
              </Field>
            )}

            <Field
              isRequired
              label="Amount"
              errorMessage={touched?.amount && errors?.amount}
            >
              {/* {console.log(values?.paymentType, "values?.paymentType")} */}
              <Input
                bsSize="sm"
                value={
                  values?.amount == "0.00" || values?.amount == "0"
                    ? ""
                    : values?.amount
                }
                // value={values?.amount }
                isRequired
                onChange={(e) => {
                  const decimal = e?.target?.value?.split(".");
                  // console.log(values, "myvalues");
                  if (decimal?.length === 1) {
                    if (AMOUNT?.test(e?.target?.value)) {
                      setFieldValue("amount", e?.target?.value);
                    }
                  } else {
                    if (
                      AMOUNT?.test(e?.target?.value) &&
                      decimal[1].length <= 2
                    ) {
                      setFieldValue("amount", e?.target?.value);
                    }
                  }
                }}
                maxLength={15}
                onBlur={handleBlur}
                invalid={touched?.amount && Boolean(errors?.amount)}
                disabled={
                  ["EMI", "Settlement"]?.includes(values?.paymentType) &&
                  values?.paymentMeasure === "Full"
                }
              />
              {message?.msgkey == "Failure" ||
              values?.amount == "0.00" ||
              values?.amount == "0" ? (
                <span style={{ color: "red" }}>Amount is required</span>
              ) : (
                ""
              )}
            </Field>

            <Field
              isRequired
              label="Mode of Payment"
              childrenClassName={styles?.inlineButtonContainer}
              errorMessage={touched?.paymentMode && errors?.paymentMode}
            >
              {MODE_OF_PAYMENT_BUTTON?.map((btn) => (
                <Button
                  key={btn}
                  color="primary"
                  outline
                  size="sm"
                  name="paymentMode"
                  active={values?.paymentMode === btn}
                  onClick={() => {
                    setFieldValue("paymentMode", btn);
                    setFieldValue("referenceNumber", "");
                    setFieldValue("chequeNumber", "");
                  }}
                  onBlur={handleBlur}
                  invalid={touched?.paymentMode && Boolean(errors?.paymentMode)}
                >
                  {btn}
                </Button>
              ))}
            </Field>
            {["Digital"]?.includes(values?.paymentMode) && (
              <Fragment>
                <Field
                  isRequired
                  label="Digital Payment Mode"
                  childrenClassName={styles?.inlineButtonContainer}
                  errorMessage={
                    touched?.digitalPaymentMode && errors?.digitalPaymentMode
                  }
                >
                  {DIGITAL_PAYMENT_BUTTON?.map((btn) => (
                    <Button
                      key={btn}
                      color="primary"
                      outline
                      size="sm"
                      name="digitalPaymentMode"
                      active={values?.digitalPaymentMode === btn}
                      onClick={() => setFieldValue("digitalPaymentMode", btn)}
                      onBlur={handleBlur}
                      invalid={
                        touched?.digitalPaymentMode &&
                        Boolean(errors?.digitalPaymentMode)
                      }
                    >
                      {btn}
                    </Button>
                  ))}
                </Field>
                <Field
                  isRequired
                  label="Reference Number"
                  errorMessage={
                    touched?.referenceNumber && errors?.referenceNumber
                  }
                >
                  <Input
                    bsSize="sm"
                    value={values?.referenceNumber}
                    onChange={handleChange}
                    name="referenceNumber"
                    onBlur={handleBlur}
                    maxLength={50}
                    invalid={
                      touched?.referenceNumber &&
                      Boolean(errors?.referenceNumber)
                    }
                  />
                </Field>
              </Fragment>
            )}

            {["Cheque"]?.includes(values?.paymentMode) && (
              <Field
                isRequired
                label="Cheque Number"
                errorMessage={touched?.chequeNumber && errors?.chequeNumber}
              >
                <Input
                  bsSize="sm"
                  value={values?.chequeNumber}
                  onChange={(e) => {
                    if (NUMBER_ONLY.test(e?.target?.value)) {
                      setFieldValue("chequeNumber", e?.target?.value);
                    } else {
                      setFieldValue("chequeNumber", e?.target?.value);
                    }
                  }}
                  name="chequeNumber"
                  maxLength={6}
                  onBlur={handleBlur}
                  invalid={
                    touched?.chequeNumber && Boolean(errors?.chequeNumber)
                  }
                />
              </Field>
            )}

            {["Demand Draft"]?.includes(values?.paymentMode) && (
              <Field label="Demand Draft Number">
                <Input
                  bsSize="sm"
                  id="demandDraftNumber"
                  value={values?.demandDraftNumber}
                  onChange={handleChange}
                  name="demandDraftNumber"
                  onBlur={handleBlur}
                  invalid={
                    touched?.demandDraftNumber &&
                    Boolean(errors?.demandDraftNumber)
                  }
                />
              </Field>
            )}

            <Field label="Evidence">
              <Button size="sm" color="primary" type="button">
                <label htmlFor="evidence">
                  <i className="bi bi-upload uploadIcon"></i>
                  <span>{values?.evidence?.name || "Evidence"}</span>
                  <input
                    type="file"
                    id="evidence"
                    style={{ display: "none" }}
                    onChange={(event) => {
                      const file = event.target?.files[0];
                      // console.log(file, "filefile");
                      // Handle the selected file here
                      setFieldValue("evidence", file);
                    }}
                  />
                </label>
              </Button>
            </Field>

            <Field
              isRequired
              label="Date of Payment"
              errorMessage={touched?.dateOfPayment && errors?.dateOfPayment}
            >
              <Input
                type="date"
                name="dateOfPayment"
                value={values?.dateOfPayment}
                max={new Date().toISOString().split("T")[0]}
                onChange={handleChange}
                onBlur={handleBlur}
              />
            </Field>

            <Field
              isRequired
              label="Time of Payment"
              errorMessage={touched?.timeOfPayment && errors?.timeOfPayment}
            >
              <Input
                type="time"
                name="timeOfPayment"
                value={values?.timeOfPayment}
                onChange={handleChange}
                onBlur={handleBlur}
              />
            </Field>

            <Field
              isRequired
              label="Payment Status"
              errorMessage={touched?.paymentStatus && errors?.paymentStatus}
            >
              <Input
                bsSize="sm"
                value={values?.paymentStatus}
                disabled
                onBlur={handleBlur}
                invalid={
                  touched?.paymentStatus && Boolean(errors?.paymentStatus)
                }
              />
            </Field>

            <Field
              isRequired
              label="Phone Number"
              errorMessage={touched?.phoneNumber && errors?.phoneNumber}
            >
              <Input
                bsSize="sm"
                value={values?.phoneNumber}
                onChange={(e) => {
                  if (NUMBER_ONLY.test(e?.target?.value)) {
                    setFieldValue("phoneNumber", e?.target?.value);
                  } else if (!e?.target?.value) {
                    setFieldValue("phoneNumber", e?.target?.value);
                  }
                }}
                name="phoneNumber"
                maxLength={10}
                onBlur={handleBlur}
                invalid={touched?.phoneNumber && Boolean(errors?.phoneNumber)}
              />
            </Field>
            <Field
              isRequired
              label="Remark"
              errorMessage={touched?.remark && errors?.remark}
            >
              <Input
                type="textarea"
                bsSize="sm"
                value={values?.remark}
                onChange={handleChange}
                name="remark"
                onBlur={handleBlur}
                invalid={touched?.remark && Boolean(errors?.remark)}
              />
            </Field>

            <div className="d-flex justify-content-end gap-2">
              <Button type="submit" size="sm" color="primary">
                Save
              </Button>
              {!props?.isCancelHidden && (
                <Button
                  type="button"
                  size="sm"
                  color="danger"
                  onClick={() => props?.onClose()}
                >
                  Cancel
                </Button>
              )}
            </div>
          </Form>
        );
      }}
    </Formik>
  );
};

export default memo(PaymentForm);
