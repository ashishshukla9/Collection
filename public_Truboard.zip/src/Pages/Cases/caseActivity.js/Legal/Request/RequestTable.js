import React, { useEffect, useMemo, useState } from "react";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Row, Col, Button, ButtonGroup } from "reactstrap";
import Request from "./Request";
import axios from "axios";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { getActivityHistory, updateInProgressCase } from "../../store";
import { useParams } from "react-router-dom";
import moment from "moment";
import { setLoader } from "../../../../reducer/globalReducer";

const RequestTable = (props) => {
  // console.log(props?.geoData, "request module")
  const { openRequest, setCloseRequest } = props;
  const [formModal, setFormModal] = useState(false)
  const [formType, setFormType] = useState('')
  const [requestTypeOptions, setRequestTypeOptions] = useState([]);
  const [data, setData] = useState({})
  const [requestData, setRequestData] = useState([])

  const user = useSelector((state) => state.user.data);
  const caseProfile = useSelector((state) => state.cases.caseProfile);
  const currentModule = useSelector((state) => state.cases);


  const roleCode = useMemo(() => user?.role?.map(a => a?.roleCode), [user])

  const { lanId } = useParams();
  const {tab}=useParams()
  const dispatch = useDispatch();

  const getAllRequestTypeData = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get("/getAllRequestType")
      dispatch(setLoader(false))
      let activeRequest = [];
      res?.data?.data?.forEach((requestOption) => {
        // console.log(requestOption, "requestOption")
        if (requestOption.isActive === "Y") {
          if((requestOption?.description === "Unallocate" || requestOption?.description === "Case Close") && tab === "MY_CASE"){
            activeRequest.push({
              label: requestOption?.description,
              value: requestOption?.code,
            });
          }else if(requestOption?.description !== "Unallocate" && requestOption?.description !== "Case Close"){
            activeRequest.push({
              label: requestOption?.description,
              value: requestOption?.code,
            });
          }
          
          // if(requestOption?.description !== "Unallocate"){
          //   activeRequest.push({
          //     label: requestOption?.description,
          //     value: requestOption?.code,
          //   });
          // } else if(requestOption?.description === "Unallocate" && (roleCode?.includes('CA') || roleCode?.includes('DRA') || roleCode?.includes('FA'))){
          //   activeRequest.push({
          //     label: requestOption?.description,
          //     value: requestOption?.code,
          //   });
          // }
        }
      });
      setRequestTypeOptions(activeRequest);
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }

  const getAllRequest = async () => {
    try {
      dispatch(setLoader(true))
      const res = await axios.get(`/getByRequestLoanAccountNumber/${lanId}`)
      dispatch(setLoader(false))
      setRequestData(res?.data?.data)
    } catch (error) {
      dispatch(setLoader(false))
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  }
  useEffect(() => {
    getAllRequestTypeData()
    getAllRequest()
  }, []);
  return (
    <Dialog
      header="Request"
      visible={openRequest}
      style={{ width: "60vw" }}
      onHide={() => setCloseRequest(false)}
    >
      <Row>
        <Col className="d-flex flex-row-reverse mb-2">
          <Button
            size="sm"
            style={{ width: "120px" }}
            color="primary"
            onClick={() => {
              setFormModal(true)
              setFormType('Create')
            }}
            disabled={caseProfile?.forCloserRequestStatus === "approved"}
          >
            Add
          </Button>
        </Col>
      </Row>
      <DataTable
        value={requestData}
        showGridlines
        paginator
        className="commonTable"
        rows={10}
        rowsPerPageOptions={[10, 20, 40, 80, "All"]}
        tableStyle={{ minWidth: "50rem" }}
        globalFilterFields={["natureofServiceId", "status"]}
      >
        <Column
          field="code"
          header="Name"
          body={(rowData) => `${rowData?.user?.firstName}${rowData?.user?.lastName}`}
        />
        <Column field="requestType" header="Request Type" />
        <Column field="remark" header="Remark" />
        <Column field="status" header="Status" />
        <Column
          field=""
          header="Time"
          body={(rowData) => moment(rowData?.lastModifiedTime).add(rowData?.lastModifiedTime).format("YYYY-MM-DD HH:mm")}
        />
        <Column
          header="Action"
          body={(rowData) => {
            return (
              <ButtonGroup>
                <i
                  className="bi bi-eye-fill text-primary"
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    setData(rowData);
                    setFormModal(true)
                    setFormType('View')
                  }}
                />
                {rowData?.status === "Pending" && caseProfile?.forCloserRequestStatus !== "approved" &&
                  <>
                    <b style={{ marginLeft: 4, marginRight: 4 }}>|</b>
                    <i
                      className="bi bi-pencil-square text-danger"
                      style={{ cursor: "pointer" }}
                      onClick={(e) => {
                        setData(rowData);
                        setFormModal(true)
                        setFormType('Edit')
                      }}
                    />
                  </>
                }
              </ButtonGroup>
            );
          }}
        />
      </DataTable>

      {formModal &&
        <Request
          formType={formType}
          geoData={props?.geoData}
          visible={formModal}
          lanId={props?.lanId}
          currentModule={currentModule?.currentModule}
          onClose={() => {
            setFormModal(false)
            setFormType('')
            setData({})
          }}
          data={data}
          onSuccess={() => {
            getAllRequest()
            dispatch(updateInProgressCase(
              {userId: user?.userId, currentTab:props?.module,  lanId, role: user?.role[0]?.roleCode, activityType: caseProfile?.fieldPickUp === "Y" ? "Field" : user?.activityType }
            ))
            dispatch(getActivityHistory(lanId))
          }}
          requestTypeOptions={requestTypeOptions}
        />
      }
    </Dialog>
  );
};

export default RequestTable;
