import { memo, useEffect, useState } from "react"
import styles from './Exception.module.scss'
import { Dialog } from "primereact/dialog"
import { Button, Card, CardBody } from "reactstrap"
import axios from "axios"
import Swal from "sweetalert2"
import ContactRaiseForm from "../ContactCenter/ContactRaiseForm"
import { useDispatch } from "react-redux"
import { setLoader } from "../../../../reducer/globalReducer"

const ExceptionForm = (props) => {
    const [documentDetail, setDocumentDetail] = useState();
    const [editModal, setEditModal] = useState(false);
    const [evidanceFile, setEvidanceFile] = useState();
    //  console.log(props,"/tragest")
    const dispatch=useDispatch()
    const handleFileUpate = async () => {
        const formData = new FormData();
        formData.append("exceptionfile", evidanceFile);
        try {
            const url = `/updateDocumentRaiseExceptionByRaiseExceptionId/${documentDetail.raiseExceptionId}`
            const headers = {
                "Content-Type": "multipart/form-data", // Set the Content-Type header
            }
            dispatch(setLoader(true))
    // console.log(formData, "evidanceFile")

            const res = await axios.put(url, formData, { headers })
            dispatch(setLoader(false))
            setEvidanceFile();
            setEditModal(!editModal);
            setDocumentDetail(res?.data?.data);
            Swal.fire({
                position: "top-end",
                icon: "success",
                title: "File Updated Succefully.",
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        } catch (error) {
            dispatch(setLoader(false))
            Swal.fire({
                position: "top-end",
                icon: "error",
                title: `${error.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
            });
        }
    };

    return (
        <Dialog
            header={`${props?.formType} Raise Exception`}
            visible={props?.visible}
            onHide={() => props?.onClose()}
            className={styles?.modalContainer}
        >
            <Card className="bg-light">
                <CardBody>
                    <ContactRaiseForm 
                    geoData={props?.geoData}
                        setEditModal={setEditModal}
                        editModal={editModal}
                        setDocumentDetail={setDocumentDetail}
                        documentDetail={documentDetail}
                        onClose={()=>props?.onClose()}
                        onSuccess={()=>props?.onSuccess()}
                        formType={props?.formType}
                        data={props?.data}
                    />
                    {/* <Formik
                        initialValues={initialValues}
                        validationSchema={validationSchema}
                        onSubmit={handleSubmit}
                    >
                        {({
                            values,
                            errors,
                            handleChange,
                            handleBlur,
                            touched,
                            handleSubmit,
                            setFieldValue,
                        }) => {
                            return (
                                <Form
                                    onSubmit={handleSubmit}
                                    className={styles.formContainer}
                                >
                                    <Field
                                        isRequired
                                        label="Exception Request"
                                        errorMessage={touched.request && errors.request}
                                    >
                                        <Select
                                            inputId="request"
                                            name="request"
                                            isClearable={true}
                                            options={props?.exceptionOptions}
                                            closeMenuOnSelect={true}
                                            hideSelectedOptions={false}
                                            onChange={(e) => {
                                                setFieldValue("request", e?.value);
                                            }}
                                            value={props?.exceptionOptions.filter(
                                                (v) => v.value === values.request
                                            )}
                                            className={classNames({
                                                abc: touched.request && Boolean(errors.request),
                                            })}
                                            onBlur={handleBlur}
                                            menuPosition={"fixed"}
                                            isDisabled={isView}
                                            classNamePrefix="react-select"
                                        />
                                    </Field>
                                    <Field
                                        isRequired
                                        label="Remarks"
                                        errorMessage={touched.remark && errors.remark}
                                    >
                                        <Input
                                            bsSize="sm"
                                            id="remark"
                                            type="textarea"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.remark}
                                            invalid={touched.remark && Boolean(errors.remark)}
                                            disabled={isView}
                                        />
                                    </Field>
                                    {(isView || isEdit) ? (
                                        <ButtonGroup style={{ width: "100%" }}>
                                            {documentDetail && (
                                                <Button
                                                    size="sm"
                                                    color="success"
                                                    outline
                                                    onClick={
                                                        () =>
                                                            DownloadFile(
                                                                `/downloadDocumentRaiseExceptionByRaiseExceptionId/${documentDetail?.raiseExceptionId}`,
                                                                documentDetail?.name
                                                            )
                                                        // console.log("first")
                                                    }
                                                >
                                                    <i className="bi bi-download me-3"></i>
                                                    Download - {documentDetail?.name}
                                                </Button>
                                            )}
                                            {isView || (
                                                <Button
                                                    size="sm"
                                                    color="primary"
                                                    outline
                                                    onClick={() => {
                                                        setEditModal(!editModal);
                                                    }}
                                                >
                                                    <i className="bi bi-pencil-square"></i>
                                                    Edit
                                                </Button>
                                            )}
                                        </ButtonGroup>
                                    ) : (
                                        <label
                                            htmlFor="evidance"
                                            className={classNames({
                                                "btn-outline-primary": !(
                                                    touched.evidance && Boolean(errors.evidance)
                                                ),
                                                "btn btn-sm upload-button": true,
                                                "is-invalid btn-outline-danger":
                                                    touched.evidance && Boolean(errors.evidance),
                                            })}
                                        >
                                            <i className="bi bi-upload uploadIcon"></i>
                                            <span>{values.evidance?.name || "Evidance"}</span>
                                            <input
                                                type="file"
                                                id="evidance"
                                                style={{ display: "none" }}
                                                onChange={(event) => {
                                                    const file = event.target?.files[0];
                                                    // Handle the selected file here
                                                    setFieldValue("evidance", file);
                                                }}
                                            />
                                        </label>
                                    )}
                                    {(isCreate || isEdit) && (
                                        <div className="d-flex justify-content-end">
                                            <Button type="submit" color="primary" className="me-1" size="sm">
                                                Submit
                                            </Button>
                                            <Button
                                                size="sm"
                                                type="button"
                                                color="danger"
                                                onClick={() => props?.onClose()}
                                            >
                                                Cancel
                                            </Button>
                                        </div>
                                    )}
                                </Form>
                            )
                        }}
                    </Formik> */}
                </CardBody>
                <Dialog
                    header="Edit Evidence File"
                    visible={editModal}
                    style={{ width: "20vw" }}
                    onHide={() => {
                        setEditModal(!editModal);
                    }}
                >
                    <label
                        htmlFor="evidence"
                        className="btn-outline-primary btn btn-sm upload-button mb-2"
                    >
                        <i className="bi bi-upload uploadIcon"></i>
                        <span>{evidanceFile?.name || "Evidence"}</span>
                        <input
                            type="file"
                            id="evidence"
                            style={{ display: "none" }}
                            onChange={(event) => {
                                const file = event.target?.files[0];
                                // Handle the selected file here
                                setEvidanceFile(file);
                            }}
                        />
                    </label>
                    {evidanceFile && (
                        <Button
                            size="sm"
                            color="primary"
                            className="d-flex ms-auto"
                            onClick={handleFileUpate}
                        >
                            Update
                        </Button>
                    )}
                </Dialog>
            </Card>
        </Dialog>
    )
}

export default memo(ExceptionForm)