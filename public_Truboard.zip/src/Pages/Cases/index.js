import React, { useState, useEffect, useMemo, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Card, CardBody, Container, Button, Input } from "reactstrap";
import "./cases.scss";
import { downloadExcel } from "../../utils/GenerateExcel";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  CACases,
  getAllCases,
  getAllocatedCasesForOtherRole,
  getAllocatedMISCases,
  getCAInProgressCases,
  getClouserRequestPending,
  getDRACases,
  getDeallocated,
  getForeclouser,
  getForeclouserMIS,
  getInProgressCases,
  getInProgressCasesDRA,
  getLenderAllCases,
  getLenderCaseCloase,
  getLenderInprogressCases,
  getMyCasesForOtherRole,
  getNewCasesForOtherRole,
  getNewMISCases,
  getSettlementCases,
  getUnallocatedCases,
  getUnallocatedCasesApproved,
  getUnallocatedCasesApprovedCA,
  getUnallocatedCasesApprovedDRA,
  getUnallocatedCasesPending,
  getUnallocatedCasesPendingCA,
  getUnallocatedCasesPendingDRA,
  getUnallocatedCasesRejected,
  getUnallocatedCasesRejectedCA,
  getUnallocatedCasesRejectedDRA,
  setAgencySelected,
  setList,
} from "./store";
import Swal from "sweetalert2";
import ManualAllocationModal from "./ManualAllocationModal";
import { OverlayPanel } from "primereact/overlaypanel";
import CaseFilterForm from "./CaseFilterForm";
import Pagination from "../../components/Pagination";
import Select from "react-select";
import { baseUrl } from "../../App.config";
import { saveAs } from "file-saver";
import { setAction, setLoader } from "../../reducer/globalReducer";
import { extendToken } from "../../utils/commonFun";
import { Cookies } from "react-cookie";
import { Dialog } from "primereact/dialog";
import CaseClose from "./CaseClose";
export default function Cases() {
  const cookies = new Cookies();
  const dispatch = useDispatch();
  const caseLists = useSelector((state) => state.cases.lists);
  const totalCount = useSelector((state) => state.cases.totalCount);
  const allTotalCount = useSelector((state) => state.cases.allTotalCount);
  const newTotalCount = useSelector((state) => state.cases.newTotalCount);
  const allocatedTotalCount = useSelector(
    (state) => state.cases.allocatedTotalCount
  );
  const InprogressTotalCount = useSelector(
    (state) => state.cases.InprogressTotalCount
  );
  const mycaseTotalCount = useSelector((state) => state.cases.mycaseTotalCount);
  const unalloactedPendingTotalCount = useSelector(
    (state) => state.cases.unalloactedPendingTotalCount
  );
  const unalloactedApproveTotalCount = useSelector(
    (state) => state.cases.unalloactedApproveTotalCount
  );
  const unalloactedRejectTotalCount = useSelector(
    (state) => state.cases.unalloactedRejectTotalCount
  );
  const caseCloaseTotalCount = useSelector(
    (state) => state.cases.caseCloaseTotalCount
  );
  const filterpayload = useSelector((state) => state.cases.filterpayload);
  const reload = useSelector((state) => state?.global?.reload);
  const user = useSelector((state) => state.user.data);
  const agencySelected = useSelector((state) => state?.cases?.agencySelected);
  const isSearch = useSelector((state) => state?.cases?.isSearch);
  const reset = useSelector((state) => state?.global?.reset);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [selectedProductsCount, setSelectedProductsCount] = useState(0);
  const [clearFilterCount, setClearFilterCount] = useState(0);
  const [isFilter, setIsFilter] = useState(false);
  const [fltrPayload, setFilterPayload] = useState([]);
  const [numberOfDataPerPage, setNumberOfDataPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [userNames, setUserNames] = useState({});
  const [agencyNames, setAgencyNames] = useState({});
  const [allSelected, setAllSelected] = useState(false);
  const [selectValue, setSelectValue] = useState({});
  const [currentModule, setCurrentModule] = useState("");
  const [caseStatusField, setCaseStatusField] = useState("caseStatus");
  const [allocatedUserField, setAllocatedUserField] = useState("allocatedUser");
  const [activeAgency, setActiveAgency] = useState([]);
  const [isAutoAllocated, setIsAutoAlloacted] = useState(false);
  const [lenderSelected, setLenderSelected] = useState([]);
  const [searchLAN, setSearchLAN] = useState("");
  const [selectAllocatedUser, setSelectAllocatedUser] = useState("");
  const [searchBorrower, setSearchBorrower] = useState("");
  const [caseClose, setcaseCloseOpen] = useState(false);
  const [childState, setChildState] = useState("");
  const handleChildStateChange = (newState) => {
    setChildState(newState);
  };
  const [casesCount, setCasesCount] = useState({
    all: 0,
    new: 0,
    allocated: 0,
    myCases: 0,
    inProgress: 0,
    unallocatedP: 0,
    unallocatedA: 0,
    unallocatedR: 0,
    foreclouser: 0,
    settlement: 0,
    requestForCloser: 0,
  });
  const filterPayload = useSelector((state) => state?.cases?.filterPayload);
  const isfilter = useSelector((state) => state?.cases?.isFilter);
  const loginSessionTimeout = useSelector(
    (state) => state?.global?.loginSessionTimeout
  );
  const currentRoles = useMemo(() =>
    user?.role?.map((a) => a?.roleCode?.toLowerCase())
  );
  const [dataOption, setDataOption] = useState(
    currentRoles?.includes("fa") ||
      currentRoles?.includes("ca") ||
      currentRoles?.includes("dra")
      ? "MY_CASE"
      : "ALL"
  );
  const navigate = useNavigate();
  const totalDataCount =
    dataOption == "ALL"
      ? allTotalCount
      : dataOption == "NEW"
      ? newTotalCount
      : dataOption == "ALLOCATED"
      ? allocatedTotalCount
      : dataOption == "MY_CASE"
      ? mycaseTotalCount || allTotalCount
      : dataOption == "IN_PROGRESS"
      ? InprogressTotalCount
      : totalCount;
  const isCountShow = useMemo(
    () => Boolean(Object.values(casesCount)?.filter(Boolean)?.length),
    [casesCount]
  );
  const manualAllocationRef = useRef(null);
  const isCaseProfileVisible = useMemo(() => {
    if (user?.masterRole) {
      const roleCode = user?.role?.map((a) => a?.roleCode);
      const keyValue = Object.entries(user?.masterRole);
      let getRoleValues = keyValue?.filter(
        (a) =>
          a[0]?.includes("caseactivity") ||
          (a[0]?.includes("customerprofile") && a)
      );
      getRoleValues =
        getRoleValues?.reduce((a, b) => ({ ...a, [b[0]]: b[1] }), {}) || {};
      getRoleValues = Object.values(getRoleValues).filter(Boolean);
      return getRoleValues.length === 1
        ? !Boolean(roleCode?.includes("MIS"))
        : true;
    }
  }, [user?.masterRole]);
  const totalStages = useMemo(
    () => [
      {
        id: 1,
        name: "All",
        countName: "allCount",
        key: "ALL",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("l01") ||
          currentRoles?.includes("l02") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "ALL"
            ? allTotalCount
            : isFilter
            ? 0
            : casesCount?.all
          : "",
      },
      {
        id: 2,
        name: "New",
        countName: "newCount",
        key: "NEW",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "NEW"
            ? newTotalCount
            : isFilter
            ? 0
            : casesCount?.new
          : "",
      },
      {
        id: 3,
        name: "Allocated",
        countName: "allocatedCount",
        key: "ALLOCATED",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "ALLOCATED"
            ? allocatedTotalCount
            : isFilter
            ? 0
            : casesCount?.allocated
          : "",
      },
      {
        id: 4,
        name: "My Cases",
        countName: "myCasesCount",
        key: "MY_CASE",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("ca") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("dra") ||
          currentRoles?.includes("fa") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "MY_CASE"
            ? mycaseTotalCount
            : isFilter
            ? 0
            : casesCount?.myCases
          : "",
      },
      {
        id: 5,
        name: "In Progress",
        countName: "myCasesCount",
        key: "IN_PROGRESS",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("ca") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("dra") ||
          currentRoles?.includes("fa") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "IN_PROGRESS"
            ? InprogressTotalCount
            : isFilter
            ? 0
            : casesCount?.inProgress
          : "",
      },
      {
        id: 6,
        name: "Unallocated (Pending)",
        countName: "unallocatedCount",
        key: "UNALLOCATED_PENDING",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("ca") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("dra") ||
          currentRoles?.includes("fa") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "UNALLOCATED_PENDING"
            ? unalloactedPendingTotalCount
            : isFilter
            ? 0
            : casesCount?.unallocatedP
          : "",
      },
      {
        id: 7,
        name: "Unallocated (Approved)",
        countName: "unallocatedCount",
        key: "UNALLOCATED_APPROVED",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("ca") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("dra") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1") ||
          currentRoles?.includes("fa"),
        count: isCountShow
          ? isFilter && dataOption === "UNALLOCATED_APPROVED"
            ? unalloactedApproveTotalCount
            : isFilter
            ? 0
            : casesCount?.unallocatedA
          : "",
      },
      {
        id: 8,
        name: "Unallocated (Approval Rejected)",
        countName: "unallocatedCount",
        key: "UNALLOCATED_rejected",

        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("ca") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("dra") ||
          currentRoles?.includes("fa") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "UNALLOCATED_rejected"
            ? unalloactedRejectTotalCount
            : isFilter
            ? 0
            : casesCount?.unallocatedR
          : "",
      },
      {
        id: 9,
        name: "Foreclosure",
        countName: "foreclouser",
        key: "FORECLOSURE",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("ca") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("dra") ||
          currentRoles?.includes("fa") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "FORECLOSURE"
            ? totalCount
            : isFilter
            ? 0
            : casesCount?.foreclouser
          : "",
      },
      {
        id: 10,
        name: "Settlement",
        countName: "settlement",
        key: "SETTLEMENT",
        visibleTo:
          currentRoles?.includes("cca") ||
          currentRoles?.includes("op") ||
          currentRoles?.includes("ca") ||
          currentRoles?.includes("sh") ||
          currentRoles?.includes("dra") ||
          currentRoles?.includes("fa") ||
          currentRoles?.includes("atl") ||
          currentRoles?.includes("aa") ||
          currentRoles?.includes("rh") ||
          currentRoles?.includes("ch") ||
          currentRoles?.includes("nrm") ||
          currentRoles?.includes("mis") ||
          currentRoles?.includes("zrm") ||
          currentRoles?.includes("rrm") ||
          currentRoles?.includes("prm") ||
          currentRoles?.includes("pco") ||
          currentRoles?.includes("arm") ||
          currentRoles?.includes("r1"),
        count: isCountShow
          ? isFilter && dataOption === "SETTLEMENT"
            ? totalCount
            : isFilter
            ? 0
            : casesCount?.settlement
          : "",
      },
      {
        id: 11,
        name: "Deallocation (Pending)",
        countName: "deAllocation",
        key: "DEALLOCATION_PENDING",
        visibleTo:
          (currentRoles?.includes("mis") ||
            currentRoles?.includes("op") ||
            currentRoles?.includes("ch") ||
            currentRoles?.includes("rh")) &&
          currentModule !== "Field",
        count: isCountShow
          ? isFilter && dataOption === "DEALLOCATION"
            ? totalCount
            : isFilter
            ? 0
            : casesCount?.deAllocation
          : "",
      },
      {
        id: 12,
        name: "Deallocation (Approved)",
        countName: "deAllocation",
        key: "DEALLOCATION_APPROVED",
        visibleTo:
          (currentRoles?.includes("mis") ||
            currentRoles?.includes("op") ||
            currentRoles?.includes("ch") ||
            currentRoles?.includes("rh")) &&
          currentModule !== "Field",
        count: isCountShow
          ? isFilter && dataOption === "DEALLOCATION_APPROVED"
            ? totalCount
            : isFilter
            ? 0
            : casesCount?.deAllocationApprove
          : "",
      },
      {
        id: 13,
        name: "Deallocation (Rejected)",
        countName: "deAllocation",
        key: "DEALLOCATION_REJECTED",
        visibleTo: currentRoles?.includes("mis") && currentModule !== "Field",
        count: isCountShow
          ? isFilter && dataOption === "DEALLOCATION_REJECTED"
            ? totalCount
            : isFilter
            ? 0
            : casesCount?.deAllocationReject
          : "",
      },
      {
        id: 14,
        name: "Case Closure (Pending)",
        countName: "requestForClouserPending",
        key: "CASE_CLOSER_PENDING",
        visibleTo:
          (currentRoles?.includes("cca") ||
            currentRoles?.includes("op") ||
            currentRoles?.includes("l01") ||
            currentRoles?.includes("l02") ||
            currentRoles?.includes("ca") ||
            currentRoles?.includes("sh") ||
            currentRoles?.includes("dra") ||
            currentRoles?.includes("fa") ||
            currentRoles?.includes("atl") ||
            currentRoles?.includes("aa") ||
            currentRoles?.includes("rh") ||
            currentRoles?.includes("ch") ||
            currentRoles?.includes("nrm") ||
            currentRoles?.includes("mis") ||
            currentRoles?.includes("zrm") ||
            currentRoles?.includes("rrm") ||
            currentRoles?.includes("prm") ||
            currentRoles?.includes("pco") ||
            currentRoles?.includes("arm") ||
            currentRoles?.includes("r1")) &&
          currentModule != "Field",
        count: isCountShow
          ? isFilter && dataOption === "CASE_CLOSE_PENDING"
            ? totalCount || caseCloaseTotalCount
            : isFilter
            ? 0
            : casesCount?.closePending
          : "",
      },
      {
        id: 15,
        name: "Case Closure (Approve)",
        countName: "requestForClouserApprove",
        key: "CASE_CLOSER_APPROVE",
        visibleTo:
          (currentRoles?.includes("cca") ||
            currentRoles?.includes("op") ||
            currentRoles?.includes("l01") ||
            currentRoles?.includes("l02") ||
            currentRoles?.includes("ca") ||
            currentRoles?.includes("sh") ||
            currentRoles?.includes("dra") ||
            currentRoles?.includes("fa") ||
            currentRoles?.includes("atl") ||
            currentRoles?.includes("aa") ||
            currentRoles?.includes("rh") ||
            currentRoles?.includes("ch") ||
            currentRoles?.includes("nrm") ||
            currentRoles?.includes("mis") ||
            currentRoles?.includes("zrm") ||
            currentRoles?.includes("rrm") ||
            currentRoles?.includes("prm") ||
            currentRoles?.includes("pco") ||
            currentRoles?.includes("arm") ||
            currentRoles?.includes("r1")) &&
          currentModule != "Field",
        count: isCountShow
          ? isFilter && dataOption === "CASE_CLOSER_APPROVE"
            ? totalCount || caseCloaseTotalCount
            : isFilter
            ? 0
            : casesCount?.closeApproved
          : "",
      },
      {
        id: 16,
        name: "Case Closure( Rejected)",
        countName: "requestForClouserRejected",
        key: "CASE_CLOSER_REJECTED",
        visibleTo:
          (currentRoles?.includes("cca") ||
            currentRoles?.includes("op") ||
            currentRoles?.includes("l01") ||
            currentRoles?.includes("l02") ||
            currentRoles?.includes("ca") ||
            currentRoles?.includes("sh") ||
            currentRoles?.includes("dra") ||
            currentRoles?.includes("fa") ||
            currentRoles?.includes("atl") ||
            currentRoles?.includes("aa") ||
            currentRoles?.includes("rh") ||
            currentRoles?.includes("ch") ||
            currentRoles?.includes("nrm") ||
            currentRoles?.includes("mis") ||
            currentRoles?.includes("zrm") ||
            currentRoles?.includes("rrm") ||
            currentRoles?.includes("prm") ||
            currentRoles?.includes("pco") ||
            currentRoles?.includes("arm") ||
            currentRoles?.includes("r1")) &&
          currentModule != "Field",
        count: isCountShow
          ? isFilter && dataOption === "CASE_CLOSER_REJECTED"
            ? totalCount || caseCloaseTotalCount
            : isFilter
            ? 0
            : casesCount?.closeRejected
          : "",
      },
    ],
    [casesCount, currentRoles, isFilter, totalCount]
  );

  const selectDropdown = useMemo(() => [
    { label: "Select All", value: 1 },
    { label: "Select only this page items", value: 2 },
  ]);
  const getCount = async () => {
    if (user?.userId) {
      try {
        const roleCode = user?.role?.map((a) => a?.roleCode);
        const primaryUrlForMis =
          currentModule === "Field" || user?.activityType === "Field"
            ? "/getCountCasesMISField"
            : "/getCountCasesMIS";
        const primaryUrl =
          currentModule === "Field" || user?.activityType === "Field"
            ? "/getCountField"
            : "/getCount";
        const primaryUrlForCA = "/getCountCA";
        const url =
          roleCode.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP")
            ? primaryUrlForMis
            : roleCode.includes("CA")
            ? primaryUrlForCA
            : roleCode.includes("DRA")
            ? "/getCountDRA"
            : primaryUrl;
        setTimeout(() => {
          dispatch(setLoader(true));
        }, 1000);
        const res = await axios.get(`${url}/${user?.userId}/${roleCode}`);
        setTimeout(() => {
          dispatch(setLoader(false));
        }, 1000);
        const data = res?.data?.data;
        const newCasesCount = {
          all:
            roleCode.includes("CA") || roleCode.includes("FA")
              ? data?.countCACaseAllocation
              : data?.allCount,
          new: data?.newCount,
          allocated: data?.allocatedCount,
          myCases:
            roleCode.includes("CA") || roleCode.includes("FA")
              ? data?.countCACaseAllocation
              : data?.myCases,
          inProgress:
            roleCode.includes("CA") || roleCode.includes("FA")
              ? data?.inprocessCA
              : data?.inProcresCount,
          unallocatedP: data?.unAllocated_p_Count,
          unallocatedA: data?.unAllocated_a_Count,
          unallocatedR: data?.unAllocated_Count,
          deAllocation: data?.deAllocationPending,
          deAllocationApprove: data?.deAllocationApprove,
          deAllocationReject: data?.deAllocationReject,
          requestForCloser: data?.requestForCloser,
          closeRejected: data?.closeRejected,
          closePending: data?.closePending,
          closeApproved: data?.closeApproved,
          foreclouser: data?.requestForCloser,
          settlement: data?.settlement,
        };
        setCasesCount(newCasesCount);
      } catch (error) {
        console.error("Error fetching data:", error);
        dispatch(setLoader(false));
      }
    }
  };
  const onAllocationClick = async () => {
    const timer = setInterval(() => {
      dispatch(setAction(1));
      extendToken(loginSessionTimeout);
    }, 60000); // every 60 seconds
    try {
      const roleCode = user?.role?.map((a) => a?.roleCode);
      let url1 = "";
      let allocationPayload = [];
      if (
        currentModule === "Field" &&
        (roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP"))
      ) {
        url1 = `autoAllocationField/${user?.userId}`;
        allocationPayload = selectedProducts;
      } else if (
        (roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP")) &&
        currentModule !== "Field"
      ) {
        url1 = "misAutoAllocationToCCA";
        allocationPayload = selectedProducts;
      } else {
        url1 = `autoAllocation/${user?.userId}`;
        allocationPayload = selectedProducts?.map((a) => a?.loanAccountNumber);
      }
      const url = allSelected ? `/${url1}/all` : `/${url1}/notall`;
      dispatch(setLoader(true));
      const res = await axios.post(baseUrl() + url, allocationPayload);
      if (res?.data?.msgKey === "Success") {
        Swal.fire({
          toast: true,
          position: "top-end",
          icon: "success",
          title: "Case Allocation Successfully.",
          showConfirmButton: false,
          timer: 4000,
          timerProgressBar: true,
          background: "#125120b5",
          color: "#fff",
          iconColor: "#fff",
        });
        setSelectedProducts([]);
        setAllSelected(false);
        setSelectValue({});
        setDataOption("ALL");
        if (
          roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP")
        ) {
          dispatch(
            getAllCases({
              currentPage,
              numberOfDataPerPage,
              currentModule,
            })
          );
        } else {
          dispatch(
            getUnallocatedCases({
              userId: user?.userId,
              currentPage,
              numberOfDataPerPage,
              activityType: currentModule || user?.activityType,
              userType: user?.userType,
            })
          );
        }
        if (isCountShow) {
          getCount();
        }
        window.location.reload();
      } else {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } finally {
      dispatch(setLoader(false));
      clearInterval(timer); // Clear the interval in any case
    }
  };
  const onAutoalloactionFilter = async () => {
    const timer = setInterval(() => {
      dispatch(setAction(1));
      extendToken(loginSessionTimeout);
    }, 60000);

    try {
      const roleCode = user?.role?.map((a) => a?.roleCode);
      const activeTab =
        dataOption?.charAt(0).toUpperCase() + dataOption.slice(1).toLowerCase();
      const dummyPayload = {
        ...filterPayload,
      };
      const payloadField = {
        allocationType: "AutoAllocationFieldMisToPrm",
        userIdTo: 0,
        roleId: 0,
        fromFieldPick: "",
        agencyIdForallocation: 0,
        filterType: "",
      };

      const payload = {
        allocationType: roleCode?.includes("MIS")
          ? "AutoAllocation"
          : "autoAllocationCCAToPRM",
        userIdTo: 0,
        roleId: 0,
        fromFieldPick: "",
        agencyIdForallocation: 0,
        filterType: "",
      };
      const finalpayload = currentModule === "Field" ? payloadField : payload;
      let bulkFilterDto = {
        ...finalpayload,
        bulkFilterDto: {
          ...dummyPayload,
        },
      };
      let url1 = "";
      if (
        currentModule === "Field" &&
        (roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP"))
      ) {
        url1 = `selectAllFilteredDataForMisField/${user?.userId}/${activeTab}/${
          activeAgency?.value || 0
        }`;
      } else if (
        (roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP")) &&
        currentModule !== "Field"
      ) {
        url1 = `selectAllFilteredDataForMisCalling/${
          user?.userId
        }/${activeTab}/${activeAgency?.value || 0}`;
      } else {
        url1 = `selectAllFilteredDataForCCAToPRM/${user?.userId}/${activeTab}/${
          activeAgency?.value || 0
        }`;
      }

      const url = allSelected ? `/${url1}` : `/${url1}`;

      dispatch(setLoader(true));
      const res = await axios.post(baseUrl() + url, bulkFilterDto);

      if (res?.data?.msgKey === "Success") {
        if (
          roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP")
        ) {
          dispatch(setLoader(true));
          setSelectedProducts([]);
          setSelectValue({});
          setClearFilterCount();
          setDataOption("ALL");
          setAllSelected(false);
          dispatch(
            getAllCases({
              currentPage,
              numberOfDataPerPage,
              currentModule,
            })
          );
          if (isCountShow) {
            getCount();
          }
          dispatch(setLoader(false));
        } else {
          Swal.fire({
            toast: true,
            position: "top-end",
            icon: "success",
            title: "Case Allocation Successfully.",
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true,
            background: "#125120b5",
            color: "#fff",
            iconColor: "#fff",
          });
          setSelectedProducts([]);
          setAllSelected(false);
          setSelectValue({});
          setDataOption("ALL");
          dispatch(
            getUnallocatedCases({
              userId: user?.userId,
              currentPage,
              numberOfDataPerPage,
              activityType: currentModule || user?.activityType,
              userType: user?.userType,
            })
          );
          if (isCountShow) {
            getCount();
          }
        }
      } else {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
      dispatch(setLoader(false));
      clearInterval(timer);
    } catch (error) {
      dispatch(setLoader(false));
      clearInterval(timer);
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
    window.location.reload();
  };
  const onManualAllocationClick = (e) => {
    manualAllocationRef.current.toggle(e);
  };
  const onDeallocationClick = () => {
    const selectedCount = getSelectedCasesCount(); // Get the count based on the selection
    Swal.fire({
      title: "Are you sure?",
      text: `You want to Deallocate ${selectedCount} Cases!`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((res) => {
      if (res?.isConfirmed) {
        onManualDeallocationClick();
      }
    });
  };
  const onManualDeallocationClick = async () => {
    try {
      dispatch(setLoader(true));
      const payload = {
        lans:
          selectValue?.value === 1
            ? []
            : selectedProducts?.map((a) => a?.loanAccountNumber),
        bulkFilter: {
          ...filterPayload,
        },
        tab:
          dataOption?.charAt(0).toUpperCase() +
          dataOption.slice(1).toLowerCase(),
        userid: user?.userId,
        agencyid: agencySelected?.value || "",
        caseType: currentModule ? "Field" : "Calling",
      };
      const res = await axios.post(`/deallocateFromMis`, payload);
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: "Deallocation Successful",
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
      setDataOption("ALL");
      setSelectedProductsCount(0);
      setSelectedProducts([]);
      setCurrentPage(1);
      if (isCountShow) {
        getCount();
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onSuccessAllocation = (e) => {
    onManualAllocationClick(e);
    setSelectedProducts([]);
    setAllSelected(false);
    setSelectValue({});
    setSelectedProductsCount(0);
    setCurrentPage(1);
    setSelectedProductsCount(0);
    if (isCountShow) {
      getCount();
    }
  };
  const checkIsPermission = useMemo(() => {
    if (user?.masterRole) {
      const roleKeyValue = Object.entries(user?.masterRole);
      let getCurrentRoleValues = roleKeyValue?.filter(
        (a) =>
          a[0]?.includes("caseactivity") ||
          (a[0]?.includes("customerprofile") && a)
      );
      getCurrentRoleValues =
        getCurrentRoleValues?.reduce((a, b) => ({ ...a, [b[0]]: b[1] }), {}) ||
        {};
      getCurrentRoleValues = Object.values(getCurrentRoleValues);
      return getCurrentRoleValues?.every((a) => a === null);
    }
  }, [user?.masterRole]);
  const roleCode = user?.role?.map((a) => a?.roleCode);
  useEffect(() => {
    if (checkIsPermission) {
      navigate("/dashboard");
    }
  }, []);
  const getSelectedCasesCount = () => {
    let count = 0;
    if (Object.values(selectValue)?.length) {
      if (allSelected) {
        count =
          dataOption === "ALL"
            ? allTotalCount
            : dataOption === "NEW"
            ? newTotalCount
            : dataOption === "MY_CASE"
            ? mycaseTotalCount
            : dataOption === "ALLOCATED"
            ? allocatedTotalCount
            : dataOption === "IN_PROGRESS"
            ? InprogressTotalCount
            : dataOption === "UNALLOCATED_PENDING"
            ? unalloactedPendingTotalCount || totalCount
            : dataOption === "UNALLOCATED_APPROVED"
            ? unalloactedApproveTotalCount
            : dataOption === "UNALLOCATED_REJECTED"
            ? unalloactedRejectTotalCount
            : dataOption === "CASE_CLOSER_REJECTED"
            ? caseCloaseTotalCount
            : dataOption === "CASE_CLOSER_APPROVE"
            ? caseCloaseTotalCount
            : dataOption === "CASE_CLOSER_PENDING"
            ? caseCloaseTotalCount
            : totalCount;
      } else {
        count = selectedProductsCount; // Assuming this is set correctly
      }
    } else {
      count = selectedProducts?.length;
    }
    return count;
  };
  <p>Selected Cases: {getSelectedCasesCount()}</p>;
  useEffect(() => {
    if (dataOption && user && Object.keys(user).length && !isFilter) {
      const roleCode = user?.role?.map((a) => a?.roleCode);
      const activityType = user?.activityType;
      switch (dataOption) {
        case "ALL":
          if (
            roleCode?.includes("MIS") ||
            roleCode.includes("RH") ||
            roleCode.includes("CH") ||
            roleCode.includes("OP")
          ) {
            dispatch(
              getAllCases({
                currentPage,
                numberOfDataPerPage,
                currentModule,
              })
            );
          } else {
            if (roleCode?.includes("FA") || roleCode?.includes("CA")) {
              const data = {
                userId: user?.userId,
                roleId: roleCode,
                currentPage,
                numberOfDataPerPage,
                dataOption,
              };
              if (user?.activityType === "Field" || currentModule === "Field") {
                dispatch(getDRACases(data));
              } else {
                dispatch(CACases(data));
              }
            } else if (roleCode?.includes("DRA")) {
              const data = {
                userId: user?.userId,
                roleId: roleCode,
                currentPage,
                numberOfDataPerPage,
              };
              dispatch(getDRACases(data));
            } else if (roleCode?.includes("L01") || roleCode?.includes("L02")) {
              const data = {
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                dataOption,
                filterpayload,
              };
              dispatch(getLenderAllCases(data));
            } else {
              dispatch(
                getUnallocatedCases({
                  userId: user?.userId,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                  userType: user?.userType,
                })
              );
            }
          }
          break;
        case "NEW":
          if (
            roleCode?.includes("MIS") ||
            roleCode.includes("RH") ||
            roleCode.includes("CH") ||
            roleCode.includes("OP")
          ) {
            dispatch(
              getNewMISCases({
                currentPage,
                numberOfDataPerPage,
                currentModule,
              })
            );
          } else {
            dispatch(
              getNewCasesForOtherRole({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
                userType: user?.userType,
              })
            );
          }
          break;
        case "ALLOCATED":
          if (
            roleCode?.includes("MIS") ||
            roleCode.includes("RH") ||
            roleCode.includes("CH") ||
            roleCode.includes("OP")
          ) {
            dispatch(
              getAllocatedMISCases({
                currentPage,
                numberOfDataPerPage,
                currentModule,
              })
            );
          } else {
            dispatch(
              getAllocatedCasesForOtherRole({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
                userType: user?.userType,
              })
            );
          }
          break;
        case "FORECLOSURE":
          if (
            roleCode?.includes("MIS") ||
            roleCode.includes("RH") ||
            roleCode.includes("CH") ||
            roleCode.includes("OP")
          ) {
            dispatch(
              getForeclouserMIS({
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
                userId: user?.userId,
              })
            );
          } else {
            dispatch(
              getForeclouser({
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
                isCA: roleCode?.includes("FA") || roleCode?.includes("CA"),
                isDRA: roleCode?.includes("DRA"),
                roleId: roleCode,
                userId: user?.userId,
              })
            );
          }
          break;
        case "MY_CASE":
          const normalizedRoleCode = roleCode
            ? String(roleCode).toLowerCase()
            : "";
          if (normalizedRoleCode === "dra") {
            const data = {
              userId: user?.userId,
              roleId: roleCode,
              currentPage,
              numberOfDataPerPage,
            };
            dispatch(getDRACases(data)); // Call getDRACases only for "dra"
          } else if (user?.masterRole?.caseactivity_manualallocation) {
            // If it's not "dra", but the user has "caseactivity_manualallocation" permission
            dispatch(
              getMyCasesForOtherRole({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
                userType: user?.userType,
              })
            );
          } else {
            // Handle other roles that are not "dra"
            if (
              normalizedRoleCode.includes("fa") ||
              normalizedRoleCode.includes("ca")
            ) {
              const data = {
                userId: user?.userId,
                roleId: roleCode,
                currentPage,
                numberOfDataPerPage,
              };
              if (user?.activityType === "Field" || currentModule === "Field") {
                dispatch(getDRACases(data));
              } else {
                dispatch(CACases(data));
              }
            } else if (normalizedRoleCode.includes("dra")) {
              const data = {
                userId: user?.userId,
                roleId: roleCode,
                currentPage,
                numberOfDataPerPage,
              };
              dispatch(getDRACases(data)); // This is still for "DRA" role.
            } else {
              dispatch(setList([])); // No cases to fetch
            }
          }
          break;

        case "IN_PROGRESS":
          if (roleCode?.includes("FA") || roleCode?.includes("CA")) {
            if (user?.activityType === "Field" || currentModule === "Field") {
              dispatch(
                getInProgressCasesDRA({
                  userId: user?.userId,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                })
              );
            } else {
              dispatch(
                getCAInProgressCases({
                  userId: user?.userId,
                  currentPage,
                  numberOfDataPerPage,
                })
              );
            }
          } else if (roleCode?.includes("DRA")) {
            dispatch(
              getInProgressCasesDRA({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          } else if (roleCode?.includes("L01")) {
            const data = {
              userId: user?.userId,
              currentPage,
              numberOfDataPerPage,
              dataOption,
              filterpayload,
            };
            dispatch(getLenderInprogressCases(data));
          } else {
            dispatch(
              getInProgressCases({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
                userType: user?.userType,
              })
            );
          }
          break;
        case "UNALLOCATED_PENDING":
          if (
            roleCode?.includes("DRA") ||
            (roleCode?.includes("FA") && !currentModule === "Field")
          ) {
            dispatch(
              getUnallocatedCasesPendingDRA({
                userId: user?.userId,
                roleId: roleCode,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          } else if (roleCode?.includes("CA") || roleCode?.includes("FA")) {
            if (user?.activityType === "Field" || currentModule === "Field") {
              dispatch(
                getUnallocatedCasesPendingDRA({
                  userId: user?.userId,
                  roleId: roleCode,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                })
              );
            } else {
              dispatch(
                getUnallocatedCasesPendingCA({
                  userId: user?.userId,
                  roleId: roleCode,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                })
              );
            }
          } else {
            dispatch(
              getUnallocatedCasesPending({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          }
          break;
        case "UNALLOCATED_APPROVED":
          if (
            roleCode?.includes("DRA") ||
            (roleCode?.includes("FA") && !currentModule === "Field")
          ) {
            dispatch(
              getUnallocatedCasesApprovedDRA({
                userId: user?.userId,
                roleId: roleCode,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          } else if (roleCode?.includes("CA") || roleCode?.includes("FA")) {
            if (user?.activityType === "Field" || currentModule === "Field") {
              dispatch(
                getUnallocatedCasesApprovedDRA({
                  userId: user?.userId,
                  roleId: roleCode,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                })
              );
            } else {
              dispatch(
                getUnallocatedCasesApprovedCA({
                  userId: user?.userId,
                  roleId: roleCode,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                })
              );
            }
          } else {
            dispatch(
              getUnallocatedCasesApproved({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          }
          break;
        case "UNALLOCATED_rejected":
          if (
            roleCode?.includes("DRA") ||
            (roleCode?.includes("FA") && !currentModule === "Field")
          ) {
            dispatch(
              getUnallocatedCasesRejectedDRA({
                userId: user?.userId,
                roleId: roleCode,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          } else if (roleCode?.includes("CA") || roleCode?.includes("FA")) {
            if (user?.activityType === "Field" || currentModule === "Field") {
              dispatch(
                getUnallocatedCasesRejectedDRA({
                  userId: user?.userId,
                  roleId: roleCode,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                })
              );
            } else {
              dispatch(
                getUnallocatedCasesRejectedCA({
                  userId: user?.userId,
                  roleId: roleCode,
                  currentPage,
                  numberOfDataPerPage,
                  activityType: currentModule || activityType,
                })
              );
            }
          } else {
            dispatch(
              getUnallocatedCasesRejected({
                userId: user?.userId,
                currentPage,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          }
          break;
        case "SETTLEMENT":
          dispatch(
            getSettlementCases({
              userId: user?.userId,
              currentPage,
              numberOfDataPerPage,
              activityType: currentModule || activityType,
            })
          );
          break;
        case "DEALLOCATION_PENDING":
          dispatch(
            getDeallocated({
              currentPage,
              numberOfDataPerPage,
              tab: "Pending",
            })
          );
          break;
        case "DEALLOCATION_APPROVED":
          dispatch(
            getDeallocated({
              currentPage,
              numberOfDataPerPage,
              tab: "Approved",
            })
          );
          break;
        case "DEALLOCATION_REJECTED":
          dispatch(
            getDeallocated({
              currentPage,
              numberOfDataPerPage,
              tab: "Rejected",
            })
          );
          break;
        case "CASE_CLOSER_PENDING":
          if (roleCode?.includes("L01") || roleCode?.includes("L02")) {
            const data = {
              userId: user?.userId,
              currentPage,
              numberOfDataPerPage,
              dataOption,
              filterpayload,
            };
            dispatch(getLenderCaseCloase(data));
          } else {
            dispatch(
              getClouserRequestPending({
                roleCode: roleCode,
                currentPage,
                currentTab: "Pending",
                userId: user?.userId,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          }

          break;
        case "CASE_CLOSER_REJECTED":
          if (roleCode?.includes("L01") || roleCode?.includes("L02")) {
            const data = {
              userId: user?.userId,
              currentPage,
              numberOfDataPerPage,
              dataOption,
              filterpayload,
            };
            dispatch(getLenderCaseCloase(data));
          } else {
            dispatch(
              getClouserRequestPending({
                roleCode: roleCode,
                currentPage,
                currentTab: "Rejected",
                userId: user?.userId,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          }
          break;
        case "CASE_CLOSER_APPROVE":
          if (roleCode?.includes("L01") || roleCode?.includes("L02")) {
            const data = {
              userId: user?.userId,
              currentPage,
              numberOfDataPerPage,
              dataOption,
              filterpayload,
            };
            dispatch(getLenderCaseCloase(data));
          } else {
            dispatch(
              getClouserRequestPending({
                roleCode: roleCode,
                currentPage,
                currentTab: "Approved",
                userId: user?.userId,
                numberOfDataPerPage,
                activityType: currentModule || activityType,
              })
            );
          }
          break;
        default:
      }
      // }
    }
  }, [
    dataOption,
    user,
    clearFilterCount,
    reload,
    numberOfDataPerPage,
    currentPage,
    clearFilterCount,
    currentModule,
    reset,
    isFilter,
  ]);

  useEffect(() => {
    if (Object.keys(selectValue).length && selectValue?.value !== 2) {
      const data = caseLists?.filter((a) =>
        !["DEALLOCATION_APPROVED", "DEALLOCATION_REJECTED"].includes(
          dataOption
        ) &&
        (currentModule === "Field" || user?.activityType === "Field")
          ? ["NEW", "ALLOCATED", "MY_CASE", "DEALLOCATION_PENDING"].includes(
              dataOption
            ) ||
            (dataOption === "ALL" && a?.[caseStatusField] !== "Allocated")
          : (["NEW", "ALLOCATED", "MY_CASE", "DEALLOCATION_PENDING"].includes(
              dataOption
            ) ||
              a?.[caseStatusField] !== "Allocated") &&
            a?.fieldPickUp !== "P" &&
            a?.fieldPickUp !== "Y" &&
            ![
              "DEALLOCATION_APPROVED",
              "DEALLOCATION_REJECTED",
              "UNALLOCATED_APPROVED",
            ].includes(dataOption)
      );
      // const newData = dataOption === "ALL" ? selectValue?.value === 2 ? data : [...selectedProducts, ...data] : selectValue?.value === 2 ? caseLists : [...selectedProducts, ...caseLists]
      const newData =
        selectValue?.value === 2 ? data : [...selectedProducts, ...data];
      const finalData = newData.filter(
        (a, i, b) =>
          b.findIndex((c) => c?.loanAccountNumber === a?.loanAccountNumber) ===
          i
      );

      setSelectedProducts(finalData);
      const getCount =
        dataOption === "ALL"
          ? totalStages?.find((a) => a?.key === "NEW")?.count
          : totalStages?.find((a) => a?.key === dataOption)?.count;

      // && dataOption == "NEW" && dataOption=="ALLOCATED" && !isfilter
      if (!isfilter) {
        // const role= ["dra", "ca", "cca"]
        setSelectedProductsCount(
          selectValue?.value === 1
            ? dataOption == "ALL"
              ? casesCount.all
              : dataOption == "NEW"
              ? casesCount.new
              : dataOption == "MY_CASE"
              ? casesCount.myCases
              : dataOption == "ALLOCATED"
              ? casesCount.allocated
              : dataOption == "IN_PROGRESS"
              ? casesCount.inProgress
              : dataOption == "UNALLOCATED_PENDING"
              ? casesCount.unallocatedP
              : 0
            : finalData?.length
        );
      } else {
        setSelectedProductsCount(
          selectValue?.value === 1 ? getCount : finalData?.length
        );
      }
    }
  }, [caseLists, dataOption, allSelected, selectValue]);
  useEffect(() => {
    const getUser = async () => {
      dispatch(setLoader(true));
      try {
        // const res = await axios.get('/getAllUserList')
        const res = await axios.get("/getUserForAllocation");
        dispatch(setLoader(false));
        const names = {};
        res?.data?.data?.filter((a) => a);
        res?.data?.data?.map((a) => {
          Object.assign(names, {
            [a?.userId]: `${a?.firstName} ${a?.lastName}`,
          });
        });
        setUserNames(names);
      } catch (error) {
        dispatch(setLoader(false));
      }
    };

    const getAgency = async () => {
      try {
        dispatch(setLoader(true));
        const res = await axios.get("/getAllAgency");
        const names = {};
        res?.data?.data?.map((a) => {
          Object.assign(names, { [a?.agencyId]: a?.agencyName });
        });
        const tempData = [];
        res?.data?.data?.forEach((lender) => {
          tempData.push({
            label: lender?.agencyName,
            value: lender?.agencyId,
          });
        });
        setActiveAgency(tempData);
        setAgencyNames(names);
        dispatch(setLoader(false));
      } catch (error) {
        dispatch(setLoader(false));
      }
    };
    getUser();
    getAgency();
  }, []);

  const onFieldClick = (e) => {
    const roleCode = user?.role?.map((a) => a?.roleCode);

    setCurrentModule(currentModule !== "Field" ? "Field" : "");
    hideCount();
    setCaseStatusField(
      currentModule !== "Field" &&
        (roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP"))
        ? "fieldCaseStatus"
        : "caseStatus"
    );
    setAllocatedUserField(
      currentModule !== "Field" &&
        (roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP"))
        ? "allocatedUserField"
        : "allocatedUser"
    );
    setSelectValue({});
    setSelectedProducts([]);
    setSelectedProductsCount(0);
    setCurrentPage(1);
    manualAllocationRef.current.hide(e);
  };

  const exportSelectedData = (pageSelected) => {
    const products = pageSelected ? caseLists : selectedProducts;
    const downloadData = products?.map((a) => ({
      ...a,
      assingedAgency: agencyNames?.[a?.assingedAgency],
      allocatedUser:
        dataOption === "MY_CASE" || a?.[allocatedUserField] === user?.userId
          ? "Self"
          : userNames?.[a?.[allocatedUserField]],
    }));
    downloadExcel(downloadData, "SelectedCases.xlsx");
  };
  const exportFilterData = async () => {
    dispatch(setLoader(true));
    try {
      let payload = filterPayload;
      const roleCode = user?.role?.map((a) => a?.roleCode);
      const activeTab =
        dataOption?.charAt(0).toUpperCase() + dataOption.slice(1).toLowerCase();
      let url =
        roleCode?.includes("MIS") ||
        roleCode.includes("RH") ||
        roleCode.includes("CH") ||
        roleCode.includes("OP")
          ? currentModule === "Field"
            ? `/getFilterBulkUpLoadByMISFieldExport/${
                user?.userId
              }/${activeTab}/${agencySelected?.value || 0}`
            : `/getFilterBulkUpLoadByMISExport/${user?.userId}/${activeTab}/${
                agencySelected?.value || 0
              }`
          : roleCode?.includes("CA") || roleCode?.includes("FA")
          ? `getFilterBulkUpLoadByAllCAExport/${
              user?.userId
            }/${activeTab}/${roleCode}/${agencySelected?.value || 0}`
          : roleCode?.includes("DRA")
          ? `getFilterBulkUpLoadByAllFieldDRAExport/${
              user?.userId
            }/${activeTab}/${roleCode}/${agencySelected?.value || 0}`
          : currentModule === "Field" || user?.activityType === "Field"
          ? `getFilterBulkUpLoadByAllFieldExport/${user?.userId}/${activeTab}/${
              agencySelected?.value || 0
            }`
          : `getFilterBulkUpLoadByAllExport/${user?.userId}/${activeTab}/${
              agencySelected?.value || 0
            }`;

      const res = await axios.post(`${url}`, payload, {
        responseType: "arraybuffer",
      });
      const blob = new Blob([res.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      dispatch(setLoader(false));
      saveAs(blob, `FilterCases.xlsx`);
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onExportData = async () => {
    try {
      dispatch(setLoader(true));
      let payload = {};
      let url = "";
      if (isFilter || selectValue?.value === 1 || !selectedProducts?.length) {
        payload = filterPayload;
        const roleCode = user?.role?.map((a) => a?.roleCode);
        const activeTab =
          dataOption?.charAt(0).toUpperCase() +
          dataOption.slice(1).toLowerCase();
        url =
          roleCode?.includes("MIS") ||
          roleCode.includes("RH") ||
          roleCode.includes("CH") ||
          roleCode.includes("OP")
            ? currentModule === "Field"
              ? `/getFilterBulkUpLoadByMISFieldExport/${
                  user?.userId
                }/${activeTab}/${agencySelected?.value || 0}`
              : `/getFilterBulkUpLoadByMISExport/${user?.userId}/${activeTab}/${
                  agencySelected?.value || 0
                }`
            : roleCode?.includes("CA") || roleCode?.includes("FA")
            ? `getFilterBulkUpLoadByAllCAExport/${
                user?.userId
              }/${activeTab}/${roleCode}/${agencySelected?.value || 0}`
            : roleCode?.includes("DRA")
            ? `getFilterBulkUpLoadByAllFieldDRAExport/${
                user?.userId
              }/${activeTab}/${roleCode}/${agencySelected?.value || 0}`
            : currentModule === "Field" || user?.activityType === "Field"
            ? `getFilterBulkUpLoadByAllFieldExport/${
                user?.userId
              }/${activeTab}/${agencySelected?.value || 0}`
            : `getFilterBulkUpLoadByAllExport/${user?.userId}/${activeTab}/${
                agencySelected?.value || 0
              }`;
      } else if (selectValue?.value === 2 || selectedProducts.length) {
        payload = selectedProducts?.map((a) => a?.loanAccountNumber);
        url = "/getManualExport";
      }
      const res = await axios.post(`${url}`, payload, {
        responseType: "arraybuffer",
      });
      if (res?.status === 200) {
        dispatch(setLoader(false));
        const blob = new Blob([res.data], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        saveAs(blob, `FilterCases.xlsx`);
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const handleClick = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You want to close selected cases!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then(async (res) => {
      if (res?.isConfirmed) {
        try {
          const activityType = user?.activityType;
          const url =
            currentModule === "Field" || activityType === "Field"
              ? "/updateStatusAfterCloserRequestApprovedFromPortfolioCoordinatorField"
              : "/updateStatusAfterCloserRequestApprovedFromPortfolioCoordinator";
          dispatch(setLoader(true));
          const res = axios.post(
            `${url}/${selectedProducts[0]?.loanAccountNumber}`
          );
          dispatch(setLoader(false));
          setSelectedProducts([]);
          setCurrentPage(1);
          setDataOption(dataOption === "ALL" ? "NEW" : "ALL");
          setSelectedProductsCount(0);
          if (isCountShow) {
            getCount();
          }

          Swal.fire({
            position: "top-end",
            icon: "success",
            title: res?.data?.message,
            showConfirmButton: false,
            toast: true,
            timer: 3000,
          });
        } catch (error) {
          dispatch(setLoader(false));
        }
      }
    });
  };
  const handleCaseClose = () => {
    setcaseCloseOpen(!caseClose);
  };
  const handleLenderCaseAutoAllocation = async () => {
    let lans = null;
    if (allSelected === false) {
      lans = selectedProducts?.map((item) => item?.loanAccountNumber);
    } else {
      lans = [];
    }
    try {
      const res = await axios.post(`/allocateToLender/${user.userId}`, lans);
      if (res?.data?.msgKey === "Success") {
        dispatch(setLoader(true));
        setSelectedProducts([]);
        setAllSelected(false);
        setSelectValue({});
        dispatch(
          getClouserRequestPending({
            roleCode: roleCode,
            currentPage,
            currentTab: "Pending",
            userId: user?.userId,
            numberOfDataPerPage,
          })
        );
        // dispatch(getLenderAllCases(data))
        if (isCountShow) {
          getCount();
        }
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: res?.data?.message,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      } else {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: res?.data?.message,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: error,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onFieldList = async () => {
    try {
      dispatch(setLoader(true));
      let url = allSelected
        ? "/addFieldVisitRequest/all"
        : "/addFieldVisitRequest/notAll";
      const tab =
        dataOption === "NEW"
          ? "New"
          : dataOption === "ALLOCATED"
          ? "Allocated"
          : "My Cases";
      url = `${url}/${tab}`;
      const payload = allSelected
        ? []
        : selectedProducts?.map((a) => a?.loanAccountNumber);
      const res = await axios.post(url, payload);
      dispatch(setLoader(false));
      setSelectedProducts([]);
      setSelectedProductsCount(0);
      setAllSelected(false);
      setDataOption(dataOption === "ALL" ? "NEW" : "ALL");
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: res?.data?.message,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const hideCount = () => {
    setCasesCount({
      all: 0,
      new: 0,
      allocated: 0,
      myCases: 0,
      inProgress: 0,
      unallocatedP: 0,
      unallocatedA: 0,
      unallocatedR: 0,
      foreclouser: 0,
      settlement: 0,
      requestForCloser: 0,
    });
  };
  const onDeallocationAction = async (action) => {
    try {
      dispatch(setLoader(true));
      const url =
        action === "Approved" ? "/approveDeallocated" : "/rejectDeallocated";
      const payload = allSelected
        ? []
        : selectedProducts?.map((a) => a?.loanAccountNumber);
      const res = await axios.post(url, payload);
      dispatch(setLoader(false));
      if (res?.data?.messageKey) {
        dispatch(
          getDeallocated({
            currentPage,
            numberOfDataPerPage,
            tab: "Pending",
          })
        );
        if (isCountShow) {
          getCount();
        }
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      } else {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${res?.data?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onDeallocationActionClick = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You want to Deallocate the Cases!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Approve",
      cancelButtonText: "Reject",
    }).then((res) => {
      if (res?.isConfirmed) {
        onDeallocationAction("Approved");
      } else if (res?.isDismissed && res?.dismiss !== "backdrop") {
        onDeallocationAction("Rejected");
      }
    });
  };
  const clearSearch = () => {
    dispatch(setAgencySelected(""));
    setLenderSelected([]);
    setSearchLAN("");
    setSelectAllocatedUser("");
    setSearchBorrower("");
    setIsFilter(false);
    setClearFilterCount(clearFilterCount + 1);
  };
  var selectedallproductscount =
    isfilter && dataOption == "ALL"
      ? allTotalCount
      : isfilter && dataOption == "NEW"
      ? newTotalCount
      : isfilter && dataOption == "ALLOCATED"
      ? allocatedTotalCount
      : selectedallproductscount;
  return (
    <Container fluid className="d-flex flex-column flex-grow-1 p-0">
      <CaseFilterForm
        activeTab={dataOption}
        clearFilter={() => setClearFilterCount(clearFilterCount + 1)}
        setIsFilter={(data) => setIsFilter(data)}
        onFieldClick={onFieldClick}
        currentModule={currentModule}
        setCurrentModule={setCurrentModule}
        numberOfDataPerPage={numberOfDataPerPage}
        handleChildStateChange={handleChildStateChange}
        currentPage={currentPage}
        isAutoAllocated={isAutoAllocated}
        allSelected={allSelected}
        isFilter={isFilter}
        activeAgency={activeAgency}
        setFilterPayload={setFilterPayload}
        fltrPayload={fltrPayload}
        setLenderSelected={setLenderSelected}
        setSearchLAN={setSearchLAN}
        setSelectAllocatedUser={setSelectAllocatedUser}
        setSearchBorrower={setSearchBorrower}
        lenderSelected={lenderSelected}
        searchLAN={searchLAN}
        selectAllocatedUser={selectAllocatedUser}
        searchBorrower={searchBorrower}
      />
      <Card className="flex-grow-1 mb-1">
        <CardBody
          className="d-flex flex-column"
          style={{ minHeight: 400, padding: "5px" }}
        >
          <div className="casesTabContaier">
            <div className="casesTab">
              {totalStages?.map((btn) => {
                if (btn?.visibleTo) {
                  return (
                    <Button
                      key={btn?.id}
                      size="sm"
                      outline
                      color="primary"
                      active={dataOption === btn?.key}
                      className="tabBtn"
                      onClick={(e) => {
                        if (dataOption !== btn?.key) {
                          dispatch(setList([]));
                          setDataOption(btn?.key);
                          manualAllocationRef.current.hide(e);
                          setSelectedProducts([]);
                          setCurrentPage(1);
                          setAllSelected(false);
                          setSelectValue({});
                        }
                      }}
                    >
                      {btn?.name} <b>{btn?.count}</b>
                    </Button>
                  );
                }
              })}
              <p
                className="countBtn"
                onClick={isCountShow ? hideCount : getCount}
              >
                {isCountShow ? "Hide" : "Show"} Count
              </p>
            </div>
            <div className="exportBtns d-flex justify-content-end">
              <Button
                size="sm"
                color="primary"
                outline
                className="m-1"
                onClick={onExportData}
              >
                Export
              </Button>
              {Boolean(
                (selectedProducts.length > 0 ||
                  (selectValue?.value === 1 && casesCount?.new)) &&
                  (currentRoles.includes("prm") ||
                    currentRoles.includes("arm") ||
                    currentRoles.includes("rrm") ||
                    currentRoles.includes("zrm") ||
                    currentRoles.includes("nrm") ||
                    currentRoles.includes("cca") ||
                    currentRoles.includes("op")) &&
                  ["NEW", "ALLOCATED", "MY_CASE"]?.includes(dataOption) &&
                  (user?.activityType === "Calling" ||
                    user?.activityType === "Both") &&
                  currentModule !== "Field"
              ) && (
                <Button
                  size="sm"
                  color="primary"
                  outline
                  className="m-1 btn-whitespace"
                  onClick={onFieldList}
                >
                  Field Visit
                </Button>
              )}
              {Boolean(
                (selectedProducts.length > 0 ||
                  (selectValue?.value === 1 && casesCount?.new)) &&
                  [
                    "ALL",
                    "NEW",
                    "CLOUSER_REQUEST",
                    "CASE_CLOSER_PENDING",
                  ]?.includes(dataOption)
              ) && (
                <>
                  {user?.masterRole?.caseactivity_autoallocation &&
                    ["ALL", "NEW"]?.includes(dataOption) && (
                      <Button
                        size="sm"
                        color="primary"
                        outline
                        className="m-1 btn-whitespace"
                        onClick={
                          (isfilter || isSearch) && allSelected
                            ? onAutoalloactionFilter
                            : onAllocationClick
                        }
                      >
                        Auto Allocation
                      </Button>
                    )}
                  {user?.masterRole?.caseactivity_manualallocation &&
                    dataOption != "CASE_CLOSER_PENDING" && (
                      <Button
                        size="sm"
                        color="primary"
                        outline
                        className="m-1"
                        onClick={onManualAllocationClick}
                      >
                        Allocation
                      </Button>
                    )}
                  {user?.masterRole?.caseactivity_manualallocation &&
                    currentRoles?.includes("mis") &&
                    dataOption == "CASE_CLOSER_PENDING" && (
                      <Button
                        size="sm"
                        color="primary"
                        outline
                        className="m-1"
                        onClick={onManualAllocationClick}
                      >
                        PCO Allocation
                      </Button>
                    )}
                  {["CASE_CLOSER_PENDING"]?.includes(dataOption) &&
                    currentRoles?.includes("pco") && (
                      <>
                        <Button
                          size="sm"
                          color="primary"
                          outline
                          className="m-1"
                          onClick={handleCaseClose}
                        >
                          Case Close
                        </Button>
                        <Button
                          size="sm"
                          color="primary"
                          outline
                          className="m-1"
                          onClick={handleLenderCaseAutoAllocation}
                        >
                          Lender Allocation
                        </Button>
                      </>
                    )}
                  {["CASE_CLOSER_PENDING"]?.includes(dataOption) &&
                    (currentRoles?.includes("l02") ||
                      currentRoles?.includes("l01")) && (
                      <>
                        <Button
                          size="sm"
                          color="primary"
                          outline
                          className="m-1"
                          onClick={handleCaseClose}
                        >
                          Case Close
                        </Button>
                      </>
                    )}
                </>
              )}
              {selectedProducts.length > 0 &&
                ["DEALLOCATION_PENDING"]?.includes(dataOption) &&
                (currentRoles?.includes("MIS") ||
                  currentRoles?.includes("ch") ||
                  currentRoles?.includes("op") ||
                  currentRoles?.includes("rh")) && (
                  <Button
                    size="sm"
                    color="primary"
                    outline
                    className="m-1"
                    onClick={onDeallocationActionClick}
                  >
                    Deallocate Action
                  </Button>
                )}
              {selectedProducts.length > 0 &&
                ["NEW", "ALLOCATED"].includes(dataOption) &&
                currentRoles.includes("mis") && (
                  <Button
                    size="sm"
                    color="primary"
                    outline
                    className="m-1"
                    onClick={onDeallocationClick}
                  >
                    Deallocation
                  </Button>
                )}
            </div>
          </div>
          <DataTable
            value={caseLists}
            selectionMode={"checkbox"}
            sortMode="multiple"
            removableSort
            size={"small"}
            tableStyle={{ minWidth: "50rem" }}
            className="d-flex flex-column flex-grow-1 casesTable"
            style={{ height: 1 }}
            rowClassName={(data) =>
              dataOption == "DEALLOCATION_PENDING" ||
              dataOption == "CASE_CLOSER_PENDING"
                ? " "
                : dataOption == "CASE_CLOSER_APPROVE" ||
                  dataOption == "CASE_CLOSER_REJECTED"
                ? "p-disabled c-disabled"
                : currentModule === "Field" || user?.activityType === "Field"
                ? (dataOption === "ALL" &&
                    data?.[caseStatusField] === "Allocated") ||
                  [
                    "UNALLOCATED_APPROVED",
                    "UNALLOCATED_rejected",
                    "FORECLOSURE",
                    "SETTLEMENT",
                    "DEALLOCATION_APPROVED",
                    "DEALLOCATION_REJECTED",
                  ]?.includes(dataOption)
                  ? "p-disabled c-disabled"
                  : ""
                : (dataOption === "ALL" &&
                    data?.[caseStatusField] === "Allocated") ||
                  (data?.fieldPickUp === "Y" &&
                    user?.activityType !== "Field" &&
                    currentModule !== "Field") ||
                  [
                    "UNALLOCATED_APPROVED",
                    "UNALLOCATED_rejected",
                    "FORECLOSURE",
                    "SETTLEMENT",
                    "DEALLOCATION_APPROVED",
                    "DEALLOCATION_REJECTED",
                  ]?.includes(dataOption) ||
                  data?.fieldPickUp === "P" ||
                  (data?.fieldPickUp === "Y" &&
                    data?.[caseStatusField] === "Allocated")
                ? "p-disabled c-disabled"
                : ""
            }
            footer={
              <div className="tableCountFooter">
                <p>
                  Total Overdue Amount:{" "}
                  {Number(
                    Number(
                      caseLists?.length
                        ? caseLists
                            ?.map((a) => a?.totalOverdueAmount)
                            ?.reduce((a, b) => a + b) || 0
                        : 0
                    )?.toFixed(2)
                  )?.toLocaleString("en-IN", {
                    style: "currency",
                    currency: "INR",
                  })}
                </p>
                <p>
                  Total Cases:{" "}
                  {dataOption === "ALL"
                    ? allTotalCount
                    : dataOption === "NEW"
                    ? newTotalCount
                    : dataOption === "MY_CASE"
                    ? mycaseTotalCount
                    : dataOption === "ALLOCATED"
                    ? allocatedTotalCount
                    : dataOption === "IN_PROGRESS"
                    ? InprogressTotalCount
                    : dataOption === "UNALLOCATED_PENDING"
                    ? unalloactedPendingTotalCount || totalCount
                    : dataOption === "UNALLOCATED_APPROVED"
                    ? unalloactedApproveTotalCount
                    : dataOption === "UNALLOCATED_rejected"
                    ? unalloactedRejectTotalCount
                    : dataOption === "CASE_CLOSER_REJECTED"
                    ? caseCloaseTotalCount
                    : dataOption === "CASE_CLOSER_APPROVE"
                    ? caseCloaseTotalCount
                    : dataOption === "CASE_CLOSER_PENDING"
                    ? caseCloaseTotalCount
                    : totalCount}
                </p>
                <p>Selected Cases: {getSelectedCasesCount()}</p>
              </div>
            }
          >
            <Column
              headerStyle={{ width: "3rem" }}
              className="cases-select-col"
              header={(data) => {
                return (
                  <Select
                    onChange={(e) => {
                      if (e?.value === selectValue?.value) {
                        setSelectValue({});
                        setAllSelected(false);
                        setSelectedProducts([]);
                        setSelectedProductsCount(0);
                      } else {
                        setSelectValue(e);
                        setAllSelected(e?.value === 1);
                      }
                      if (e?.value !== selectValue?.value) {
                        if (dataOption == "DEALLOCATION_PENDING") {
                          var data = caseLists?.filter((a) =>
                            ![
                              "DEALLOCATION_APPROVED",
                              "DEALLOCATION_REJECTED",
                            ].includes(dataOption) &&
                            (currentModule === "Field" ||
                              user?.activityType === "Field")
                              ? [
                                  "NEW",
                                  "ALLOCATED",
                                  "MY_CASE",
                                  "DEALLOCATION_PENDING",
                                  "IN_PROGRESS",
                                ].includes(dataOption) ||
                                (dataOption === "ALL" &&
                                  a?.[caseStatusField] !== "Allocated")
                              : ([
                                  "NEW",
                                  "ALLOCATED",
                                  "MY_CASE",
                                  "DEALLOCATION_PENDING",
                                  "IN_PROGRESS",
                                ].includes(dataOption) ||
                                  a?.[caseStatusField] !== "Allocated") &&
                                a?.fieldPickUp !== "P" &&
                                (a?.fieldPickUp !== "Y" ||
                                  a?.fieldPickUp == "Y") &&
                                ![
                                  "DEALLOCATION_APPROVED",
                                  "DEALLOCATION_REJECTED",
                                  "UNALLOCATED_APPROVED",
                                ].includes(dataOption)
                          );
                        } else {
                          var data = caseLists?.filter((a) =>
                            ![
                              "DEALLOCATION_APPROVED",
                              "DEALLOCATION_REJECTED",
                            ].includes(dataOption) &&
                            (currentModule === "Field" ||
                              user?.activityType === "Field")
                              ? [
                                  "NEW",
                                  "ALLOCATED",
                                  "MY_CASE",
                                  "CASE_CLOSER_PENDING",
                                  "DEALLOCATION_PENDING",
                                  "IN_PROGRESS",
                                ].includes(dataOption) ||
                                (dataOption === "ALL" &&
                                  a?.[caseStatusField] !== "Allocated")
                              : ([
                                  "NEW",
                                  "ALLOCATED",
                                  "MY_CASE",
                                  "DEALLOCATION_PENDING",
                                  "IN_PROGRESS",
                                  "CASE_CLOSER_PENDING",
                                ].includes(dataOption) ||
                                  a?.[caseStatusField] !== "Allocated") &&
                                ((a?.fieldPickUp !== "P" &&
                                  a?.fieldPickUp !== "Y" &&
                                  ![
                                    "DEALLOCATION_APPROVED",
                                    "DEALLOCATION_REJECTED",
                                    "CASE_CLOSER_REJECTED",
                                    "CASE_CLOSER_APPROVED",
                                    "UNALLOCATED_APPROVED",
                                  ].includes(dataOption)) ||
                                  (dataOption == "CASE_CLOSER_PENDING" &&
                                    a?.fieldPickUp == "Y"))
                          );
                        }
                        const newData =
                          e?.value === 2
                            ? data
                            : [...selectedProducts, ...data];
                        const finalData = newData.filter(
                          (a, i, b) =>
                            b.findIndex(
                              (c) =>
                                c?.loanAccountNumber === a?.loanAccountNumber
                            ) === i
                        );
                        setSelectedProducts(finalData);
                        const getCount =
                          dataOption === "ALL"
                            ? totalStages?.find((a) => a?.key === "NEW")?.count
                            : totalStages?.find((a) => a?.key === dataOption)
                                ?.count;
                        setSelectedProductsCount(
                          e?.value === 1 ? getCount : finalData?.length
                        );
                      }
                    }}
                    options={selectDropdown}
                    classNamePrefix="react-select"
                    value={selectValue}
                    classNames={{
                      container: () => "react-select-selection-container",
                      valueContainer: () => "value-container",
                      indicatorsContainer: () => "indicator",
                    }}
                    menuPosition="fixed"
                    hideSelectedOptions={false}
                    closeMenuOnSelect={true}
                    isClearable={true}
                  />
                );
              }}
              body={(data) => {
                return (
                  <Input
                    type="checkbox"
                    className="cases-select-checkbox"
                    name={data?.loanAccountNumber}
                    onChange={(e) => {
                      if (e?.target?.checked) {
                        setSelectedProducts([...selectedProducts, data]);
                      } else {
                        const newData = selectedProducts?.filter(
                          (a) => a?.loanAccountNumber !== e.target?.name
                        );
                        setSelectedProducts(newData);
                      }
                      setAllSelected(false);
                      setSelectValue({});
                    }}
                    checked={selectedProducts
                      ?.map((a) => a?.loanAccountNumber)
                      .includes(data?.loanAccountNumber)}
                  />
                );
              }}
            />
            <Column
              field="loanAccountNumber"
              sortable
              header="LAN ID"
              body={(rowData) => {
                if (isCaseProfileVisible) {
                  return (
                    <Link
                      to={`/case_profile/${dataOption}/${
                        currentModule ? currentModule : "calling"
                      }/${rowData.loanAccountNumber}`}
                      className="caseId"
                    >
                      {rowData.loanAccountNumber}
                    </Link>
                  );
                } else {
                  return <span>{rowData.loanAccountNumber}</span>;
                }
              }}
            ></Column>
            <Column field="name" sortable header="Name"></Column>
            <Column
              field="totalOverdueAmount"
              sortable
              header="Total Overdue Amount"
              body={(rowData) => {
                let amount = String(rowData.totalOverdueAmount);
                amount = amount.includes(".")
                  ? Number(amount)
                  : Number(`${amount}.00`);
                amount = amount.toLocaleString("en-IN", {
                  style: "currency",
                  currency: "INR",
                });
                return <span>{amount}</span>;
              }}
            ></Column>
            <Column
              field=""
              sortable
              header="Followup Call"
              body={(rowData) => {
                let date = rowData?.reReach
                  ? new Date(rowData?.reReach)?.toLocaleDateString()?.split("/")
                  : "";
                date = date ? `${date[1]}/${date[0]}/${date[2]}` : "";
                const time = rowData?.reReach
                  ? new Date(rowData?.reReach)?.toLocaleTimeString("en-us", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })
                  : "";
                return rowData?.reReach ? `${date} ${time}` : "";
              }}
            />
            <Column
              field="lenderName"
              sortable
              header="Type"
              body={(rowData) => {
                const type =
                  rowData?.fieldPickUp === "Y"
                    ? "Field PickUp"
                    : rowData?.fieldPickUp === "P"
                    ? "Field Visit Pending"
                    : "";
                return <span>{type}</span>;
              }}
            />
            <Column field="lenderName" sortable header="Lender Name"></Column>
            <Column field="loanProduct" sortable header="Product" />
            <Column field="dpd" header="DPD" sortable></Column>
            <Column
              field="caseStatus"
              header="Status"
              sortable
              body={(data) => {
                return (
                  <span>
                    {dataOption === "IN_PROGRESS"
                      ? "In Progress"
                      : data?.[caseStatusField]}
                  </span>
                );
              }}
            ></Column>

            <Column
              field="allocatedUser"
              header="Allocated User"
              body={(rowData) => {
                return (
                  <span>
                    {dataOption === "MY_CASE" ||
                    rowData?.[allocatedUserField] === user?.userId
                      ? "Self"
                      : userNames?.[rowData?.[allocatedUserField]] ||
                        userNames?.[rowData?.allocateduserid1]}
                  </span>
                );
              }}
              sortable
            />
            <Column
              field=""
              header="Agency"
              sortable
              body={(rowData) => {
                return <span>{agencyNames?.[rowData?.assingedAgency]}</span>;
              }}
            />
            <Column field="dormancy" sortable header="Dormancy"></Column>
            <Column field="bucket" header="Bucket" sortable></Column>
          </DataTable>
          <Pagination
            totalCount={totalDataCount || totalCount}
            currentPage={currentPage}
            numberOfDataPerPage={numberOfDataPerPage}
            setCurrentPage={setCurrentPage}
            setNumberOfDataPerPage={setNumberOfDataPerPage}
          />
        </CardBody>
        <Dialog
          header="Case Close "
          visible={caseClose}
          style={{ width: "35%" }}
          onHide={() => setcaseCloseOpen(false)}
        >
          <CaseClose
            selectedCases={selectedProducts}
            userId={user?.userId}
            setcaseCloseOpen={setcaseCloseOpen}
            roleCode={roleCode}
            currentPage={currentPage}
            currentTab={"Pending"}
            numberOfDataPerPage={numberOfDataPerPage}
            activityType={currentModule}
            dataOption={dataOption}
            filterpayload={filterPayload}
          />
        </Dialog>
      </Card>
      <OverlayPanel ref={manualAllocationRef} dismissable={false}>
        <ManualAllocationModal
          selectedCases={selectedProducts}
          isfilter={isfilter}
          isSearch={isSearch}
          filterPayload={filterPayload}
          currentPage={currentPage}
          numberOfDataPerPage={numberOfDataPerPage}
          // currentModule={currentModule}
          setAllSelected={setAllSelected}
          clearSearch={clearSearch}
          activeTab={
            dataOption?.charAt(0).toUpperCase() +
            dataOption.slice(1).toLowerCase()
          }
          activeAgency={activeAgency}
          onClose={onManualAllocationClick}
          onSuccessAllocation={onSuccessAllocation}
          // setIsFilter={setIsFilter}
          allSelected={allSelected}
          currentModule={currentModule}
          currentTab={dataOption}
        />
      </OverlayPanel>

      {/* } */}
    </Container>
  );
}
