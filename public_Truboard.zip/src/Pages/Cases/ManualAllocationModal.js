import { Fragment, memo, useEffect, useMemo, useState } from "react";
import { Button, Card, Input, Label } from "reactstrap";
import "./cases.scss";
import { useDispatch, useSelector } from "react-redux";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import axios from "axios";
import Swal from "sweetalert2";
import { setAction, setLoader, setReload } from "../../reducer/globalReducer";
import { extendToken } from "../../utils/commonFun";
import { getAllCases, setReset } from "./store";

const ManualAllocationModal = (props) => {
  const [currentTab, setCurrentTab] = useState("");
  const [agencySearch, setAgencySearch] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const [allocationFilter, setAllocationFilter] = useState("Online");
  const [activityTypeFilter, setActivityTypeFilter] = useState("");
  const [agencyDetails, setAgencyDetails] = useState([]);
  const [allAgencyDetails, setAllAgencyDetails] = useState([]);
  const [userDetails, setUserDetails] = useState([]);
  const [allUserDetails, setAllUserDetails] = useState([]);
  const [selfSelectedCheck, setSelfSelectedCheck] = useState(false);
  const [selectedAgency, setSelectedAgency] = useState({});
  const [selectedUser, setSelectedUser] = useState({});
  const [selectedRoleId, setSelectedRoleId] = useState("");
  const [selectedRoleCode, setSelectedRoleCode] = useState("");
  const [agencyInternalUser, setAgencyInternalUser] = useState([]);
  const [allAgencyInternalUser, setAllAgencyInternalUser] = useState([]);
  const [roleCode, setRoleCode] = useState([]);
  const [agencyRoleId, setAgencyRoleId] = useState([]);
  const [internalTabSelected, setInternalTabSelected] = useState("Calling");

  // console.log("selectedAgencyselectedAgency",selectedAgency);
  const user = useSelector((state) => state.user.data);
  const roleId = useSelector((state) => state?.cases?.roleId);
  const filterPayload = useSelector((state) => state?.cases?.filterPayload);
  const loginSessionTimeout = useSelector(
    (state) => state?.global?.loginSessionTimeout
  );
  const reset = useSelector((state) => state?.global?.reset);

  const reload = useSelector((state) => state?.global?.reload);

  const dispatch = useDispatch();
  // console.log(props?.currentTab, "mycurrenttab")
  useEffect(() => {
    if (user) {
      user.role.map((data) => {
        const roleCodeArray = [];
        roleCodeArray.push(data.roleCode);

        setRoleCode(roleCodeArray);
      });
    }
  }, [user]);

  const tabs = useMemo(() => {
    if (user?.userType === "U103") {
      return [
        {
          id: 1,
          btnName: "Self",
        },
        {
          id: 2,
          btnName: "Agency Users",
        },
      ];
    } else if (roleCode?.includes("MIS")) {
      return [
        {
          id: 2,
          btnName: "Truboard Users",
        },
      ];
    } else if (roleCode?.includes("CCA")) {
      return [
        {
          id: 1,
          btnName: "Self",
        },
        {
          id: 2,
          btnName: "Truboard Users",
        },
      ];
    } else {
      return [
        {
          id: 1,
          btnName: "Self",
        },
        {
          id: 2,
          btnName: "Truboard Users",
        },
        {
          id: 3,
          btnName: "Agencies",
        },
      ];
    }
  }, [user, roleCode]);

  const onSearchAgency = (e) => {
    setAgencySearch(e?.target?.value);
  };

  const onSearchUser = (e) => {
    setUserSearch(e?.target?.value);
  };

  const handleAgencyFilter = (filter) => {
    setAllocationFilter(filter);
    const filterData = allAgencyDetails?.filter((data) =>
      data?.agencyType?.toLowerCase().includes(filter?.toLowerCase())
    );
    // console.log("filterDatafilterData", filterData);
    setAgencyDetails(filterData);
  };

  const handleActivityTypeFilter = (filter) => {
    setActivityTypeFilter(filter);
    const filterData = allAgencyInternalUser?.filter(
      (data) =>
        data?.activityType?.toLowerCase().includes(filter?.toLowerCase()) ||
        data?.activityType?.toLowerCase() === "both"
    );
    setAgencyInternalUser(filterData);
  };

  const handleAllocateCases = async (e) => {
    if (props?.selectedCases?.length) {
      const activityType = user?.activityType;
      const payload = props?.allSelected
        ? []
        : props?.selectedCases?.map((a) => a?.loanAccountNumber);
      const timer = setInterval(() => {
        dispatch(setAction(1));
        extendToken(loginSessionTimeout);
      }, 60000);
      if (currentTab === "Self") {
        // console.log("selfSelectedCheck", selfSelectedCheck);
        if (selfSelectedCheck) {
          try {
            dispatch(setLoader(true));
            const primaryUrl =
              activityType === "Field" || props?.currentModule === "Field"
                ? "/postMyCaseAllocationField"
                : "/postMyCaseAllocation";
            const url = props?.allSelected
              ? `${primaryUrl}/${user?.userId}/${
                  roleId || user?.role[0]?.roleId
                }/all`
              : `${primaryUrl}/${user?.userId}/${
                  roleId || user?.role[0]?.roleId
                }/notAll`;
            const res = await axios.post(url, payload);

            clearInterval(timer);
            dispatch(setLoader(false));
            if (res?.data?.msgKey === "Success") {
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
              // props?.setrefress(!props?.refress)
              props?.onSuccessAllocation(e);
              //  props?.setAllSelected()
              props?.clearSearch();
              props?.setAllSelected(false);
            }
          } catch (error) {
            dispatch(setLoader(false));
            clearInterval(timer);
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } else {
          clearInterval(timer);
        }
      } else if (currentTab === "Truboard Users") {
        // console.log("selectedRoleId", selectedRoleId);
        if (selectedRoleId) {
          try {
            const roleId = selectedRoleId?.split("_")[1];
            let primaryUrl = "";

            if (props?.currentTab == "CASE_CLOSER_PENDING") {
              primaryUrl = `/allocateToPco/${selectedUser?.userId}`;
            } else {
              primaryUrl = ["FA", "CA"].includes(selectedRoleCode)
                ? "/CAAllocation"
                : ["DRA"]?.includes(selectedRoleCode)
                ? "/DRAAllocation"
                : activityType === "Field" || props?.currentModule === "Field"
                ? "/postManualAllocationField"
                : (roleCode.includes("MIS") ||
                    roleCode.includes("CCA") ||
                    roleCode.includes("AA")) &&
                  internalTabSelected === "Field"
                ? "/postManualAllocationCallingToField"
                : "/postManualAllocation";
            }
            let url = ["DRA"]?.includes(selectedRoleCode)
              ? `${primaryUrl}/${user?.userId}/${selectedUser?.userId}/${roleId}/N`
              : `${primaryUrl}/${user?.userId}/${selectedUser?.userId}/${roleId}`;
            url = props?.allSelected ? `${url}/all` : `${url}/notAll`;
            dispatch(setLoader(true));
            // const currentPage= props?.currentPage
            // const numberOfDataPerPage= props?.numberOfDataPerPage
            // const currentModule=props?.currentModule
            // dispatch(getAllCases({
            //   currentPage,
            //   numberOfDataPerPage,
            //   currentModule
            // }))
            const finalUrl =
              props?.currentTab == "CASE_CLOSER_PENDING" ? primaryUrl : url;
            const res = await axios.post(finalUrl, payload);
            dispatch(setLoader(false));

            // if (props?.currentModule === "Field" && roleCode.includes("MIS")) {
            //   const updatePayload = res?.data?.data

            //   dispatch(setLoader(true))
            //   const updateRes = await axios.put('/updateCaseStatusAfterAutoAllocation', updatePayload)
            //   dispatch(setLoader(false))
            // }
            clearInterval(timer);

            if (res?.data?.msgKey === "Success") {
              props?.onSuccessAllocation(e);
              //  props?.setAllSelected()
              props?.clearSearch();
              props?.setAllSelected(false);
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });
              // dispatch(setReload(true))
            }
          } catch (error) {
            dispatch(setLoader(false));
            clearInterval(timer);
            // Swal.fire({
            //   position: "top-end",
            //   icon: "error",
            //   title: `${error?.message}`,
            //   showConfirmButton: false,
            //   toast: true,
            //   timer: 3000,
            // });
          }
        } else {
          clearInterval(timer);
        }
      } else if (currentTab === "Agencies") {
        // console.log("selectedAgency", selectedAgency);
        if (selectedAgency) {
          try {
            if (Object.keys(selectedAgency)?.length) {
              // console.log("selectedAgencyselectedAgency",selectedAgency);
              const primaryUrl =
                props?.currentModule === "Field" ||
                user?.activityType === "Field"
                  ? "/allocateToAgencyFromField"
                  : "/allocateToAgency";
              const url = props?.allSelected
                ? `${primaryUrl}/${selectedAgency?.agencyId}/${user?.userId}/all`
                : `${primaryUrl}/${selectedAgency?.agencyId}/${user?.userId}/notAll`;
              dispatch(setLoader(true));
              // console.log("payload", payload);
              const res = await axios.post(url, payload);
              // console.log("resres", res);
              dispatch(setLoader(false));
              clearInterval(timer);

              if (res?.data?.msgKey === "Success") {
                Swal.fire({
                  position: "top-end",
                  icon: "success",
                  title: `${res?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
                props?.onSuccessAllocation(e);
                //  props?.setAllSelected()
                props?.clearSearch();
                props?.setAllSelected(false);
                // props?.setrefress(!props?.refress)
                // props?.onSuccessAllocation(e);
                // dispatch(setReload(reload == true))
                // dispatch(setReset(reset == true ? false : true))
              } else {
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${res?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            } else {
              clearInterval(timer);
            }
          } catch (error) {
            dispatch(setLoader(false));
            clearInterval(timer);
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error?.response?.data?.message || error?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } else {
          clearInterval(timer);
        }
      } else if (currentTab === "Agency Users") {
        if (selectedRoleId) {
          const roleId = selectedRoleId?.split("_")[1];
          try {
            let baseUrl = "";
            if (["FA"].includes(selectedRoleCode)) {
              if (activityTypeFilter === "Calling") {
                baseUrl = "/CAAllocation";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === "Field"
              ) {
                baseUrl = "/DRAAllocation";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === ""
              ) {
                baseUrl = "/DRAAllocationCallingToField";
              }
            } else if (["ATL"].includes(selectedRoleCode)) {
              if (activityTypeFilter === "Calling") {
                baseUrl = "/postManualAllocation";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === "Field"
              ) {
                baseUrl = "/postManualAllocationField";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === ""
              ) {
                baseUrl = "/DRAAllocationCallingToField";
              }
            }
            let url =
              baseUrl + `/${user?.userId}/${selectedUser?.userId}/${roleId}`;
            if (
              baseUrl === "/DRAAllocation" ||
              baseUrl === "/DRAAllocationCallingToField"
            ) {
              url = props?.allSelected ? `${url}/N/all` : `${url}/N/notAll`;
            } else {
              url = props?.allSelected ? `${url}/all` : `${url}/notAll`;
            }
            dispatch(setLoader(true));
            const res = await axios.post(url, payload);
            dispatch(setLoader(false));
            clearInterval(timer);
            if (res?.data?.msgKey === "Success") {
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });

              props?.onSuccessAllocation(e);
              //  props?.setAllSelected()
              props?.clearSearch();
              props?.setAllSelected(false);
            }
          } catch (error) {
            dispatch(setLoader(false));
            clearInterval(timer);
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } else {
          clearInterval(timer);
        }
      } else {
        clearInterval(timer);
      }
    }
  };

  const handleFilterAlloacteCase = async (e) => {
    if (props?.selectedCases?.length) {
      // console.log("props?.selectedCases", props?.selectedCases);
      // console.log("props?.filterPayload", props?.filterPayload);
      const activityType = user?.activityType;
      // console.log("activityType", activityType);

      const dummyPayload = {};

      if (props?.filterPayload?.borrowerName) {
        dummyPayload.borrowerName = props?.filterPayload.borrowerName;
      }

      if (props?.filterPayload?.lenderId) {
        dummyPayload.lenderId = [...props?.filterPayload.lenderId];
      }

      if (props?.filterPayload?.lenderName) {
        dummyPayload.lenderName = [...props?.filterPayload.lenderName];
      }

      // Add any other fields as necessary
      // Example:
      // if (props?.filterPayload?.anotherField) {
      //   dummyPayload.anotherField = props?.filterPayload.anotherField;
      // }

      // console.log("dummyPayload", dummyPayload);

      // const payload = {
      //   allocationType: "manualAllocationCalling",
      //   userIdTo: 0,
      //   roleId: 0,
      //   fromFieldPick: "",
      //   agencyIdForallocation: 0,
      //   filterType: ""
      // };

      const timer = setInterval(() => {
        dispatch(setAction(1));
        extendToken(loginSessionTimeout);
      }, 60000);

      if (currentTab === "Self") {
        if (selfSelectedCheck) {
          try {
            dispatch(setLoader(true));
            // RRM PRM ARM
            const primaryUrl =
              (activityType === "Field" || props?.currentModule === "Field") &&
              !roleCode.includes("PRM") &&
              !roleCode.includes("ARM") &&
              !roleCode.includes("RRM")
                ? "/postMyCaseAllocationField"
                : "/selectAllFilteredDataForAll";

            const primaryUrl1 = "/selectAllFilteredDataForAgency";

            // const url = props?.allSelected? `${primaryUrl}/${user?.userId}/${roleId || user?.role[0]?.roleId}/all`: `${primaryUrl}/${user?.userId}/${props?.activeTab}/${props?.activeAgency?.value || 0}`;
            const url =
              user?.userType == "U101"
                ? `${primaryUrl}/${user?.userId}/${props?.activeTab}/${
                    props?.activeAgency?.value || 0
                  }`
                : `${primaryUrl1}/${user?.userId}/${props?.activeTab}/${
                    props?.activeAgency?.value || 0
                  }`;

            const payload = {
              allocationType: "manualAllocationSelf",
              userIdTo: 0,
              roleId: roleId || user?.role[0]?.roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType: "",
            };

            const bulkFilterDto = {
              ...payload,
              filterType: "calling",
              bulkFilterDto: {
                ...dummyPayload,
              },
            };

            // console.log("bulkFilterDto", bulkFilterDto);

            const Fieldpayload = {
              allocationType: "manualAllocationSelfField",
              userIdTo: 0,
              roleId: roleId || user?.role[0]?.roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType: "",
            };

            const FieldbulkFilterDto = {
              ...Fieldpayload,
              filterType: "field",
              bulkFilterDto: {
                ...dummyPayload,
              },
            };

            // console.log("FieldbulkFilterDto", FieldbulkFilterDto);

            const agencypayload = {
              allocationType:
                activityType === "Field" || props?.currentModule === "Field"
                  ? "manualAllocationSelfField"
                  : "manualAllocationSelf",
              userIdTo: 0,
              roleId: roleId || user?.role[0]?.roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType:
                activityType === "Field" || props?.currentModule === "Field"
                  ? "field"
                  : "calling",
            };

            const agencybulkFilterDto = {
              ...agencypayload,
              // filterType: "field",
              bulkFilterDto: {
                ...dummyPayload,
              },
            };
            // console.log("agencybulkFilterDto", agencybulkFilterDto);

            let finalpayload = "";
            if (user?.userType == "U101") {
              finalpayload =
                activityType === "Field" || props?.currentModule === "Field"
                  ? FieldbulkFilterDto
                  : bulkFilterDto;
            } else {
              finalpayload = agencybulkFilterDto;
            }

            // console.log("finalpayload", finalpayload);
            const res = await axios.post(url, finalpayload);
            // console.log("finalpayload response", res);
            clearInterval(timer);
            dispatch(setLoader(false));
            if (res?.data?.msgKey === "Success") {
              props?.clearSearch();
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });

              props?.onSuccessAllocation(e);
              props?.setIsFilter(false);
              // console.log(props?.setIsFilter, "vghhjvgj");
            }
          } catch (error) {
            dispatch(setLoader(false));
            clearInterval(timer);
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } else {
          clearInterval(timer);
        }
      } else if (currentTab === "Truboard Users") {
        if (selectedRoleId) {
          try {
            const roleId = selectedRoleId?.split("_")[1];
            const primaryUrl =
              (activityType == "Field" || props?.currentModule == "Field") &&
              roleCode == "MIS"
                ? "/selectAllFilteredDataForMisField"
                : roleCode == "MIS"
                ? "/selectAllFilteredDataForMisCalling"
                : (!roleCode == "PRM" ||
                    !roleCode == "MIS" ||
                    !roleCode == "CA" ||
                    !roleCode == "DRA") &&
                  user?.userType == "U101" &&
                  props?.selectedCases
                ? "/DRAAllocation"
                : "/selectAllFilteredDataForAll";

            let url = `${primaryUrl}/${user?.userId}/${props?.activeTab}/${
              props?.activeAgency?.value || 0
            }`;

            url = props?.allSelected ? `${url}` : `${url}`;
            dispatch(setLoader(true));

            // mis payload
            const payload = {
              allocationType:
                internalTabSelected == "Field" ||
                props?.currentModule == "Field" ||
                activityType == "Field"
                  ? "manualAllocationField"
                  : "manualAllocationCalling",
              userIdTo: selectedUser?.userId,
              roleId: roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType:
                ((!roleCode.includes("MIS") ||
                  !roleCode.includes("CCA") ||
                  !roleCode.includes("AA")) &&
                  activityType == "Field") ||
                props?.currentModule == "Field"
                  ? "field"
                  : "calling",
            };

            // console.log(selectedUser, "selectedUserselectedUserselectedUser")
            // prm payload
            const Prmpayload = {
              allocationType:
                props?.currentModule == "Field" || activityType == "Field"
                  ? "manualAllocationDRA"
                  : "manualAllocationCA",
              userIdTo: selectedUser?.userId,
              roleId: roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType:
                props?.currentModule == "Field" || activityType == "Field"
                  ? "field"
                  : "calling",
            };

            // CCApayload
            const CCApayload = {
              allocationType: "manualAllocationCallingToField",
              userIdTo: selectedUser?.userId,
              roleId: roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType: "calling",
            };

            // calling paylod merge
            const bulkFilterDto = {
              ...payload,
              bulkFilterDto: {
                ...dummyPayload,
              },
            };

            const PrmbulkFilterDto = {
              ...Prmpayload,
              bulkFilterDto: {
                ...dummyPayload,
              },
            };

            const CCAbullkFilterDto = {
              ...CCApayload,
              bulkFilterDto: {
                ...dummyPayload,
              },
            };
            // field payload merge
            // const bulkFilterDtoField = {
            //   ...Fieldpayload,
            //   bulkFilterDto: {
            //     ...dummyPayload
            //   }
            // };

            let finalpayload = "";
            if (roleCode == "CCA" && internalTabSelected == "Field") {
              finalpayload = CCAbullkFilterDto;
            } else {
              // const checkrole= [ "PRM", "ARM"]
              const checkrole1 = ["DRA", "CA"];

              // const finalpayload = checkrole.includes(roleCode) ? PrmbulkFilterDto : bulkFilterDto;

              finalpayload = checkrole1.includes(
                selectedUser?.role[0]?.roleCode
              )
                ? PrmbulkFilterDto
                : bulkFilterDto;

              // finalpayload = roleCode == "PRM" ? PrmbulkFilterDto  :   bulkFilterDto
            }

            const res = await axios.post(url, finalpayload);
            dispatch(setLoader(false));

            // if (props?.currentModule === "Field" && roleCode.includes("MIS")) {
            //   const updatePayload = res?.data?.data

            //   dispatch(setLoader(true))
            //   const updateRes = await axios.put('/updateCaseStatusAfterAutoAllocation', updatePayload)
            //   dispatch(setLoader(false))
            // }
            // console.log(res?.data?.msgKey, "messagedaa")
            clearInterval(timer);

            if (res?.data?.msgKey === "Success") {
              //
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });

              props?.onSuccessAllocation(e);
              props?.clearSearch();
              // props?.transferFunction()
              // dispatch(setReset(true))
              // props?.setIsFilter(false)
            }
          } catch (error) {
            alert(error?.message);
            dispatch(setLoader(false));
            clearInterval(timer);
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } else {
          clearInterval(timer);
        }
      } else if (currentTab === "Agencies") {
        // console.log("selectedAgency", selectedAgency);
        if (selectedAgency) {
          try {
            if (Object.keys(selectedAgency)?.length) {
              const primaryUrl = "/selectAllFilteredDataForAll";
              const url = `${primaryUrl}/${user?.userId}/${props?.activeTab}/${
                props?.activeAgency?.value || 0
              }`;

              const agencypayload = {
                allocationType:
                  props?.currentModule == "Field" || activityType == "Field"
                    ? "manualAllocationAgencyField"
                    : "manualAllocationAgency",
                userIdTo: selectedUser?.userId,
                roleId: agencyRoleId,
                fromFieldPick: "",
                agencyIdForallocation: selectedAgency?.agencyId || 0,
                filterType:
                  props?.currentModule == "Field" || activityType == "Field"
                    ? "field"
                    : "calling",
              };

              console.log(
                "props?.activeAgency[0]?.value",
                props?.activeAgency[0]?.value
              );
              // console.log("roleId", roleId);
              const agencybulkFilterDto = {
                ...agencypayload,
                bulkFilterDto: {
                  ...dummyPayload,
                },
              };

              // console.log("agencypayload", agencypayload);
              // console.log("agencybulkFilterDto", agencybulkFilterDto);
              dispatch(setLoader(true));
              const res = await axios.post(url, agencybulkFilterDto);
              dispatch(setLoader(false));
              clearInterval(timer);

              if (res?.data?.msgKey === "Success") {
                props?.clearSearch();
                Swal.fire({
                  position: "top-end",
                  icon: "success",
                  title: `${res?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });

                props?.onSuccessAllocation(e);
                // props?.setIsFilter(true)
              } else {
                Swal.fire({
                  position: "top-end",
                  icon: "error",
                  title: `${res?.data?.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              }
            } else {
              clearInterval(timer);
            }
          } catch (error) {
            dispatch(setLoader(false));
            clearInterval(timer);
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error?.response?.data?.message || error?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        }
      } else if (currentTab === "Agency Users") {
        if (selectedRoleId) {
          const roleId = selectedRoleId?.split("_")[1];
          try {
            let baseUrl = "";
            if (["FA"].includes(selectedRoleCode)) {
              if (activityTypeFilter === "Calling") {
                baseUrl = "/selectAllFilteredDataForAgency";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === "Field"
              ) {
                baseUrl = "/selectAllFilteredDataForAgency";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === ""
              ) {
                baseUrl = "/selectAllFilteredDataForAgency";
              }
            } else if (["ATL"].includes(selectedRoleCode)) {
              if (activityTypeFilter === "Calling") {
                baseUrl = "/selectAllFilteredDataForAgency";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === "Field"
              ) {
                baseUrl = "/selectAllFilteredDataForAgency";
              } else if (
                activityTypeFilter === "Field" &&
                props?.currentModule === ""
              ) {
                baseUrl = "/selectAllFilteredDataForAgency";
              }
            }

            let url =
              baseUrl +
              `/${user?.userId}/${props?.activeTab}/${
                props?.activeAgency?.value || 0
              }`;
            if (
              baseUrl === "/DRAAllocation" ||
              baseUrl === "/selectAllFilteredDataForAgency"
            ) {
              url = props?.allSelected ? `${url}` : `${url}`;
            } else {
              url = props?.allSelected ? `${url}` : `${url}`;
            }

            // fa payload
            const agencypayload = {
              allocationType:
                activityType === "Field" ||
                props?.currentModule === "Field" ||
                internalTabSelected == "Field"
                  ? "manualAllocationDRA"
                  : activityTypeFilter === "Field"
                  ? "manualAllocationCallingToField"
                  : "manualAllocationCA",
              userIdTo: selectedUser?.userId,
              roleId: roleId || user?.role[0]?.roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType:
                activityType === "Field" || props?.currentModule === "Field"
                  ? "field"
                  : "calling",
            };

            const agencybulkFilterDto = {
              ...agencypayload,
              // filterType: "field",
              bulkFilterDto: {
                ...dummyPayload,
              },
            };

            // Atl payload here
            const agencyAtlpayload = {
              allocationType:
                activityType === "Field" ||
                props?.currentModule === "Field" ||
                internalTabSelected == "Field"
                  ? "manualAllocationField"
                  : activityTypeFilter === "Field"
                  ? "manualAllocationCallingToField"
                  : "manualAllocationCalling",
              userIdTo: selectedUser?.userId,
              roleId: roleId || user?.role[0]?.roleId,
              fromFieldPick: "",
              agencyIdForallocation: 0,
              filterType:
                activityType === "Field" || props?.currentModule === "Field"
                  ? "field"
                  : "calling",
            };

            const agencyAtlbulkFilterDto = {
              ...agencyAtlpayload,
              // filterType: "field",
              bulkFilterDto: {
                ...dummyPayload,
              },
            };

            //  final payload
            const finalpayload =
              selectedRoleCode == "FA"
                ? agencybulkFilterDto
                : agencyAtlbulkFilterDto;

            dispatch(setLoader(true));
            const res = await axios.post(url, finalpayload);
            dispatch(setLoader(false));
            clearInterval(timer);
            if (res?.data?.msgKey === "Success") {
              props?.clearSearch();
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: `${res?.data?.message}`,
                showConfirmButton: false,
                toast: true,
                timer: 3000,
              });

              props?.onSuccessAllocation(e);
              props?.setIsFilter(false);
            }
          } catch (error) {
            dispatch(setLoader(false));
            clearInterval(timer);
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: `${error?.message}`,
              showConfirmButton: false,
              toast: true,
              timer: 3000,
            });
          }
        } else {
          clearInterval(timer);
        }
      } else {
        clearInterval(timer);
      }
    }
  };

  const getAllAgency = async () => {
    try {
      dispatch(setLoader(true));
      const res = await axios.get(`/getAgencyByUserId/${user?.userId}`);
      // console.log("getAgencyByUserId",res.data.data);
      dispatch(setLoader(false));
      setAgencyDetails(res?.data?.data);
      setAllAgencyDetails(res?.data?.data);
      // console.log("getAgencyByUserId", agencyDetails);
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const getAllInternalUser = async () => {
    try {
      if (roleCode?.includes("MIS") || roleCode?.includes("CCA")) {
        dispatch(setLoader(true));
        const res = await axios.get("/getUserForAllocation");
        // console.log(res, "allocationresponse");
        dispatch(setLoader(false));
        // const data = res?.data?.data?.filter(a=> a?.userType === "U101" && user?.userId !== a?.userId)
        let data = res?.data?.data?.filter(
          (a) =>
            a?.userType === "U101" &&
            user?.userId !== a?.userId &&
            (a?.activityType === "Both" ||
              (props?.currentModule === "Field" ||
              internalTabSelected === "Field"
                ? ["Field", "Both"]?.includes(a?.activityType)
                : ["Both", "Calling"]?.includes(a?.activityType))) &&
            a?.role?.find(
              (b) => !["DRA", "FA", "CA", "R1", "MIS"].includes(b?.roleCode)
            ) &&
            user?.reportingManager?.toString() !== a?.userId?.toString()
        ); //: res?.data?.data?.filter(a => a?.userType === "U101" && user?.userId !== a?.userId && (a?.activityType === "Both" || (props?.currentModule === "Field" ? a?.activityType === "Field" : a?.activityType === "Calling")) && a?.role?.find(b => !["DRA", "FA", "CA", "R1"].includes(b?.roleCode)) && user?.reportingManager?.toString() !== a?.userId?.toString())
        // let data = res?.data?.data?.filter(a => a?.userType === "U101" && user?.userId !== a?.userId && (a?.activityType === "Both" || (props?.currentModule === "Field" ? a?.activityType === "Field" : a?.activityType === "Calling")) && a?.role?.find(b => !["DRA", "FA", "CA", "R1"].includes(b?.roleCode)) && user?.reportingManager?.toString() !== a?.userId?.toString())
        if (props?.currentTab === "CASE_CLOSER_PENDING") {
          data = data?.filter((a) =>
            a?.role?.some((b) => b?.roleCode === "PCO")
          );
        }
        if (filterPayload?.portfolio?.length) {
          data = data?.filter((a) =>
            a?.portfolio.some((b) =>
              filterPayload?.portfolio?.includes(b?.portfolioId)
            )
          );
        }
        setUserDetails(data);
        setAllUserDetails(data);
      } else {
        dispatch(setLoader(true));
        // const res = await axios.get(`/getLowerHierarchyByUserId/${user?.userId}`);
        const res = await axios.get(
          `/getAllocatedLowerHierarchyByUserId/${user?.userId}`
        );
        // console.log(res, "agencydatafilter")
        dispatch(setLoader(false));
        let data = res?.data?.data?.filter(
          (a) =>
            a?.userType === "U101" &&
            (props?.currentModule === "Field" || user?.activityType === "Field"
              ? ["Field", "Both"]?.includes(a?.activityType)
              : ["Calling", "Both"]?.includes(a?.activityType))
        );
        if (filterPayload?.portfolio?.length) {
          data = data?.filter((a) =>
            a?.portfolio.some((b) =>
              filterPayload?.portfolio.includes(b?.portfolioId)
            )
          );
        }
        setUserDetails(data);
        setAllUserDetails(data);
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const getAllAgencyInternalUser = async () => {
    // console.log("useruser", user.agency);
    if (user?.agency[0]?.agencyId) {
      try {
        dispatch(setLoader(true));
        const res = await axios.get(
          `/getUserByAgency/${user?.agency[0]?.agencyId}`
        );
        const result = res.data.data;
        if (result) {
          result.map((val) => {
            if (val.role[0].roleCode === "AA") {
              setAgencyRoleId(val.role[0].roleId);
              // console.log("roleID", val.role[0].roleId);
            }
          });
        }
        // console.log("resresresagency", res);
        // console.log("resresres", res.data.data);
        dispatch(setLoader(false));
        if (res?.data?.msgKey === "Success") {
          // && (user?.activityType === a?.activityType || user?.activityType === "Both")
          let filterUser = res?.data?.data?.filter(
            (a) =>
              a?.userType === "U103" &&
              a?.reportingManager?.toString() === user?.userId?.toString() &&
              user?.userId !== a?.userId &&
              (user?.activityType === a?.activityType ||
                user?.activityType === "Both")
          );
          if (filterPayload?.portfolio?.length) {
            filterUser = filterUser?.filter((a) =>
              a?.portfolio.some((b) =>
                filterPayload?.portfolio.includes(b?.portfolioId)
              )
            );
          }
          // console.log("filterUserfilterUser",filterPayload);
          setAgencyInternalUser(filterUser);
          setAllAgencyInternalUser(filterUser);
        }
      } catch (error) {
        dispatch(setLoader(false));
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: `${error?.message}`,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    }
  };

  useEffect(() => {
    if (user?.userId && roleCode?.length) {
      getAllAgency(user?.userId);
      getAllAgencyInternalUser();
    }
  }, [user, roleCode]);

  useEffect(() => {
    if (user?.userId && roleCode?.length) {
      getAllInternalUser(user?.userId);
    }
  }, [user, roleCode, internalTabSelected]);

  useEffect(() => {
    const search = setTimeout(() => {
      const data =
        user?.userType === "U103" ? allAgencyInternalUser : allUserDetails;
      const searchData = data?.filter(
        (data) =>
          data?.firstName
            ?.toLowerCase()
            ?.startsWith(userSearch?.toLowerCase()) ||
          data?.lastName?.toLowerCase()?.startsWith(userSearch?.toLowerCase())
      );
      user?.userType === "U103"
        ? setAgencyInternalUser(searchData)
        : setUserDetails(searchData);
    }, 1000);

    return () => {
      clearTimeout(search);
    };
  }, [userSearch, allAgencyInternalUser, allUserDetails]);

  useEffect(() => {
    if (Array.isArray(allAgencyDetails)) {
      const search = setTimeout(() => {
        const searchData = allAgencyDetails?.filter((data) =>
          data?.agencyName
            .toLowerCase()
            ?.startsWith(agencySearch?.toLowerCase())
        );
        setAgencyDetails(searchData);
      }, 1000);

      return () => {
        clearTimeout(search);
      };
    }
  }, [allAgencyDetails, agencySearch]);

  return (
    <>
      <div className="tabRow">
        {tabs?.map((btn) => (
          <Button
            key={btn?.id}
            color="primary"
            active={currentTab === btn?.btnName}
            onClick={() => setCurrentTab(btn?.btnName)}
            size="sm"
            outline
          >
            {btn?.btnName}
          </Button>
        ))}
      </div>

      <div className="allocationModalBody">
        {currentTab === "Self" && (
          <>
            <Input
              type="checkbox"
              id="selfAllocation"
              value={selfSelectedCheck}
              onChange={(e) => setSelfSelectedCheck(e?.target?.checked)}
            />
            <Label for="selfAllocation" check className="ms-2">
              Allocate to me
            </Label>
          </>
        )}

        {currentTab === "Truboard Users" && (
          <div className="allocationAgencyContainer">
            <div className="allocationInputGrp">
              <Label className="label">Truboard User:</Label>
              <Input
                onChange={onSearchUser}
                value={userSearch}
                placeholder="search user"
                className="inputBox"
              />
            </div>
            {props?.currentModule !== "Field" &&
              (roleCode.includes("MIS") || roleCode.includes("CCA")) && (
                <div className="filterBtnGrp">
                  <Button
                    color="primary"
                    outline
                    size="sm"
                    active={internalTabSelected === "Calling"}
                    onClick={() => setInternalTabSelected("Calling")}
                  >
                    Calling
                  </Button>

                  <Button
                    color="primary"
                    outline
                    size="sm"
                    active={internalTabSelected === "Field"}
                    onClick={() => setInternalTabSelected("Field")}
                  >
                    Field
                  </Button>
                </div>
              )}
            <DataTable
              value={userDetails}
              sortMode="single"
              size={"small"}
              className="allocationAgencyTable"
              selectionMode="radiobutton"
              onSelectionChange={(e) => {
                setSelectedUser(e?.value);
                setSelectedRoleId("");
                setSelectedRoleCode("");
              }}
              selection={selectedUser}
            >
              <Column selectionMode="single" />
              <Column
                header="User Name"
                body={(data) => {
                  return (
                    <p className="userName">
                      {data?.firstName} {data?.lastName}
                    </p>
                  );
                }}
              />
              <Column
                header="User Role"
                body={(data) => {
                  return data?.role?.map((a) => (
                    <div className="userRoleGrp" key={a?.roleId}>
                      <Input
                        type="radio"
                        name={`role${a?.roleId}`}
                        value={selectedRoleId}
                        checked={
                          selectedUser?.userId === data?.userId &&
                          selectedRoleId === `${data?.userId}_${a?.roleId}`
                        }
                        disabled={selectedUser?.userId !== data?.userId}
                        onChange={(e) => {
                          console.log(
                            "selected role id:",
                            `${data?.userId}_${a?.roleId}`
                          );
                          setSelectedRoleId(`${data?.userId}_${a?.roleId}`);
                          setSelectedRoleCode(a?.roleCode);
                        }}
                      />
                      <p className="roleName">{a?.roleCode}</p>
                    </div>
                  ));
                }}
              />
              {/* <Column
                header="Reporting Manager"
                field="reportingManagerName"
                className="userName"
              /> */}
            </DataTable>
          </div>
        )}

        {currentTab === "Agencies" && (
          <div className="allocationAgencyContainer">
            <div className="allocationInputGrp">
              <Label className="label">Agency:</Label>
              <Input
                onChange={onSearchAgency}
                value={agencySearch}
                placeholder="search agency"
                className="inputBox"
              />
            </div>

            <div className="filterBtnGrp">
              <Button
                color="primary"
                outline
                size="sm"
                active={allocationFilter === "Online"}
                onClick={() => handleAgencyFilter("Online")}
                // onClick={()=>setAllocationFilter('Online')}
              >
                Online
              </Button>
              <Button
                color="primary"
                outline
                size="sm"
                active={allocationFilter === "Offline"}
                onClick={() => handleAgencyFilter("Offline")}
                // onClick={()=>setAllocationFilter('Offline')}
              >
                Offline
              </Button>
            </div>

            <DataTable
              value={agencyDetails}
              sortMode="single"
              size={"small"}
              className="allocationAgencyTable"
              onSelectionChange={(e) => {
                // console.log("userDetails", agencyDetails);
                // console.log("userDetails eee", e?.value?.agencyId);
                setSelectedAgency(e?.value);
              }}
              selectionMode="radiobutton"
              selection={selectedAgency}
            >
              <Column selectionMode="single" headerStyle={{ width: "3rem" }} />
              <Column field="agencyName" header="Agency Name" />
              <Column field="agencyType" header="Type" />
            </DataTable>
          </div>
        )}

        {currentTab === "Agency Users" && (
          <div className="allocationAgencyContainer">
            <div className="allocationInputGrp">
              <Label className="label">Agency User:</Label>
              <Input
                onChange={onSearchUser}
                value={userSearch}
                placeholder="search user"
                className="inputBox"
              />
            </div>

            <div className="filterBtnGrp">
              {(props?.currentModule === "Field" ||
                roleCode.includes("AA")) && (
                <Button
                  color="primary"
                  outline
                  size="sm"
                  active={activityTypeFilter === "Field"}
                  onClick={() => handleActivityTypeFilter("Field")}
                  // onClick={()=>setactivityTypeFilter('Field')}
                >
                  Field
                </Button>
              )}
              {!props?.currentModule && (
                <Button
                  color="primary"
                  outline
                  size="sm"
                  active={activityTypeFilter === "Calling"}
                  onClick={() => handleActivityTypeFilter("Calling")}
                  // onClick={()=>setactivityTypeFilter('Calling')}
                >
                  Calling
                </Button>
              )}
            </div>

            {activityTypeFilter && (
              <DataTable
                value={agencyInternalUser}
                sortMode="single"
                size={"small"}
                className="allocationAgencyTable"
                selectionMode="radiobutton"
                onSelectionChange={(e) => {
                  setSelectedUser(e?.value);
                  setSelectedRoleId("");
                  setSelectedRoleCode("");
                }}
                selection={selectedUser}
              >
                <Column
                  selectionMode="single"
                  headerStyle={{ width: "3rem" }}
                />
                <Column
                  header="User Name"
                  body={(data) => {
                    return (
                      <span>
                        {data?.firstName} {data?.lastName}
                      </span>
                    );
                  }}
                />
                <Column
                  header="User Role"
                  body={(data) => {
                    // console.log("data333",data);
                    return data?.role?.map((a) => (
                      <Fragment key={a?.roleId}>
                        <Input
                          type="radio"
                          name={`role${a?.roleId}`}
                          value={selectedRoleId}
                          checked={
                            selectedUser?.userId === data?.userId &&
                            selectedRoleId === `${data?.userId}_${a?.roleId}`
                          }
                          disabled={selectedUser?.userId !== data?.userId}
                          onChange={(e) => {
                            setSelectedRoleId(`${data?.userId}_${a?.roleId}`);
                            setSelectedRoleCode(a?.roleCode);
                          }}
                        />
                        <span>{a?.roleCode}</span>
                        {/* {console.log("a?.roleCode",selectedRoleCode)} */}
                      </Fragment>
                    ));
                  }}
                />
              </DataTable>
            )}
          </div>
        )}
      </div>
      {/* */}
      <div className="allocationModalBtnGrp">
        <Button
          color="primary"
          onClick={
            (props?.isFilter || props?.isSearch) &&
            (props?.allSelected || !props?.selectedCases)
              ? handleFilterAlloacteCase
              : handleAllocateCases
          }
          size="sm"
        >
          Allocate
        </Button>

        <Button color="secondary" onClick={props?.onClose} size="sm">
          Cancel
        </Button>
      </div>
    </>
  );
};
export default memo(ManualAllocationModal);
