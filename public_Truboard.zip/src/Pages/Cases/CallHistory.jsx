import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Dialog } from "primereact/dialog";
import { Fragment, memo, useEffect, useState } from "react"
import { useParams } from "react-router-dom";
import CallHistorySummary from "./CallHistorySummary";
import { getCallHistory } from "./store";
import { useDispatch, useSelector } from "react-redux";
import { addAudit } from "../../utils/commonFun";

const CallHistory = (props) => {
    const [historyData, setHistoryData] = useState({})

    const callHistoryData = useSelector((state)=> state?.cases?.callHistory)
    const user = useSelector((state) => state.user.data);

    const { lanId } = useParams();

    const dispatch = useDispatch()

    const onPreview = (data) => {
        setHistoryData(data)
        const payload={
            userName : user?.userName,
            module : "Cases",
            activity : `${user?.userName} viewed Call History details of application number: ${lanId}, call history id: ${data?.callHistoryId}, call outcome: ${data?.callOutcome}`
        }
        addAudit(payload)
    }

    useEffect(() => {
        dispatch(getCallHistory(lanId))
    }, [])

    return (
        <Fragment>
            <DataTable
                value={callHistoryData}
                size={"small"}
                tableStyle={{ minWidth: "50rem" }}
                className="d-flex flex-column flex-grow-1 casesTable"
            // style={{ height: 1 }}
            >
                <Column
                    field="lastModifiedTime"
                    header="Timestamp"
                    body={data => {
                        const time = new Date(data?.lastModifiedTime).toLocaleTimeString('en-us',{hour: '2-digit',minute: '2-digit'})
                        const date = new Date(data?.lastModifiedTime).toLocaleDateString().split('/')
                        
                        return (
                            <p>{`${date[1]}/${date[0]}/${date[2]} ${time}`}</p>
                        )
                    }}
                />
                <Column
                    field="name"
                    header="Name"
                />
                <Column
                    field="number"
                    header="Number"
                />
                <Column
                    field="status"
                    header="Status"
                />
                <Column
                    field="callDuration"
                    header="Duration"
                />
                <Column
                    field="play"
                    header="Play"
                />
                <Column
                    field="action"
                    header="Action"
                    body={data => {
                        return (
                            <p
                                className="callHistoryViewBtn"
                                onClick={() => onPreview(data)}
                            >
                                View
                            </p>
                        )
                    }}
                />
                <Column
                    field="callOutcome"
                    header="Call Outcome"
                />
            </DataTable>

            {Boolean(Object.keys(historyData).length) &&
                <Dialog
                    header="Call Summary"
                    visible={Boolean(Object.keys(historyData).length)}
                    onHide={()=>setHistoryData({})}
                    style={{width: '500px'}}
                >
                    <CallHistorySummary
                        data={historyData}
                        raiseException={props?.raiseException}
                        disputeReason={props?.disputeReason}
                    />
                </Dialog>
            }
        </Fragment>
    )
}

export default memo(CallHistory)