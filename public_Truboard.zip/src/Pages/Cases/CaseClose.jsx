import { Formik } from 'formik';
import { Card, CardBody, Form, Input, Button, Col, Row } from 'reactstrap';
import React, { useState } from 'react';
import styles from './CaseCloase.module.scss';
import Field from '../../components/Field';
import { IoAddSharp } from "react-icons/io5";
import { GrFormSubtract } from "react-icons/gr";
import axios from 'axios';
import { setLoader } from '../../reducer/globalReducer';
import { useDispatch } from 'react-redux';
import Swal from "sweetalert2"
import { getClouserRequestPending, getLenderCaseCloase } from './store';
import * as yup from "yup";


const CaseClose = (props) => {
    const [fields, setFields] = useState([{ id: 1 }]);
    const [evidence, setEvidanceFile] = useState([])
    const [action, setAction] = useState(null);
    const dispatch = useDispatch()

    const addField = () => {
        const newId = fields.length + 1;
        setFields([...fields, { id: newId }]);
    };

    const deleteField = (id) => {
        setFields(fields.filter(field => field.id !== id));
    };



    const initialValues = {
        evidence: "",
        remark: ""
    };


    const handleSubmit = async (values) => {
        if (evidence.length != 0 || action == "Rejected") {
            try {
                dispatch(setLoader(true))
                const userId = props?.userId
                const selectedLan = props?.selectedCases?.map((item) => item?.loanAccountNumber)
                const payload = {
                    userId: userId,
                    lan: selectedLan,
                    status: action,
                    remark: values?.remark
                }
                const res = await axios.post("/pcoCaseClosure", payload)
                if (res?.data?.msgKey == "Success") {
                    if (res?.data?.message == "Case Approved by PCO") {
                        for (let i = 0; i < evidence.length; i++) {
                            const element = evidence[i];
                            const formData = new FormData();
                            formData.append("file", element);
                            const evidenceResponse = await axios.put(`/addCaseClosureEvidence/${res?.data?.data}`, formData)
                        }
                    }
                    dispatch(setLoader(false))
                    Swal.fire({
                        position: "top-end",
                        icon: "success",
                        title: `${res?.data?.message}`,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                    props?.setcaseCloseOpen(false)
                    const roleCode = props?.roleCode;
                    const currentPage = props?.currentPage;
                    const currentTab = props?.currentTab;
                    const userId = props?.userId;
                    const numberOfDataPerPage = props?.numberOfDataPerPage;
                    const dataOption = props?.dataOption
                    const filterpayload = props?.filterpayload
                    const data = {
                        userId,
                        currentPage,
                        numberOfDataPerPage,
                        dataOption,
                        filterpayload
                    }
                    // console.log(roleCode, "rolecodeedewee")

                    if (roleCode == "L02" || roleCode == "L01") {
                        dispatch(getLenderCaseCloase(data))
                    } else {
                        dispatch(getClouserRequestPending({
                            roleCode,
                            currentPage,
                            currentTab,
                            userId,
                            numberOfDataPerPage,
                        }))
                    }

                } else {
                    dispatch(setLoader(false))
                    Swal.fire({
                        position: "top-end",
                        icon: "error",
                        title: `${res?.data?.message}`,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                }
            } catch (error) {
                dispatch(setLoader(false))
                Swal.fire({
                    position: "top-end",
                    icon: "error",
                    title: `Error Occure`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                });
            }
        }
    };


    return (
        <Card className="mx-3 bg-light">
            <CardBody>
                <Formik
                    initialValues={initialValues}
                    onSubmit={handleSubmit}
                >
                    {({
                        values,
                        errors,
                        handleBlur,
                        touched,
                        handleSubmit,
                        setFieldValue,
                    }) => {
                        return (
                            <Form className={styles.formContainer} >
                                {fields?.map((field, index) => (
                                    <Row key={index} style={{ width: "100%", }}>
                                        <Col style={{ width: "100px" }} >
                                            <Field
                                                // isRequired
                                                label="Evidence"
                                            >
                                                <Input
                                                    bsSize="sm"
                                                    required
                                                    id={`remark_${field.id}`}
                                                    type="file"
                                                    onChange={(event) => {
                                                        const file = event.target?.files[0];
                                                        setEvidanceFile([...evidence, file]);
                                                    }}
                                                />
                                                {(evidence?.length == 0 && action == "Approved") ? <span style={{ fontSize: "13px", color: "red" }}>Evidence is required</span> : ""}
                                            </Field>
                                        </Col>
                                        <div style={{ maxWidth: "80px" }}>
                                            <IoAddSharp style={{ size: 50, color: "black", cursor: "pointer" }} onClick={addField} />
                                            {fields.length > 1 && <GrFormSubtract style={{ size: 50, color: "black", cursor: "pointer" }} onClick={() => deleteField(field.id)} />}
                                        </div>
                                    </Row>
                                ))}
                                <Row>
                                    <Field
                                        label="Remark"
                                        style={{ paddingLeft: "10px" }}
                                        errorMessage={touched?.remark && errors?.remark}
                                    >
                                        <Input
                                            bsSize="sm"
                                            id="remark"
                                            type="textarea"
                                            onChange={(e) => setFieldValue("remark", e?.target?.value)}
                                            value={values.remark}
                                        // invalid={touched?.remark && Boolean(errors?.remark)}
                                        // disabled={isView}
                                        />
                                    </Field>
                                </Row>
                                <Row >
                                    <Col style={{ display: "flex", justifyContent: "flex-end" }}>
                                        {/* style={{ marginRight: 5 }} */}
                                        <div >
                                            <Button color="primary" outline style={{ marginRight: 5 }} onClick={() => {
                                                setAction("Approved")
                                                handleSubmit()
                                            }}>Approved</Button>
                                            <Button color="danger" outline onClick={() => {
                                                setAction("Rejected")
                                                handleSubmit()
                                            }}>Reject</Button>
                                        </div>
                                    </Col>
                                </Row>
                                <Button type="submit" style={{ display: "none" }} />
                            </Form>
                        )
                    }}
                </Formik>
            </CardBody>
        </Card>
    );
};

export default CaseClose;
