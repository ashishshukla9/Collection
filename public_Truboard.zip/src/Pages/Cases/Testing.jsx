import React, { useRef, useState } from 'react'
// import "./s"
import Swal from "sweetalert2";
import ProgressBar from '../../components/ProgressBar'
import axios from 'axios';
import { saveAs } from "file-saver";
// import ProgressBar from '../../components/ProgressBar'


function Testing() {
    const [progressLoader, setProgressLoader] = useState(false)
    const [fileUploadProgress, setFileUploadProgress] = useState({
        percentage: 0,
        uploadedData: 0,
        totalData: 0,
        stage: ''
    })
    const fileInputRef = useRef(null);

    // Function to trigger file input when the visible element is clicked
    const handleClick = () => {
        fileInputRef.current.click();
    };



    const handleChange = (e) => {
        Swal.fire({
            title: "Are you sure?",
            text: "You want to upload file!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, Upload it!",
        }).then(async (res) => {
            if (res?.isConfirmed) {
                axios.defaults.timeout = 1000 * 60 * 60 * 8
                axios.defaults.timeoutErrorMessage = 'timeout'
                const formData = new FormData()
                const fileFormData = new FormData()
                fileFormData.append("file", e?.target?.files[0])

                try {
                    setProgressLoader(true)
                    const eventSource = new EventSource('http://192.168.1.100:8081/v1/collections/case-upload/sse_key')
                    let guidValues = null;

                    eventSource.addEventListener('sse_key', async (event) => {
                        guidValues = JSON.parse(event?.data)

                        formData.append('sse_key', guidValues)
                        eventSource.addEventListener('message', (event) => {
                            const result = event?.data?.split('\n')
                            setFileUploadProgress({
                                percentage: result[0],
                                uploadedData: result[1],
                                totalData: result[2],
                                stage: result[3]
                            })

                            if (parseInt(result[0]) === 100) {
                                eventSource.close()
                                setProgressLoader(false)
                            }
                        })

                        const res = await axios.post(`http://192.168.1.100:8081/v1/collections/case-upload/file`, fileFormData, {
                            headers: {
                                "Content-Type": "multipart/form-data",
                                "sse_key": guidValues,
                                "api_key": "FIN.CU.k33JJ9X1fsdfHOsdsd50sA.77d8cd51-948c-4be7-a42c-6cc75"
                            }
                        })

                        const res1 = await axios.get(`http://192.168.1.100:8081/v1/collections/get/case-upload/file?batchId=BATCH0020240405121748`)

                        // console.log(res, "blob")
                        setProgressLoader(false)

                        if (res1?.data) {
                            // const res = await axios.post(`/getExportByBatchId/${batchId}?reportType=${type}`, null, { responseType: "arraybuffer" })
                            const blob = new Blob([res1.data], {
                                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            });
                            saveAs(blob, `failurecase.xlsx`);

                        }

                        Swal.fire({
                            toast: true,
                            position: "top-end",
                            icon: "success",
                            title: "Upload Successfully",
                            showConfirmButton: false,
                            timer: 4000,
                            timerProgressBar: true,
                            background: "#125120b5",
                            color: "#fff",
                            iconColor: "#fff",
                        });
                    })

                    eventSource.onerror = (event) => {
                        if (event?.target?.readyState === EventSource.CLOSED) {
                        }
                        setProgressLoader(false)
                        setFileUploadProgress({
                            percentage: 0,
                            uploadedData: 0,
                            totalData: 0,
                            stage: ''
                        })
                        eventSource.close()
                    }

                    eventSource.onopen = () => {
                    }
                } catch (error) {
                    Swal.fire({
                        position: "top-end",
                        icon: "error",
                        title: `${error.message}`,
                        showConfirmButton: false,
                        toast: true,
                        timer: 3000,
                    });
                }

            }
        })
    }
    return (
        <main>
            <div className='main'>
                <div className='secondContainer' >
                    <input type="file" ref={fileInputRef}
                        style={{ display: "none" }}
                        onChange={(e) => handleChange(e)}
                    />
                    <div onClick={() => handleClick()}>
                        <h3>
                            Case Upload
                        </h3>
                    </div>
                </div>
            </div>
            {
                progressLoader && <ProgressBar progressData={fileUploadProgress} />
            }
        </main>
    )
}

export default React.memo(Testing)
