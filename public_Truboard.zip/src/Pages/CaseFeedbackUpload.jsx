import React from 'react'

const CaseFeedbackUpload = () => {
  return (
    <div>
      feed back upload
    </div>
  )
}

export default CaseFeedbackUpload
