import { configureStore } from "@reduxjs/toolkit";
import { apiSlice } from "./features/api/apiSlice";
import { disputeReducer } from "./features/DisputeReducer";
import { caseProfileReducer } from "./features/CaseProfileReducer";
import sidebarReducer from "./features/sideBar/sidebarSlice";
import userSlice from "./features/user/userSlice";
import caseSlice from "./Pages/Cases/store";
import state from "./Pages/Master/GeographyMaster/State/store";
import region from "./Pages/Master/GeographyMaster/Region/store";
import pincode from "./Pages/Master/GeographyMaster/Pincode/store";
import city from "./Pages/Master/GeographyMaster/City/store";
import zone from "./Pages/Master/GeographyMaster/Zone/store";
import country from "./Pages/Master/GeographyMaster/Country/store";
import bankMaster from "./Pages/Master/Bank/BankMaster/store";
import bankBranchMaster from "./Pages/Master/Bank/BankBranchMaster/store";
import users from "./Pages/User/store";
import role from "./Pages/Role/store";
import profile from "./Pages/Profile/store";
import global from './reducer/globalReducer';
import portfolioMaster from './Pages/Master/store/portfolioMasterSlice';
import productMaster from './Pages/Master/store/productMasterSlice';
import lookup from './Pages/Master/LookupMaster/lookupSlice';
import payloadDetailsReducer, { setAllPayload } from "./Pages/Dashboard/Features";
import LiveTrackingSlice from "./Pages/LiveTracking/LiveTrackingSlice";
export const store = configureStore({
  reducer: {
    [apiSlice.reducerPath]: apiSlice.reducer,
    sideNav: sidebarReducer,
    user: userSlice,
    users,
    cases: caseSlice,
    dispute: disputeReducer,
    case: caseProfileReducer,
    zone,
    state,
    region,
    pincode,
    city,
    country,
    bankMaster,
    bankBranchMaster,
    role,
    profile,
    global,
    portfolioMaster,
    productMaster,
    lookup,
    allpayload: payloadDetailsReducer,
    Allcharttype: payloadDetailsReducer,
    AllDashboardData: payloadDetailsReducer,
    setGeoLocation: payloadDetailsReducer,
    LiveTrackingSlice
  },
  middleware: (getDefaultMiddleware) => {
    return getDefaultMiddleware({ serializableCheck: false }).concat(
      apiSlice.middleware
    );
  },
  devTools: true,
});
export default store;
const name = "akash"
const obj = {
  name: name
}