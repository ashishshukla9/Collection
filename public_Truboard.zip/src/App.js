import React, { Fragment, useEffect } from "react";
import "./App.css";
import "./scss/style.scss";

//theme
import "primereact/resources/themes/lara-light-indigo/theme.css";

//core
import "primereact/resources/primereact.min.css";

import "bootstrap-icons/font/bootstrap-icons.css";
import { RouterProvider } from "react-router-dom";
import router from "./routes";
import { useDispatch, useSelector } from "react-redux";
import { ProgressSpinner } from "primereact/progressspinner";
import { getPasswordValidation, getSessionTimeout, setLetLong } from "./reducer/globalReducer";
function App() {
  const loader = useSelector(state => state?.global?.loader)
  const unfoldable = useSelector((state) => state.sideNav.sidebarUnfoldable);
  const dispatch = useDispatch()
  useEffect(() => {
    dispatch(getPasswordValidation())
    dispatch(getSessionTimeout())
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        dispatch(setLetLong(`${latitude},${longitude}`))
      },
        (error) => {
          dispatch(setLetLong(''))
        }
      );
    } else {
      dispatch(setLetLong(''))
    }
  }, [])
  return (
    <Fragment>
      {loader &&
        <div className={`loader ${window?.location?.hash === "#/dashboard" && (unfoldable ? 'foldableLoader' : 'unfoldableLoader')}`}>
          <ProgressSpinner />
        </div>
      }
      <RouterProvider router={router} />
    </Fragment>
  );
}
export default App;