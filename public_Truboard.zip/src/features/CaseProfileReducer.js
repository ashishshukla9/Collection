const initialState = {
  caseProfile: {},
  payment: [],
  ptp: [],
  activityHistory: [],
};

export const caseProfileReducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case "SET_CASE_PROFILE":
      return { ...state, caseProfile: { ...payload } };

    // Payment
    case "SET_CASE_PAYMENT":
      return { ...state, payment: [...payload] };
    case "ADD_CASE_PAYMENT":
      let paymentTemp = state.payment;
      paymentTemp.push(payload);
      return { ...state, payment: paymentTemp };
    case "UPDATE_CASE_PAYMENT":
      let newStatePayment = [];
      let updateIndexPayment = state.payment.indexOf(
        (e) => e.paymentId === payload.paymentId
      );
      state.payment.splice(updateIndexPayment, 1);
      newStatePayment = [payload, ...state.payment];
      return { ...state, payment: [...newStatePayment] };

    // PTP
    case "SET_CASE_PTP":
      return { ...state, ptp: [...payload] };
    case "ADD_CASE_PTP":
      let ptpTemp = state.ptp;
      ptpTemp.push(payload);
      return { ...state, ptp: ptpTemp };
    case "UPDATE_CASE_PTP":
      let newStatePtp = [];
      let updateIndexPtp = state.ptp.indexOf((e) => e.ptpId === payload.ptpId);
      state.ptp.splice(updateIndexPtp, 1);
      newStatePtp = [payload, ...state.ptp];
      return { ...state, ptp: [...newStatePtp] };

    // activity history
    case "SET_ACTIVITY_HISTORY":
      return { ...state, activityHistory: [...payload] };
    default:
      return state;
  }
};
