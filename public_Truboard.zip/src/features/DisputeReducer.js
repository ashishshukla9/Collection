const initialState = [];

export const disputeReducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case "GET_ALL_DISPUTE":
      return [...payload];
    case "ADD_DISPUTE":
      return [...state, payload];
    case "UPDATE_DISPUTE":
      let newState = [];
      let updateIndex = state.indexOf(
        (e) => e.disputeOrRtpId === payload.disputeOrRtpId
      );
      state.splice(updateIndex, 1);
      newState = [payload, ...state];
      return [...newState];
    default:
      return state;
  }
};
