import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { Cookies } from "react-cookie";

const cookies=new Cookies()
export const apiSlice = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({
    baseUrl: process.env.REACT_APP_BASE_URL,
    prepareHeaders: (headers, { getState }) => {
      const token = cookies.get("token");
      if (token) {
        headers.set("Authorization", `Bearer ${token}`);
      }
      return headers;
    },
    // credentials: "include", // This allows server to set cookies
  }),
  // tagTypes: ["PORTFOLIO", "PRODUCT"],
  endpoints: () => ({
    // getUsers: builder.query({
    //   query: () => "/getUserByUID/admin",
    // }),
  }),
});

export const { useGetUsersQuery } = apiSlice;
