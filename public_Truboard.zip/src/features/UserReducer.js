import { createReducer } from "@reduxjs/toolkit";

const userInitialState = {
  data: null,
};

// export const userState = (state = userInitialState, { type, payload }) => {
//   switch (type) {
//     case "LOGIN":
//       return { ...state, data: payload };
//     case "LOGOUT":
//       return { ...state, data: null };
//     default:
//       return state;
//   }
// };

export const userState = createReducer(userInitialState, (builder) => {
  builder
    .addCase("LOGIN", (state, action) => {
      state.data = action.payload;
    })
    .addCase("LOGOUT", (state, action) => {
      state.data = null;
    });
});
