import React, { useContext, createContext, useReducer } from "react";
import jwtDecode from "jwt-decode";
import { setToken } from "../utils/setToken";
import setUser from "../utils/setUser";
import { logout } from "../features/user/userSlice";
import store from "../store";
import { Cookies } from "react-cookie";

const AuthContext = createContext();
const AuthDispatchContext = createContext();
const cookies=new Cookies()

// let user = { name: "John" };
let user = null;
const token = cookies.get("token");
let userObj = cookies.get("user");
if (token && token !== undefined && token!==null && token!=="undefined") {
  const decodeToken = jwtDecode(token);
  const expireAt = new Date(decodeToken.exp * 1000);

  if (new Date() > expireAt) {
    cookies.remove("token");
    setToken();
  } else {
    setToken(token);
    user = decodeToken;
    // setUser(userObj?.name);
    setUser(user?.sub)
  }
} else {
  console.log("No token found");
}

const authReducer = (state, action) => {
  switch (action.type) {
    case "LOGIN":
      localStorage.setItem("token", action.payload.token);
      const decodeToken = jwtDecode(action.payload.token);
      setToken(action.payload.token);
      setUser(userObj?.name);
      return {
        ...state,
        user: decodeToken,
      };
    case "LOGOUT":
      localStorage.clear();
      store.dispatch(logout());
      setToken();
      return {
        ...state,
        user: null,
      };
    default:
      return state;
  }
};

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, { user });

  return (
    <AuthDispatchContext.Provider value={dispatch}>
      <AuthContext.Provider value={state}>{children}</AuthContext.Provider>
    </AuthDispatchContext.Provider>
  );
};

export const useAuthState = () => useContext(AuthContext);
export const useAuthDispatch = () => useContext(AuthDispatchContext);
