import React from "react";
import Select, { components } from "react-select";
import cx from "classnames";
import { FormGroup, Label, Col, FormFeedback } from "reactstrap";
import { useFormikContext } from "formik";

export default function SelectionFormik({
  options,
  component,
  value,
  handleChangeEvent,
  ids,
  label,
  isView,
  isMultiSelection = false,
}) {
  const { errors, handleBlur, touched, setFieldValue } = useFormikContext();

  const DropdownIndicator = (props) => {
    return (
      <components.DropdownIndicator {...props}>
        <span role="img" aria-label="search-icon">
          <i className="bi bi-search"></i>
        </span>
      </components.DropdownIndicator>
    );
  };

  return (
    <FormGroup row className="align-items-center">
      <Label sm={4} for={ids}>
        {label}
        <span className="required c-danger">*</span>
      </Label>
      <Col sm={8}>
        <Select
          bsSize="sm"
          inputId={ids}
          isClearable={true}
          options={options}
          hideSelectedOptions={false}
          closeMenuOnSelect={true}
          components={{ ...component, DropdownIndicator }}
          value={value}
          onChange={(e) => handleChangeEvent(e, setFieldValue)}
          className={cx({
            abc: touched[ids] && Boolean(errors[ids]),
          })}
          classNamePrefix="react-select"
          onBlur={handleBlur}
          isMulti={isMultiSelection}
          menuPosition={"fixed"}
          isDisabled={isView}
        ></Select>
        {touched[ids] && Boolean(errors[ids]) && (
          <FormFeedback style={{ display: "block" }}>
            {errors[ids]}
          </FormFeedback>
        )}
      </Col>
    </FormGroup>
  );
}
