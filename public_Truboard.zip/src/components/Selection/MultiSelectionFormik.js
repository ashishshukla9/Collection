import React from "react";
import Select, { components } from "react-select";
import cx from "classnames";
import { FormGroup, Label, Col, FormFeedback } from "reactstrap";
import { useFormikContext } from "formik";
import Field from "../Field";
export default function MultiSelectionFormik({
  options,
  component,
  value,
  handleChangeEvent,
  ids,
  label,
  isView,
  closeMenu = false,
  error,
  touch,
  filterOption,
  onKeyDown,
  onInputChange,
  isRequired,
  onMenuScrollToBottom
}) {
  const { errors, handleBlur, touched } = useFormikContext();
  const DropdownIndicator = (props) => {
    return (
      <components.DropdownIndicator {...props}>
        <span role="img" aria-label="search-icon">
          <i className="bi bi-search"></i>
        </span>
      </components.DropdownIndicator>
    );
  };
  const Option = (props) => {
    return (
      <div>
        <components.Option {...props}>
          <input
            type="checkbox"
            checked={props.isSelected}
            onChange={() => null}
          />{" "}
          <label>{props.label}</label>
        </components.Option>
      </div>
    );
  };
  return (
    <Field
      isRequired={isRequired}
      label={label}
      errorMessage={((touched[ids] || touch) && (Boolean(errors[ids]) || Boolean(error))) && (errors[ids] || error)}
    >
      <Select
        style={{ zIndex: 999}}
        bsSize="sm"
        inputId={ids}
        isClearable={true}
        options={options}
        isMulti
        hideSelectedOptions={false}
        components={{ ...component, DropdownIndicator, Option }}
        value={value}
        onChange={(e,actionMeta) => handleChangeEvent(e,actionMeta)}
        className={cx('multiSelectDropdwn', {
          abc:
            (touched[ids] || touch) &&
            (Boolean(errors[ids]) || Boolean(error)),
        })}
        classNamePrefix="react-select"
        closeMenuOnSelect={closeMenu}
        onBlur={handleBlur}
        menuPosition={"fixed"}
        isDisabled={isView}
        filterOption={filterOption}
        onKeyDown={onKeyDown}
        onInputChange={onInputChange}
        styles={{
          menuPortal: base => ({ ...base, zIndex: 9999}),
        }}
        onMenuScrollToBottom={onMenuScrollToBottom}
      />
    </Field>
  );
}
