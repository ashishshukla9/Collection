import React from "react";
import { useLocation } from "react-router-dom";

import { routes } from "../../routes";

import { CBreadcrumb, CBreadcrumbItem } from "@coreui/react";

const AppBreadcrumb = () => {
  const currentLocation = useLocation().pathname;

  // const getRouteName = (pathname, routes) => {
  //   const currentRoute = routes.find((route) => route.path === pathname);
  //   console.log(currentRoute, "oooooooo", pathname);
  //   return currentRoute ? currentRoute.name : false;
  // };

  // const getBreadcrumbs = (location) => {
  //   const breadcrumbs = [];
  //   location.split("/").reduce((prev, curr, index, array) => {
  //     const currentPathname = `${prev}/${curr}`;
  //     const routeName = getRouteName(currentPathname, routes);
  //     console.log(currentPathname);
  //     routeName &&
  //       breadcrumbs.push({
  //         pathname: currentPathname,
  //         name: routeName,
  //         active: index + 1 === array.length ? true : false,
  //       });
  //     return currentPathname;
  //   });
  //   console.log(breadcrumbs, "iiiiii");
  //   return breadcrumbs;
  // };

  // const breadcrumbs = getBreadcrumbs(currentLocation);

  function header(location) {
    let templocation = location.split("/")[1];
    return templocation.toUpperCase().replace("_", " ");
  }

  return (
    <CBreadcrumb className="m-0 ms-2">
      <CBreadcrumbItem href="#/dashboard">HOME</CBreadcrumbItem>
      {/* {breadcrumbs.map((breadcrumb, index) => { */}
      {/* return ( */}
      <CBreadcrumbItem>{header(currentLocation)}</CBreadcrumbItem>
      {/* ); */}
    </CBreadcrumb>
  );
};

export default React.memo(AppBreadcrumb);
