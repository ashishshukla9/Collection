import React, { useEffect, useState } from "react";
import {
  CBadge,
  CDropdown,
  CDropdownHeader,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from "@coreui/react";
import {
  cilBell,
  cilEnvelopeOpen,
  cilLockLocked,
} from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import axios from "axios";
import { Cookies } from "react-cookie";
import { Badge } from 'primereact/badge';
import { useNavigate } from "react-router-dom";

const AppHeaderDropdown = () => {
  const [avatrImag, setAvtarImag] = useState();
  const [notification, setNotification] = useState(0)
  const [count, setcount] = useState(0)
  const user = useSelector((state) => state.user.data);
  const cookies = new Cookies()
  const navigate = useNavigate()


  // console.log(user, "userreponse")
  const handleLogout = async () => {
    try {
      const payload = {
        userid: user?.userId,
        token: cookies.get('token'),
        reason: 'Manual Logout'
      }
      const res = await axios.put('/logOutUser', payload)
      cookies.remove('user')
      cookies.remove('token')
      cookies.remove('logout')
      window.location.reload();
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };

  const avtarFuncton = () => {
    const firstName = user?.firstName.charAt(0);
    const lastName = user?.lastName.charAt(0);
    const avtarImg = firstName + lastName;
    setAvtarImag(avtarImg || '');
  };

  // const getResponse = async () => {
  //   try {
  //     const res = await axios.get(`/getByReportingManager/${user?.userId}/${1}/${10}`)
  //     setNotification(res?.data?.pending)
  //   } catch (error) {
  //   }
  // }


  useEffect(() => {
    if (user) {
      const getNotificationCount = async () => {
        const res = await axios.get("/mapperNewCount")
        setcount(res?.data?.data)
      }
      getNotificationCount()
    }
  }, [user])


  const handleClick = async () => {
    const res = await axios.post("/updateMapperCount")
    const resCount = res?.data?.data == null ? 0 : res?.data?.data
    navigate("/cases");
    setNotification(resCount)
  }

  useEffect(() => {
    avtarFuncton();
    // getResponse();

  }, [user, count]);

  return (
    <CDropdown variant="nav-item">
      <CDropdownToggle placement="bottom-end" className="py-0" caret={false}>
        {/* <CAvatar src={avatar8} size="md" /> */}

        <div className="d-flex justify-content-end gap-2">
          <div
            style={{
              width: "40px", // Set your desired width and height
              height: "40px",
              backgroundColor: "grey",
              borderRadius: "50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "white"
            }}
          >
            <h5>{avatrImag}</h5>
          </div>
          {user?.firstName && user?.lastName &&
            <span className="h5 mt-1">{user?.firstName + " " + user?.lastName}</span>
          }
        </div>
      </CDropdownToggle>
      <CDropdownMenu className="pt-0" placement="bottom-end">
        <CDropdownHeader className="bg-light fw-semibold py-2">
          Account
        </CDropdownHeader>
        {/* <CDropdownItem href="#">
          <CIcon icon={cilBell} className="me-2" />
          Updates
          <CBadge color="info" className="ms-2">
            42
          </CBadge>
        </CDropdownItem>
       
        <CDropdownItem href="#">
          <CIcon icon={cilTask} className="me-2" />
          Tasks
          <CBadge color="danger" className="ms-2">
            42
          </CBadge>
        </CDropdownItem>
        <CDropdownItem href="#">
          <CIcon icon={cilCommentSquare} className="me-2" />
          Comments
          <CBadge color="warning" className="ms-2">
            42
          </CBadge>
        </CDropdownItem>
        <CDropdownHeader className="bg-light fw-semibold py-2">
          Settings
        </CDropdownHeader>
        <CDropdownItem href="#">
          <CIcon icon={cilUser} className="me-2" />
          Profile
        </CDropdownItem>
        <CDropdownItem href="#">
          <CIcon icon={cilSettings} className="me-2" />
          Settings
        </CDropdownItem>
        <CDropdownItem href="#">
          <CIcon icon={cilCreditCard} className="me-2" />
          Payments
          <CBadge color="secondary" className="ms-2">
            42
          </CBadge>
        </CDropdownItem>
        <CDropdownItem href="#">
          <CIcon icon={cilFile} className="me-2" />
          Projects
          <CBadge color="primary" className="ms-2">
            42
          </CBadge>
        </CDropdownItem>
        <CDropdownDivider /> */}
        <CDropdownItem onClick={handleLogout} style={{ cursor: "pointer" }}>
          <CIcon icon={cilLockLocked} className="me-2" />
          Logout
        </CDropdownItem>
        {/* {
          user?.masterRole?.requestmanagement_all == "F" ? (
            <CDropdownItem onClick={() => { navigate("/requests"); setNotification(0) }} style={{ cursor: "pointer" }}>
              <CIcon icon={cilBell} className="me-2" />
              Requests
              {
                notification > 0 ? (<CBadge color="info" className="ms-2">
                  {notification}
                </CBadge>) : ""
              }

            </CDropdownItem>
          ) : ("")
        } */}
        {
          user?.role[0]?.roleCode == "MIS" ? (<CDropdownItem onClick={handleClick} style={{ cursor: "pointer" }}>
            <CIcon icon={cilBell} className="me-2" />
            New Cases
            {
              count > 0 ? (<CBadge color="secondary" className="ms-2">
                {count}
              </CBadge>) : ""
            }

          </CDropdownItem>) : ""
        }


      </CDropdownMenu>
    </CDropdown>
  );
};

export default AppHeaderDropdown;
