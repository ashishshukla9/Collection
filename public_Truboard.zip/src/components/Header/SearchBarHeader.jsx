import { memo, useEffect, useState } from "react"
import { Button, Input } from "reactstrap"
import styles from './Header.module.css'

const SearchBarHeader = (props) => {
    const [search, setSearch] = useState('')
    const [isSearchAPICalled,setIsSearchAPICalled]=useState(false)
    useEffect(()=>{
        const searchFun = setTimeout(() => {
            if(search?.trim()){
                if(isSearchAPICalled){
                    props?.serachAPI({
                        search: search?.trim(),
                        currentPage: props?.currentPage,
                        numberOfDataPerPage: props?.numberOfDataPerPage
                    })
                }else{
                    if(props?.isPagination){
                        setIsSearchAPICalled(true)
                        props?.serachAPI({
                            search: search?.trim(),
                            currentPage: 1,
                            numberOfDataPerPage: props?.numberOfDataPerPage
                        })
                    }else{
                        props?.serachAPI(search?.trim())
                    }
                }
            }else{
                setIsSearchAPICalled(false)
                props?.getAllAPI()
            }
        }, 1000);

        return(()=> clearInterval(searchFun))
    },[search,props?.currentPage,props?.numberOfDataPerPage])

    return (
        <div className={`mb-1 ${styles?.container}`}>
            <Input
                placeholder="Search..."
                type="text"
                value={search}
                onChange={(e) => {
                    setIsSearchAPICalled(false)
                    setSearch(e?.target?.value)
                }}
                className={styles?.input}
            />

            {/* create button here  */}
            {(props?.permission !== "V" && props?.permission) &&
            // console.log("inner the condition")
                <Button
                    size="sm"
                    color="primary"
                    onClick={props?.onClick}
                >
                    Create
                </Button>
            }
        </div>
    )
}

export default memo(SearchBarHeader)