import {
  Button,
  Card,
  CardBody,
  Col,
  Form,
  Input,
  FormGroup,
  Label,
  Row,
  FormFeedback,
  Container,
} from "reactstrap";
import { Formik } from "formik";
import { scrollToErrorMessage } from "../../utils/commonFun";
import { Link } from "react-router-dom";
import * as yup from "yup";
import Swal from "sweetalert2";
import axios from "axios";

const ForgotScrren = () => {
  const initialValues = {
    uid: "",
  };

  const validation = yup.object({
    uid: yup.string().required("User Name Is Required."),
  });

  var currentLocation = window.location.origin.includes("localhost")
    ? window.location.origin + "/#/forgot_password"
    : window.location.origin + "/collection/#/forgot_password";
  const gotoMail = async (values, { resetForm }) => {
    try {
      await axios
        .get(
          `${process.env.REACT_APP_BASE_URL}/generateMailToken/${values?.uid}`
        )
        .then((res) => {
          const params = {
            url: currentLocation + "?" + res?.data?.data,
          };
          if (res?.data?.msgKey === "Success") {
            axios
              .post(`/sendResetPasswordMail/${values?.uid}`, null, {
                params,
              })
              .then((response) => {
                if (res?.data?.msgKey === "Success") {
                  Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: `{res.data.message}`,
                    showConfirmButton: false,
                    toast: true,
                    timer: 3000,
                  });
                  resetForm({ uid: "" });
                }

                Swal.fire({
                  position: "top-end",
                  icon: res?.data?.msgKey === "Failure" ? "error" : "success",
                  title: `${res.data.message}`,
                  showConfirmButton: false,
                  toast: true,
                  timer: 3000,
                });
              });
          }

          window.changeURL = btoa(JSON.stringify(params))
        }); 
    } catch (error) {
      console.log(error);
    }
  };

  // /forgot_password
  return (
    <>
      <div className="App">
        <Container>
          <Formik
            enableReinitialize={true}
            initialValues={initialValues}
            validationSchema={validation}
            onSubmit={gotoMail}
          >
            {({
              values,
              errors,
              handleChange,
              handleBlur,
              touched,
              handleSubmit,
              setFieldValue,
              setFieldError,
              isSubmitting,
            }) => {
              const err = Object.keys(errors)[0];
              scrollToErrorMessage(isSubmitting, err);
              return (
                <div
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    minHeight: "100vh",
                  }}
                >
                  <Form onSubmit={handleSubmit}>
                    <Card
                      style={{
                        width: "500px",
                        height: "450px",
                        padding: "20px",
                      }}
                    >
                      <CardBody>
                        <Row className="mt-5 mb-3">
                          <h4>
                            <b>Forgot Password</b>
                          </h4>
                          <br />
                          <br />
                          <p>
                            Please enter the User Name you had provided while
                            creating your account
                          </p>
                        </Row>
                        <Row className="mb-3">
                          <Col lg={12} md={12} sm={12}>
                            <FormGroup className="rmb-0" floating>
                              <Input
                                type="text"
                                id="uid"
                                value={values.uid}
                                placeholder="User Name"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                invalid={touched.uid && Boolean(errors.uid)}
                              />
                              <Label for="password">User Name</Label>
                              <FormFeedback>{errors?.uid}</FormFeedback>
                            </FormGroup>
                          </Col>
                        </Row>

                        <Row className="mb-3 mt-3">
                          <FormGroup className="rmb-0" floating>
                            <div className="d-flex justify-content-center">
                              <Button
                                size="md"
                                type="submit"
                                color="primary"
                                style={{ color: "white" }}
                              >
                                Send Mail
                              </Button>
                            </div>
                          </FormGroup>
                        </Row>
                        <Row>
                          <text className="d-flex justify-content-center text-success">
                            Back to login <Link to={"/"}>Click here.</Link>
                          </text>
                        </Row>
                      </CardBody>
                    </Card>
                  </Form>
                </div>
              );
            }}
          </Formik>
        </Container>
      </div>
    </>
  );
};

export default ForgotScrren;
