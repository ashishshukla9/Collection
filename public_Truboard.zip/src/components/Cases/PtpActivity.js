import moment from "moment";
import React from "react";
import { Card, CardBody, CardTitle, Col, Row, Table } from "reactstrap";

export default function PtpActivity({ obj, isHistory = false }) {

  const dateFormate = (dateString) => {
    const dateParts = dateString.split("-");
    return `${dateParts[2]}/${dateParts[1]}/${dateParts[0].slice(2)}`;

  }


  function convertTimeToAmPm(timeString) {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const minute = parseInt(minutes, 10);
    const period = (hour >= 12) ? 'PM' : 'AM';
    const hour12 = (hour > 12) ? hour - 12 : (hour === 0) ? 12 : hour;
    const formattedTime = `${hour12}:${minutes} ${period}`;
    return formattedTime;
  }
  // console.log(obj, "ptptp")
  return (
    <Card className="m-1">
      <CardBody>
        <>
          <Table striped className="text-center activityHistory mb-0 b-0">
            <tbody>
              {isHistory && (
                <tr>
                  <td className="fw-bold">Name</td>
                  <td>{`${obj?.user?.firstName} ${obj?.user?.lastName}`}</td>
                  <td className="fw-bold leftBorder">Created Time</td>
                  <td>
                    {moment(obj?.createdTime).format("YYYY-MM-DD HH:mm:ss")}
                  </td>
                </tr>
              )}
              <tr>
                <td className="fw-bold">PTP Amount</td>
                <td>{obj?.ptpAmount?.toLocaleString('en-IN', {
                  style: 'currency',
                  currency: 'INR'
                })}</td>
                <td className="fw-bold leftBorder">PTP Date</td>
                <td>{dateFormate(obj?.ptpDate)}</td>
                {/* {obj.ptpDate} */}

              </tr>
              <tr>
                <td className="fw-bold">PTP Status</td>
                <td>{obj?.status ?? '-'}</td>
                <td className="fw-bold leftBorder">PTP Time</td>
                <td>{obj?.ptpTime ? convertTimeToAmPm(obj?.ptpTime) : '-'}</td>
              </tr>
              <tr>
                <td className="fw-bold">PTP Type</td>
                <td>{obj?.ptpType ?? '-'}</td>
                <td className="fw-bold leftBorder">Remark</td>
                <td>{obj?.remark ?? '-'}</td>
              </tr>
              
              {obj?.offlineCreationDate ? (
                <tr >
                  <td className="fw-bold">Offline Created-Date</td>
                  <td style={{borderRight:"1px solid lightgray"}}>{obj.offlineCreationDate}</td>
                </tr>
              ) : null}

            </tbody>
          </Table>
        </>
      </CardBody>
    </Card>
  );
}
