import moment from "moment";
import { memo } from "react"
import { Card, CardBody, Table } from "reactstrap"

const ContactCenterActivity = ({ obj, disputeReason, isHistory = false }) => {
    
    return (
        <Card className="m-1">
            <CardBody>
                <Table striped className="text-center activityHistory mb-0 b-0">
                    <tbody>
                        {isHistory && (
                            <tr>
                                <td className="fw-bold">Name</td>
                                <td>{`${obj?.contactCentre?.user?.firstName} ${obj?.contactCentre?.user?.lastName}`}</td>
                                <td className="fw-bold leftBorder">Update Time</td>
                                <td>
                                    {moment(obj?.createdTime).format("YYYY-MM-DD HH:mm:ss")}
                                </td>
                            </tr>
                        )}
                        <tr>
                            <td className="fw-bold">Ref</td>
                            <td>{obj?.amount}</td>
                            <td className="fw-bold leftBorder">Remarks</td>
                            <td>{obj?.remark}</td>
                        </tr>
                        <tr>
                            <td className="fw-bold">Dispute Type</td>
                            <td>{obj?.disputeType}</td>
                            <td className="fw-bold leftBorder">Dispute Reason</td>
                            <td>{disputeReason[obj?.disputeReason]}</td>
                        </tr>
                        <tr>
                            <td className="fw-bold">Evidence</td>
                            <td>{obj?.ptpType ?? "-"}</td>
                            <td className="fw-bold leftBorder"></td>
                            <td></td>
                        </tr>
                    </tbody>
                </Table>
            </CardBody>
        </Card>
    )
}

export default memo(ContactCenterActivity)