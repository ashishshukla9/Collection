import moment from "moment";
import React from "react";
import { Card, CardBody, Table } from "reactstrap";

export default function PaymentInfoActivity({ obj, isHistory = false }) {
  return (
    <Card className="m-1">
      <CardBody>
        <div>
          <Table striped className="text-center activityHistory mb-0 b-0">
            <tbody>
              {isHistory && (
                <tr>
                  <td className="fw-bold">Name</td>
                  <td>{`${obj?.user?.firstName} ${obj?.user?.lastName}`}</td>
                  <td className="fw-bold leftBorder">Created Time</td>
                  <td>
                    {moment(obj?.createdTime).format("YYYY-MM-DD HH:mm:ss")}
                  </td>
                </tr>
              )}
              <tr>
                <td className="fw-bold">Amount</td>
                <td>{obj?.amount}</td>
                <td className="fw-bold leftBorder">Mobile</td>
                <td>{obj?.phoneNumber}</td>
              </tr>
              <tr>
                <td className="fw-bold">Remark</td>
                <td>{obj?.remark}</td>
                <td className="fw-bold leftBorder">Payment Type</td>
                <td>{obj?.paymentType}</td>
              </tr>
              <tr>
                <td className="fw-bold">Payment Status</td>
                <td>{obj?.paymentStatus}</td>
                <td className="fw-bold leftBorder"></td>
                <td></td>
              </tr>

              {obj?.offlineCreationDate ? (
                <tr>
                  <td className="fw-bold">Offline Created-Date</td>
                  <td style={{borderRight:"1px solid lightgray"}}>{obj.offlineCreationDate}</td>
                </tr>
              ) : null}


            </tbody>
          </Table>
        </div>
      </CardBody>
    </Card>
  );
}
