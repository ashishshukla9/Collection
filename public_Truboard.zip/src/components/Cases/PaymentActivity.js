import axios from "axios";
import moment from "moment";
import React, { useState } from "react";
import { Card, CardBody, Table } from "reactstrap";
import { DownloadFile } from "../../utils/DownloadFile";
import { Dialog } from "primereact/dialog";


export default function PaymentActivity({ obj, isHistory = false }) {
  // console.log(obj, "paymentcreated time")
  const [EvidenceImage, setEvedenceImage] = useState(false)
  const [evidencedata, setEvidenceData] = useState("")

  function formatDateTime(milliseconds) {
    if (!milliseconds) return null;
    var dateTime = new Date(milliseconds);
    var year = dateTime.getFullYear();
    var month = String(dateTime.getMonth() + 1).padStart(2, '0');
    var day = String(dateTime.getDate()).padStart(2, '0');
    var hours = String(dateTime.getHours()).padStart(2, '0');
    var minutes = String(dateTime.getMinutes()).padStart(2, '0');
    var seconds = String(dateTime.getSeconds()).padStart(2, '0');
    var formattedDateTime = day + '-' + month + '-' + year + ' ' + hours + ':' + minutes + ':' + seconds;

    return formattedDateTime;
  }


  function convertDateFormat(dateString) {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    const formattedDate = `${day}/${month}/${year}`;
    return formattedDate;
  }


  function convertTimeToAmPm(timeString) {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const minute = parseInt(minutes, 10);
    const period = (hour >= 12) ? 'PM' : 'AM';
    const hour12 = (hour > 12) ? hour - 12 : (hour === 0) ? 12 : hour;
    const formattedTime = `${hour12}:${minutes} ${period}`;
    return formattedTime;
  }


  const handlePaymentDownload = async (obj) => {

    try {
      const res = await axios.get(`/getDocumentByPaymentId/${obj?.paymentId}`)
      await DownloadFile(`/download-payment-file/${res?.data?.paymentId}`, res?.data?.name)
    } catch (error) {
    }
  }

  const handleShowPaymentAvidance = async (obj) => {
    try {
      const res = await axios.get(`/getDocumentByPaymentId/${obj?.paymentId}`)
      const response = await axios({
        url: `/download-payment-file/${res?.data?.paymentId}`,
        method: "GET",
        responseType: "blob",
      });

      const link = document.createElement("a");
      link.href = URL.createObjectURL(new Blob([response.data]));
      setEvidenceData(link.href)
      setEvedenceImage(!EvidenceImage)
    } catch (error) {
      console.log(error)
    }

  }
  return (
    <Card className="m-1">
      <CardBody>
        <div>
          <Table striped className="text-center activityHistory mb-0 b-0">
            <tbody>
              {isHistory && (
                <tr>
                  <td className="fw-bold">Name</td>
                  <td>{`${obj?.user?.firstName} ${obj?.user?.lastName}`}</td>
                  <td className="fw-bold leftBorder">Created Time</td>
                  <td>
                    {/* {moment(obj?.createdTime).format("YYYY-MM-DD HH:mm:ss")} */}
                    {formatDateTime(obj?.createdTime)}
                  </td>
                </tr>
              )}
              <tr>
                <td className="fw-bold">Amount</td>
                <td>{obj?.amount.toLocaleString('en-IN')}</td>
                <td className="fw-bold leftBorder">Mobile</td>
                <td>{obj?.phoneNumber}</td>
              </tr>
              <tr>
                <td className="fw-bold">Remark</td>
                <td>{obj?.remark}</td>
                <td className="fw-bold leftBorder">Payment Type</td>
                <td>{obj?.paymentType}</td>
              </tr>
              <tr>
                <td className="fw-bold">Payment Status</td>
                <td>{obj?.paymentStatus}</td>
                <td className="fw-bold leftBorder">Payment Date</td>
                <td>{convertDateFormat(obj?.paymentDate)}</td>
              </tr>

              <tr>
                <td className="fw-bold">Payment time</td>
                <td>{convertTimeToAmPm(obj?.timeOfPayment)}</td>
                <td className="fw-bold leftBorder">Evidence</td>
                <td>
                  {

                    obj?.isDocument == "yes" ? (
                      <>
                        <button onClick={() => handleShowPaymentAvidance(obj)} style={{ background: "transparent", color: "green", border: "none" }}><i class="bi bi-card-image" ></i></button>
                        <button onClick={() => handlePaymentDownload(obj)} style={{ background: "transparent", color: "green", border: "none" }}><i class="bi bi-cloud-download" ></i></button>
                      </>
                    ) : "No Upload"
                  }
                </td>

              </tr>

              {obj?.offlineCreationDate ? (
                <tr>
                  <td className="fw-bold">Offline Created-Date</td>
                  <td style={{borderRight:"1px solid lightgray"}}>{obj.offlineCreationDate}</td>
                </tr>
              ) : null}


              {/* {console.log(obj, "objobjobjobj")} */}
              <tr>
                {obj?.paymentMode === 'Digital' ? (
                  <><td className="fw-bold leftBorder">Payment Mode</td><td>{obj?.paymentMode ? obj?.paymentMode : "-"}</td></>
                ) : (
                  <>
                    <td className="fw-bold">Deposition Status</td>
                    <td>{obj?.depositionStatus}</td>
                    <td className="fw-bold leftBorder" style={{borderTop:"1px solid lightgray"}}>Payment Mode</td>
                    <td style={{borderTop:"1px solid lightgray"}}>{obj?.paymentMode ? obj?.paymentMode : "-"}</td>
                  </>
                )}
              </tr>

              <tr>
                <td className="fw-bold">Cheque Number</td>
                <td>{obj?.chequeNumber ? obj?.chequeNumber : "-"}</td>
                <td className="fw-bold leftBorder"> Reference Number</td>
                <td>{obj?.referenceNumber ? obj?.referenceNumber : "-"}</td>
              </tr>
              <tr>
                <td className="fw-bold">Demand Draft Number</td>
                <td>{obj?.demandDraftNumber ? obj?.demandDraftNumber : "-"}</td>
                <td className="fw-bold leftBorder">Digital Payment Mode</td>
                <td>{obj?.digitalPaymentMode ? obj?.digitalPaymentMode : "-"}</td>
              </tr>

            </tbody>
          </Table>
          <Dialog
            visible={EvidenceImage && evidencedata}
            header="Payment Evidence"

            onHide={() => setEvedenceImage(!EvidenceImage)}
          >
            <img src={evidencedata} style={{ width: "100%", height: "100%" }}></img>
          </Dialog>
        </div>
      </CardBody>
    </Card>
  );
}
