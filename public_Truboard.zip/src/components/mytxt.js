//   Add user pincode search custom previous code 
import axios from "axios";
import React, { memo, useEffect, useRef, useState } from "react";
import ReactSelect, { components } from "react-select";

function MultiSelectComma(props) {
  const [menuIsOpen,setMenuIsOpen]=useState(false)
  const [options,setOptions]=useState([])
  // isOptionSelected sees previous props.value after onChange
  const valueRef = useRef(props.value);
  valueRef.current = props.value;

  const selectAllOption = {
    value: "<SELECT_ALL>",
    label: "Select All",
  };

  // const getValue = () =>{
  //   return (!props?.isSearch) ? [selectAllOption] : props.value;
  // }

  const onChange = (newValue, actionMeta) => {
    const { action, option, removedValue } = actionMeta;

    if (action === "select-option" && option?.value === selectAllOption?.value) {
      props.onChange([option], actionMeta,true);
    } else if ((action === "deselect-option" && option?.value === selectAllOption?.value) || (action === "remove-value" && removedValue?.value === selectAllOption?.value)) {
      props.onChange([], actionMeta,false);
    } else if (actionMeta?.action === "deselect-option") {
      props.onChange(props?.options?.filter(({ value }) => value !== option?.value),actionMeta,false);
    } else {
      props.onChange(newValue || [], actionMeta,false);
    }
  };

  const DropdownIndicator = (props) => {
    return (
      <components.DropdownIndicator {...props}>
        <span role="img" aria-label="search-icon">
          <i className="bi bi-search"></i>
        </span>
      </components.DropdownIndicator>
    );
  };

  const Option = (props) => {
    return (
      <div>
        <components.Option {...props}>
          {props?.isMulti &&
            <input
              type="checkbox"
              checked={props.isSelected}
              onChange={() => null}
            />        
          }
          <label>{props.label}</label>
        </components.Option>
      </div>
    );
  };

  useEffect(()=>{
    if(props?.isSearch && props?.options?.length){
      setOptions(props?.options)
    }else{
      props?.setIsSearch(false)
      setOptions([props?.isMulti ? selectAllOption : null,...props?.options]?.filter(Boolean))
    }
  },[props?.options,props?.isSearch])

  useEffect(()=>{
    setMenuIsOpen(props?.menuIsOpen)
  },[props?.menuIsOpen])

  return (
    <ReactSelect
      {...props}
      onMenuOpen={()=>{
        setMenuIsOpen(true)
      }}
      onFocus={()=>{
        setMenuIsOpen(true)
      }}
      onBlur={()=>{
        setMenuIsOpen(false)
      }}
      menuIsOpen={menuIsOpen}
      placeholder={props.placeholder || "Search..."}
      options={options}
      value={props?.value}
      onChange={onChange}
      hideSelectedOptions={false}
      closeMenuOnSelect={false}
      isMulti={props?.isMulti}
      isClearable={props.isClearable}
      className={`multiSelectDropdwn} ${props?.className}`}
      classNamePrefix="react-select"
      styles={{
        menuPortal: base => ({...base, zIndex: 9999})
      }}
      components={{ ...props?.component, DropdownIndicator, Option }}
      onInputChange={(val,action)=>{
        props?.onInputChange(val,action)
      }}
      menuPosition={"fixed"}
    />
  );
}

export default memo(MultiSelectComma)