import React, { useEffect, useState } from "react";
import MultiSelectionFormik from "../Selection/MultiSelectionFormik";
import cx from "classnames";
import { useFormikContext } from "formik";
import axios from "axios";
import SelectionFormik from "../Selection/SelectionFormik";
import { setLoader } from "../../reducer/globalReducer";
import { useDispatch } from "react-redux";

export default function PincodeDropdown({
  isView,
  ids,
  error,
  touch,
  cityLists,
  value,
}) {
  const { setFieldValue } = useFormikContext();
  const dispatch=useDispatch()
  const Menu = ({ innerProps, children }) => {
    return (
      <div {...innerProps} className="customDropDown">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            padding: "2%",
          }}
        >
          <span>Pincode</span>
          <span>Area</span>
        </div>
        <div>{children}</div>
      </div>
    );
  };
  const Option = ({ innerProps, label, data, selectOption, isFocused }) => {
    return (
      <div
        {...innerProps}
        style={{
          display: "flex",
          justifyContent: "space-between",
          padding: "2%",
        }}
        className={cx({
          howerSelection: isFocused,
        })}
        // onMouseEnter={handleMouseEnter}
        onClick={() => selectOption(data)}
      >
        <span>{data.value}</span>
        <span>{label.split(" - ")[0]}</span>
      </div>
    );
  };
  const [activePincode, setActivePincode] = useState([]);
  useEffect(() => {
    if (cityLists.length > 0) {
      let city = cityLists?.map((portfolio) => portfolio.value)?.join();
      if (city)
      dispatch(setLoader(true))
        axios.get(`/getPincodeByCity/${city}/1/10`).then(({ data }) => {
          dispatch(setLoader(false))
          let tempPincode = [];
          data.data.forEach((c) => {
            tempPincode.push({
              label: `${c.pincode} - ${c.areaName}`,
              value: c.pincodeId,
            });
          });
          setActivePincode([...tempPincode]);
        });
        dispatch(setLoader(false))
    } else {
      setFieldValue(ids, []);
      setActivePincode([]);
    }
  }, [cityLists]);
  return (
    <MultiSelectionFormik
      label={"Pincode:"}
      isView={isView}
      ids={ids}
      options={activePincode}
      // component={{ Menu, Option }}
      handleChangeEvent={(e) => {
        setFieldValue(ids, e);
      }}
      touch={touch}
      value={value}
      error={error}
      isRequired
    />
  );
}
