import React, { useEffect, useState } from "react";
import { useFormikContext } from "formik";
import { FormGroup, Label, Col } from "reactstrap";
import Select from "react-select";
import cx from "classnames";
import axios from "axios";

export default function OrganisationName({
  isView,
  activeUserType,
  setOrgName,
  isUpdate,
}) {
  const { values, errors, touched, setFieldValue, handleBlur } =
    useFormikContext();
  const [dropdownMenu, setDropdownMenu] = useState([]);
  const [label, setLabel] = useState("Organisation Name");

  // console.log("usertype", values.userType);
  let user = activeUserType
    .filter((e) => e.value === values.userType)[0]
    ?.label.toLowerCase();
  useEffect(() => {
    // let user = activeUserType
    //   .filter((e) => e.value === values.userType)[0]
    //   ?.label.toLowerCase();
    if (user) {
      // axios call according to value U101 - Truboard | LENDER | AGENCY
      if (user === "lender") {
        setLabel("Lender Name");
        axios
          .get("/getAllActiveLender")
          .then(({ data }) => {
            // console.log(data);
            let temp = [];
            data.data.forEach((e) => {
              // TODO: STatus check
              temp.push({
                ...e,
                label: e.lenderName,
                value: e.lenderId,
                branch: e.branches,
              });
            });
            setDropdownMenu([...temp]);
          })
          .catch((error) => {
            console.log(error);
          });
      } else if (user === "agency") {
        setLabel("Agency Name");
        axios
          .get("/getAllAgency")
          .then(({ data }) => {
            // console.log(data);
            let temp = [];
            data.data.forEach((e) => {
              // TODO: Status check
              temp.push({
                ...e,
                label: e.agencyName,
                value: e.agencyId.toString(),
                branch: e.agencyBranches,
              });
            });
            setDropdownMenu([...temp]);
          })
          .catch((error) => {
            console.log(error);
          });
      } else {
        setLabel("Organisation Name");
        setDropdownMenu([
          {
            label: "Turboard",
            value: "Truboard",
            branch: [{ branchName: "Truboard", branchCode: "Truboard" }],
          },
        ]);
      }
    }
  }, [user, activeUserType]);

  useEffect(() => {
    if (isUpdate || isView) {
      let tempOrg = dropdownMenu.filter(
        (e) => e.value === values.organisationName
      );
      if (tempOrg.length > 0) {
        setOrgName([...tempOrg[0]?.branch]);
      }
    }
  }, [dropdownMenu, isUpdate]);

  return (
    <FormGroup row>
      <Label sm={4} for="organisationName">
        {label}
      </Label>
      <Col sm={8}>
        <Select
          inputId="organisationName"
          placeholder="Select an Option"
          options={dropdownMenu}
          closeMenuOnSelect={true}
          hideSelectedOptions={false}
          onChange={(e) => {
            setFieldValue("organisationName", e);
            if(values?.userType !== "U101"){
              setOrgName(e?.branch);
            }
          }}
          classNamePrefix="react-select"
          value={values?.organisationName}
          className={cx({
            abc: touched.organisationName && Boolean(errors.organisationName),
          })}
          onBlur={handleBlur}
          isDisabled={isView}
          menuPosition="fixed"
        />
        {touched.organisationName && errors.organisationName && (
          <div style={{ display: "block" }} className="invalid-feedback">
            {errors.organisationName}
          </div>
        )}
      </Col>
    </FormGroup>
  );
}
