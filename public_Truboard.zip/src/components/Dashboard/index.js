
import React from "react";
import { Card, CardBody, Col, Row } from "reactstrap";

export default function Dashboard() {
  return (
    <main id="main">
      <div className="mb-3">
        <h2>Activity</h2>
        <Row>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
      <div className="mb-3">
        <h2>Lender</h2>
        <Row>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
          <Col lg={3} md={4} sm={12}>
            <Card className="m-2 card-shadow">
              <CardBody className="text-center">
                <p className="display-4 mb-0">4512</p>
                <span
                  style={{
                    color: "grey",
                  }}
                >
                  Cases Uploaded
                </span>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </main>
  );
}
