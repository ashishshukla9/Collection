import React, { useEffect, useState } from "react";
import {
  Card,
  CardTitle,
  Button,
  CardBody,
  Form,
  FormGroup,
  Input,
  Label,
  NavLink,
  FormFeedback,
} from "reactstrap";
import LOGO_HEADER from "../../assets/images/logo/logo.png";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import cx from "classnames";
import { Formik } from "formik";
import { NUMBER_ONLY } from "../../utils/regex";
import { setToken } from "../../utils/setToken";
import setUser from "../../utils/setUser";
import { Cookies } from "react-cookie";
import { useDispatch, useSelector } from "react-redux";
import { setLoader } from "../../reducer/globalReducer";
export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [isMobileLogin, setIsMobileLogin] = useState(false);
  const [otpSend, setOtpSend] = useState(false);
  const loginSessionTimeout = useSelector(
    (state) => state?.global?.loginSessionTimeout
  );
  const user = useSelector((state) => state.user.data);
  const cookies = new Cookies();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const handleSubmit = async (values) => {
    try {
      const payload = {
        principal:
          isMobileLogin && otpSend ? values?.mobileNumber : values?.uid,
        credentials: values?.password,
      };
      const params = {
        type: isMobileLogin && otpSend ? "mobile" : "uid",
      };
      dispatch(setLoader(true));
      const res = await axios.post(
        `${process.env.REACT_APP_BASE_URL}/web/token`,
        // `http://192.168.1.100:8081/CollectionBE/v1/collections/web/token`,
        payload,
        { params }
      );
      dispatch(setLoader(false));
      if (res?.data?.messageKey) {
        const cookiesExpireTime = 60 * (loginSessionTimeout || 3);
        let showLogoutMessageTiming = new Date();
        showLogoutMessageTiming = showLogoutMessageTiming.setSeconds(
          showLogoutMessageTiming.getSeconds() + (cookiesExpireTime - 30)
        );
        // console.log(res.data.user, "finalizeuserdata");
        cookies.set("user", JSON.stringify(res.data.user));
        cookies.set("token", res?.data?.token, { maxAge: cookiesExpireTime });
        cookies.set("logout", showLogoutMessageTiming, {
          maxAge: cookiesExpireTime,
        });
        setToken(res?.data?.token);
        setUser(res.data.user?.name);
        // console.log(user, "cookiesUser");

        setTimeout(() => {
          navigate("/dashboard");
        }, 1000);
      } else {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: res?.data?.response,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      dispatch(setLoader(false));
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `${error?.message}`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  const onClickGetOTP = async (values) => {
    try {
      dispatch(setLoader(true));
      const res = await axios.post(`/sendLoginOtp/${values?.mobileNumber}`);
      dispatch(setLoader(false));
      if (res?.data?.msgKey === "Failure") {
        Swal.fire({
          position: "top-end",
          icon: "error",
          title: res?.data?.message,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      } else {
        dispatch(setLoader(false));
        setOtpSend(true);

        Swal.fire({
          position: "top-end",
          icon: "success",
          title: res?.data?.message,
          showConfirmButton: false,
          toast: true,
          timer: 3000,
        });
      }
    } catch (error) {
      Swal.fire({
        position: "top-end",
        icon: "error",
        title: `Bad Credentials`,
        showConfirmButton: false,
        toast: true,
        timer: 3000,
      });
    }
  };
  useEffect(() => {
    if (cookies.get("token")) {
      setTimeout(() => {
        navigate("/dashboard");
      }, 5000);
    }
  }, []);
  return (
    <div className="App">
      <header className="App-header">
        <div className="">
          <Card
            style={{ boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)" }}
            className="loginCard"
          >
            <CardTitle tag="h5" className="text-center">
              {/* <img
                width={"50%"}
                src={LOGO_HEADER}
                alt="Logo"
                className="mt-3"
              ></img> */}
            </CardTitle>
            <CardBody>
              <Formik
                initialValues={{
                  uid: "",
                  mobileNumber: "",
                  password: "",
                }}
                onSubmit={handleSubmit}
              >
                {({
                  values,
                  errors,
                  handleChange,
                  handleBlur,
                  setFieldValue,
                  handleSubmit,
                }) => {
                  return (
                    <Form
                      onSubmit={handleSubmit}
                      className="loginFormContainer"
                    >
                      {isMobileLogin ? (
                        <FormGroup floating>
                          <Input
                            id="mobileNumber"
                            name="mobileNumber"
                            placeholder="Mobile Number"
                            type="text"
                            autoComplete="off"
                            value={values?.mobileNumber}
                            onChange={(e) => {
                              if (
                                NUMBER_ONLY.test(e?.target?.value) ||
                                !e?.target?.value
                              ) {
                                setFieldValue("mobileNumber", e?.target?.value);
                              }
                            }}
                            onBlur={handleBlur}
                            invalid={errors?.mobileNumber && true}
                            maxLength={10}
                            minLength={10}
                          />
                          <Label for="mobileNumber">Mobile Number</Label>
                          <FormFeedback>{errors?.mobileNumber}</FormFeedback>
                        </FormGroup>
                      ) : (
                        <FormGroup floating>
                          <Input
                            id="uid"
                            name="uid"
                            placeholder="UID"
                            type="text"
                            autoComplete="off"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            invalid={errors?.uid && true}
                          />
                          <Label for="uid">UID</Label>
                          <FormFeedback>{errors?.uid}</FormFeedback>
                        </FormGroup>
                      )}
                      {!isMobileLogin && (
                        <FormGroup className="rmb-0" floating>
                          <Input
                            id="password"
                            name="password"
                            placeholder="password"
                            type={showPassword ? "text" : "password"}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            className="password"
                            invalid={errors?.password && true}
                          />
                          <Label for="password">Password</Label>
                          <FormFeedback>{errors?.password}</FormFeedback>
                          <i
                            className={cx({
                              bi: true,
                              "bi-eye-fill": showPassword,
                              "bi-eye-slash-fill": !showPassword,
                            })}
                            onClick={() => setShowPassword(!showPassword)}
                          ></i>
                        </FormGroup>
                      )}
                      {otpSend && (
                        <FormGroup className="rmb-0" floating>
                          <Input
                            id="otp"
                            name="password"
                            placeholder="otp"
                            onChange={(e) => {
                              if (
                                NUMBER_ONLY.test(e?.target?.value) ||
                                !e?.target?.value
                              ) {
                                setFieldValue("password", e?.target?.value);
                              }
                            }}
                            onBlur={handleBlur}
                            invalid={errors?.password && true}
                            minLength={4}
                            maxLength={4}
                          />
                          <Label for="otp">OTP</Label>
                          <FormFeedback>{errors?.password}</FormFeedback>
                        </FormGroup>
                      )}
                      <div className="d-flex justify-content-center mb-2">
                        {isMobileLogin ? (
                          <NavLink
                            style={{ cursor: "pointer" }}
                            onClick={() => {
                              setIsMobileLogin(!isMobileLogin);
                            }}
                            className="text-primary"
                          >
                            Login with User Name
                          </NavLink>
                        ) : (
                          <NavLink
                            style={{ cursor: "pointer" }}
                            onClick={() => {
                              setIsMobileLogin(!isMobileLogin);
                            }}
                            className="text-primary"
                          >
                            Login with OTP
                          </NavLink>
                        )}
                      </div>
                      {(!isMobileLogin || otpSend) && (
                        <Button type="submit" size="sm" color="primary">
                          Login
                        </Button>
                      )}
                      {isMobileLogin && !otpSend && (
                        <Button
                          type="button"
                          size="sm"
                          color="primary"
                          onClick={() => onClickGetOTP(values)}
                        >
                          Get OTP
                        </Button>
                      )}
                      <div className="d-flex justify-content-center mt-3 gap-3">
                        <Link to={"reset_password"}>Forget Password?</Link>
                      </div>
                    </Form>
                  );
                }}
              </Formik>
            </CardBody>
          </Card>
          <div
            className="mt-3 card text-center loginCard py-3"
            style={{ boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)" }}
          >
            <h6 className="text-black">
              <p>&copy; TruBoard Servicing Private Limited</p>
            </h6>
          </div>
        </div>
      </header>
    </div>
  );
}