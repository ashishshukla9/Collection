import React, { useEffect, Suspense, useState, useRef } from "react";
import Sidenav from "./Sidenav";
import AppHeader from "./Header";
import { Outlet, useNavigate } from "react-router-dom";
import { ProgressSpinner } from "primereact/progressspinner";
import { Cookies } from "react-cookie";
import { useSelector } from "react-redux";
import axios from "axios";

export default function HOC(props) {
  const [showLogout, setShowLogout] = useState(false)
  const [expireTime, setExpireTime] = useState(30)
  const [activity, setActivity] = useState(0)

  const action = useSelector(state => state?.global?.action)
  const loader = useSelector(state => state?.global?.loader)
  const navigate = useNavigate();
  const cookies = new Cookies()

  const ref = useRef()

  const loginSessionTimeout = useSelector((state) => state?.global?.loginSessionTimeout)
  const user = useSelector((state) => state.user.data);


  // logout time extend here 
  const extendTime = (e) => {
    setShowLogout(false)
    setActivity(prev => prev + 1)

    const getToken = cookies.get('token')
    cookies.remove('token')
    const cookiesExpireTime = 60 * (loginSessionTimeout || 3)
    let showLogoutMessageTiming = new Date()
    showLogoutMessageTiming = showLogoutMessageTiming.setSeconds(showLogoutMessageTiming.getSeconds() + (cookiesExpireTime - 30))
    cookies.set('token', getToken, { maxAge: cookiesExpireTime })
    cookies.remove('logout')
    cookies.set('logout', showLogoutMessageTiming, { maxAge: cookiesExpireTime })
  }

  useEffect(() => {
    const token = cookies.get('token')
    if (!token || token === 'null' || token === 'undefined' || token === null || token === undefined) {
      cookies.remove('user')
      cookies.remove('token')
      cookies.remove('logout')
      navigate("/");
    }
  }, []);

  useEffect(() => {
    const getLogoutTime = cookies.get("logout")
    let test = null
    if (getLogoutTime && !showLogout) {
      test = setInterval(() => {
        const currentTimeValue = new Date().valueOf()
        if (getLogoutTime <= currentTimeValue) {
          setShowLogout(true)
          clearInterval(test)
        } else if (showLogout) {
          clearInterval(test)
        }
      }, 2000)
    }
    return (() => {
      clearInterval(test)
    })
  }, [showLogout, activity, action])

  // logout automatic
  useEffect(() => {
    let time = 30
    const token = cookies.get('token')
    const test = setInterval(() => {
      // && loader===false this codition added by me 
      if (showLogout && loader === false) {
        if (time === 0) {
          clearInterval(test)
          setTimeout(async () => {
            const payload = {
              userid: user?.userId,
              token: token,
              reason: 'Session Logout'
            }
            const res = await axios.put('/logOutUser', payload)
            navigate('/')
          }, 1000)
        } else if (time >= 0) {
          time -= 1
          setExpireTime(time)
        }
      } else {
        clearInterval(test)
      }
    }, 1000)

    if (!showLogout) {
      clearInterval(test)
    }

    return (() => {
      clearInterval(test)
    })
  }, [showLogout])

  useEffect(() => {
    window.addEventListener('click', extendTime)
    // window.addEventListener('keypress',extendTime)

    return () => {
      window.removeEventListener('click', extendTime)
      // window.removeEventListener('keypress',extendTime)
    }
  }, [])

  return (
    <div ref={ref} className={`${loader ? 'loading' : ''}`}>
      <Sidenav />
      <div className="wrapper d-flex flex-column min-vh-100 bg-light">
        {showLogout && <p>Your session will expire in {expireTime} seconds. <span className="clickHere" onClick={extendTime}>click here</span> to keep logged in</p>}
        <AppHeader />
        <Suspense
          fallback={
            <div className="d-flex justify-content-center">
              <ProgressSpinner />
            </div>
          }
        >

          <div className="body flex-grow-1 px-1 d-flex flex-column">
            <Outlet />
          </div>
        </Suspense>
        {/* <AppFooter /> */}
      </div>
    </div>
  );
}
