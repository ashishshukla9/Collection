import { Fragment, memo, useEffect, useState } from "react"
import { Button, ButtonGroup, Table } from "reactstrap";
import { DownloadFile } from "../../utils/DownloadFile";
import 'primeicons/primeicons.css';
import { RxCross1 } from "react-icons/rx";

const FileTable = (props) => {
    const [documentData, setDocumentData] = useState([])
    // console.log(props?.docData, "blbblbb")

    // console.log(documentData, "documentDatadocumentData")

    const handleRemove = (document) => {
        // console.log(document, "documenty");

        const removedoc = documentData?.filter((item) => {
            return item.uniquercudoc !== document.uniquercudoc ||
                item.uniquekycdoc !== document.uniquekycdoc ||
                (item?.aggducuniue !== document?.aggducuniue);
        });

        // console.log(removedoc, "removedoc")
        if (document?.aggducuniue) {
            props?.setAggDocument(removedoc)
            setDocumentData(removedoc);
        }

        if (document.uniquercudoc) {
            props?.setRcaDocument(removedoc)
            setDocumentData(removedoc);
        }

        if (document.uniquekycdoc) {
            props?.setKycDocument(removedoc)
            setDocumentData(removedoc);

        }

    };
    useEffect(() => {
        setDocumentData(props?.docData)
    }, [props?.docData])
    return (
        <Fragment>
            <Button
                color="success"
                className="text-white"
                onClick={props?.onBtnClick}
                disabled={props?.isView}
                size="sm"
            >
                {props?.btnName}
            </Button>

            <Table className="text-center">
                <thead>
                    <tr>
                        <th>Sr No</th>
                        <th>Filename</th>

                        <th>Document Type</th>
                        <th>Action</th>
                        <th>Uploaded At</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {documentData?.map((document, index) => {
                        return (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td className="text-start">{document?.name}</td>
                                <td className="text-start">{document?.fileType}</td>
                                <td>
                                    {document?.[props?.id] &&
                                        <ButtonGroup style={{ width: '100%' }}>
                                            <Button
                                                color="success"
                                                outline
                                                onClick={() =>
                                                    DownloadFile(
                                                        `${props?.downloadURL}/${document?.[props?.id]}`,
                                                        document?.name
                                                    )
                                                }
                                                size="sm"
                                                style={{ width: 'calc(100% - 200px)' }}
                                                type="button"
                                            >
                                                <i className="bi bi-download me-3"></i>
                                                Download - {document?.name}
                                            </Button>
                                            {/* {props?.isView || (
                                                <Button
                                                    color="primary"
                                                    outline
                                                    onClick={() => props?.onEditClick(document?.[props?.id], index)}
                                                    size="sm"
                                                    type="button"
                                                >
                                                    <i className="bi bi-pencil-square"></i>
                                                    Edit
                                                </Button>
                                            )} */}
                                        </ButtonGroup>
                                    }
                                </td>
                                <td>{document?.lastModifiedTime?.split("T")[0]}</td>
                                <td style={{ cursor: "pointer" }}>
                                    {

                                        document?.[props?.id] ? "" : (<>
                                            <div color="Danger" size="sm" onClick={() => { handleRemove(document) }}> X</div>
                                        </>)
                                    }

                                </td>
                            </tr>
                        )
                    })}
                </tbody>
            </Table>
        </Fragment>
    )
}

export default memo(FileTable)