import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
    loader: false,
    passwordValidations: {},
    loginSessionTimeout: 0,
    action: 0,
    latLong: '',
    reload:false,
}

export const getPasswordValidation = createAsyncThunk(
    "cases/getPasswordValidation",
    async () => {
        try {
            const res = await axios.get("/getPasswordValidations")
        } catch (error) {

        }
    }
);

export const getSessionTimeout = createAsyncThunk(
    "cases/getSessionTimeout",
    async () => {
        try {
            const res = await axios.get("/GetTimeout")
            return{
                loginSessionTimeout: res?.data?.data || 3
            }
        } catch (error) {
            console.log(error);
        }
    }
)

const globalSlice = createSlice({
    name: 'global',
    initialState,
    reducers: {
        setLoader: (state, action) => {
            state.loader = action.payload
        },
        setAction: (state, action) => {
            state.action = state.action + action.payload
        },
        setLetLong: (state, action)=>{
            state.latLong = action.payload
        }, 
        setReload: (state, action)=>{
            state.reload=action.payload
        }
    },
    extraReducers: (builder) => {
        builder.addCase(getPasswordValidation.fulfilled, (state, action) => {

        })
        builder.addCase(getSessionTimeout.fulfilled, (state, action) => {
            state.loginSessionTimeout= action?.payload?.loginSessionTimeout
        })
    }
})

export const { setLoader, setAction, setLetLong, setReload } = globalSlice.actions;
export default globalSlice.reducer;