const initialState = [];

export const exceptionReducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case "GET_ALL_RAISED_EXCEPTION":
      return [...payload];
    case "ADD_RAISED_EXCEPTION":
      return [...state, payload];
    case "UPDATE_RAISED_EXCEPTION":
      let newState = [];
      let updateIndex = state.indexOf(
        (e) => e.raiseExceptionId === payload.raiseExceptionId
      );
      state.splice(updateIndex, 1);
      newState = [payload, ...state];
      return [...newState];
    default:
      return state;
  }
};
