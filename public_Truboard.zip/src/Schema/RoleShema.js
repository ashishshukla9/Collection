import * as yup from "yup";

export const RoleShema = {
  profileName: "",
  roleCode: "",
  roleName: "",
  isActive: "Y",
  access: {
    administrator_all: null,
    administrator_role: null,
    administrator_profile: null,
    administrator_user: null,
    administrator_lender: null,
    administrator_agency: null,
    administrator_geographymaster: null,
    administrator_bankbranchmaster: null,
    administrator_portfoliomaster: null,
    administrator_productmaster: null,
    administrator_lookupmaster: null,

    customerprofile_all: null,
    customerprofile_applicationdetails: null,
    customerprofile_loanhistory: null,
    customerprofile_collateraldetails: null,

    caseactivity_all: null,
    caseactivity_paymentinfo: null,
    caseactivity_ptp: null,
    caseactivity_payment: null,
    caseactivity_disputertp: null,
    caseactivity_raiseexception: null,
    caseactivity_request: null,
    caseactivity_contactcentre: null,
    caseactivity_statcard: null,

    campaignmanagement_all: null,
    campaignmanagement_campaignmanagement: null,

    requestmanagement_all: null,
    requestmanagement_requestmanagement: null,

    reports_all: null,
    reports_reports: null,

    incentivespayouts_all: null,
    incentivespayouts_incentivespayouts: null,

    reconciliation_all: null,
    reconciliation_reconciliation: null,

    bulkdealocation_all: null,
    bulkdealocation_bulkdealocation: null,

    offlineagencyfeedbackupload_offlineagencyfeedbackupload: null,
    offlineagencyfeedbackupload_all: null
  },
};

export const validationSchema = yup.object({
  // roles
  profile: yup.array().required('Required').min(1, "Required"),
  roleCode: yup
    .string()
    .min(1, "Too Short!")
    .max(4, "Too Long!")
    .required("Required"),
  roleName: yup.string().required("Required"),
});
