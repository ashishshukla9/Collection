import axios from "axios";
import * as yup from "yup";

export const Lender = {
  // lenderId: "",
  lenderName: "",
  shortName: "",
  startDate: "",
  endDate: "",
  maskingMobileNo: "",
  status: "Y",
  shareWelcomeLetter: "Y",
  aggrementScanning: [],
  ruc:'',
  branches: [
    {
      branchCode: "",
      branchName: "",
      address: "",
      bankAccountNo: "",
      bankIfscCode: "",
      upiDetails: "",
      emailId: [""],
      contactNo: [""],
      pincodeId: "",
      pincode: '',
      city: "",
      cityName:'',
      state: "",
      stateName:'',
      isVerified: "N",
    },
  ],
};

export const lenderValidation = yup.object({
  lenderName: yup
    .string()
    .min(1, "Too Short!")
    .max(65, "Too Long!")
    .required("Required"),

  shortName: yup
    .string()
    .min(2, "Too Short!")
    .max(30, "Too Long!")
    .required("Required"),

  startDate: yup.string().required("Required"),
  endDate: yup.string().required("Required"),
  aggrementScanning: yup.mixed().required("Required"),
  maskingMobileNo: yup
    .string()
    .required("Required")
    .test("valueCheck", "Invalid Value", function (value) {
      if (
        value !== "" &&
        !isNaN(value) &&
        (Number(value) > 10 || Number(value) < 0)
      ) {
        return false;
      }
      return true;
    }),

  branches: yup.array().of(
    yup.object().shape({
      branchCode: yup.string().max(8, "Too Long!").required("Required"),
      branchName: yup.string().max(25, "Too Long!").required("Required"),

      address: yup.string().max(80, "Too Long!").required("Required"),

      bankAccountNo: yup
        .string()
        .max(20, "Invalid Account ! ")
        .required("Required"),

      pincode: yup.string().required("Required"),
      city: yup.string().required("Required"),
      state: yup.string().required("Required"),

      bankIfscCode: yup
        .string()
        .min(11, "Invalid IFSC !")
        .max(11, "Invalid IFSC ! ")
        .required("Required"),
      upiDetails: yup.string().max(25, "Too Long!"),
      emailId: yup
        .array()
        .of(yup.string().email("Invalid Email").required("Required")),
      contactNo: yup
        .array()
        .of(
          yup
            .string()
            .min(10, "Invalid Mobile!")
            .max(10, "Invalid Mobile!")
            .required("Required")
        )
      // isVerified: yup
      //   .string()
      //   .test("verifyUPI", "Invalid!", async function (value) {
      //     let UPI = this.parent.upiDetails?.trim();
      //     let name = this.parent.lenderName;
      //     console.log(value, UPI, Date());
      //     try {
      //       if (value === "P" && UPI !== "") {
      //         console.log("calling........");
      //         // let response = await axios.post("/verify-Upi", {
      //         //   consent: "Y",
      //         //   vpa: UPI,
      //         //   name,
      //         // });
      //         // let response;
      //         // console.log(response);
      //         // if (response.data.msgKey === "Success") {
      //         //   return true;
      //         // } else {
      //         //   return false;
      //         // }
      //         if (UPI === "qqqq") {
      //           return false;
      //         }
      //       }
      //       return true;
      //     } catch (error) {
      //       console.log(error, "sssseeee");
      //       return false;
      //     }
      //   }),
    })
  ),
});
