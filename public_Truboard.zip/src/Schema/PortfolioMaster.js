import * as yup from "yup";

export const PortfolioMasterSchema = {
  active: "Y",
  portfolioCode: "",
  portfolioDescription: "",
  portfolioCurrency: "",
};

export const portfolioMasterValidation = yup.object({
  portfolioCode: yup.string().max(8, "Too Long").required("Required"),
  portfolioDescription: yup.string().max(25, "Too Long!").required("Required"),
  portfolioCurrency: yup.string().max(5, "Too Long!").required("Required"),
});
