import * as yup from "yup";
export const gridTypeSchema = {
  gridDescription: "",
  gridType: "",
};
export const validationSchema = yup.object({
    gridDescription: yup.string().max(8, "Too Long!").required("Required"),
    gridType: yup.string().max(30, "Too Long!").required("Required"),
});
