import * as yup from "yup";

export const userTypeSchema = {
  code: "",
  description: "",
  isActive: "Y",
};

export const validationSchema = yup.object({
  code: yup.string().max(4, "Too Long!").required("Required"),
  description: yup.string().max(8, "Too Long!").required("Required"),
});
