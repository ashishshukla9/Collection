import * as yup from "yup";

export const natureOfServiceSchema = {
  code: "",
  description: "",
  isActive: "Y",
};

export const validationSchema = yup.object({
  code: yup.string().max(4, "Too Long!").required("Required"),
  description: yup.string().max(15, "Too Long!").required("Required"),
});