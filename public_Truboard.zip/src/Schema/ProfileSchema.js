import * as yup from "yup";

export const ProfileSchema = {
  fieldCode: "",
  profileName: "",
  userType: "",
  isActive: "Y",
};

export const validationSchema = yup.object({
  fieldCode: yup.string().max(4, "Too Long!").required("Required"),

  profileName: yup.string().max(35, "Too Long!").required("Required"),

  userType: yup.string().required("Required"),
});
