import * as yup from "yup";

export const bankMasterSchema = {
  bankCode: "",
  isActive: "Y",
  bankName:""
};

export const bankValidationSchema = yup.object({
  bankCode: yup.string().max(8, "Too Long!").required("Required"),
  bankName: yup.string().max(50, "Too Long!").required("Required"),
});
