import * as yup from "yup";

export const agencySchema = {
  agencyName: "",
  shortName: "",
  agencyType: "",

  agencyAddress: "",
  // pincode: "",
  pincode: [],
  city: "",
  state: "",
  natureOfService: [],

  contactPersonName: "",
  contactEmailId: "",
  contactMobileNo: "",

  usingSystemDialer: "Y",
  expiryNotification: "Y",
  startDate: "",
  endDate: "",

  aggrementScanning: "",
  ruc: "",

  agencyBranches: [{ branchCode: "", branchName: "" }],

  agencyOwnerDetails: [
    {
      ownerPersonName: "",
      ownerEmailId: "",
      ownerMobileNumber: "",
      city: "",
      state: "",
    },
  ],

  agencySpocDetails: [
    {
      spocPersonName: "",
      spocEmailId: "",
      spocMobileNo: "",
      city: "",
      state: "",
    },
  ],

  kycs: [
    {
      KYC: "",
    },
  ],

  managedBy: "",
  userMapping: "",
  status: "Y",
};

export const validationSchema = yup.object({
  agencyName: yup.string().max(65, "Too Long!").required("Required"),
  shortName: yup.string().max(65, "Too Long!").required("Required"),
  agencyType: yup.string().required("Required"),

  agencyAddress: yup.string().max(65, "Too Long!").required("Required"),
  pincode: yup.array().test("Required", (value) => {
    return value.length > 0;
  }),

  natureOfService: yup.array().test("customRoleTest", "Required", (value) => {
    return value.length > 0;
  }),

  startDate: yup.string().required("Required"),
  endDate: yup.string().required("Required"),

  agencyBranches: yup.array().of(
    yup.object().shape({
      branchCode: yup.string().max(8, "Too Long!").required("Required"),
      branchName: yup.string().max(25, "Too Long!").required("Required"),
    })
  ),

  contactMobileNo: yup
    .string()
    .matches(/^\d{10}$/, "Phone number must be 10 digits"),
  contactEmailId: yup.string().email("Invalid Email ID"),

  agencyOwnerDetails: yup.array().of(
    yup.object().shape({
      ownerPersonName: yup.string().max(65, "Too Long!").required("Required"),
      ownerEmailId: yup
        .string()
        .email("Invalid email")
        .max(65, "Too Long!")
        .required("Required"),
      ownerMobileNumber: yup
        .string()
        .matches(/^\d{10}$/, "Phone number must be 10 digits")
        .required("Required"),
      city: yup.string().required("Required"),
    })
  ),

  agencySpocDetails: yup.array().of(
    yup.object().shape({
      spocPersonName: yup.string().max(65, "Too Long!").required("Required"),
      spocEmailId: yup
        .string()
        .email("Invalid email")
        .max(65, "Too Long!")
        .required("Required"),
      spocMobileNo: yup
        .string()
        .matches(/^\d{10}$/, "Phone number must be 10 digits")
        .required("Required"),
      city: yup.string().required("Required"),
    })
  ),
  aggrementScanning: yup.mixed().required("Document Required"),
  ruc: yup.mixed().required("Document Required"),

  managedBy: yup.string().max(15, "Too Long!").required("Required"),
  kycs: yup.array().of(
    yup.object().shape({
      KYC: yup.string().required("Document Required"),
    })
  ),
});

export const updateValidationSchema = yup.object({
  agencyName: yup.string().max(65, "Too Long!").required("Required"),
  shortName: yup.string().max(65, "Too Long!").required("Required"),
  agencyType: yup.string().required("Required"),

  agencyAddress: yup.string().max(65, "Too Long!").required("Required"),
  // pincode: yup.string().required("Required"),
  pincode: yup.array().test("Required", (value) => {
    return value.length > 0;
  }),

  natureOfService: yup.array().test("customRoleTest", "Required", (value) => {
    return value.length > 0;
  }),

  startDate: yup.string().required("Required"),
  endDate: yup.string().required("Required"),
  //new 9-8-2023
  // endDate: yup.string().test("customRoleTest", "Required", (value) => {
  //   return value.startDate < value.endDate;
  // }),

  agencyBranches: yup.array().of(
    yup.object().shape({
      branchCode: yup.string().max(8, "Too Long!").required("Required"),
      branchName: yup.string().max(25, "Too Long!").required("Required"),
    })
  ),

  agencyOwnerDetails: yup.array().of(
    yup.object().shape({
      ownerPersonName: yup.string().max(65, "Too Long!").required("Required"),
      ownerEmailId: yup
        .string()
        .email("Invalid email")
        .max(65, "Too Long!")
        .required("Required"),
      ownerMobileNumber: yup
        .string()
        .matches(/^\d{10}$/, "Phone number must be 10 digits")
        .required("Required"),
      city: yup.string().required("Required"),
    })
  ),

  agencySpocDetails: yup.array().of(
    yup.object().shape({
      spocPersonName: yup.string().max(65, "Too Long!").required("Required"),
      spocEmailId: yup
        .string()
        .email("Invalid email")
        .max(65, "Too Long!")
        .required("Required"),
      spocMobileNo: yup
        .string()
        .matches(/^\d{10}$/, "Phone number must be 10 digits")
        .required("Required"),
      city: yup.string().required("Required"),
    })
  ),

  managedBy: yup.string().max(15, "Too Long!").required("Required"),
});
