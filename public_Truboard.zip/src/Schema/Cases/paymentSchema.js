import * as yup from "yup";

export const paymentSchema = {
  totalOverdueAmount: "",
  pendingEmiAmount: "",
  charges: "",
  settlementAmount: "",
  ptpMode: null,
  amount: "",
  sub_type: ["Other charge", "DCP/LPP", "Cheque Bounce"],
  emiAmount: "",
  remark: "",
  ptpType: "",
  paymentStatus: "Pending",
  paymentMode: "CASH",
  digitalPaymentMode: "",
  paymentType: "Foreclosure",
  paymentMeasure: "Full",
  referenceNumber: "",
  chequeNumber: "",
  phoneNumber: "",
  status: "status1",
};

export const validationSchema = yup.object({
  // ptpType: yup.string().required("Please select a PTP Type"),
  // amount: yup.number().required("Please enter an amount"),
  // sub_type: yup
  //   .mixed()
  //   .test("custom", "Please select Sub Type", function (value) {
  //     if (this.parent.ptpType === "Charges" && value.length <= 0) {
  //       return false;
  //     }
  //     return true;
  //   }),
  sub_type: yup.array().when("paymentType", {
    is: (e) => e === "Charges",
    then: (schema) =>
      schema.test("customLengthCheck", "Required", function (value) {
        if (value.length <= 0) {
          return false;
        }
        return true;
      }),
  }),
  chequeNumber: yup.string().when("paymentMode", {
    is: (e) => e === "CHEQUE",
    then: (schema) => schema.required("Required"),
  }),
  referenceNumber: yup.string().when("paymentMode", {
    is: (e) => e === "DIGITAL",
    then: (schema) => schema.required("Required"),
  }),
  phoneNumber: yup.string().required("Required"),
  remark: yup.string().required("Please enter a remark"),
});
