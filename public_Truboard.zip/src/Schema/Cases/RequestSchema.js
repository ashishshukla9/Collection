import * as yup from "yup";

export const requestSchema = {
  request: "",
  remark: "",
  evidance: "",
  addressType: "",
  new: "",
  old: "",
};

export const requestValidationSchema = yup.object({
  request: yup.string().required("Required"),
  remark: yup.string().max(250, "Too Long.").required("Required"),
  evidance: yup.mixed().required("Required"),
});

export const updateRequestValidationSchema = yup.object({
  request: yup.string().required("Required"),
  remark: yup.string().max(250, "Too Long.").required("Required"),
});
