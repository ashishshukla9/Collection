import * as yup from "yup";

export const pendingPTPSchema = {
  totalOverdueAmount: "",
  pendingEmiAmount: "",
  charges: "",
  settlementAmount: "",
  emiAmount: "",

  remark: "",
  ptpType: "Foreclosure",
  ptpMode: "Full",
  sub_type: ["Other charge", "DCP/LPP", "Cheque Bounce"],
  ptpDate: "",
  ptpTime: "",
  followUpDate: "",
  ptpAmount: "",
  loanAccountNumber: "",
};

export const validationSchema = yup.object({
  ptpDate: yup.date().required("Required"),
  followUpDate: yup.date().required("Required"),
  ptpTime: yup.string().required("Required"),
  ptpAmount: yup.number().required("Required"),
  sub_type: yup.array().when("ptpType", {
    is: (e) => e === "Charges",
    then: (schema) =>
      schema.test("customLengthCheck", "Required", function (value) {
        if (value.length <= 0) {
          return false;
        }
        return true;
      }),
  }),
  remark: yup.string().required("Please enter a remark"),
});
